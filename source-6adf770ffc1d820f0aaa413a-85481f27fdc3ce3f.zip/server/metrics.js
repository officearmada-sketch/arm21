'use strict';
// Metrik gaya Prometheus (teks), tanpa dependensi.
function createMetrics() {
  const counters = new Map();
  const hist = new Map();
  const BUCKETS = [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10];
  const gauges = new Map();
  const key = (name, labels) => name + (labels ? '{' + Object.entries(labels).map(([k, v]) => `${k}="${String(v).replace(/["\\\n]/g, '_')}"`).join(',') + '}' : '');
  return {
    inc(name, labels, n = 1) { const k = key(name, labels); if (!counters.has(k) && counters.size >= 2000) return; counters.set(k, (counters.get(k) || 0) + n); },
    observe(name, labels, seconds) {
      const k = key(name, labels);
      let h = hist.get(k);
      if (!h && hist.size >= 500) return;
      if (!h) { h = { name, labels, buckets: BUCKETS.map(() => 0), sum: 0, count: 0 }; hist.set(k, h); }
      BUCKETS.forEach((b, i) => { if (seconds <= b) h.buckets[i]++; });
      h.sum += seconds; h.count++;
    },
    gauge(name, fn) { gauges.set(name, fn); },
    render() {
      const out = [];
      for (const [k, v] of counters) out.push(`${k} ${v}`);
      for (const h of hist.values()) {
        const base = h.labels ? Object.entries(h.labels).map(([k, v]) => `${k}="${v}"`).join(',') + ',' : '';
        BUCKETS.forEach((b, i) => out.push(`${h.name}_bucket{${base}le="${b}"} ${h.buckets[i]}`));
        out.push(`${h.name}_bucket{${base}le="+Inf"} ${h.count}`, `${h.name}_sum${h.labels ? '{' + base.slice(0, -1) + '}' : ''} ${h.sum}`, `${h.name}_count${h.labels ? '{' + base.slice(0, -1) + '}' : ''} ${h.count}`);
      }
      for (const [n, fn] of gauges) { try { out.push(`${n} ${fn()}`); } catch { /* lewati */ } }
      out.push(`process_uptime_seconds ${Math.round(process.uptime())}`, `process_resident_memory_bytes ${process.memoryUsage().rss}`);
      return out.join('\n') + '\n';
    },
  };
}
module.exports = { createMetrics };
