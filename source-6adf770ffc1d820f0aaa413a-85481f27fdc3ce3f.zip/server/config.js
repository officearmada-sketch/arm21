'use strict';
// Konfigurasi dibaca sekali dari environment dan divalidasi saat start. Salah konfigurasi = server menolak jalan.
const path = require('node:path');

const bool = (v, d) => (v === undefined || v === '' ? d : /^(1|true|yes|on)$/i.test(String(v)));
const int = (v, d, min, max) => {
  if (v === undefined || v === '') return d;
  const n = Number(v);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`Konfigurasi tidak valid: "${v}" (harus bilangan bulat ${min}..${max})`);
  return n;
};

function load(env = process.env) {
  const prod = env.NODE_ENV === 'production';
  const dataDir = path.resolve(env.DATA_DIR || path.join(__dirname, '..', 'data'));
  const c = {
    prod,
    host: env.HOST || '0.0.0.0',
    port: int(env.PORT, 3000, 0, 65535),
    dataDir,
    dbFile: path.join(dataDir, 'armada.db'),
    publicDir: path.resolve(env.PUBLIC_DIR || path.join(__dirname, '..', 'public')),
    privateDir: path.resolve(env.PRIVATE_DIR || path.join(__dirname, '..', 'private')),
    trustProxy: bool(env.TRUST_PROXY, prod),
    cookieSecure: bool(env.COOKIE_SECURE, prod),
    cookieName: bool(env.COOKIE_SECURE, prod) ? '__Host-armada' : 'armada',
    sessionIdleMin: int(env.SESSION_IDLE_MINUTES, 240, 5, 7 * 24 * 60),
    sessionMaxHours: int(env.SESSION_MAX_HOURS, 12, 1, 24 * 30),
    loginMaxFails: int(env.LOGIN_MAX_FAILS, 5, 3, 50),
    loginLockMin: int(env.LOGIN_LOCK_MINUTES, 15, 1, 24 * 60),
    ipLoginLimit: int(env.IP_LOGIN_LIMIT, 30, 5, 10000), // percobaan login per IP per 10 menit
    bodyLimit: int(env.BODY_LIMIT_BYTES, 9 * 1024 * 1024, 1024, 64 * 1024 * 1024),
    metricsToken: env.METRICS_TOKEN || '',
    logLevel: env.LOG_LEVEL || 'info',
    dataKey: env.DATA_KEY || '',
    identityUrl: env.NETLIFY_IDENTITY_URL || '',
    google: {
      saFile: env.GOOGLE_SA_FILE || '',
      saJson: env.GOOGLE_SA_JSON || '',
      apiBase: (env.SHEETS_API_BASE || 'https://sheets.googleapis.com').replace(/\/$/, ''),
      tokenUrl: env.GOOGLE_TOKEN_URL || 'https://oauth2.googleapis.com/token',
      accId: env.SHEETS_ACC_ID || '1uwenWPo9NR9rkTfZpHuJaXQFEGnspVjg0Ty6K4xpSDI',
      formId: env.SHEETS_FORM_ID || '1V18f6If7Emm_bgpfuMUnLiJDCzA-4w1bAnM7D5EhJjw',
      sppdId: env.SHEETS_SPPD_ID || '19BQ1RVmu04zoehzE_SNJYuurRAH9hgysJU2z_370Q5M',
      empId: env.SHEETS_EMP_ID || '1h5jyC0dui20lPWCQLaKguzMuVvcHtjjIVPMkd4jrzNA',
      logId: env.SHEETS_LOG_ID || '1d39r0zquQEgUA45ZxEbXx0uFjAmobUW4Qkimzb7qaBY',
      returnFolderId: env.DRIVE_RETURN_FOLDER_ID || '1ogPsvCHhhVcY17J2bfwdISmThzg9J3VH',
      driveApiBase: (env.DRIVE_API_BASE || 'https://www.googleapis.com').replace(/\/$/, ''),
      cacheTtlMs: int(env.SHEETS_CACHE_TTL_MS, 10000, 0, 600000),
      areaRefreshMs: int(env.SHEETS_AREA_REFRESH_MS, 300000, 1000, 86400000),
      timeoutMs: int(env.SHEETS_TIMEOUT_MS, 15000, 1000, 120000),
    },
  };
  if (c.dataKey) {
    const raw = Buffer.from(c.dataKey, 'base64');
    if (raw.length !== 32) throw new Error('DATA_KEY harus 32 byte dalam base64 (buat dengan: node -e "console.log(require(\'crypto\').randomBytes(32).toString(\'base64\'))")');
  } else if (prod) {
    throw new Error('DATA_KEY wajib diisi di production');
  } else {
    c.dataKey = Buffer.alloc(32, 7).toString('base64'); // hanya untuk development lokal
  }
  return c;
}

module.exports = { load };
