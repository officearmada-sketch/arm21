'use strict';
const { HttpError } = require('./http');
const { hashPassword } = require('./auth');

// Credentials are supplied only by the function environment, never the request body.
async function setupAdmin(client, username, password, ip = '') {
  if (typeof username !== 'string' || !/^[A-Za-z0-9._-]{3,64}$/.test(username)) throw new HttpError(400, 'bad_request', 'Username harus 3–64 karakter: huruf, angka, titik, garis bawah, atau tanda hubung.');
  const now = Date.now();
  await client.query('BEGIN');
  try {
    // Serialize competing setup requests, including claims on different empty admin rows.
    await client.query('LOCK TABLE users IN EXCLUSIVE MODE');
    const ready = await client.query("SELECT id FROM users WHERE role = 'admin' AND (password_hash <> '' OR EXISTS (SELECT 1 FROM identity_links WHERE user_id = users.id))");
    if (ready.rows.length) { await client.query('COMMIT'); return false; }
    const hash = await hashPassword(password);
    const collision = await client.query("SELECT id FROM users WHERE lower(username) = lower($1) AND (role <> 'admin' OR password_hash <> '' OR disabled)", [username]);
    if (collision.rows.length) throw new HttpError(409, 'username_used', 'Username sudah digunakan. Pilih username lain.');
    const empty = await client.query("SELECT id FROM users WHERE role = 'admin' AND password_hash = '' AND NOT disabled ORDER BY id LIMIT 1");
    let result;
    if (empty.rows.length) {
      result = await client.query('UPDATE users SET username = $1, password_hash = $2, failed_count = 0, locked_until = 0, updated_at = $3 WHERE id = $4 RETURNING id', [username, hash, now, empty.rows[0].id]);
    } else {
      result = await client.query("INSERT INTO users (username, password_hash, role, areas, label, created_at, updated_at) VALUES ($1, $2, 'admin', '[]', 'Admin', $3, $3) RETURNING id", [username, hash, now]);
    }
    const id = result.rows[0].id;
    await client.query("INSERT INTO audit (at, user_id, username, action, ip) VALUES ($1, $2, $3, 'admin.setup.environment', $4)", [now, id, username, ip]);
    await client.query('COMMIT');
    return true;
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') throw new HttpError(409, 'username_used', 'Username sudah digunakan. Pilih username lain.');
    throw error;
  }
}
module.exports = { setupAdmin };
