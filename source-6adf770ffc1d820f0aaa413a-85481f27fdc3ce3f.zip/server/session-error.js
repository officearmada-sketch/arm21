'use strict';

// Database adapters wrap errors with SQL and parameters. Never expose or log
// their message, stack, query, or parameters: these can contain credentials.
function sessionError(error) {
  const causes = [];
  for (let cause = error; cause && causes.length < 8 && !causes.includes(cause); cause = cause.cause) causes.push(cause);
  const hasCode = (...codes) => causes.some(cause => codes.includes(cause.code));
  if (causes.some(cause => cause.name === 'MissingDatabaseConnectionError')) {
    return { code: 'database_configuration', message: 'Login belum tersedia: koneksi Netlify Database belum tersedia untuk Functions pada deploy ini. Admin perlu memeriksa koneksi database dan melakukan deploy ulang.' };
  }
  if (hasCode('42501', '25006')) {
    return { code: 'database_permissions', message: 'Login belum tersedia: database menolak akses tulis untuk layanan login. Admin perlu memeriksa izin koneksi Netlify Database pada deploy ini.' };
  }
  if (hasCode('42P01', '42703')) {
    return { code: 'database_schema', message: 'Login belum tersedia: tabel atau kolom database belum lengkap. Admin perlu memeriksa hasil migrasi database pada deploy ini.' };
  }
  if (hasCode('28P01', '28000', '3D000')) {
    return { code: 'database_configuration', message: 'Login belum tersedia: konfigurasi koneksi database ditolak. Admin perlu memeriksa koneksi Netlify Database pada deploy ini.' };
  }
  if (hasCode('ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT', 'ENOTFOUND', 'EAI_AGAIN', '53300', '57P01', '08001', '08006')) {
    return { code: 'database_unavailable', message: 'Koneksi database sedang tidak tersedia. Coba login lagi beberapa saat. Jika tetap gagal, admin perlu memeriksa layanan Netlify Database.' };
  }
  return { code: 'service_unavailable', message: 'Layanan login mengalami gangguan internal. Admin perlu memeriksa log Function session pada deploy ini.' };
}

module.exports = { sessionError };
