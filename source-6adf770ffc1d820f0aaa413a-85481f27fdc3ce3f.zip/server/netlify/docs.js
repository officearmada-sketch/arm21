'use strict';
const { randomBytes } = require('node:crypto');
const { HttpError } = require('../http');
const { COLL_RE, ID_RE, FIELD_RE, MAX_DOC, rule, allowed, areaOk, readableArea, dataVisible, kodeOk, PAKAI_STAFF, DENY } = require('../routes/docs').policy;
const shape = d => ({ id: d.id, data: JSON.parse(d.data), version: d.version, updatedAt: Number(d.updated_at) });
const check = (c, id) => {
  if (!COLL_RE.test(c) || (id !== undefined && (!ID_RE.test(id) || id === '.' || id === '..'))) throw new HttpError(400, 'bad_request', 'Jalur dokumen tidak valid.');
};
const deny = () => { throw new HttpError(403, 'forbidden', DENY); };
const payload = (b, c, user) => {
  if (!b || typeof b.data !== 'object' || b.data === null || Array.isArray(b.data)) throw new HttpError(400, 'bad_request', 'Isi dokumen harus berupa objek JSON.');
  const data = { ...b.data };
  if (rule(c).stamp) { data.by = user.username; data.serverAt = new Date().toISOString(); }
  const s = JSON.stringify(data);
  if (Buffer.byteLength(s) > (rule(c).max || MAX_DOC)) throw new HttpError(413, 'too_large', 'Dokumen terlalu besar.');
  return s;
};
module.exports = (r, { query, transaction, audit }) => {
  r.get('/api/db/:collection', async ctx => {
    const user = ctx.requireUser(), c = ctx.params.collection;
    check(c); if (!allowed(rule(c).read, user)) deny();
    const limit = Math.min(2000, Math.max(1, Math.trunc(Number(ctx.query.get('limit')) || 1000)));
    const ob = ctx.query.get('orderBy');
    if (ob && !FIELD_RE.test(ob)) throw new HttpError(400, 'bad_request', 'Kolom urutan tidak valid.');
    // JSON values retain numeric ordering, unlike a text extraction.
    const order = ob ? `data::jsonb -> $2 ${ctx.query.get('dir') === 'desc' ? 'DESC NULLS LAST' : 'ASC NULLS FIRST'}, id` : 'id';
    const rows = await query(`SELECT * FROM docs WHERE collection=$1 ORDER BY ${order}`, ob ? [c, ob] : [c]);
    let bytes = 0; const docs = [];
    for (const d of rows) {
      if (!readableArea(c, d.id, user)) continue;
      const sh = shape(d); if (!dataVisible(c, sh.data, user)) continue;
      bytes += Buffer.byteLength(d.data); if (bytes > 24 * 1024 * 1024) break;
      docs.push(sh); if (docs.length >= limit) break;
    }
    ctx.json(200, { docs });
  });
  r.get('/api/db/:collection/:id', async ctx => {
    const user = ctx.requireUser(), { collection: c, id } = ctx.params;
    check(c, id); if (!allowed(rule(c).read, user)) deny();
    const [d] = await query('SELECT * FROM docs WHERE path=$1', [`${c}/${id}`]);
    if (d && (!readableArea(c, id, user) || !dataVisible(c, JSON.parse(d.data), user))) deny();
    ctx.json(200, d ? { exists: true, ...shape(d) } : { exists: false, id });
  });
  const save = async (ctx, add) => {
    const user = ctx.requireUser(), c = ctx.params.collection, id = add ? randomBytes(10).toString('hex') : ctx.params.id;
    check(c, id); if (!allowed(rule(c).write, user) || !areaOk(c, add ? '' : id, user)) deny();
    const s = payload(await ctx.readJson(), c, user);
    const version = await transaction(async q => {
      // Serialize writes to this collection, including creation of append-only log IDs.
      await q('SELECT pg_advisory_xact_lock(hashtext($1))', ['docs:' + c]);
      const [old] = await q('SELECT * FROM docs WHERE path=$1', [`${c}/${id}`]);
      if (rule(c).append && old) deny();
      if (rule(c).kodeField && user.role === 'daerah') {
        const od = old && JSON.parse(old.data), nd = JSON.parse(s);
        if (!od || !kodeOk(user, od[rule(c).kodeField]) || !PAKAI_STAFF.every(f => JSON.stringify(nd[f]) === JSON.stringify(od[f]))) deny();
      }
      if (rule(c).cap && !old) {
        const [count] = await q('SELECT count(*)::int AS n FROM docs WHERE collection=$1', [c]);
        if (count.n >= rule(c).cap) throw new HttpError(429, 'quota', 'Koleksi ini sudah penuh.');
      }
      const [saved] = await q(`INSERT INTO docs (path, collection, id, data, version, updated_at, updated_by) VALUES ($1,$2,$3,$4,1,$5,$6)
        ON CONFLICT(path) DO UPDATE SET data=excluded.data, version=docs.version+1, updated_at=excluded.updated_at, updated_by=excluded.updated_by RETURNING version`, [`${c}/${id}`, c, id, s, Date.now(), user.id]);
      if (c !== 'log') await audit(q, user, 'db.set', `${c}/${id}`, `v${saved.version} ${Buffer.byteLength(s)}B`, ctx.ip);
      return saved.version;
    });
    ctx.json(add ? 201 : 200, add ? { ok: true, id } : { ok: true, version });
  };
  r.put('/api/db/:collection/:id', ctx => save(ctx, false));
  r.post('/api/db/:collection', ctx => save(ctx, true));
  r.delete('/api/db/:collection/:id', async ctx => {
    const user = ctx.requireUser(), { collection: c, id } = ctx.params;
    check(c, id); if (!allowed(rule(c).del, user)) deny();
    await transaction(async q => {
      await q('SELECT pg_advisory_xact_lock(hashtext($1))', ['docs:' + c]);
      const [old] = await q('SELECT * FROM docs WHERE path=$1', [`${c}/${id}`]);
      const od = old && JSON.parse(old.data);
      if (rule(c).kodeField && od && (od.dep || od.returned)) throw new HttpError(409, 'conflict', 'Pemakaian yang sudah berangkat tidak bisa dihapus.');
      await q('DELETE FROM docs WHERE path=$1', [`${c}/${id}`]);
      await audit(q, user, 'db.delete', `${c}/${id}`, null, ctx.ip);
    });
    ctx.json(200, { ok: true });
  });
};
