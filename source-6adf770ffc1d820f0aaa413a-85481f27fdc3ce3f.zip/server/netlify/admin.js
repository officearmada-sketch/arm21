'use strict';
const { HttpError } = require('../http');
const { ROLES, hashPassword, publicUser, parseAreas, AREA_NAMES } = require('../auth');
const row = u => ({ ...publicUser(u), disabled: u.disabled, lastLoginAt: u.last_login_at ? new Date(Number(u.last_login_at)).toISOString() : null });
const cleanAreas = (role, areas) => {
  if (role !== 'daerah') return [];
  if (!Array.isArray(areas) || !areas.length || !areas.every(a => typeof a === 'string' && /^[A-Z0-9]{2,8}$/.test(a))) throw new HttpError(400, 'bad_request', 'Akun area harus punya minimal satu kode area (mis. LPG).');
  return [...new Set(areas)];
};
module.exports = (r, { query, transaction, audit, sheets, env }) => {
  const admin = ctx => { const u = ctx.requireUser(); if (u.role !== 'admin') throw new HttpError(403, 'forbidden', 'Hanya admin.'); return u; };
  r.get('/api/admin/users', async ctx => {
    admin(ctx);
    ctx.json(200, { users: (await query('SELECT * FROM users ORDER BY lower(username)')).map(row), areas: AREA_NAMES });
  });
  r.post('/api/admin/users', async ctx => {
    const me = admin(ctx), b = await ctx.readJson();
    if (typeof b.username !== 'string' || !/^[A-Za-z0-9._-]{3,64}$/.test(b.username)) throw new HttpError(400, 'bad_request', 'Username 3-64 karakter: huruf, angka, titik, strip, garis bawah.');
    if (!ROLES.includes(b.role)) throw new HttpError(400, 'bad_request', 'Peran tidak valid.');
    const areas = cleanAreas(b.role, b.areas), hash = await hashPassword(b.password), now = Date.now();
    let user;
    try {
      user = await transaction(async q => {
        const [u] = await q('INSERT INTO users (username, password_hash, role, areas, label, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$6) RETURNING *', [b.username, hash, b.role, JSON.stringify(areas), String(b.label || '').slice(0, 80), now]);
        await audit(q, me, 'user.create', b.username, `${b.role} ${areas.join(',')}`, ctx.ip);
        return u;
      });
    } catch (e) { if (e.code === '23505') throw new HttpError(409, 'exists', 'Username sudah dipakai.'); throw e; }
    ctx.json(201, { user: row(user) });
  });
  r.patch('/api/admin/users/:username', async ctx => {
    const me = admin(ctx), b = await ctx.readJson();
    const hash = b.password === undefined ? undefined : await hashPassword(b.password);
    const user = await transaction(async q => {
      // Same lock as first-admin initialization; concurrent edits cannot remove all administrators.
      await q('LOCK TABLE users IN EXCLUSIVE MODE');
      const [target] = await q('SELECT * FROM users WHERE lower(username) = lower($1)', [ctx.params.username]);
      if (!target) throw new HttpError(404, 'not_found', 'Pengguna tidak ditemukan.');
      const role = b.role === undefined ? target.role : b.role;
      if (!ROLES.includes(role)) throw new HttpError(400, 'bad_request', 'Peran tidak valid.');
      if (b.disabled !== undefined && typeof b.disabled !== 'boolean') throw new HttpError(400, 'bad_request', 'Status akun tidak valid.');
      const areas = cleanAreas(role, b.areas === undefined ? parseAreas(target) : b.areas);
      const disabled = b.disabled === undefined ? target.disabled : b.disabled;
      const [updated] = await q('UPDATE users SET role=$1, areas=$2, label=$3, disabled=$4, updated_at=$5 WHERE id=$6 RETURNING *', [role, JSON.stringify(areas), b.label === undefined ? target.label : String(b.label).slice(0, 80), disabled, Date.now(), target.id]);
      const [count] = await q("SELECT count(*)::int AS n FROM users WHERE role='admin' AND NOT disabled");
      if (!count.n) throw new HttpError(409, 'last_admin', 'Harus ada minimal satu admin aktif.');
      if (hash !== undefined) await q('UPDATE users SET password_hash=$1, failed_count=0, locked_until=0 WHERE id=$2', [hash, target.id]);
      if (hash !== undefined || disabled || role !== target.role || JSON.stringify(areas) !== target.areas) await q('DELETE FROM sessions WHERE user_id=$1', [target.id]);
      await audit(q, me, 'user.update', target.username, JSON.stringify({ role, areas, disabled, password: hash !== undefined }), ctx.ip);
      return updated;
    });
    ctx.json(200, { user: row(user) });
  });
  r.get('/api/admin/status', async ctx => {
    admin(ctx);
    const [counts] = await query(`SELECT
      (SELECT count(*)::int FROM users WHERE NOT disabled) AS users,
      (SELECT count(*)::int FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.expires_at>$1 AND s.last_seen_at>$2 AND NOT u.disabled) AS sessions,
      (SELECT count(*)::int FROM docs) AS docs, (SELECT count(*)::int FROM cek) AS cek, (SELECT count(*)::int FROM audit) AS audit`, [Date.now(), Date.now() - 240 * 60000]);
    const locked = await query('SELECT username, locked_until FROM users WHERE locked_until>$1', [Date.now()]);
    ctx.json(200, { version: require('../../package.json').version, commit: null, builtAt: null, uptimeSec: Math.round(process.uptime()), node: process.version, env: env('CONTEXT') || 'production', sheets: sheets.status(), counts, lockedUsers: locked.map(u => ({ username: u.username, until: new Date(Number(u.locked_until)).toISOString() })) });
  });
  r.get('/api/admin/audit', async ctx => {
    admin(ctx);
    const limit = Math.min(500, Math.max(1, Math.trunc(Number(ctx.query.get('limit')) || 100)));
    const items = await query('SELECT at, username, action, target, detail, ip FROM audit ORDER BY id DESC LIMIT $1', [limit]);
    ctx.json(200, { items: items.map(a => ({ ...a, at: new Date(Number(a.at)).toISOString() })) });
  });
};
