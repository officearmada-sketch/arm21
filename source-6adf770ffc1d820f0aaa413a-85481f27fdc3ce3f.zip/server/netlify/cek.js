'use strict';
const { HttpError } = require('../http');
const { actorLabel } = require('../auth');
const iso = t => new Date(Number(t)).toISOString();
const shape = (row, hist) => ({ k: row.key, cek: row.cek, catatan: row.catatan, oleh: row.oleh, at: iso(row.at), jenis: row.jenis, jenisBy: row.jenis_by, jenisAt: Number(row.jenis_at) ? iso(row.jenis_at) : '', hist: hist.map(h => ({ at: iso(h.at), by: h.oleh, act: h.act, note: h.note })) });
module.exports = (r, { query, transaction, audit }) => {
  r.get('/api/cek', async ctx => {
    ctx.requireUser();
    const rows = await query('SELECT * FROM cek');
    const hist = await query('SELECT * FROM (SELECT *, row_number() OVER (PARTITION BY key ORDER BY at DESC, id DESC) AS rn FROM cek_hist) h WHERE rn<=30 ORDER BY at DESC, id DESC');
    const groups = new Map();
    for (const h of hist) { if (!groups.has(h.key)) groups.set(h.key, []); groups.get(h.key).push(h); }
    ctx.json(200, { items: rows.map(row => shape(row, groups.get(row.key) || [])) });
  });
  r.post('/api/cek', async ctx => {
    const user = ctx.requireUser(), b = await ctx.readJson();
    if (user.role === 'viewer') throw new HttpError(403, 'forbidden', 'Akun lihat saja tidak bisa mengubah koreksi.');
    const key = typeof b.key === 'string' ? b.key : '', act = b.act, note = typeof b.note === 'string' ? b.note.trim() : '';
    if (!key || key.length > 300 || !['note', 'clear', 'open', 'jenis'].includes(act) || note.length > 1000) throw new HttpError(400, 'bad_request', 'Kunci trip, aksi, atau catatan tidak valid.');
    if (act === 'clear' && !note) throw new HttpError(400, 'note_required', 'Isi keterangan sebelum menandai clear.');
    if (act === 'jenis' && !['TITIKAN', 'LANGSUNG'].includes(b.jenis)) throw new HttpError(400, 'bad_request', 'Jenis trip harus TITIKAN atau LANGSUNG.');
    const now = Date.now(), label = actorLabel(user);
    const out = await transaction(async q => {
      await q('SELECT pg_advisory_xact_lock(hashtext($1))', ['cek:' + key]);
      await q("INSERT INTO cek (key, at) VALUES ($1,$2) ON CONFLICT DO NOTHING", [key, now]);
      if (act === 'jenis') {
        await q('UPDATE cek SET jenis=$1, jenis_by=$2, jenis_at=$3, oleh=$2, oleh_user=$4, at=$3 WHERE key=$5', [b.jenis, label, now, user.username, key]);
      } else {
        await q("UPDATE cek SET cek=CASE WHEN $1='clear' THEN 'CLEAR' WHEN $1='open' THEN '' ELSE cek END, catatan=$2, oleh=$3, oleh_user=$4, at=$5 WHERE key=$6", [act, note, label, user.username, now, key]);
      }
      await q('INSERT INTO cek_hist (key, at, oleh, oleh_user, act, note) VALUES ($1,$2,$3,$4,$5,$6)', [key, now, label, user.username, act, act === 'jenis' ? note || 'Jenis diubah' : note]);
      await q('DELETE FROM cek_hist WHERE key=$1 AND id NOT IN (SELECT id FROM cek_hist WHERE key=$1 ORDER BY at DESC, id DESC LIMIT 30)', [key]);
      await audit(q, user, 'cek.' + act, key, act === 'jenis' ? b.jenis : note.slice(0, 120), ctx.ip);
      const [row] = await q('SELECT * FROM cek WHERE key=$1', [key]);
      return shape(row, await q('SELECT * FROM cek_hist WHERE key=$1 ORDER BY at DESC, id DESC', [key]));
    });
    ctx.json(200, out);
  });
};
