'use strict';
// Jembatan ke Google Sheets lewat akun layanan (service account). Semua akses divalidasi di SERVER:
// browser tidak pernah memegang kredensial Google dan tidak bisa meminta spreadsheet/rentang sembarangan.
const crypto = require('node:crypto');
const fs = require('node:fs');
const { jpegToPdf } = require('./pdf');
const { HttpError } = require('./http');
const { parseAreas } = require('./auth');

const ID_RE = /^[A-Za-z0-9_-]{20,80}$/;
const A1 = "(?:'(?:[^']|'')+'|[A-Za-z0-9_ ]+)!";
const RANGE_RE = new RegExp(`^(?:${A1})?[A-Z]{1,3}\\d{0,6}(?::[A-Z]{1,3}\\d{0,6})?$`);
const AREA_WRITE_RE = /^'DATA PEMINJAM'!([RY])(\d{1,5})$/;
const RET_CELL_RE = /^'DATA PEMINJAM'!([UXWV])(\d{1,5})$/;
const RET_TEXT = { U: ['TELAH DIKEMBALIKAN'], X: ['NORMAL', 'ADA KERUSAKAN'] };
const HYPER_RE = /^=HYPERLINK\("https:\/\/drive\.google\.com\/file\/d\/([A-Za-z0-9_-]{10,80})\/view\?usp=drivesdk"[;,]"([A-Z0-9][A-Z0-9 ]{1,40})_(FORM_PULANG|PULANG|BERANGKAT)_\d{12}\.(?:jpeg|pdf|zip)"\)$/;
const codeMatch = (a, b) => !!a && !!b && (a === b || a.startsWith(b) || b.startsWith(a)); // JMB = JMBR
const MAX_ROW = 20000, MAX_COL = 52; // batas rentang baca: cegah permintaan raksasa ke Google
const colNum = (s) => [...s].reduce((n, c) => n * 26 + c.charCodeAt(0) - 64, 0);
function rangeTooBig(range) {
  for (const m of String(range).replace(/^.*!/, '').matchAll(/([A-Z]{1,3})(\d{0,6})/g)) if (colNum(m[1]) > MAX_COL || (m[2] && +m[2] > MAX_ROW)) return true;
  return false;
}
const JENIS_OK = ['PULANG', 'FORM_PULANG', 'KERUSAKAN', 'BERANGKAT', 'CHECKLIST_BERANGKAT', 'PAKAI_BERANGKAT', 'PAKAI_PULANG']; // sama dengan jenis di script Upload: BERANGKAT/PULANG
const wibStamp = () => { const p = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Jakarta', day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' }).formatToParts(new Date()).reduce((o, x) => (o[x.type] = x.value, o), {}); return p.day + p.month + p.year + p.hour + p.minute + p.second; };
const ACC_WRITE_RE = /^'ACC PUSAT'!Y(\d{1,5})$/;
const AREA_SHEET = "'DATA PEMINJAM'!";

const b64u = (b) => Buffer.from(b).toString('base64url');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function loadServiceAccount(g) {
  let raw = g.saJson;
  if (!raw && g.saFile) raw = fs.readFileSync(g.saFile, 'utf8');
  if (!raw) return null;
  const sa = JSON.parse(raw);
  if (!sa.client_email || !sa.private_key) throw new Error('GOOGLE_SA_* tidak berisi client_email/private_key');
  return sa;
}

function createSheets({ cfg, log, metrics, fetchImpl = fetch, uploads = null }) {
  const g = cfg.google;
  let sa = null, saError = '';
  try { sa = loadServiceAccount(g); } catch (e) { saError = e.message; log.error('akun_layanan_google_gagal_dimuat', { error: e.message }); }

  // ---- token OAuth (di-cache, satu permintaan sekaligus) ----
  let tok = { value: '', exp: 0 }, tokPromise = null;
  async function accessToken() {
    if (!sa) throw new HttpError(503, 'sheets_not_configured', 'Akun layanan Google belum dikonfigurasi di server.');
    if (tok.value && Date.now() < tok.exp - 60000) return tok.value;
    if (tokPromise) return tokPromise;
    tokPromise = (async () => {
      const iat = Math.floor(Date.now() / 1000);
      const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
      const claim = b64u(JSON.stringify({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive', aud: g.tokenUrl, iat, exp: iat + 3600 }));
      const sig = crypto.sign('RSA-SHA256', Buffer.from(`${head}.${claim}`), sa.private_key);
      const res = await fetchImpl(g.tokenUrl, {
        method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer', assertion: `${head}.${claim}.${b64u(sig)}` }),
        signal: AbortSignal.timeout(g.timeoutMs),
      });
      const j = await res.json().catch(() => ({}));
      if (!res.ok || !j.access_token) {
        log.error('token_google_gagal', { status: res.status, error: j.error, desc: j.error_description });
        throw new HttpError(503, 'sheets_auth_failed', 'Server gagal masuk ke Google (cek akun layanan).');
      }
      tok = { value: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
      return tok.value;
    })().finally(() => { tokPromise = null; });
    return tokPromise;
  }

  // ---- panggilan API dengan batas waktu dan retry (hanya untuk kegagalan sementara) ----
  async function call(method, url, body, { retries }) {
    let lastErr;
    for (let attempt = 0; attempt <= retries; attempt++) {
      const t0 = process.hrtime.bigint();
      try {
        const res = await fetchImpl(url, {
          method, headers: { Authorization: `Bearer ${await accessToken()}`, ...(body ? { 'Content-Type': 'application/json' } : {}) },
          body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(g.timeoutMs),
        });
        metrics.observe('sheets_request_seconds', { method }, Number(process.hrtime.bigint() - t0) / 1e9);
        metrics.inc('sheets_requests_total', { method, status: res.status });
        if (res.ok) return await res.json();
        const j = await res.json().catch(() => ({}));
        const msg = (j.error && j.error.message) || res.statusText;
        if (res.status === 401) { tok = { value: '', exp: 0 }; lastErr = new HttpError(503, 'sheets_auth_failed', 'Token Google ditolak.'); }
        else if (res.status === 429 || res.status >= 500) lastErr = new HttpError(503, 'sheets_unavailable', 'Google Sheets sedang sibuk. Coba lagi sebentar.');
        else if (res.status === 403 || res.status === 404) throw new HttpError(502, 'sheets_denied', 'Google menolak akses ke spreadsheet. Pastikan akun layanan sudah dibagikan sebagai Editor.');
        else { log.warn('google_error', { status: res.status, msg: String(msg).slice(0, 200) }); throw new HttpError(502, 'sheets_error', 'Google Sheets menolak permintaan ini.'); }
      } catch (e) {
        if (e instanceof HttpError && e.code !== 'sheets_unavailable' && e.code !== 'sheets_auth_failed') throw e;
        lastErr = e instanceof HttpError ? e : new HttpError(503, 'sheets_unavailable', 'Google Sheets tidak merespons. Coba lagi sebentar.');
        metrics.inc('sheets_requests_total', { method, status: 'error' });
      }
      if (attempt < retries) await sleep(250 * 2 ** attempt + Math.random() * 150);
    }
    throw lastErr;
  }

  // ---- cache baca jangka pendek + coalescing ----
  const cache = new Map(); // `${id}|${range}` -> {t, p}
  const rangeUrl = (id, range) => `${g.apiBase}/v4/spreadsheets/${id}/values/${encodeURIComponent(range)}`;
  function rawRead(id, range) {
    const k = `${id}|${range}`, now = Date.now(), hit = cache.get(k);
    if (hit && now - hit.t < g.cacheTtlMs) return hit.p;
    const p = call('GET', `${rangeUrl(id, range)}?valueRenderOption=FORMATTED_VALUE&majorDimension=ROWS`, null, { retries: 2 })
      .then((j) => ({ range: j.range || range, values: (j.values || []).map((r) => r.map((c) => (c == null ? '' : String(c)))) }));
    cache.set(k, { t: now, p });
    p.catch(() => { if (cache.get(k) && cache.get(k).p === p) cache.delete(k); });
    if (cache.size > 500) {
      for (const [kk, v] of cache) if (now - v.t > g.cacheTtlMs) cache.delete(kk);
      for (const kk of cache.keys()) { if (cache.size <= 400) break; cache.delete(kk); } // batas keras: buang yang tertua
    }
    return p;
  }
  const dropCache = (id) => { for (const k of cache.keys()) if (id ? k.startsWith(id + '|') : true) cache.delete(k); };

  // ---- daftar area (dari sheet MASTER di ACC PUSAT) ----
  const folderCache = new Map();
  let areas = new Map(), sheetToArea = new Map(), areasAt = 0, areasP = null, areasErr = '';
  function refreshAreas(force) {
    if (!force && Date.now() - areasAt < g.areaRefreshMs) return Promise.resolve();
    if (areasP) return areasP;
    areasP = (async () => {
      try {
        const j = await call('GET', `${rangeUrl(g.accId, "'MASTER'!A1:C60")}?valueRenderOption=FORMATTED_VALUE`, null, { retries: 2 });
        const a = new Map(), s = new Map();
        for (const r of j.values || []) {
          const code = String(r[0] || '').trim(), name = String(r[1] || '').trim(), m = String(r[2] || '').match(/\/d\/([A-Za-z0-9_-]{20,80})/);
          if (!code || !m) continue;
          a.set(code, { name, sheetId: m[1] });
          s.set(m[1], code);
        }
        areas = a; sheetToArea = s; areasErr = '';
      } catch (e) { areasErr = e.message; log.warn('daftar_area_gagal', { error: e.message }); }
      areasAt = Date.now(); // jangan menghantam Google terus-menerus saat gagal
    })().finally(() => { areasP = null; });
    return areasP;
  }

  async function areaOf(id) {
    if (!sheetToArea.has(id) && Date.now() - areasAt > 30000) await refreshAreas(true);
    else if (!areas.size) await refreshAreas(false);
    return sheetToArea.get(id) || null;
  }

  // ---- otorisasi ----
  const isStaff = (u) => u.role === 'admin' || u.role === 'pusat';
  const forbid = (m) => new HttpError(403, 'forbidden', m || 'Akun Anda tidak berwenang untuk data ini.');

  async function authorizeRead(user, id, range) {
    if (user.role === 'admin') return;
    if (user.role === 'viewer') throw forbid();
    // ACC PUSAT, MASTER armada, daftar SPPD dan database karyawan (Pemakaian Unit) hanya untuk Armada Pusat dan Admin
    if (id === g.accId || id === g.formId || id === g.sppdId || id === g.empId) { if (user.role === 'pusat') return; throw forbid(); }
    const code = await areaOf(id);
    if (!code) throw forbid('Spreadsheet ini tidak terdaftar.');
    if (user.role === 'pusat') return;
    if (user.role === 'daerah' && parseAreas(user).includes(code) && range.startsWith(AREA_SHEET)) return;
    throw forbid();
  }

  // Hanya tiga jenis tulisan yang diizinkan: centang ACC Armada Pusat (R), ACC area (Y), ACC pusat/Manager (Y di ACC PUSAT).
  async function authorizeWrite(user, id, range, values) {
    if (!Array.isArray(values) || values.length !== 1 || !Array.isArray(values[0]) || values[0].length !== 1) throw new HttpError(400, 'bad_request', 'Hanya satu sel yang boleh ditulis.');
    const v = values[0][0];
    if (typeof v !== 'boolean' && v !== 'TRUE' && v !== 'FALSE') throw new HttpError(400, 'bad_request', 'Nilai harus TRUE atau FALSE.');
    if (id === g.accId) {
      if (ACC_WRITE_RE.test(range) && isStaff(user)) return `acc_pusat.manager`;
      throw forbid('Hanya Armada Pusat dan Admin yang bisa ACC pusat.');
    }
    const m = AREA_WRITE_RE.exec(range);
    if (!m) throw forbid('Rentang ini tidak boleh diubah.');
    const code = await areaOf(id);
    if (!code) throw forbid('Spreadsheet ini tidak terdaftar.');
    if (m[1] === 'R') { if (isStaff(user)) return `acc_armada_pusat.${code}`; throw forbid('Hanya Armada Pusat dan Admin yang bisa ACC Armada Pusat.'); }
    if (isStaff(user) || (user.role === 'daerah' && parseAreas(user).includes(code))) return `acc_area.${code}`;
    throw forbid('Akun Anda tidak berwenang untuk area ini.');
  }

  // Kolom pengembalian: U (status), X (keterangan) berupa teks tetap; W berupa rumus HYPERLINK ke berkas Drive.
  async function authorizeReturnWrite(user, id, range, value, kind) {
    const m = RET_CELL_RE.exec(range);
    if (!m) throw forbid('Rentang ini tidak boleh diubah.');
    if (user.role === 'viewer') throw forbid();
    const code = await areaOf(id);
    if (!code) throw forbid('Spreadsheet ini tidak terdaftar.');
    if (!(isStaff(user) || (user.role === 'daerah' && parseAreas(user).includes(code)))) throw forbid('Akun Anda tidak berwenang untuk area ini.');
    if (kind === 'formula') {
      const h = (m[1] === 'W' || m[1] === 'V') && typeof value === 'string' ? HYPER_RE.exec(value) : null;
      if (!h || (m[1] === 'V') !== (h[3] === 'BERANGKAT')) throw new HttpError(400, 'bad_request', 'Isi kolom UPLOAD PENGEMBALIAN tidak valid.');
      // berkas harus hasil unggahan server ini, dan kode areanya sama dengan area sheet tujuan
      const upArea = uploads ? uploads.get(h[1]) : null;
      if (!upArea || !codeMatch(upArea, code)) throw forbid('Berkas foto ini tidak terdaftar untuk area tersebut.');
    } else if (m[1] === 'W' || m[1] === 'V' || !(RET_TEXT[m[1]] || []).includes(value)) throw new HttpError(400, 'bad_request', 'Nilai tidak diizinkan untuk kolom ini.');
    return `kembali.${m[1]}.${code}`;
  }
  const one = (values) => {
    if (!Array.isArray(values) || values.length !== 1 || !Array.isArray(values[0]) || values[0].length !== 1) throw new HttpError(400, 'bad_request', 'Hanya satu sel yang boleh ditulis.');
    return values[0][0];
  };

  function validate(id, range) {
    if (typeof id !== 'string' || !ID_RE.test(id)) throw new HttpError(400, 'bad_request', 'ID spreadsheet tidak valid.');
    if (typeof range !== 'string' || range.length > 200 || !RANGE_RE.test(range) || rangeTooBig(range)) throw new HttpError(400, 'bad_request', 'Rentang sel tidak valid.');
  }

  return {
    configured: () => !!sa,
    status: () => ({ configured: !!sa, error: saError, areas: areas.size, areasError: areasErr, areasAt }),
    refreshAreas,
    areas: () => areas,
    invalidate: dropCache,
    async read(user, id, range) {
      validate(id, range);
      await authorizeRead(user, id, range);
      return rawRead(id, range);
    },
    async writeReturn(user, id, range, values, kind) {
      validate(id, range);
      const value = one(kind === 'formula' ? values : values);
      const what = await authorizeReturnWrite(user, id, range, value, kind);
      const j = await call('PUT', `${rangeUrl(id, range)}?valueInputOption=USER_ENTERED`, { range, majorDimension: 'ROWS', values: [[value]] }, { retries: 1 });
      dropCache(id);
      return { what, value: kind === 'formula' ? '(tautan Drive)' : value, updatedCells: j.updatedCells || 1, range };
    },
    // Menambah satu baris log perubahan Monitor ke spreadsheet log (13 kolom teks, tanpa rumus).
    async appendLog(user, values) {
      if (user.role === 'viewer') throw forbid();
      if (!Array.isArray(values) || values.length !== 1 || !Array.isArray(values[0]) || values[0].length !== 13) throw new HttpError(400, 'bad_request', 'Baris log harus 13 kolom.');
      const row = values[0].map((v) => { let t = String(v == null ? '' : v).slice(0, 1000); if (/^[=+\-@]/.test(t)) t = "'" + t; return t; });
      const range = "'LOG PERUBAHAN'!A1";
      await call('POST', `${rangeUrl(g.logId, range)}:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS`, { range, majorDimension: 'ROWS', values: [row] }, { retries: 0 }); // tanpa retry: jangan menggandakan baris log
      return { what: 'log.monitor', row };
    },
    // Foto unit pulang / form pemeriksaan: JPEG kecil, disimpan di subfolder per area (dicari, atau dibuat bila belum ada)
    // di bawah satu folder tetap. Nama berkas mengikuti script: NAMA AREA_JENIS_ddMMyyHHmmss.jpeg
    async uploadReturnPhoto(user, { code, jenis, base64Content: b64, oldId }) {
      if (user.role === 'viewer') throw forbid();
      if (!areas.size) await refreshAreas(false);
      const area = areas.get(String(code || ''));
      if (!area || !/^[A-Z0-9][A-Z0-9 ]{1,40}$/.test(area.name.toUpperCase())) throw new HttpError(400, 'bad_request', 'Area tidak dikenal.');
      if (!JENIS_OK.includes(jenis)) throw new HttpError(400, 'bad_request', 'Jenis berkas tidak valid.');
      if (!(isStaff(user) || (user.role === 'daerah' && parseAreas(user).includes(code)))) throw forbid('Akun Anda tidak berwenang untuk area ini.');
      if (typeof b64 !== 'string' || b64.length > 6 * 1024 * 1024 || !/^[A-Za-z0-9+/=]+$/.test(b64)) throw new HttpError(400, 'bad_request', 'Isi berkas tidak valid atau terlalu besar.');
      let buf = Buffer.from(b64, 'base64');
      const isJpeg = buf.length >= 100 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
      const isZip = buf.length >= 22 && buf[0] === 0x50 && buf[1] === 0x4b && buf[2] === 0x03 && buf[3] === 0x04;
      let ext = 'jpeg', mime = 'image/jpeg';
      if (jenis === 'FORM_PULANG' || jenis === 'BERANGKAT' || jenis === 'PAKAI_BERANGKAT' || jenis === 'PAKAI_PULANG') { // form pemeriksaan selalu disimpan sebagai PDF
        if (buf.length >= 100 && buf.subarray(0, 5).toString('latin1') === '%PDF-') { /* PDF diterima apa adanya */ }
        else {
          if (!isJpeg) throw new HttpError(400, 'bad_request', 'Form harus berupa foto JPEG atau PDF.');
          try { buf = jpegToPdf(buf); } catch (e) { throw new HttpError(400, 'bad_request', 'Foto form tidak bisa dibuat PDF.'); }
        }
        ext = 'pdf'; mime = 'application/pdf';
      } else if (jenis === 'CHECKLIST_BERANGKAT') { // checklist keberangkatan: JPG atau PDF apa adanya, tanpa mengubah aturan ACC
        if (buf.length >= 100 && buf.subarray(0, 5).toString('latin1') === '%PDF-') { ext = 'pdf'; mime = 'application/pdf'; }
        else if (!isJpeg) throw new HttpError(400, 'bad_request', 'Checklist harus berupa JPG atau PDF.');
      } else if (isZip) { ext = 'zip'; mime = 'application/zip'; }
      else if (!isJpeg) throw new HttpError(400, 'bad_request', 'Berkas harus berupa foto JPEG atau ZIP berisi foto.');
      const nama = area.name.toUpperCase();
      const title = `${nama}_${jenis}_${wibStamp()}.${ext}`;
      const token = await accessToken();
      const auth = { Authorization: `Bearer ${token}` };
      const gj = async (method, url, body) => {
        let res;
        try { res = await fetchImpl(url, { method, headers: { ...auth, ...(body ? { 'Content-Type': 'application/json' } : {}) }, body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(g.timeoutMs) }); }
        catch (e) { throw new HttpError(503, 'drive_unavailable', 'Google Drive tidak merespons. Coba lagi sebentar.'); }
        const j = await res.json().catch(() => ({}));
        if (!res.ok) { log.error('drive_gagal', { status: res.status }); throw new HttpError(502, 'drive_error', 'Google Drive menolak permintaan. Pastikan folder PENGEMBALIAN dibagikan ke akun layanan sebagai Editor.'); }
        return j;
      };
      const parent = g.returnFolderId;
      let folder = folderCache.get(nama);
      if (!folder) {
        const q = `'${parent}' in parents and name = '${nama.replace(/['\\]/g, '')}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false`;
        const f = await gj('GET', `${g.driveApiBase}/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id)&supportsAllDrives=true&includeItemsFromAllDrives=true&pageSize=1`);
        folder = f.files && f.files[0] && f.files[0].id;
        if (!folder) folder = (await gj('POST', `${g.driveApiBase}/drive/v3/files?supportsAllDrives=true&fields=id`, { name: nama, mimeType: 'application/vnd.google-apps.folder', parents: [parent] })).id;
        if (!folder) throw new HttpError(502, 'drive_error', 'Folder area tidak bisa dibuat di Google Drive.');
        folderCache.set(nama, folder);
      }
      const boundary = 'b' + crypto.randomBytes(12).toString('hex');
      const meta = JSON.stringify({ name: title, parents: [folder], mimeType: mime });
      const body = Buffer.concat([
        Buffer.from(`--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--${boundary}\r\nContent-Type: ${mime}\r\n\r\n`),
        buf, Buffer.from(`\r\n--${boundary}--`)]);
      let res;
      try {
        res = await fetchImpl(`${g.driveApiBase}/upload/drive/v3/files?uploadType=multipart&supportsAllDrives=true&fields=id`, {
          method: 'POST', headers: { ...auth, 'Content-Type': `multipart/related; boundary=${boundary}` }, body, signal: AbortSignal.timeout(g.timeoutMs * 3) });
      } catch (e) { throw new HttpError(503, 'drive_unavailable', 'Google Drive tidak merespons. Coba lagi sebentar.'); }
      const j = await res.json().catch(() => ({}));
      if (!res.ok || !j.id) { log.error('drive_upload_gagal', { status: res.status }); throw new HttpError(502, 'drive_error', 'Google Drive menolak unggahan. Pastikan folder PENGEMBALIAN dibagikan ke akun layanan sebagai Editor.'); }
      if (uploads) uploads.add(j.id, code);
      // berkas lama dibuang ke sampah hanya bila hasil unggahan server ini untuk area yang sama (seperti script: hanya di subfolder yang sama)
      if (oldId && typeof oldId === 'string' && /^[A-Za-z0-9_-]{10,80}$/.test(oldId) && uploads && uploads.get(oldId) === code && oldId !== j.id) {
        try { await gj('PATCH', `${g.driveApiBase}/drive/v3/files/${oldId}?supportsAllDrives=true`, { trashed: true }); } catch (e) { /* abaikan */ }
      }
      return { id: j.id, title, folder, viewUrl: `https://drive.google.com/file/d/${j.id}/view?usp=drivesdk`, bytes: buf.length };
    },
    async write(user, id, range, values) {
      validate(id, range);
      const what = await authorizeWrite(user, id, range, values);
      const value = values[0][0] === true || values[0][0] === 'TRUE';
      const j = await call('PUT', `${rangeUrl(id, range)}?valueInputOption=USER_ENTERED`, { range, majorDimension: 'ROWS', values: [[value]] }, { retries: 1 });
      dropCache(id);
      return { what, value, updatedCells: j.updatedCells || 1, range };
    },
  };
}

module.exports = { createSheets, RANGE_RE, ID_RE };
