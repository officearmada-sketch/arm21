'use strict';
const { HttpError } = require('../http');
const { ROLES, hashPassword, publicUser, parseAreas, AREA_NAMES } = require('../auth');
const { tx } = require('../db');

const NAME_RE = /^[A-Za-z0-9._-]{3,64}$/;
const AREA_RE = /^[A-Z0-9]{2,8}$/;

module.exports = (r, { cfg, db, auth, audit, sheets }) => {
  const startedAt = Date.now();
  const q = {
    list: db.prepare('SELECT * FROM users ORDER BY username COLLATE NOCASE'),
    byName: db.prepare('SELECT * FROM users WHERE username = ?'),
    ins: db.prepare('INSERT INTO users (username, password_hash, role, areas, label, created_at, updated_at) VALUES (?,?,?,?,?,?,?)'),
    upd: db.prepare('UPDATE users SET role = ?, areas = ?, label = ?, disabled = ?, updated_at = ? WHERE id = ?'),
    admins: db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND disabled = 0"),
    audit: db.prepare('SELECT at, username, action, target, detail, ip FROM audit ORDER BY id DESC LIMIT ?'),
  };
  const admin = (ctx) => { const u = ctx.requireUser(); if (u.role !== 'admin') throw new HttpError(403, 'forbidden', 'Hanya admin.'); return u; };
  const cleanAreas = (role, areas) => {
    if (role !== 'daerah') return [];
    if (!Array.isArray(areas) || !areas.length || !areas.every((a) => typeof a === 'string' && AREA_RE.test(a))) throw new HttpError(400, 'bad_request', 'Akun area harus punya minimal satu kode area (mis. LPG).');
    return [...new Set(areas)];
  };
  const row = (u) => ({ ...publicUser(u), disabled: !!u.disabled, lastLoginAt: u.last_login_at ? new Date(u.last_login_at).toISOString() : null });

  r.get('/api/admin/users', (ctx) => { admin(ctx); ctx.json(200, { users: q.list.all().map(row), areas: AREA_NAMES }); });

  r.post('/api/admin/users', async (ctx) => {
    const me = admin(ctx), b = await ctx.readJson();
    if (typeof b.username !== 'string' || !NAME_RE.test(b.username)) throw new HttpError(400, 'bad_request', 'Username 3-64 karakter: huruf, angka, titik, strip, garis bawah.');
    if (!ROLES.includes(b.role)) throw new HttpError(400, 'bad_request', 'Peran tidak valid.');
    const areas = cleanAreas(b.role, b.areas);
    const hash = await hashPassword(b.password);
    const now = Date.now();
    try { q.ins.run(b.username, hash, b.role, JSON.stringify(areas), String(b.label || '').slice(0, 80), now, now); }
    catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'exists', 'Username sudah dipakai.'); throw e; }
    audit({ user: me, action: 'user.create', target: b.username, detail: `${b.role} ${areas.join(',')}`, ip: ctx.ip });
    ctx.json(201, { user: row(q.byName.get(b.username)) });
  });

  r.patch('/api/admin/users/:username', async (ctx) => {
    const me = admin(ctx), b = await ctx.readJson();
    const target = q.byName.get(ctx.params.username);
    if (!target) throw new HttpError(404, 'not_found', 'Pengguna tidak ditemukan.');
    const role = b.role === undefined ? target.role : b.role;
    if (!ROLES.includes(role)) throw new HttpError(400, 'bad_request', 'Peran tidak valid.');
    const areas = cleanAreas(role, b.areas === undefined ? parseAreas(target) : b.areas);
    const disabled = b.disabled === undefined ? target.disabled : b.disabled ? 1 : 0;
    tx(db, () => {
      q.upd.run(role, JSON.stringify(areas), b.label === undefined ? target.label : String(b.label).slice(0, 80), disabled, Date.now(), target.id);
      if (q.admins.get().n < 1) throw new HttpError(409, 'last_admin', 'Harus ada minimal satu admin aktif.');
    });
    if (b.password !== undefined) await auth.setPassword(target.id, b.password);
    if (b.password !== undefined || disabled || role !== target.role) auth.revokeUser(target.id);
    audit({ user: me, action: 'user.update', target: target.username, detail: JSON.stringify({ role, areas, disabled, password: b.password !== undefined }), ip: ctx.ip });
    ctx.json(200, { user: row(q.byName.get(target.username)) });
  });

  r.get('/api/admin/status', (ctx) => {
    admin(ctx);
    const n = (sql, ...a) => db.prepare(sql).get(...a).n;
    let version = {};
    try { version = JSON.parse(require('node:fs').readFileSync(require('node:path').join(cfg.publicDir, 'version.json'), 'utf8')); } catch { /* belum ada */ }
    ctx.json(200, {
      version: version.version || null, commit: version.commit || null, builtAt: version.builtAt || null,
      uptimeSec: Math.round((Date.now() - startedAt) / 1000), node: process.version, env: cfg.prod ? 'production' : 'development',
      sheets: sheets.status(),
      counts: { users: n('SELECT COUNT(*) n FROM users WHERE disabled = 0'), sessions: n('SELECT COUNT(*) n FROM sessions WHERE expires_at > ?', Date.now()), docs: n('SELECT COUNT(*) n FROM docs'), cek: n('SELECT COUNT(*) n FROM cek'), audit: n('SELECT COUNT(*) n FROM audit') },
      lockedUsers: db.prepare('SELECT username, locked_until FROM users WHERE locked_until > ?').all(Date.now()).map((u) => ({ username: u.username, until: new Date(u.locked_until).toISOString() })),
    });
  });

  r.get('/api/admin/audit', (ctx) => {
    admin(ctx);
    const n = Math.min(500, Math.max(1, Number(ctx.query.get('limit')) || 100));
    ctx.json(200, { items: q.audit.all(n).map((a) => ({ ...a, at: new Date(a.at).toISOString() })) });
  });
};
