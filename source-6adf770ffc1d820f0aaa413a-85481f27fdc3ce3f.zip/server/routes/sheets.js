'use strict';
const { HttpError } = require('../http');
const { parseAreas, actorLabel } = require('../auth');

module.exports = (r, { sheets, audit, log }) => {
  r.post('/api/sheets/get_values', async (ctx) => {
    const user = ctx.requireUser();
    const b = await ctx.readJson();
    const res = await sheets.read(user, b.spreadsheetId, b.range);
    ctx.json(200, { payload: { range: res.range, values: res.values } });
  });

  r.post('/api/sheets/update_values', async (ctx) => {
    const user = ctx.requireUser();
    const b = await ctx.readJson();
    const isRet = /^'DATA PEMINJAM'!([UXW])\d{1,5}$/.test(String(b.range || ''));
    const res = isRet ? await sheets.writeReturn(user, b.spreadsheetId, b.range, b.values, 'text') : await sheets.write(user, b.spreadsheetId, b.range, b.values);
    audit({ user, action: 'sheet.write', target: `${res.what}`, detail: `${String(b.spreadsheetId).slice(0, 12)}… ${res.range} = ${res.value}`, ip: ctx.ip });
    log.info('sheet_write', { user: user.username, what: res.what, range: res.range, value: res.value });
    ctx.json(200, { payload: { updatedCells: res.updatedCells } });
  });

  r.post('/api/sheets/update_formulas', async (ctx) => {
    const user = ctx.requireUser();
    const b = await ctx.readJson();
    const res = await sheets.writeReturn(user, b.spreadsheetId, b.range, b.formulas, 'formula');
    audit({ user, action: 'sheet.write', target: res.what, detail: `${String(b.spreadsheetId).slice(0, 12)}… ${res.range}`, ip: ctx.ip });
    ctx.json(200, { payload: { updatedCells: res.updatedCells } });
  });

  r.post('/api/sheets/append_values', async (ctx) => {
    const user = ctx.requireUser();
    const b = await ctx.readJson();
    // waktu dan pelaku diisi SERVER dari sesi login; klien tidak bisa memalsukannya
    if (Array.isArray(b.values) && Array.isArray(b.values[0]) && b.values[0].length === 13) {
      b.values[0][0] = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      b.values[0][12] = actorLabel(user);
    }
    const res = await sheets.appendLog(user, b.values);
    audit({ user, action: 'log.monitor', target: String(res.row[1]).slice(0, 60), detail: String(res.row[2]).slice(0, 80), ip: ctx.ip });
    ctx.json(200, { payload: { updatedCells: 13 } });
  });

  r.post('/api/drive/create_file', async (ctx) => {
    const user = ctx.requireUser();
    const b = await ctx.readJson();
    const f = await sheets.uploadReturnPhoto(user, b);
    audit({ user, action: 'drive.upload', target: f.title, detail: `${f.bytes} byte`, ip: ctx.ip });
    ctx.json(200, { payload: { id: f.id, title: f.title, viewUrl: f.viewUrl, folder: f.folder } });
  });

  // Daftar area dan ID spreadsheet-nya, dibaca server dari sheet MASTER. Akun daerah hanya menerima areanya sendiri.
  r.get('/api/areas', async (ctx) => {
    const user = ctx.requireUser();
    await sheets.refreshAreas(false);
    const out = {};
    for (const [code, a] of sheets.areas()) {
      if (user.role === 'admin' || user.role === 'pusat' || (user.role === 'daerah' && parseAreas(user).includes(code))) out[code] = { name: a.name, sheetId: a.sheetId };
    }
    ctx.json(200, { areas: out, error: sheets.status().areasError || '' });
  });

  r.post('/api/sheets/invalidate', (ctx) => {
    const user = ctx.requireUser();
    if (user.role === 'admin' || user.role === 'pusat') sheets.invalidate(); // akun lain: tidak berbuat apa-apa (cache pendek kedaluwarsa sendiri)
    ctx.json(200, { ok: true });
  });
};
