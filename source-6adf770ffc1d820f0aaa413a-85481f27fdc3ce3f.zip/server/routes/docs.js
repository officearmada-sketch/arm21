'use strict';
// Penyimpanan dokumen generik (pengganti database artefak) dengan aturan akses per koleksi, ditegakkan di server.
const crypto = require('node:crypto');
const { HttpError } = require('../http');

const COLL_RE = /^[A-Za-z0-9_-]{1,64}$/;
const ID_RE = /^[A-Za-z0-9_.:@+~-]{1,200}$/;
const FIELD_RE = /^[A-Za-z0-9_]{1,40}$/;
const MAX_DOC = 4 * 1024 * 1024;

// Level: 'any' = semua pengguna yang login; 'staff' = admin dan Armada Pusat (yang di Monitor boleh impor/ubah data);
// 'admin' = hanya admin. Koleksi tak terdaftar = baca semua, tulis admin.
const RULES = {
  log: { read: 'any', write: 'writer', del: 'admin', stamp: true, append: true, max: 16 * 1024, cap: 50000 },
  trips: { read: 'any', write: 'staff', del: 'staff' },
  imports: { read: 'any', write: 'staff', del: 'admin' },
  // laporan pengembalian unit (kondisi, keterangan, foto): akun non-viewer; akun daerah hanya untuk areanya (lihat areaOk)
  kembali: { read: 'writer', write: 'writer', del: 'staff', area: true, max: 400 * 1024 },
  // status pengembalian ringan (dibaca daftar peminjaman)
  kstat: { read: 'any', write: 'writer', del: 'staff', area: true, max: 16 * 1024 },
  config: { read: 'any', write: 'admin', del: 'admin' },
  // pemakaian unit (SPPD mobil inventaris): ID dokumen = nomor SPPD. Akun daerah hanya melihat/mengubah dokumen berkode areanya sendiri
  // (kodeField), tidak boleh membuat dokumen, dan tidak boleh mengubah kolom milik Armada Pusat (PAKAI_STAFF).
  pakai: { read: 'writer', write: 'writer', del: 'staff', kodeField: 'kode', max: 128 * 1024 },
};
const PAKAI_STAFF = ['sppd', 'nib', 'nama', 'agenda', 'bTxt', 'pTxt', 'berangkat', 'pulang', 'nopol', 'jenis', 'merk', 'tipe', 'lokasi', 'grup', 'kode', 'area',
  'ar', 'arAt', 'arBy', 'pu', 'puAt', 'puBy', 'dep', 'depAt', 'depBy', 'createdAt', 'createdBy'];
const userAreas = (user) => { try { return JSON.parse(user.areas) || []; } catch { return []; } };
// JMB dan JMBR dianggap area yang sama (awalan kode), seperti pada Peminjaman
const kodeOk = (user, kode) => { const k = String(kode || '').toUpperCase(); return k.length >= 2 && userAreas(user).some((a) => a.startsWith(k) || k.startsWith(a)); };
// baca per dokumen (butuh isi dokumen): akun daerah hanya untuk koleksi berkode area
const dataVisible = (c, data, user) => !rule(c).kodeField || user.role !== 'daerah' || kodeOk(user, data && data[rule(c).kodeField]);
const rule = (c) => RULES[c] || { read: 'any', write: 'admin', del: 'admin' };
const allowed = (level, user) => level === 'any' || (level === 'writer' ? user.role !== 'viewer'
  : level === 'staff' ? user.role === 'admin' || user.role === 'pusat' : user.role === 'admin');
// ID dokumen berupa nomor form (mis. JMBR261019002): akun daerah hanya boleh menulis untuk kode areanya sendiri
const areaOk = (c, id, user) => {
  if (!rule(c).area || user.role !== 'daerah') return true;
  let list = []; try { list = JSON.parse(user.areas); } catch { /* kosong */ }
  const L = ((String(id || '').toUpperCase().match(/^[A-Z]+/) || [''])[0]);
  // JMB dan JMBR dianggap area yang sama (awalan kode)
  return /\d{6,}$/.test(id || '') && L.length >= 2 && list.some((a) => a.startsWith(L) || L.startsWith(a));
};
// baca: akun daerah hanya melihat dokumen areanya pada koleksi berarea
const readableArea = (c, id, user) => {
  if (!rule(c).area || user.role !== 'daerah') return true;
  let list = []; try { list = JSON.parse(user.areas); } catch { /* kosong */ }
  const L = ((String(id || '').toUpperCase().match(/^[A-Z]+/) || [''])[0]);
  return L.length >= 2 && list.some((a) => a.startsWith(L) || L.startsWith(a));
};
const DENY = 'Akun Anda tidak berwenang untuk tindakan ini.';

module.exports = (r, { db, audit }) => {
  const q = {
    get: db.prepare('SELECT * FROM docs WHERE path = ?'),
    upsert: db.prepare(`INSERT INTO docs (path, collection, id, data, version, updated_at, updated_by) VALUES (?,?,?,?,1,?,?)
      ON CONFLICT(path) DO UPDATE SET data = excluded.data, version = docs.version + 1, updated_at = excluded.updated_at, updated_by = excluded.updated_by RETURNING version`),
    del: db.prepare('DELETE FROM docs WHERE path = ?'),
  };
  const shape = (d) => ({ id: d.id, data: JSON.parse(d.data), version: d.version, updatedAt: d.updated_at });
  const check = (c, id) => {
    if (!COLL_RE.test(c)) throw new HttpError(400, 'bad_request', 'Nama koleksi tidak valid.');
    if (id !== undefined && (!ID_RE.test(id) || id === '.' || id === '..')) throw new HttpError(400, 'bad_request', 'ID dokumen tidak valid.');
  };
  const payload = (b, c, user) => {
    if (!b || typeof b.data !== 'object' || b.data === null || Array.isArray(b.data)) throw new HttpError(400, 'bad_request', 'Isi dokumen harus berupa objek JSON.');
    const data = { ...b.data };
    if (rule(c).stamp) { data.by = user.username; data.serverAt = new Date().toISOString(); } // pelaku diisi server, bukan browser
    const s = JSON.stringify(data);
    if (Buffer.byteLength(s) > (rule(c).max || MAX_DOC)) throw new HttpError(413, 'too_large', 'Dokumen terlalu besar.');
    return s;
  };

  r.get('/api/db/:collection', (ctx) => {
    const user = ctx.requireUser(), c = ctx.params.collection;
    check(c);
    if (!allowed(rule(c).read, user)) throw new HttpError(403, 'forbidden', 'Tidak boleh membaca koleksi ini.');
    const limit = Math.min(2000, Math.max(1, Number(ctx.query.get('limit')) || 1000));
    const ob = ctx.query.get('orderBy');
    let sql = 'SELECT * FROM docs WHERE collection = ?', args = [c];
    if (ob) {
      if (!FIELD_RE.test(ob)) throw new HttpError(400, 'bad_request', 'Kolom urutan tidak valid.');
      sql += ` ORDER BY json_extract(data, ?) ${ctx.query.get('dir') === 'desc' ? 'DESC' : 'ASC'}`;
      args.push('$.' + ob);
    } else sql += ' ORDER BY id';
    sql += ' LIMIT ?'; args.push(limit);
    let total = 0;
    const docs = [];
    for (const d of db.prepare(sql).all(...args)) {
      if (!readableArea(c, d.id, user)) continue;
      const sh = shape(d);
      if (!dataVisible(c, sh.data, user)) continue;
      total += d.data.length; if (total > 24 * 1024 * 1024) break; // batas ukuran satu balasan
      docs.push(sh);
    }
    ctx.json(200, { docs });
  });

  r.get('/api/db/:collection/:id', (ctx) => {
    const user = ctx.requireUser(), { collection: c, id } = ctx.params;
    check(c, id);
    if (!allowed(rule(c).read, user)) throw new HttpError(403, 'forbidden', 'Tidak boleh membaca koleksi ini.');
    const d = q.get.get(`${c}/${id}`);
    if (d && !readableArea(c, id, user)) throw new HttpError(403, 'forbidden', 'Tidak boleh membaca dokumen ini.');
    const sh = d && readableArea(c, id, user) ? shape(d) : null;
    if (sh && !dataVisible(c, sh.data, user)) throw new HttpError(403, 'forbidden', 'Tidak boleh membaca dokumen ini.');
    ctx.json(200, sh ? { exists: true, ...sh } : { exists: false, id });
  });

  r.put('/api/db/:collection/:id', async (ctx) => {
    const user = ctx.requireUser(), { collection: c, id } = ctx.params;
    check(c, id);
    if (!allowed(rule(c).write, user) || !areaOk(c, id, user)) throw new HttpError(403, 'forbidden', DENY);
    if (rule(c).append && q.get.get(`${c}/${id}`)) throw new HttpError(403, 'forbidden', DENY); // log hanya boleh ditambah, tidak ditimpa
    const s = payload(await ctx.readJson(), c, user);
    if (rule(c).kodeField && user.role === 'daerah') {
      const old = q.get.get(`${c}/${id}`), nd = JSON.parse(s);
      const od = old ? JSON.parse(old.data) : null;
      const same = (f) => JSON.stringify(nd[f]) === JSON.stringify(od[f]);
      if (!od || !kodeOk(user, od[rule(c).kodeField]) || !PAKAI_STAFF.every(same)) throw new HttpError(403, 'forbidden', DENY);
    }
    const v = q.upsert.get(`${c}/${id}`, c, id, s, Date.now(), user.id).version;
    if (c !== 'log') audit({ user, action: 'db.set', target: `${c}/${id}`, detail: `v${v} ${s.length}B`, ip: ctx.ip });
    ctx.json(200, { ok: true, version: v });
  });

  r.post('/api/db/:collection', async (ctx) => {
    const user = ctx.requireUser(), c = ctx.params.collection;
    check(c);
    if (!allowed(rule(c).write, user) || !areaOk(c, '', user)) throw new HttpError(403, 'forbidden', DENY);
    const s = payload(await ctx.readJson(), c, user);
    if (rule(c).cap && db.prepare('SELECT COUNT(*) n FROM docs WHERE collection = ?').get(c).n >= rule(c).cap) throw new HttpError(429, 'quota', 'Koleksi ini sudah penuh.');
    const id = crypto.randomBytes(10).toString('hex');
    q.upsert.get(`${c}/${id}`, c, id, s, Date.now(), user.id);
    ctx.json(201, { ok: true, id });
  });

  r.delete('/api/db/:collection/:id', (ctx) => {
    const user = ctx.requireUser(), { collection: c, id } = ctx.params;
    check(c, id);
    if (!allowed(rule(c).del, user)) throw new HttpError(403, 'forbidden', DENY);
    if (rule(c).kodeField) { // pemakaian yang sudah berangkat atau kembali adalah arsip: tidak boleh dihapus
      const old = q.get.get(`${c}/${id}`), od = old ? JSON.parse(old.data) : null;
      if (od && (od.dep || od.returned)) throw new HttpError(409, 'conflict', 'Pemakaian yang sudah berangkat tidak bisa dihapus.');
    }
    q.del.run(`${c}/${id}`);
    audit({ user, action: 'db.delete', target: `${c}/${id}`, ip: ctx.ip });
    ctx.json(200, { ok: true });
  });
};

// Shared authorization rules for the Postgres-backed Netlify endpoints.
module.exports.policy = { COLL_RE, ID_RE, FIELD_RE, MAX_DOC, rule, allowed, areaOk, readableArea, dataVisible, kodeOk, PAKAI_STAFF, DENY };
