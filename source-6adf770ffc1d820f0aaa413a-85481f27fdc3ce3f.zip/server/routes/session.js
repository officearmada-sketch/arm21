'use strict';
const zlib = require('node:zlib');
const { HttpError, serializeCookie } = require('../http');
const { publicUser } = require('../auth');

module.exports = (r, { cfg, db, auth, audit }) => {
  const sessionBody = (user) => ({ user: publicUser(user), key: cfg.dataKey });
  const cookieOpts = () => ({ secure: cfg.cookieSecure, httpOnly: true, sameSite: 'Lax', path: '/' });

  r.post('/api/login', async (ctx) => {
    const b = await ctx.readJson();
    const { token, user } = await auth.login(ctx, b.username, b.password);
    ctx.setCookie(serializeCookie(cfg.cookieName, token, { ...cookieOpts(), maxAge: cfg.sessionMaxHours * 3600 }));
    ctx.json(200, sessionBody(user));
  });

  r.post('/api/login/google', async (ctx) => {
    const { verifyIdentity } = require('../google-identity');
    const identity = await verifyIdentity(ctx.req.headers.cookie, cfg.identityUrl);
    const { token, user } = await auth.loginIdentity(ctx, identity.id);
    ctx.setCookie(serializeCookie(cfg.cookieName, token, { ...cookieOpts(), maxAge: cfg.sessionMaxHours * 3600 }));
    ctx.json(200, sessionBody(user));
  });

  r.post('/api/google/link', async (ctx) => {
    const user = ctx.requireUser();
    const { verifyIdentity } = require('../google-identity');
    const identity = await verifyIdentity(ctx.req.headers.cookie, cfg.identityUrl);
    try {
      db.prepare('INSERT INTO identity_links (identity_id, user_id, created_at) VALUES (?,?,?)').run(identity.id, user.id, Date.now());
    } catch (e) {
      const existing = db.prepare('SELECT user_id FROM identity_links WHERE identity_id = ?').get(identity.id);
      if (!existing || existing.user_id !== user.id) throw new HttpError(409, 'google_linked', 'Akun sudah memiliki tautan Google lain. Hubungi admin.');
    }
    audit({ user, action: 'google.link', ip: ctx.ip });
    ctx.json(200, { ok: true });
  });

  r.get('/api/session', (ctx) => {
    ctx.requireUser();
    ctx.json(200, sessionBody(ctx.user));
  });

  r.post('/api/logout', (ctx) => {
    if (ctx.session) { auth.logout(ctx.session.hash); audit({ user: ctx.user, action: 'logout', ip: ctx.ip }); }
    ctx.setCookie(serializeCookie(cfg.cookieName, '', { ...cookieOpts(), maxAge: 0 }));
    ctx.json(200, { ok: true });
  });

  r.post('/api/password', async (ctx) => {
    const u = ctx.requireUser();
    const b = await ctx.readJson();
    if (typeof b.current !== 'string' || typeof b.next !== 'string') throw new HttpError(400, 'bad_request', 'Isi password saat ini dan yang baru.');
    await auth.changePassword(u, b.current, b.next);
    auth.revokeUser(u.id); // semua sesi lama berakhir, termasuk milik penyerang bila ada
    audit({ user: u, action: 'password.change', ip: ctx.ip });
    ctx.setCookie(serializeCookie(cfg.cookieName, '', { ...cookieOpts(), maxAge: 0 }));
    ctx.json(200, { ok: true, relogin: true });
  });

  // Data bawaan Monitor (dulu terenkripsi di dalam halaman). Sekarang hanya terkirim ke pengguna yang sudah login.
  const kv = db.prepare("SELECT value FROM kv WHERE key = 'builtin_gz'");
  let builtin = null, builtinAt = 0;
  r.get('/api/builtin', (ctx) => {
    ctx.requireUser();
    if (!builtin || Date.now() - builtinAt > 60000) {
      const row = kv.get();
      builtin = row ? zlib.gunzipSync(Buffer.from(row.value, 'base64')) : Buffer.from('[]');
      builtinAt = Date.now();
    }
    ctx.raw(200, builtin, 'application/json; charset=utf-8');
  });
};
