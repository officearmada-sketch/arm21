'use strict';
// Gambar yang tidak boleh publik (tanda tangan dan stempel pada form peminjaman, template checklist).
// Disimpan di luar folder public dan hanya dikirim ke akun yang sudah login dan bukan "hanya lihat".
const fs = require('node:fs');
const path = require('node:path');
const { HttpError } = require('../http');

const FILES = { 'ttd_staf.png': 'image/png', 'ttd_mgr.png': 'image/png', 'chk.jpg': 'image/jpeg' };

module.exports = (r, { cfg }) => {
  const cache = new Map();
  r.get('/api/asset/:name', (ctx) => {
    const user = ctx.requireUser();
    if (user.role === 'viewer') throw new HttpError(403, 'forbidden', 'Akun ini tidak boleh membuka berkas ini.');
    const name = ctx.params.name;
    if (!Object.prototype.hasOwnProperty.call(FILES, name)) throw new HttpError(404, 'not_found', 'Berkas tidak ditemukan.');
    let buf = cache.get(name);
    if (!buf) {
      try { buf = fs.readFileSync(path.join(cfg.privateDir, name)); }
      catch { throw new HttpError(404, 'not_found', 'Berkas belum dipasang di server.'); }
      cache.set(name, buf);
    }
    ctx.raw(200, buf, FILES[name], { 'Cache-Control': 'private, max-age=3600' });
  });
};
