'use strict';
// Catatan koreksi dan status "Clear" pada Monitor. Semua akun boleh menulis; pelaku dicatat SERVER dari sesi login.
const { HttpError } = require('../http');
const { actorLabel } = require('../auth');
const { tx } = require('../db');

const HIST_KEEP = 30;

module.exports = (r, { db, audit }) => {
  const q = {
    all: db.prepare('SELECT * FROM cek'),
    hist: db.prepare('SELECT key, at, oleh, act, note FROM cek_hist ORDER BY key, at DESC, id DESC'),
    cur: db.prepare('SELECT * FROM cek WHERE key = ?'),
    upsert: db.prepare(`INSERT INTO cek (key, cek, catatan, oleh, oleh_user, at) VALUES (?,?,?,?,?,?)
      ON CONFLICT(key) DO UPDATE SET cek = excluded.cek, catatan = excluded.catatan, oleh = excluded.oleh, oleh_user = excluded.oleh_user, at = excluded.at`),
    setJ: db.prepare('UPDATE cek SET jenis = ?, jenis_by = ?, jenis_at = ?, oleh = ?, oleh_user = ?, at = ? WHERE key = ?'),
    insH: db.prepare('INSERT INTO cek_hist (key, at, oleh, oleh_user, act, note) VALUES (?,?,?,?,?,?)'),
    prune: db.prepare('DELETE FROM cek_hist WHERE key = ? AND id NOT IN (SELECT id FROM cek_hist WHERE key = ? ORDER BY at DESC, id DESC LIMIT ?)'),
    histOf: db.prepare('SELECT at, oleh AS who, act, note FROM cek_hist WHERE key = ? ORDER BY at DESC, id DESC'),
  };
  const iso = (t) => new Date(t).toISOString();
  const shape = (row, hist) => ({ k: row.key, cek: row.cek, catatan: row.catatan, oleh: row.oleh, at: iso(row.at), jenis: row.jenis || '', jenisBy: row.jenis_by || '', jenisAt: row.jenis_at ? iso(row.jenis_at) : '', hist: hist.map((h) => ({ at: iso(h.at), by: h.who || h.oleh, act: h.act, note: h.note })) });

  r.get('/api/cek', (ctx) => {
    ctx.requireUser();
    const hist = new Map();
    for (const h of q.hist.all()) { if (!hist.has(h.key)) hist.set(h.key, []); const a = hist.get(h.key); if (a.length < HIST_KEEP) a.push(h); }
    ctx.json(200, { items: q.all.all().map((row) => shape(row, hist.get(row.key) || [])) });
  });

  r.post('/api/cek', async (ctx) => {
    const user = ctx.requireUser();
    const b = await ctx.readJson();
    const key = typeof b.key === 'string' ? b.key : '', act = b.act, note = typeof b.note === 'string' ? b.note.trim() : '';
    if (!key || key.length > 300) throw new HttpError(400, 'bad_request', 'Kunci trip tidak valid.');
    if (!['note', 'clear', 'open', 'jenis'].includes(act)) throw new HttpError(400, 'bad_request', 'Aksi tidak dikenal.');
    if (user.role === 'viewer') throw new HttpError(403, 'forbidden', 'Akun lihat saja tidak bisa mengubah koreksi.');
    if (note.length > 1000) throw new HttpError(400, 'bad_request', 'Catatan maksimal 1000 karakter.');
    if (act === 'clear' && !note) throw new HttpError(400, 'note_required', 'Isi keterangan sebelum menandai clear.');
    const now = Date.now(), label = actorLabel(user);
    if (act === 'jenis') {
      const to = b.jenis;
      if (to !== 'TITIKAN' && to !== 'LANGSUNG') throw new HttpError(400, 'bad_request', 'Jenis trip harus TITIKAN atau LANGSUNG.');
      if (user.role === 'viewer') throw new HttpError(403, 'forbidden', 'Akun lihat saja tidak bisa mengubah jenis trip.');
      const outJ = tx(db, () => {
        const cur = q.cur.get(key);
        if (!cur) q.upsert.run(key, '', '', label, user.username, now);
        q.setJ.run(to, label, now, label, user.username, now, key);
        q.insH.run(key, now, label, user.username, 'jenis', (note || 'Jenis diubah') .slice(0, 1000));
        q.prune.run(key, key, HIST_KEEP);
        return shape(q.cur.get(key), q.histOf.all(key));
      });
      audit({ user, action: 'cek.jenis', target: key, detail: to, ip: ctx.ip });
      return ctx.json(200, outJ);
    }
    const out = tx(db, () => {
      const cur = q.cur.get(key);
      const cekVal = act === 'clear' ? 'CLEAR' : act === 'open' ? '' : cur ? cur.cek : '';
      q.upsert.run(key, cekVal, note, label, user.username, now);
      q.insH.run(key, now, label, user.username, act, note);
      q.prune.run(key, key, HIST_KEEP);
      return shape(q.cur.get(key), q.histOf.all(key));
    });
    audit({ user, action: 'cek.' + act, target: key, detail: note.slice(0, 120), ip: ctx.ip });
    ctx.json(200, out);
  });
};
