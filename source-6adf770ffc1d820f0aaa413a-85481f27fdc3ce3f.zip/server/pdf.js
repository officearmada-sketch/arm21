'use strict';
// PDF satu halaman A4 berisi satu foto JPEG (tanpa dependensi). JPEG disematkan apa adanya (DCTDecode).
function jpegInfo(buf) {
  let i = 2;
  while (i + 9 < buf.length) {
    if (buf[i] !== 0xff) { i++; continue; }
    const m = buf[i + 1];
    if (m === 0xd8 || (m >= 0xd0 && m <= 0xd7) || m === 0x01 || m === 0xff) { i += (m === 0xff ? 1 : 2); continue; }
    const len = buf.readUInt16BE(i + 2);
    if ((m >= 0xc0 && m <= 0xcf) && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) return { h: buf.readUInt16BE(i + 5), w: buf.readUInt16BE(i + 7), comps: buf[i + 9] };
    i += 2 + len;
  }
  return null;
}
function jpegToPdf(jpeg) {
  const info = jpegInfo(jpeg);
  if (!info || !info.w || !info.h) throw new Error('JPEG tidak terbaca');
  const W = 595.28, H = 841.89, k = Math.min(W / info.w, H / info.h), w = +(info.w * k).toFixed(2), h = +(info.h * k).toFixed(2);
  const x = +((W - w) / 2).toFixed(2), y = +((H - h) / 2).toFixed(2);
  const cs = info.comps === 1 ? '/DeviceGray' : info.comps === 4 ? '/DeviceCMYK' : '/DeviceRGB';
  const content = Buffer.from(`q ${w} 0 0 ${h} ${x} ${y} cm /Im0 Do Q`);
  const parts = [], offs = [];
  let len = 0;
  const push = (b) => { const bb = Buffer.isBuffer(b) ? b : Buffer.from(b, 'latin1'); parts.push(bb); len += bb.length; };
  const obj = (n, body) => { offs[n] = len; push(`${n} 0 obj\n`); push(body); push('\nendobj\n'); };
  push('%PDF-1.4\n');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, '<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
  obj(3, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>`);
  offs[4] = len; push('4 0 obj\n'); push(`<< /Type /XObject /Subtype /Image /Width ${info.w} /Height ${info.h} /ColorSpace ${cs} /BitsPerComponent 8 /Filter /DCTDecode${info.comps === 4 ? ' /Decode [1 0 1 0 1 0 1 0]' : ''} /Length ${jpeg.length} >>\nstream\n`); push(jpeg); push('\nendstream\nendobj\n');
  offs[5] = len; push('5 0 obj\n'); push(`<< /Length ${content.length} >>\nstream\n`); push(content); push('\nendstream\nendobj\n');
  const xref = len;
  let t = 'xref\n0 6\n0000000000 65535 f \n';
  for (let n = 1; n <= 5; n++) t += String(offs[n]).padStart(10, '0') + ' 00000 n \n';
  push(t + `trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
  return Buffer.concat(parts);
}
module.exports = { jpegToPdf, jpegInfo };
