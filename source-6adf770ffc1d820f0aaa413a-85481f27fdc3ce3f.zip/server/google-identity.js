'use strict';
const { HttpError, parseCookies } = require('./http');

// Always verify with this site's Identity API; never trust browser-supplied claims.
async function verifyIdentity(cookie, endpoint, fetchImpl = fetch) {
  const token = parseCookies(cookie || '').nf_jwt;
  if (!token || token.length > 16384) throw new HttpError(401, 'google_session', 'Silakan masuk dengan Google lagi.');
  if (!endpoint || !/^https:\/\//.test(endpoint)) throw new HttpError(503, 'google_unavailable', 'Login Google belum dikonfigurasi.');
  let response;
  try {
    response = await fetchImpl(endpoint.replace(/\/$/, '') + '/user', {
      headers: { Authorization: 'Bearer ' + token }, redirect: 'error', signal: AbortSignal.timeout(10000),
    });
  } catch { throw new HttpError(503, 'google_unavailable', 'Layanan Google sedang tidak tersedia. Coba lagi.'); }
  if (!response.ok) throw new HttpError(401, 'google_session', 'Sesi Google tidak valid. Silakan masuk lagi.');
  const user = await response.json();
  if (!user.id || !user.email || !user.confirmed_at) throw new HttpError(403, 'google_unverified', 'Email akun Google belum terverifikasi.');
  return { id: user.id, email: user.email, roles: Array.isArray(user.app_metadata?.roles) ? user.app_metadata.roles.filter(role => typeof role === 'string') : [] };
}
module.exports = { verifyIdentity };
