'use strict';
const { load } = require('./config');
const { createApp } = require('./app');

let cfg;
try { cfg = load(); } catch (e) { console.error('Konfigurasi gagal: ' + e.message); process.exit(78); }
const app = createApp(cfg);
const { log } = app;

app.server.listen(cfg.port, cfg.host, () => {
  log.info('server_mulai', { port: cfg.port, host: cfg.host, prod: cfg.prod, db: cfg.dbFile, sheets: app.sheets.configured() ? 'dikonfigurasi' : 'BELUM dikonfigurasi' });
  if (app.sheets.configured()) app.sheets.refreshAreas(true).catch(() => {});
});

let closing = false;
async function shutdown(sig) {
  if (closing) return;
  closing = true;
  log.info('server_berhenti', { sig });
  const t = setTimeout(() => process.exit(1), 15000);
  t.unref();
  await app.close();
  process.exit(0);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('unhandledRejection', (e) => log.error('unhandled_rejection', { error: e && e.message, stack: e && e.stack }));
process.on('uncaughtException', (e) => { log.error('uncaught_exception', { error: e.message, stack: e.stack }); shutdown('uncaughtException'); });
