'use strict';
const crypto = require('node:crypto');
const { HttpError } = require('./http');

const ROLES = ['admin', 'pusat', 'daerah', 'viewer'];
const SCRYPT = { N: 32768, r: 8, p: 1, keylen: 64, maxmem: 96 * 1024 * 1024 };

const scrypt = (pw, salt, o) => new Promise((res, rej) => crypto.scrypt(pw, salt, o.keylen, { N: o.N, r: o.r, p: o.p, maxmem: SCRYPT.maxmem }, (e, k) => (e ? rej(e) : res(k))));

async function hashPassword(pw) {
  if (typeof pw !== 'string' || pw.length < 8 || pw.length > 200) throw new HttpError(400, 'weak_password', 'Password minimal 8 karakter.');
  const salt = crypto.randomBytes(16);
  const key = await scrypt(pw, salt, SCRYPT);
  return `scrypt$${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString('base64')}$${key.toString('base64')}`;
}

async function verifyPassword(pw, stored) {
  const [alg, N, r, p, saltB, keyB] = String(stored).split('$');
  if (alg !== 'scrypt') return false;
  const salt = Buffer.from(saltB, 'base64'), want = Buffer.from(keyB, 'base64');
  const got = await scrypt(String(pw), salt, { N: +N, r: +r, p: +p, keylen: want.length });
  return got.length === want.length && crypto.timingSafeEqual(got, want);
}

// Hash palsu dipakai agar waktu respons sama untuk username yang tidak ada (mencegah user enumeration).
let dummy;
async function dummyVerify(pw) {
  dummy = dummy || (await hashPassword('dummy-password-untuk-waktu-sama'));
  await verifyPassword(pw, dummy);
}

const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');

// Pembatas laju dalam memori (satu proses). Kunci -> daftar waktu kejadian dalam jendela.
function createLimiter(max, windowMs) {
  const hits = new Map();
  return {
    hit(key, now = Date.now()) {
      const arr = (hits.get(key) || []).filter((t) => now - t < windowMs);
      arr.push(now);
      hits.set(key, arr);
      if (hits.size > 5000) for (const [k, v] of hits) if (!v.some((t) => now - t < windowMs)) hits.delete(k);
      return arr.length <= max;
    },
    reset(key) { hits.delete(key); },
  };
}

const parseAreas = (u) => { try { return JSON.parse(u.areas); } catch { return []; } };

// Label pelaku yang tampil di catatan: akun area -> "Armada Lampung", dst. Selalu dihitung server dari data akun.
const AREA_NAMES = {
  PST: 'Pusat', CPY: 'Cipayung', MRD: 'Marunda', BDG: 'Bandung', CKR: 'Cikarang', KLW: 'Kaliwungu', BGR: 'Bogor',
  LGD: 'Legundi', MDN: 'Madiun', TGR: 'Tangerang', BJM: 'Banjarmasin', PRB: 'Probolinggo', MKS: 'Makassar',
  DLS: 'Deliserdang', LPG: 'Lampung', PJG: 'Pejagan', PKB: 'Pekanbaru', SLK: 'Solok', PLB: 'Palembang',
  JMBR: 'Jembrana', BPN: 'Balikpapan', PNK: 'Pontianak',
};
function actorLabel(u) {
  const areas = parseAreas(u);
  if (u.role === 'daerah') return 'Armada ' + (areas.map((c) => AREA_NAMES[c] || c).join(', ') || u.username);
  if (u.role === 'pusat') return u.username.toLowerCase() === 'manager' ? 'Manager Armada' : 'Armada Pusat';
  if (u.role === 'admin') return 'Admin';
  return `Pengguna lihat (${u.username})`;
}

const publicUser = (u) => ({ username: u.username, role: u.role, areas: parseAreas(u), label: actorLabel(u) });

function createAuth({ db, cfg, log, audit }) {
  const q = {
    userByName: db.prepare('SELECT * FROM users WHERE username = ?'),
    userById: db.prepare('SELECT * FROM users WHERE id = ?'),
    fail: db.prepare('UPDATE users SET failed_count = failed_count + 1, locked_until = CASE WHEN failed_count + 1 >= ? THEN ? ELSE locked_until END, updated_at = ? WHERE id = ?'),
    ok: db.prepare('UPDATE users SET failed_count = 0, locked_until = 0, last_login_at = ?, updated_at = ? WHERE id = ?'),
    insSess: db.prepare('INSERT INTO sessions (id_hash, user_id, created_at, last_seen_at, expires_at, ip, ua) VALUES (?,?,?,?,?,?,?)'),
    getSess: db.prepare('SELECT s.*, u.id AS uid FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id_hash = ?'),
    touch: db.prepare('UPDATE sessions SET last_seen_at = ? WHERE id_hash = ?'),
    delSess: db.prepare('DELETE FROM sessions WHERE id_hash = ?'),
    delUserSess: db.prepare('DELETE FROM sessions WHERE user_id = ?'),
    purge: db.prepare('DELETE FROM sessions WHERE expires_at < ?'),
    setPw: db.prepare('UPDATE users SET password_hash = ?, failed_count = 0, locked_until = 0, updated_at = ? WHERE id = ?'),
  };
  const ipLimiter = createLimiter(cfg.ipLoginLimit, 10 * 60 * 1000);

  async function login(ctx, username, password) {
    const now = Date.now();
    if (typeof username !== 'string' || typeof password !== 'string' || !username || !password || username.length > 64 || password.length > 200) {
      throw new HttpError(400, 'bad_request', 'Isi username dan password.');
    }
    if (!ipLimiter.hit(ctx.ip, now)) {
      audit({ action: 'login.ratelimit', detail: username, ip: ctx.ip });
      throw new HttpError(429, 'rate_limited', 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.', { retryAfter: 600 });
    }
    const u = q.userByName.get(username.trim());
    if (!u || u.disabled) {
      await dummyVerify(password);
      audit({ action: 'login.fail', detail: u ? 'dinonaktifkan' : 'tidak dikenal', target: username.trim().slice(0, 24).replace(/[^A-Za-z0-9._-]/g, '?'), ip: ctx.ip });
      throw new HttpError(401, 'invalid_credentials', 'Username atau password salah.');
    }
    if (u.locked_until && u.locked_until <= now) { db.prepare('UPDATE users SET failed_count = 0, locked_until = 0 WHERE id = ?').run(u.id); u.failed_count = 0; u.locked_until = 0; }
    if (u.locked_until > now) {
      audit({ user: u, action: 'login.locked', ip: ctx.ip });
      throw new HttpError(429, 'locked', 'Akun dikunci sementara karena terlalu banyak percobaan. Coba lagi nanti.', { retryAfter: Math.ceil((u.locked_until - now) / 1000) });
    }
    if (!(await verifyPassword(password, u.password_hash))) {
      q.fail.run(cfg.loginMaxFails, now + cfg.loginLockMin * 60000, now, u.id);
      audit({ user: u, action: 'login.fail', detail: 'password salah', ip: ctx.ip });
      throw new HttpError(401, 'invalid_credentials', 'Username atau password salah.');
    }
    ipLimiter.reset(ctx.ip);
    q.ok.run(now, now, u.id);
    const token = crypto.randomBytes(32).toString('base64url');
    q.insSess.run(sha256(token), u.id, now, now, now + cfg.sessionMaxHours * 3600000, ctx.ip, String(ctx.req.headers['user-agent'] || '').slice(0, 200));
    audit({ user: u, action: 'login.ok', ip: ctx.ip });
    return { token, user: q.userById.get(u.id) };
  }

  // Memuat sesi dari cookie; null jika tidak ada/kedaluwarsa/akun dinonaktifkan.
  function resolve(token) {
    if (!token || token.length > 100) return null;
    const now = Date.now();
    const h = sha256(token);
    const s = q.getSess.get(h);
    if (!s) return null;
    const u = q.userById.get(s.user_id);
    if (!u || u.disabled || s.expires_at < now || now - s.last_seen_at > cfg.sessionIdleMin * 60000) {
      q.delSess.run(h);
      return null;
    }
    if (now - s.last_seen_at > 60000) q.touch.run(now, h);
    return { user: u, hash: h };
  }

  return {
    async loginIdentity(ctx, identityId) {
      const u = db.prepare('SELECT u.* FROM users u JOIN identity_links l ON l.user_id = u.id WHERE l.identity_id = ?').get(identityId);
      if (!u || u.disabled) throw new HttpError(403, 'google_unlinked', 'Akun Google belum ditautkan. Masuk dengan username dan password, lalu pilih Hubungkan Google.');
      const now = Date.now();
      const token = crypto.randomBytes(32).toString('base64url');
      q.insSess.run(sha256(token), u.id, now, now, now + cfg.sessionMaxHours * 3600000, ctx.ip, String(ctx.req.headers['user-agent'] || '').slice(0, 200));
      q.ok.run(now, now, u.id);
      audit({ user: u, action: 'login.google', ip: ctx.ip });
      return { token, user: u };
    },
    login,
    resolve,
    logout: (hash) => q.delSess.run(hash),
    revokeUser: (id) => q.delUserSess.run(id),
    purgeExpired: () => q.purge.run(Date.now()).changes,
    async changePassword(user, current, next) {
      if (!(await verifyPassword(current, user.password_hash))) throw new HttpError(403, 'invalid_credentials', 'Password saat ini salah.');
      const h = await hashPassword(next);
      q.setPw.run(h, Date.now(), user.id);
    },
    async setPassword(id, pw) { q.setPw.run(await hashPassword(pw), Date.now(), id); },
  };
}

module.exports = { ROLES, hashPassword, verifyPassword, createAuth, createLimiter, actorLabel, publicUser, parseAreas, sha256, AREA_NAMES };
