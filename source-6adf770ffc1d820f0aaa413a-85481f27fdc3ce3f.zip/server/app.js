'use strict';
const http = require('node:http');
const { HttpError, createRouter, parseCookies, readBody, serveStatic, securityHeaders, newId } = require('./http');
const { open } = require('./db');
const { createAuth } = require('./auth');
const { createSheets } = require('./sheets');
const { createLogger } = require('./log');
const { createMetrics } = require('./metrics');

const SAFE = new Set(['GET', 'HEAD', 'OPTIONS']);

function createApp(cfg, { fetchImpl, logger } = {}) {
  const log = logger || createLogger(cfg.logLevel);
  const metrics = createMetrics();
  const db = open(cfg.dbFile);
  const insAudit = db.prepare('INSERT INTO audit (at, user_id, username, action, target, detail, ip) VALUES (?,?,?,?,?,?,?)');
  const audit = ({ user, action, target, detail, ip }) => {
    try { insAudit.run(Date.now(), user ? user.id : null, user ? user.username : null, action, target || null, detail ? String(detail).slice(0, 500) : null, ip || null); }
    catch (e) { log.error('audit_gagal', { error: e.message }); }
  };
  const auth = createAuth({ db, cfg, log, audit });
  // catatan berkas foto yang benar-benar diunggah server: rumus HYPERLINK di kolom W hanya boleh menunjuk ke berkas ini
  const uploads = {
    add: (id, area) => { db.prepare('INSERT OR REPLACE INTO kv (key, value) VALUES (?, ?)').run('upl:' + id, `${area}|${Date.now()}`); },
    get: (id) => { const r = db.prepare('SELECT value FROM kv WHERE key = ?').get('upl:' + id); return r ? String(r.value).split('|')[0] : null; },
  };
  const sheets = createSheets({ cfg, log, metrics, fetchImpl, uploads });
  const router = createRouter();
  const deps = { cfg, db, log, metrics, auth, sheets, audit };
  for (const m of ['session', 'docs', 'cek', 'sheets', 'assets', 'admin']) require(`./routes/${m}`)(router, deps);

  metrics.gauge('armada_users_total', () => db.prepare('SELECT COUNT(*) n FROM users WHERE disabled = 0').get().n);
  metrics.gauge('armada_sessions_active', () => db.prepare('SELECT COUNT(*) n FROM sessions WHERE expires_at > ?').get(Date.now()).n);
  metrics.gauge('armada_docs_total', () => db.prepare('SELECT COUNT(*) n FROM docs').get().n);

  const baseHeaders = securityHeaders(cfg.cookieSecure);
  const clientIp = (req) => {
    if (cfg.trustProxy) {
      const xff = String(req.headers['x-forwarded-for'] || '').split(',').map((s) => s.trim()).filter(Boolean);
      if (xff.length) return xff[xff.length - 1]; // yang ditambahkan proxy tepercaya kita
    }
    return req.socket.remoteAddress || '';
  };
  const expectedHost = (req) => (cfg.trustProxy && req.headers['x-forwarded-host']) || req.headers.host || '';

  // ---- system routes ----
  router.get('/healthz', (ctx) => ctx.json(200, { ok: true }));
  router.get('/readyz', (ctx) => {
    try { db.prepare('SELECT 1').get(); } catch { throw new HttpError(503, 'db_down', 'Database tidak siap.'); }
    const st = sheets.status();
    ctx.json(200, { ok: true, db: 'ok', sheets: { configured: st.configured, areas: st.areas } });
  });
  router.get('/metrics', (ctx) => {
    const local = /^(::1|127\.0\.0\.1|::ffff:127\.0\.0\.1)$/.test(ctx.req.socket.remoteAddress || '') && !ctx.req.headers['x-forwarded-for'];
    const tok = (ctx.req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const tokOk = !!cfg.metricsToken && tok.length === cfg.metricsToken.length && require('node:crypto').timingSafeEqual(Buffer.from(tok), Buffer.from(cfg.metricsToken));
    if (!(local || tokOk)) throw new HttpError(403, 'forbidden', 'Tidak diizinkan.');
    ctx.raw(200, metrics.render(), 'text/plain; version=0.0.4');
  });

  async function handle(req, res) {
    const t0 = process.hrtime.bigint();
    const id = req.headers['x-request-id'] && /^[\w-]{6,64}$/.test(req.headers['x-request-id']) ? req.headers['x-request-id'] : newId();
    const ip = clientIp(req);
    let url;
    try { url = new URL(req.url, 'http://x'); } catch { res.writeHead(400); return res.end(); }
    const pathname = url.pathname;
    const outHeaders = { ...baseHeaders, 'X-Request-Id': id };
    const cookies = [];
    let status = 500, routeName = pathname.startsWith('/api/') ? pathname.replace(/\/[^/]+$/, '/:x') : 'static';

    const ctx = {
      req, res, ip, id, url, query: url.searchParams, params: {}, user: null, session: null,
      setCookie: (c) => cookies.push(c),
      json(code, obj) { status = code; send(code, 'application/json; charset=utf-8', JSON.stringify(obj), { 'Cache-Control': 'no-store' }); },
      raw(code, body, type, extra) { status = code; send(code, type, body, { 'Cache-Control': 'no-store', ...extra }); },
      async readJson() {
        const buf = await readBody(req, cfg.bodyLimit);
        if (!buf.length) return {};
        if (!/^application\/json/i.test(req.headers['content-type'] || '')) throw new HttpError(415, 'unsupported', 'Content-Type harus application/json.');
        try { const v = JSON.parse(buf.toString('utf8')); if (v === null || typeof v !== 'object') throw 0; return v; }
        catch { throw new HttpError(400, 'bad_json', 'Isi permintaan bukan JSON yang valid.'); }
      },
      requireUser() { if (!ctx.user) throw new HttpError(401, 'unauthenticated', 'Silakan login.'); return ctx.user; },
    };
    function send(code, type, body, extra) {
      if (res.headersSent) return;
      const headers = { ...outHeaders, 'Content-Type': type, ...extra };
      if (cookies.length) headers['Set-Cookie'] = cookies;
      const buf = Buffer.isBuffer(body) ? body : Buffer.from(body);
      headers['Content-Length'] = buf.length;
      res.writeHead(code, headers);
      res.end(req.method === 'HEAD' ? undefined : buf);
    }

    try {
      if (pathname.startsWith('/api/') || pathname === '/healthz' || pathname === '/readyz' || pathname === '/metrics') {
        const m = router.match(req.method, pathname);
        if (!m.handler) throw m.pathMatched ? new HttpError(405, 'method_not_allowed', 'Metode tidak diizinkan.') : new HttpError(404, 'not_found', 'Tidak ditemukan.');
        routeName = m.pattern;
        ctx.params = m.params;
        // Perlindungan CSRF untuk semua metode yang mengubah data: header khusus + Origin harus sama dengan host kita.
        if (!SAFE.has(req.method)) {
          if (req.headers['x-requested-with'] !== 'armada-web') throw new HttpError(403, 'csrf', 'Permintaan ditolak.');
          const origin = req.headers.origin;
          if (origin) { let oh = ''; try { oh = new URL(origin).host; } catch { /* kosong */ } if (oh !== expectedHost(req)) throw new HttpError(403, 'csrf', 'Asal permintaan tidak cocok.'); }
        }
        const sess = auth.resolve(parseCookies(req.headers.cookie)[cfg.cookieName]);
        if (sess) { ctx.user = sess.user; ctx.session = sess; }
        await m.handler(ctx);
        if (!res.headersSent) throw new Error(`handler ${m.pattern} tidak mengirim respons`);
      } else if (req.method === 'GET' || req.method === 'HEAD') {
        status = 200;
        if (!serveStatic(req, res, cfg.publicDir, pathname, outHeaders)) { status = 404; send(404, 'text/plain; charset=utf-8', 'Tidak ditemukan'); }
      } else {
        throw new HttpError(405, 'method_not_allowed', 'Metode tidak diizinkan.');
      }
    } catch (e) {
      if (e instanceof HttpError) {
        status = e.status;
        const extra = { 'Cache-Control': 'no-store' };
        if (e.extra && e.extra.retryAfter) extra['Retry-After'] = String(e.extra.retryAfter);
        send(e.status, 'application/json; charset=utf-8', JSON.stringify({ error: { code: e.code, message: e.message } }), extra);
      } else {
        status = 500;
        log.error('error_tak_terduga', { reqId: id, route: routeName, error: e && e.message, stack: e && e.stack });
        send(500, 'application/json; charset=utf-8', JSON.stringify({ error: { code: 'internal', message: 'Terjadi kesalahan di server.', reqId: id } }), { 'Cache-Control': 'no-store' });
      }
    } finally {
      const dur = Number(process.hrtime.bigint() - t0) / 1e9;
      const rn = status === 404 ? 'unmatched' : routeName; // jangan biarkan path acak menambah seri metrik
      metrics.inc('http_requests_total', { route: rn, method: req.method, status: Math.floor(status / 100) + 'xx' });
      metrics.observe('http_request_seconds', { route: rn }, dur);
      if (routeName !== '/healthz') log.info('req', { reqId: id, method: req.method, path: pathname, status, ms: Math.round(dur * 1000), user: ctx.user ? ctx.user.username : undefined, ip });
    }
  }

  const server = http.createServer((req, res) => { handle(req, res).catch((e) => { log.error('handler_crash', { error: e && e.message }); try { res.destroy(); } catch { /* sudah ditutup */ } }); });
  server.requestTimeout = 60000;
  server.headersTimeout = 20000;
  server.keepAliveTimeout = 65000;

  const purgeTimer = setInterval(() => { try { const n = auth.purgeExpired(); if (n) log.info('sesi_dibersihkan', { n }); } catch (e) { log.error('purge_gagal', { error: e.message }); } }, 3600000);
  purgeTimer.unref();

  return {
    server, db, auth, sheets, audit, log, metrics,
    close: () => new Promise((resolve) => { clearInterval(purgeTimer); server.close(() => { try { db.close(); } catch { /* sudah tertutup */ } resolve(); }); server.closeIdleConnections && server.closeIdleConnections(); }),
  };
}

module.exports = { createApp };
