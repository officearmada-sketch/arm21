'use strict';
// Log terstruktur satu baris JSON per kejadian, ke stdout (dikumpulkan oleh Docker).
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
function createLogger(level = 'info', out = process.stdout) {
  const min = LEVELS[level] || 20;
  const write = (lvl, msg, fields) => {
    if (LEVELS[lvl] < min) return;
    const rec = { t: new Date().toISOString(), level: lvl, msg, ...fields };
    // jangan pernah mencatat rahasia
    for (const k of ['password', 'pass', 'token', 'key', 'cookie', 'authorization']) if (k in rec) rec[k] = '[disembunyikan]';
    out.write(JSON.stringify(rec) + '\n');
  };
  return {
    debug: (m, f) => write('debug', m, f),
    info: (m, f) => write('info', m, f),
    warn: (m, f) => write('warn', m, f),
    error: (m, f) => write('error', m, f),
  };
}
module.exports = { createLogger };
