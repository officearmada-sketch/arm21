'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

function open(file, { migrationsDir = path.join(__dirname, '..', 'migrations') } = {}) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL;');
  migrate(db, migrationsDir);
  return db;
}

// Migrasi maju-saja, berurutan, masing-masing dalam satu transaksi. Versi disimpan di PRAGMA user_version.
function migrate(db, dir) {
  const files = fs.readdirSync(dir).filter((f) => /^\d{3}_.+\.sql$/.test(f)).sort();
  const current = db.prepare('PRAGMA user_version').get().user_version;
  for (const f of files) {
    const v = Number(f.slice(0, 3));
    if (v <= current) continue;
    db.exec('BEGIN IMMEDIATE');
    try {
      db.exec(fs.readFileSync(path.join(dir, f), 'utf8'));
      db.exec(`PRAGMA user_version = ${v}`);
      db.exec('COMMIT');
    } catch (e) {
      db.exec('ROLLBACK');
      throw new Error(`Migrasi ${f} gagal: ${e.message}`);
    }
  }
}

function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* sudah rollback */ }
    throw e;
  }
}

module.exports = { open, migrate, tx };
