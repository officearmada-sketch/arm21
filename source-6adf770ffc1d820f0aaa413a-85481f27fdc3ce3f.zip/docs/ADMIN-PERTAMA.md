# Membuat admin melalui environment Netlify

Pengaturan ini berlaku untuk aplikasi Netlify dengan Netlify Database. Admin aplikasi dibuat saat percobaan login pertama memakai username yang dikonfigurasi. Tidak diperlukan undangan Identity atau halaman penyiapan.

1. Buka proyek situs di dashboard Netlify, lalu pilih **Project configuration → Environment variables**.
2. Tambahkan `ADMIN_USERNAME`. Isi dengan username admin pilihan Anda (3–64 karakter; huruf, angka, titik, garis bawah, atau tanda hubung). Jika variabel ini tidak diisi, aplikasi menggunakan username `admin`. Pilih username yang belum digunakan akun lain.
3. Tambahkan `ADMIN_PASSWORD` dan isi sendiri dengan password unik sepanjang 8–200 karakter. Tandai sebagai nilai rahasia jika opsi tersedia, lalu simpan di pengelola password pribadi.
4. Pastikan kedua variabel tersedia pada scope **Functions** dan deploy context yang dipakai. Untuk situs utama pilih **Production**; jika menguji Deploy Preview, atur nilainya untuk **Deploy Previews** juga. Database preview dan produksi terpisah.
5. Atur `DATA_KEY` pada scope **Functions** dan deploy context yang sama. Variabel ini **wajib**, terpisah dari username dan password, dan harus berisi kunci acak 32 byte dalam base64. Jika aplikasi pernah menyimpan data, pulihkan kunci lamanya; jangan membuat pengganti karena data lama memerlukan kunci yang sama. Untuk instalasi baru yang belum pernah memiliki kunci, buat kunci secara lokal dengan pengelola rahasia atau generator kriptografis, simpan secara pribadi, lalu masukkan ke environment Netlify. Jangan memakai password admin sebagai kunci.
6. Buka **Deploys**, lalu jalankan deploy baru agar perubahan environment berlaku. Tunggu sampai deploy berhasil dipublikasikan.
7. Buka halaman utama situs. Login menggunakan username dan password yang Anda simpan pada langkah 2–3. Saat login ini, aplikasi menginisialisasi admin yang masih kosong, menyimpan hash password ke database, lalu membuka sesi admin.
8. Setelah berhasil masuk, hapus `ADMIN_PASSWORD` dari environment dan lakukan deploy baru. Login berikutnya tetap memakai password yang sudah tersimpan sebagai hash di database. `ADMIN_USERNAME` juga boleh dihapus setelah inisialisasi berhasil.

Untuk membuat `DATA_KEY` pada instalasi baru, jalankan `openssl rand -base64 32` di terminal komputer Anda. Salin hasilnya langsung ke environment Netlify dan pengelola password pribadi; jangan membagikannya di chat atau menyimpannya dalam kode. Pertahankan kunci ini pada deploy berikutnya.

Mengganti environment tidak mereset password atau membuat admin tambahan setelah ada admin yang memiliki password atau tautan Identity, termasuk admin yang dinonaktifkan. Gunakan akun admin yang sudah ada untuk mengelola akun. Jika username pilihan sudah dipakai akun lain, pilih username berbeda dan deploy ulang sebelum login pertama. Tanpa `ADMIN_PASSWORD`, inisialisasi tidak berjalan.

Login Google tetap opsional. Setelah login dengan username dan password, gunakan **Hubungkan Google** jika penyedia Google sudah diaktifkan.

Jika username dan password sudah benar tetapi login tetap gagal, periksa `DATA_KEY` terlebih dahulu. Akun admin dapat sudah terinisialisasi meskipun sesi gagal dibuka karena kunci belum tersedia. Melengkapi kunci tidak memerlukan pembuatan ulang admin atau perubahan password. Setelah mengubah environment, deploy ulang dan coba login kembali melalui HTTPS. Pesan konfigurasi kini ditampilkan langsung pada layar login.
