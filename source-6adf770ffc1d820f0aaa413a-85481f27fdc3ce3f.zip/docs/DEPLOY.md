# Memasang di VPS

Vercel dan Netlify tidak cocok: aplikasi ini butuh proses server yang menetap, database SQLite di disk, dan sesi login. Gunakan satu VPS kecil (1 vCPU, 1 GB RAM cukup; Ubuntu 24.04).

## A. Siapkan server

1. Buat VPS, catat IP. Arahkan DNS: rekaman `A` untuk domain Anda ke IP itu.
2. Opsi cepat: tempel `deploy/cloud-init.yaml` saat membuat VPS (memasang Docker, firewall, pengguna `deploy`). Opsi manual: pasang Docker + Compose plugin, buka port 22, 80, 443 saja.
3. Salin folder `deploy/` ke `/opt/armada/deploy` di server.

## B. Konfigurasi

```bash
cd /opt/armada/deploy
cp ../.env.example .env && nano .env        # DOMAIN, ACME_EMAIL, DATA_KEY, IMAGE
mkdir -p secrets && nano secrets/google-sa.json   # isi JSON akun layanan, chmod 600
```

- `DATA_KEY`: `node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"`. **Simpan salinannya di password manager.** Tanpa kunci ini data Monitor yang sudah tersimpan tidak bisa dibuka.
- Bangun image lokal (tanpa CI): di folder proyek `docker build -t armada-pusat .` lalu set `IMAGE=armada-pusat`, `IMAGE_TAG=latest`.

## C. Jalankan

```bash
docker compose --env-file .env up -d
docker compose logs -f app          # tunggu "listening"
docker compose exec app node --disable-warning=ExperimentalWarning scripts/seed.js --accounts /tmp/akun.csv
```

Buat akun admin pertama: `docker compose exec app node --disable-warning=ExperimentalWarning scripts/user.js add admin admin`.
Buka `https://DOMAIN`. Caddy mengurus sertifikat otomatis.

## D. CI/CD (opsional, GitHub Actions)

`.github/workflows/ci.yml` menjalankan tes, membangun image ke GHCR, lalu deploy lewat SSH. Isi *Repository secrets*: `DEPLOY_HOST`, `DEPLOY_USER`, `DEPLOY_SSH_KEY`, `DEPLOY_KNOWN_HOSTS`, `DEPLOY_URL`. Deploy memanggil `deploy.sh`, yang mencadangkan database dulu dan otomatis kembali ke versi sebelumnya bila aplikasi tidak sehat.

## E. Pembaruan manual

```bash
cd /opt/armada/deploy && ./deploy.sh <tag>
```
