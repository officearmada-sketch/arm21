# Akun layanan Google

Server membaca dan menulis Google Sheets/Drive sebagai satu akun layanan, bukan sebagai pengguna. Jadi tidak ada lagi pesan "akun Google Anda belum punya akses".

## 1. Buat akun layanan

1. console.cloud.google.com -> buat proyek (mis. `armada-pusat`).
2. APIs & Services -> Library -> aktifkan **Google Sheets API** dan **Google Drive API**.
3. IAM & Admin -> Service Accounts -> Create. Nama bebas. Tidak perlu peran proyek.
4. Buka akun itu -> Keys -> Add key -> JSON. Simpan berkasnya. Alamatnya berbentuk `nama@proyek.iam.gserviceaccount.com`.
5. Letakkan JSON di server: `deploy/secrets/google-sa.json` (izin `chmod 600`). Jangan commit.

## 2. Bagikan ke alamat akun layanan

| Yang dibagikan | Peran | Alasan |
|---|---|---|
| ACC PUSAT (`1uwenWPo9...`) | Editor | baca daftar, tulis ACC Manager Armada (kolom Y) |
| 22 spreadsheet area | Editor | baca DATA PEMINJAM; tulis ACC Armada (R), ACC Area (Y), status/keterangan/link pengembalian (U, X, W) |
| Database formulir (`1V18f6If...`) | Viewer | banner sinkron dan database utama; sheet MASTER dipakai Pemakaian Unit (mobil grup OPERASIONAL) |
| Daftar perjalanan dinas (`19BQ1RVm...`) | Viewer | Pemakaian Unit: sheet LIST PERJALANAN DINAS NEW (hanya tipe MOBIL INVENTARIS yang dipakai) |
| Database karyawan (`1h5jyC0d...`) | Viewer | Pemakaian Unit: NIB menjadi nama dari sheet STAFF, NON-STAFF, SOPIR, TKBM |
| LOG MONITOR KETEPATAN ARMADA (`1d39r0zq...`) | Editor | tambah baris log |
| Folder Drive **PENGEMBALIAN** (`1ogPsvCH...`) | Editor | induk foto form dan foto unit pulang; subfolder per area dibuat otomatis |

Cara cepat: bagikan seluruh folder induk berisi semua file area sebagai Editor, lalu bagikan ACC PUSAT dan LOG bila belum termasuk.

## 3. Izin IMPORTRANGE

File area membaca ACC PUSAT lewat IMPORTRANGE dan sebaliknya. Setiap file baru perlu satu kali klik **Allow access** pada sel yang menampilkan `#REF!` (sheet IZIN AKSES di ACC PUSAT, mis. Jembrana T5 dan Banjarmasin A5). Setelah link di MASTER berganti, ulangi untuk file yang baru.

## 4. Variabel server

`SHEETS_ACC_ID`, `SHEETS_FORM_ID`, `SHEETS_SPPD_ID`, `SHEETS_EMP_ID` sudah ada di `.env.example`. Opsional: `SHEETS_LOG_ID`, `DRIVE_RETURN_FOLDER_ID` bila Anda memindahkan log atau folder.

## Yang TIDAK diubah

App Script di spreadsheet (pembuat 21 file, trigger tanda tangan) tidak disentuh. Server hanya menulis sel yang disebut di atas.
