# Catatan keamanan

## Yang dijaga server (bukan hanya tampilan)
- Peran dan area ditegakkan di server pada setiap permintaan: akun daerah hanya melihat dan menulis areanya; viewer tidak bisa menulis.
- Pemakaian Unit: SPPD, MASTER armada, dan database karyawan hanya terbaca oleh Admin dan Armada Pusat. Koleksi `pakai` hanya bisa dibuat/dihapus staf; akun daerah hanya melihat dan mengubah ACC area serta berkas unggahan untuk areanya sendiri (kolom milik Armada Pusat dan identitas pengajuan ditolak bila diubah), dan pemakaian yang sudah berangkat tidak bisa dihapus.
- Penulisan ke Google dibatasi allowlist per sel dan per nilai (centang boolean; U = `TELAH DIKEMBALIKAN`; X = `NORMAL`/`ADA KERUSAKAN`; W = rumus HYPERLINK ke Drive dengan pola nama; log 13 kolom dengan netralisasi rumus; foto harus JPEG kecil, folder ditentukan server).
- Pelaku perubahan dicatat dari sesi login, bukan dari kiriman browser.
- Password scrypt, sesi disimpan sebagai hash, cookie `__Host-` HttpOnly SameSite=Lax (agar sesi tetap terbaca setelah kembali dari Google), kunci akun dan batas laju per IP, CSRF header + Origin, CSP ketat, container non-root dengan filesystem read-only.

## Batasan yang perlu Anda ketahui
- Foto form pemeriksaan: salinan kecil (~170 KB) di database untuk tampilan, salinan lebih besar di Google Drive. Foto unit pulang dan form diunggah ke subfolder per area di folder PENGEMBALIAN (dibuat otomatis bila belum ada); nama berkas `NAMA AREA_PULANG|FORM_PULANG_ddMMyyHHmmss.jpeg`; berkas lama hanya dibuang ke sampah bila hasil unggahan server untuk area yang sama.
- Akun layanan punya hak Editor atas file area; kebocoran `google-sa.json` = akses ke file itu. Simpan dengan `chmod 600`, jangan commit, putar kuncinya bila perlu.
- `package-lock.json` belum ada (tidak bisa dibuat tanpa akses registry npm). Buat dan commit sebelum produksi agar versi dependensi build terkunci.
- Tinjauan keamanan sudah dilakukan dan perbaikannya diterapkan (akun viewer tidak boleh menulis catatan, rentang baca dibatasi, metrik dan /readyz tidak membocorkan detail, tautan kolom W hanya ke berkas unggahan server, invalidate cache hanya efektif untuk staf). Masih tercatat: `DATA_KEY` dikirim ke klien untuk membuka data bawaan Monitor, CSP masih `style 'unsafe-inline'`, batas ukuran body login dan batas laju per akun belum ada. Tes: 24 tes server, 16 skenario E2E (semua lulus).

## Daftar periksa sebelum dipakai
- [ ] Semua akun awal mengganti password; `akun_baru.csv` dihapus dari semua tempat.
- [ ] `DATA_KEY` tersimpan di dua tempat aman.
- [ ] Uji pulihkan cadangan berhasil.
- [ ] Hanya port 22/80/443 terbuka; login SSH memakai kunci.
- [ ] Salinan cadangan ke luar server aktif.
