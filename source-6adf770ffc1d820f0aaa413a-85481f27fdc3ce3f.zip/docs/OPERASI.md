# Operasi harian

## Akun
```bash
docker compose exec app node --disable-warning=ExperimentalWarning scripts/user.js list
... user.js add <nama> <admin|pusat|daerah|viewer> [--areas LPG] [--password ...]
... user.js passwd <nama>          # password baru dibuat acak lalu ditampilkan sekali
... user.js disable|enable <nama>
```
Admin juga bisa mengelola akun dari panel di aplikasi.

## Cadangan
Layanan `backup` membuat salinan database harian (`VACUUM INTO`, diverifikasi, dirotasi `BACKUP_KEEP` hari) di volume terpisah. Salinan ke luar server: jalankan dengan profil `offsite` (rclone) dan isi `OFFSITE_PATH`.
Pulihkan: `scripts/restore.js <berkas>` (hentikan `app` dulu). Uji pemulihan minimal sekali sebelum dipakai nyata.

## Pemantauan
`/healthz` untuk cek sehat, `/metrics` (butuh `METRICS_TOKEN`). Profil `monitoring` menjalankan Uptime Kuma. Log berformat JSON: `docker compose logs app`.

## Masalah umum
| Gejala | Penyebab biasa |
|---|---|
| "Spreadsheet area X belum didaftarkan" | link di sheet MASTER kosong/salah, atau file belum dibagikan ke akun layanan |
| Pengajuan ada di formulir tapi tidak di ACC PUSAT | izin IMPORTRANGE belum diklik (docs/GOOGLE.md bagian 3) |
| Foto unit gagal diunggah | folder PENGEMBALIAN belum dibagikan ke akun layanan sebagai Editor |
| Data Monitor tidak terbuka setelah pindah server | `DATA_KEY` berbeda dari yang lama |
| Login terkunci | tunggu `LOGIN_LOCK_MINUTES` atau `user.js enable <nama>` |

## Gangguan login di Netlify

Endpoint login membedakan gangguan database dari kesalahan username/password dan konfigurasi `DATA_KEY`. Jika login tetap gagal, buka log Function `session` pada deploy yang sedang diakses. Entri `session.failure` menampilkan tahap kegagalan dan kode bantuan tanpa menyertakan password, kunci, atau parameter SQL.

| Kode | Pemeriksaan admin |
|---|---|
| `database_configuration` | Pastikan koneksi Netlify Database tersedia untuk Functions pada deploy/context tersebut. |
| `database_permissions` | Periksa izin koneksi database; login memerlukan akses tulis untuk audit dan sesi. |
| `database_schema` | Periksa hasil migrasi deploy. Pertahankan migrasi yang sudah diterapkan; koreksi melalui migrasi baru. |
| `database_unavailable` | Coba kembali, lalu periksa ketersediaan database dan batas koneksi jika berulang. |
| `service_unavailable` | Periksa tahap pada log `session.failure` untuk menentukan operasi yang gagal. |

Jangan mengganti `DATA_KEY` atau mereset akun admin untuk mengatasi gangguan database.
