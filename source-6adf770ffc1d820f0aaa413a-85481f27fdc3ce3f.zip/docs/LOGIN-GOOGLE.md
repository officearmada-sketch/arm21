# Login Google dan username/password

Login username/password tetap tersedia. Google menjadi cara masuk tambahan ke akun internal yang sama; role dan batas area tetap diambil dari database aplikasi.

Untuk akun admin pertama yang belum memiliki akses internal, ikuti [panduan penyiapan admin](ADMIN-PERTAMA.md). Admin aplikasi diinisialisasi melalui environment pada login pertama.

## Menggunakan Google

1. Masuk memakai username dan password akun Armada yang sudah aktif.
2. Pilih **Hubungkan Google** pada navigasi, lalu pilih akun Google milik Anda.
3. Setelah kembali ke aplikasi, tautan tersimpan. Keluar dari aplikasi.
4. Pada halaman login, pilih **Masuk dengan Google**.

Satu akun Google hanya bisa ditautkan ke satu akun Armada, dan satu akun Armada hanya memiliki satu tautan Google. Penautan tidak mengubah password atau role. Akun yang dinonaktifkan tidak bisa masuk, termasuk melalui Google. Akun Google yang belum ditautkan ditolak; tidak ada pembuatan admin otomatis berdasarkan email atau data dari browser. Penyiapan admin pertama memakai environment server; setelah login dengan password, admin dapat memilih Hubungkan Google.

## Konfigurasi Netlify

- Aktifkan Google di **Project configuration → Identity → External providers**. Jika memakai aplikasi OAuth sendiri, daftarkan callback yang benar-benar dikirim endpoint authorize Identity ke Google. Pemeriksaan situs ini pada 26 Oktober 2026 menunjukkan callback `https://identity.services.netlify.com/callback`, baik dari domain utama maupun alias `main`. Alamat situs dan alamat kembali ke aplikasi berbeda dari callback OAuth provider.
- Identity harus tersedia pada origin situs yang digunakan untuk masuk. Uji dengan domain HTTPS utama; pastikan konfigurasi redirect Identity juga mengizinkan URL preview jika dipakai.
- Netlify menerapkan migrasi baru `identity_links` saat deploy. Migrasi lama tidak diubah.
- Endpoint sesi pada Netlify menggunakan Netlify Database dan membutuhkan konfigurasi `DATA_KEY` yang sama dengan data terenkripsi aplikasi. Jangan mengganti kunci yang sudah digunakan.
- Akun internal harus sudah ada dan memiliki password valid. Menambahkan fitur ini tidak membuat akun admin baru, tidak mengatur password awal, dan tidak mengubah password akun yang ada. Akun Netlify Identity saja belum cukup untuk login Armada; tautkan dengan sesi internal terlebih dahulu.
- Netlify Function baru menangani endpoint login, sesi, logout, penautan Google, perubahan password, dan data bawaan Monitor. Endpoint operasional lainnya, seperti dokumen dan Google Sheets, tetap memerlukan backend aplikasi; migrasi seluruh backend berada di luar perubahan login ini.

## Mengatasi Google Error 400: redirect_uri_mismatch

Error ini terjadi sebelum Google mengembalikan pengguna ke aplikasi. Google menolak `redirect_uri` yang tidak terdaftar pada klien OAuth yang digunakan Netlify Identity.

1. Buka **Google Cloud Console → Google Auth Platform → Clients** (atau **APIs & Services → Credentials**), lalu pilih klien OAuth bertipe **Web application** yang digunakan pada provider Google di Netlify Identity. Pastikan proyek dan kliennya sesuai.
2. Di **Authorized redirect URIs**, tambahkan persis `https://identity.services.netlify.com/callback` lalu simpan. Jangan menambahkan slash di akhir. Menambahkan alamat ini hanya ke **Authorized JavaScript origins** tidak cukup.
3. Tunggu beberapa menit hingga perubahan berlaku, lalu mulai ulang login dari `https://armdapusat.netlify.app`.
4. Jika error masih muncul, buka detail error Google dan cocokkan `redirect_uri` dengan daftar pada klien yang sama. Gunakan nilai aktual tersebut jika konfigurasi layanan berubah. Jangan membagikan URL authorize lengkap, token, atau client secret.

Alamat `https://armdapusat.netlify.app/.netlify/identity/callback` yang sebelumnya dicantumkan pada panduan ini bukan callback yang dikirim oleh layanan Identity situs saat diperiksa. Perubahan daftar callback harus dilakukan di Google Cloud Console; perubahan kode aplikasi atau deploy saja tidak memperbarui daftar tersebut. Login username/password tetap tersedia selama konfigurasi Google diperbaiki.

## Backend Node yang sudah ada

Backend Node/SQLite juga mendukung penautan dan login Google. Atur `NETLIFY_IDENTITY_URL` ke endpoint Identity proyek yang dipercaya, yaitu URL situs diikuti `/.netlify/identity`. Jangan menerima endpoint dari input pengguna. Browser memakai endpoint Identity pada origin yang sama, sehingga deployment backend Node juga harus menyediakan routing `/.netlify/identity/*` ke layanan Identity proyek tersebut. Migrasi SQLite baru diterapkan oleh mekanisme startup backend yang sudah ada.

## Verifikasi

Pengujian mencakup sesi Identity tidak valid, email belum terverifikasi, layanan Identity tidak tersedia, penautan tanpa sesi internal, konflik tautan antar akun, role yang tidak boleh naik melalui metadata browser, akun dinonaktifkan, logout, dan login password sesudah penautan. Login Google end-to-end memerlukan interaksi dengan provider di browser setelah deploy.
