import type { Config, Context } from '@netlify/functions';
import { getDatabase } from '@netlify/database';
import http from '../../server/http.js';
import auth from '../../server/auth.js';
import adminRoutes from '../../server/netlify/admin.js';
import docsRoutes from '../../server/netlify/docs.js';
import cekRoutes from '../../server/netlify/cek.js';
import configuration from '../../server/config.js';
import googleSheets from '../../server/sheets.js';
import metrics from '../../server/metrics.js';

export default async (req: Request, context: Context) => {
  const { HttpError, createRouter } = http;
  const url = new URL(req.url);
  const reply = (status: number, body: unknown) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
  let pool: ReturnType<typeof getDatabase>['pool'] | undefined;
  let client: Awaited<ReturnType<ReturnType<typeof getDatabase>['pool']['connect']>> | undefined;
  try {
    if (!['GET', 'HEAD'].includes(req.method) && (req.headers.get('x-requested-with') !== 'armada-web' || req.headers.get('origin') !== url.origin)) throw new HttpError(403, 'csrf', 'Permintaan tidak diizinkan.');
    const db = getDatabase(); pool = db.pool; client = await pool.connect();
    const query = async (sql: string, values: unknown[] = []) => (await client!.query(sql, values)).rows;
    const cookieName = url.protocol === 'https:' ? '__Host-armada' : 'armada';
    const token = context.cookies.get(cookieName);
    if (!token || token.length > 100) throw new HttpError(401, 'unauthenticated', 'Silakan login.');
    const now = Date.now();
    const [user] = await query(`SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id
      WHERE s.id_hash=$1 AND s.expires_at>$2 AND s.last_seen_at>$3 AND NOT u.disabled`, [auth.sha256(token), now, now - 240 * 60000]);
    if (!user) throw new HttpError(401, 'unauthenticated', 'Silakan login.');
    await query('UPDATE sessions SET last_seen_at=$1 WHERE id_hash=$2', [now, auth.sha256(token)]);
    let response: Response | undefined;
    const router = createRouter();
    const transaction = async (work: (q: typeof query) => Promise<unknown>) => {
      await query('BEGIN');
      try { const result = await work(query); await query('COMMIT'); return result; }
      catch (error) { await query('ROLLBACK'); throw error; }
    };
    const audit = async (q: typeof query, actor: any, action: string, target: string, detail: string | null, ip: string) => {
      await q('INSERT INTO audit (at, user_id, username, action, target, detail, ip) VALUES ($1,$2,$3,$4,$5,$6,$7)',
        [Date.now(), actor.id, actor.username, action, target, detail, ip]);
    };
    const env = (name: string) => Netlify.env.get(name);
    // Read only the existing Sheets settings; credentials stay on the server.
    const googleEnv: Record<string, string> = {};
    for (const name of ['GOOGLE_SA_JSON', 'SHEETS_ACC_ID', 'SHEETS_FORM_ID', 'SHEETS_SPPD_ID', 'SHEETS_EMP_ID', 'SHEETS_LOG_ID', 'DRIVE_RETURN_FOLDER_ID']) {
      const value = env(name); if (value) googleEnv[name] = value;
    }
    const sheets = googleSheets.createSheets({
      cfg: configuration.load(googleEnv), metrics: metrics.createMetrics(),
      log: { error: () => {}, warn: () => {}, info: () => {} },
    });
    const deps = { query, transaction, audit, sheets, env };
    adminRoutes(router, deps);
    docsRoutes(router, deps);
    cekRoutes(router, deps);
    const match = router.match(req.method, url.pathname);
    if (!match.handler) throw new HttpError(match.pathMatched ? 405 : 404, 'not_found', 'Endpoint tidak ditemukan atau metode tidak didukung.');
    await match.handler({
      query: url.searchParams, params: match.params, ip: context.ip, requireUser: () => user,
      json: (status: number, body: unknown) => { response = reply(status, body); },
      raw: (status: number, body: BodyInit, type: string, headers: Record<string, string> = {}) => { response = new Response(body, { status, headers: { 'Content-Type': type, ...headers } }); },
      readJson: async () => {
        if (!/^application\/json/i.test(req.headers.get('content-type') || '')) throw new HttpError(415, 'unsupported', 'Content-Type harus application/json.');
        const limit = 9 * 1024 * 1024;
        if (Number(req.headers.get('content-length')) > limit) throw new HttpError(413, 'too_large', 'Data terlalu besar.');
        const reader = req.body?.getReader();
        const chunks: Uint8Array[] = []; let size = 0;
        if (reader) while (true) {
          const { value, done } = await reader.read(); if (done) break;
          size += value.byteLength;
          if (size > limit) { await reader.cancel(); throw new HttpError(413, 'too_large', 'Data terlalu besar.'); }
          chunks.push(value);
        }
        let body;
        try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
        catch { throw new HttpError(400, 'bad_json', 'Isi permintaan bukan JSON yang valid.'); }
        if (!body || typeof body !== 'object' || Array.isArray(body)) throw new HttpError(400, 'bad_json', 'Isi permintaan harus berupa objek JSON.');
        return body;
      },
    });
    if (!response) throw new Error('missing_response');
    return req.method === 'HEAD' ? new Response(null, { status: response.status, headers: response.headers }) : response;
  } catch (error: any) {
    if (error instanceof HttpError) return reply(error.status, { error: { code: error.code, message: error.message } });
    console.error('application.failure', { code: 'service_unavailable' });
    return reply(503, { error: { code: 'service_unavailable', message: 'Layanan aplikasi sedang tidak tersedia. Coba lagi beberapa saat atau hubungi admin.' } });
  } finally {
    client?.release();
    if (pool) { try { await pool.end(); } catch { console.error('application.failure', { code: 'database_close' }); } }
  }
};
export const config: Config = { path: ['/api/admin/*', '/api/db/*', '/api/cek'] };
