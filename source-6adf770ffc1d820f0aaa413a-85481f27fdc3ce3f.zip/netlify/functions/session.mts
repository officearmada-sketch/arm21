import type { Config, Context } from '@netlify/functions';
import { getDatabase } from '@netlify/database';
import { randomBytes } from 'node:crypto';
import { gunzipSync } from 'node:zlib';
import auth from '../../server/auth.js';
import googleIdentity from '../../server/google-identity.js';
import http from '../../server/http.js';
import setup from '../../server/setup-admin.js';
import sessionErrors from '../../server/session-error.js';

export default async (req: Request, context: Context) => {
  const { publicUser, verifyPassword, hashPassword, sha256 } = auth;
  const { verifyIdentity } = googleIdentity;
  const { HttpError } = http;
  const reply = (status: number, body: unknown) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });
  const fail = (status: number, code: string, message: string) => { throw new HttpError(status, code, message); };
  const path = new URL(req.url).pathname;
  const cookieName = new URL(req.url).protocol === 'https:' ? '__Host-armada' : 'armada';
  const now = Date.now();
  const maxAge = 12 * 3600;
  const setCookie = (value: string, age: number) => context.cookies.set({ name: cookieName, value, path: '/', httpOnly: true, secure: new URL(req.url).protocol === 'https:', sameSite: 'Lax', maxAge: age });
  let stage = 'request';
  let pool: ReturnType<typeof getDatabase>['pool'] | undefined;
  try {
    if (req.method !== 'GET' && req.method !== 'POST') return reply(405, { error: { code: 'method', message: 'Metode tidak didukung.' } });
    if (req.method === 'POST' && (req.headers.get('x-requested-with') !== 'armada-web' || req.headers.get('origin') !== new URL(req.url).origin)) {
      fail(403, 'forbidden', 'Permintaan tidak diizinkan.');
    }
    const expectedMethod = ['/api/session', '/api/builtin'].includes(path) ? 'GET' : 'POST';
    if (req.method !== expectedMethod) return reply(405, { error: { code: 'method', message: 'Metode tidak didukung.' } });
    stage = 'database.connect';
    const db = getDatabase();
    pool = db.pool;
    stage = 'session.read';
    const sessionHash = sha256(context.cookies.get(cookieName) || '');
    const sessions = await db.sql`SELECT u.*, s.id_hash FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.id_hash = ${sessionHash} AND s.expires_at > ${now} AND s.last_seen_at > ${now - 240 * 60000} AND NOT u.disabled`;
    const current = sessions[0];
    const requireUser = () => { if (!current) fail(401, 'unauthenticated', 'Silakan login.'); return current; };
    const audit = async (user: any, action: string) => {
      await db.sql`INSERT INTO audit (at, user_id, username, action, ip) VALUES (${now}, ${user?.id ?? null}, ${user?.username ?? null}, ${action}, ${context.ip})`;
    };
    const bodyFor = (user: any) => {
      const key = Netlify.env.get('DATA_KEY');
      if (!key || Buffer.from(key, 'base64').length !== 32) fail(503, 'configuration', 'Login belum bisa dilanjutkan: DATA_KEY belum diatur atau tidak valid. Admin perlu mengatur kunci penyimpanan 32 byte dalam base64 pada environment Functions, lalu deploy ulang. Jika sebelumnya sudah digunakan, pulihkan kunci yang sama.');
      return { user: publicUser(user), key };
    };
    const establish = async (user: any, action: string) => {
      stage = 'session.create';
      const body = bodyFor(user);
      const token = randomBytes(32).toString('base64url');
      await db.sql`INSERT INTO sessions (id_hash, user_id, created_at, last_seen_at, expires_at, ip, ua)
        VALUES (${sha256(token)}, ${user.id}, ${now}, ${now}, ${now + maxAge * 1000}, ${context.ip}, ${(req.headers.get('user-agent') || '').slice(0, 200)})`;
      await db.sql`UPDATE users SET failed_count = 0, locked_until = 0, last_login_at = ${now}, updated_at = ${now} WHERE id = ${user.id}`;
      await audit(user, action);
      setCookie(token, maxAge);
      return reply(200, body);
    };
    if (path === '/api/logout') {
      await db.sql`DELETE FROM sessions WHERE id_hash = ${sessionHash}`;
      setCookie('', 0);
      return reply(200, { ok: true });
    }
    if (path === '/api/session') {
      const user = requireUser();
      await db.sql`UPDATE sessions SET last_seen_at = ${now} WHERE id_hash = ${sessionHash}`;
      return reply(200, bodyFor(user));
    }
    if (path === '/api/builtin') {
      requireUser();
      const rows = await db.sql`SELECT value FROM kv WHERE key = 'builtin_gz'`;
      const value = rows[0] ? JSON.parse(gunzipSync(Buffer.from(rows[0].value, 'base64')).toString()) : [];
      return reply(200, value);
    }
    if (path === '/api/google/link' || path === '/api/login/google') {
      if (path === '/api/google/link') requireUser();
      const identitySite = context.site.url;
      const endpoint = Netlify.env.get('NETLIFY_IDENTITY_URL') || (identitySite ? `${identitySite.replace(/\/$/, '').replace(/^http:/, 'https:')}/.netlify/identity` : '');
      const identity = await verifyIdentity(req.headers.get('cookie'), endpoint);
      if (path === '/api/google/link') {
        const user = requireUser();
        await db.sql`INSERT INTO identity_links (identity_id, user_id, created_at) VALUES (${identity.id}, ${user.id}, ${now}) ON CONFLICT DO NOTHING`;
        const links = await db.sql`SELECT user_id FROM identity_links WHERE identity_id = ${identity.id}`;
        if (!links[0] || links[0].user_id !== user.id) fail(409, 'google_linked', 'Akun sudah memiliki tautan Google lain. Hubungi admin.');
        await audit(user, 'google.link');
        return reply(200, { ok: true });
      }
      const users = await db.sql`SELECT u.* FROM users u JOIN identity_links l ON l.user_id = u.id WHERE l.identity_id = ${identity.id} AND NOT u.disabled`;
      if (!users[0]) fail(403, 'google_unlinked', 'Akun Google belum ditautkan. Masuk dengan username dan password, lalu pilih Hubungkan Google.');
      return await establish(users[0], 'login.google');
    }
    if (path === '/api/password') {
      const user = requireUser();
      const body = await req.json();
      if (typeof body.current !== 'string' || body.current.length > 200 || typeof body.next !== 'string') fail(400, 'bad_request', 'Isi password saat ini dan yang baru.');
      if (!user.password_hash || !(await verifyPassword(body.current, user.password_hash))) fail(403, 'invalid_credentials', 'Password saat ini salah.');
      const hash = await hashPassword(body.next);
      await db.sql`UPDATE users SET password_hash = ${hash}, failed_count = 0, locked_until = 0, updated_at = ${now} WHERE id = ${user.id}`;
      await db.sql`DELETE FROM sessions WHERE user_id = ${user.id}`;
      setCookie('', 0);
      return reply(200, { ok: true, relogin: true });
    }
    if (path === '/api/login') {
      stage = 'login.validate';
      const body = await req.json();
      if (typeof body.username !== 'string' || typeof body.password !== 'string' || !body.username || !body.password || body.username.length > 64 || body.password.length > 200) fail(400, 'bad_request', 'Isi username dan password.');
      const attempts = await db.sql`SELECT count(*)::int AS n FROM audit WHERE ip = ${context.ip} AND action = 'login.attempt' AND at > ${now - 600000}`;
      if (attempts[0].n >= 30) fail(429, 'rate_limited', 'Terlalu banyak percobaan. Coba lagi nanti.');
      stage = 'login.audit';
      await audit(null, 'login.attempt');
      const adminUsername = (Netlify.env.get('ADMIN_USERNAME') || 'admin').trim();
      const adminPassword = Netlify.env.get('ADMIN_PASSWORD');
      if (adminPassword && body.username.trim().toLowerCase() === adminUsername.toLowerCase()) {
        stage = 'admin.initialize';
        const client = await db.pool.connect();
        try { await setup.setupAdmin(client, adminUsername, adminPassword, context.ip); }
        finally { client.release(); }
      }
      stage = 'login.verify';
      const users = await db.sql`SELECT * FROM users WHERE lower(username) = lower(${body.username.trim()})`;
      const user = users[0];
      if (user && user.locked_until > now) fail(429, 'locked', 'Akun dikunci sementara. Coba lagi nanti.');
      const dummy = await hashPassword(randomBytes(24).toString('hex'));
      const valid = await verifyPassword(body.password, user?.password_hash || dummy);
      if (!user || user.disabled || !valid) {
        if (user && !user.disabled) await db.sql`UPDATE users SET
          failed_count = CASE WHEN locked_until > 0 AND locked_until <= ${now} THEN 1 ELSE failed_count + 1 END,
          locked_until = CASE WHEN (CASE WHEN locked_until > 0 AND locked_until <= ${now} THEN 1 ELSE failed_count + 1 END) >= 5 THEN ${now + 900000}::bigint ELSE 0 END,
          updated_at = ${now} WHERE id = ${user.id}`;
        fail(401, 'invalid_credentials', 'Username atau password salah.');
      }
      return await establish(user, 'login.ok');
    }
    return reply(404, { error: { code: 'not_found', message: 'Tidak ditemukan.' } });
  } catch (error: any) {
    if (error instanceof SyntaxError) return reply(400, { error: { code: 'bad_request', message: 'Permintaan tidak valid.' } });
    if (error instanceof HttpError) return reply(error.status, { error: { code: error.code, message: error.message } });
    const failure = sessionErrors.sessionError(error);
    // Log only fixed labels. Database error messages may include SQL parameters.
    console.error('session.failure', { stage, code: failure.code });
    return reply(503, { error: failure });
  } finally {
    // Each invocation creates its own pool; close it on success and failure so
    // repeated login attempts cannot exhaust the database's connections.
    if (pool) {
      try { await pool.end(); }
      catch { console.error('session.failure', { stage: 'database.close', code: 'database_unavailable' }); }
    }
  }
};
export const config: Config = { path: ['/api/login', '/api/login/google', '/api/google/link', '/api/logout', '/api/session', '/api/password', '/api/builtin'] };
