CREATE TABLE "identity_links" (
	"identity_id" text PRIMARY KEY,
	"user_id" integer NOT NULL UNIQUE,
	"created_at" bigint NOT NULL
);
--> statement-breakpoint
ALTER TABLE "identity_links" ADD CONSTRAINT "identity_links_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;