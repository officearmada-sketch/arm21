CREATE TABLE "audit" (
	"id" serial PRIMARY KEY,
	"at" bigint NOT NULL,
	"user_id" integer,
	"username" text,
	"action" text NOT NULL,
	"target" text,
	"detail" text,
	"ip" text
);
--> statement-breakpoint
CREATE TABLE "cek" (
	"key" text PRIMARY KEY,
	"cek" text DEFAULT '' NOT NULL,
	"catatan" text DEFAULT '' NOT NULL,
	"oleh" text DEFAULT '' NOT NULL,
	"oleh_user" text DEFAULT '' NOT NULL,
	"at" bigint NOT NULL,
	"jenis" text DEFAULT '' NOT NULL,
	"jenis_by" text DEFAULT '' NOT NULL,
	"jenis_at" bigint DEFAULT 0 NOT NULL,
	CONSTRAINT "cek_key_len" CHECK (length("key") BETWEEN 1 AND 300),
	CONSTRAINT "cek_cek_ok" CHECK ("cek" IN ('','CLEAR')),
	CONSTRAINT "cek_catatan_len" CHECK (length("catatan") <= 1000),
	CONSTRAINT "cek_jenis_ok" CHECK ("jenis" IN ('','TITIKAN','LANGSUNG'))
);
--> statement-breakpoint
CREATE TABLE "cek_hist" (
	"id" serial PRIMARY KEY,
	"key" text NOT NULL,
	"at" bigint NOT NULL,
	"oleh" text NOT NULL,
	"oleh_user" text NOT NULL,
	"act" text NOT NULL,
	"note" text DEFAULT '' NOT NULL,
	CONSTRAINT "cek_hist_act_ok" CHECK ("act" IN ('note','clear','open','jenis'))
);
--> statement-breakpoint
CREATE TABLE "docs" (
	"path" text PRIMARY KEY,
	"collection" text NOT NULL,
	"id" text NOT NULL,
	"data" text NOT NULL,
	"version" integer DEFAULT 1 NOT NULL,
	"updated_at" bigint NOT NULL,
	"updated_by" integer,
	CONSTRAINT "docs_path_ok" CHECK ("path" = "collection" || '/' || "id"),
	CONSTRAINT "docs_coll_len" CHECK (length("collection") BETWEEN 1 AND 64),
	CONSTRAINT "docs_id_len" CHECK (length("id") BETWEEN 1 AND 200)
);
--> statement-breakpoint
CREATE TABLE "google_accounts" (
	"user_id" integer PRIMARY KEY,
	"email" text NOT NULL,
	"refresh_token_enc" text NOT NULL,
	"scope" text DEFAULT '' NOT NULL,
	"connected_at" bigint NOT NULL,
	"updated_at" bigint NOT NULL
);
--> statement-breakpoint
CREATE TABLE "kv" (
	"key" text PRIMARY KEY,
	"value" text NOT NULL
);
--> statement-breakpoint
CREATE TABLE "sessions" (
	"id_hash" text PRIMARY KEY,
	"user_id" integer NOT NULL,
	"created_at" bigint NOT NULL,
	"last_seen_at" bigint NOT NULL,
	"expires_at" bigint NOT NULL,
	"ip" text,
	"ua" text
);
--> statement-breakpoint
CREATE TABLE "users" (
	"id" serial PRIMARY KEY,
	"username" text NOT NULL,
	"password_hash" text DEFAULT '' NOT NULL,
	"role" text NOT NULL,
	"areas" text DEFAULT '[]' NOT NULL,
	"label" text DEFAULT '' NOT NULL,
	"disabled" boolean DEFAULT false NOT NULL,
	"failed_count" integer DEFAULT 0 NOT NULL,
	"locked_until" bigint DEFAULT 0 NOT NULL,
	"created_at" bigint NOT NULL,
	"updated_at" bigint NOT NULL,
	"last_login_at" bigint,
	CONSTRAINT "users_username_ok" CHECK ("username" ~ '^[A-Za-z0-9._-]{3,64}$'),
	CONSTRAINT "users_role_ok" CHECK ("role" IN ('admin','pusat','daerah','viewer')),
	CONSTRAINT "users_label_len" CHECK (length("label") <= 80),
	CONSTRAINT "users_failed_ok" CHECK ("failed_count" >= 0),
	CONSTRAINT "users_daerah_areas" CHECK ("role" <> 'daerah' OR "areas" <> '[]')
);
--> statement-breakpoint
CREATE INDEX "audit_at" ON "audit" ("at" DESC NULLS LAST);--> statement-breakpoint
CREATE INDEX "cek_hist_key" ON "cek_hist" ("key","at" DESC NULLS LAST);--> statement-breakpoint
CREATE INDEX "docs_collection" ON "docs" ("collection");--> statement-breakpoint
CREATE INDEX "sessions_user" ON "sessions" ("user_id");--> statement-breakpoint
CREATE INDEX "sessions_exp" ON "sessions" ("expires_at");--> statement-breakpoint
CREATE UNIQUE INDEX "users_username_lower" ON "users" (lower("username"));--> statement-breakpoint
ALTER TABLE "cek_hist" ADD CONSTRAINT "cek_hist_key_cek_key_fkey" FOREIGN KEY ("key") REFERENCES "cek"("key") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "docs" ADD CONSTRAINT "docs_updated_by_users_id_fkey" FOREIGN KEY ("updated_by") REFERENCES "users"("id") ON DELETE SET NULL;--> statement-breakpoint
ALTER TABLE "google_accounts" ADD CONSTRAINT "google_accounts_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;--> statement-breakpoint
ALTER TABLE "sessions" ADD CONSTRAINT "sessions_user_id_users_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE CASCADE;