-- Akun awal. Password sengaja kosong: tidak ada password yang tersimpan di repo.
-- admin masuk pertama kali memakai ADMIN_PASSWORD (variabel lingkungan Netlify), lalu mengatur password akun lain dari menu Admin.
INSERT INTO "users" ("username", "password_hash", "role", "areas", "label", "created_at", "updated_at") VALUES
  ('admin', '', 'admin', '[]', 'Admin', (extract(epoch from now()) * 1000)::bigint, (extract(epoch from now()) * 1000)::bigint),
  ('manager', '', 'pusat', '[]', 'Manager Armada', (extract(epoch from now()) * 1000)::bigint, (extract(epoch from now()) * 1000)::bigint),
  ('armadapusat', '', 'pusat', '[]', 'Armada Pusat', (extract(epoch from now()) * 1000)::bigint, (extract(epoch from now()) * 1000)::bigint)
ON CONFLICT DO NOTHING;
