'use strict';
// Fitur pengembalian unit, jenis trip, dan log Monitor: aturan siapa boleh menulis apa.
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp } = require('./helpers');
const { ids } = require('./fake-google');

let t;
test.before(async () => {
  t = await startApp();
  await t.addUser('admin', 'admin');
  await t.addUser('armada.cpy', 'daerah', ['CPY']);
  await t.addUser('armada.lpg', 'daerah', ['LPG']);
  await t.addUser('lihat', 'viewer');
});
test.after(async () => { await t.close(); });

const jpeg = () => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.alloc(300, 7)]).toString('base64');
const jpegSof = () => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x04, 0, 0, 0xff, 0xc0, 0x00, 0x11, 0x08, 0x00, 0x20, 0x00, 0x30, 0x03, 1, 0x22, 0, 2, 0x11, 1, 3, 0x11, 1]), Buffer.alloc(300, 7)]).toString('base64');
const zipB64 = () => Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.alloc(60, 1), Buffer.from([0x50, 0x4b, 0x05, 0x06]), Buffer.alloc(18)]).toString('base64');
const cell = (id, col, row = 5) => (t.google.state.data[id]['DATA PEMINJAM'][row - 1] || [])[col.charCodeAt(0) - 65];

test('kolom U dan X area: hanya nilai tetap, hanya akun yang berwenang atas areanya', async () => {
  const cpy = t.client(), lpg = t.client(), lihat = t.client();
  await cpy.login('armada.cpy'); await lpg.login('armada.lpg'); await lihat.login('lihat');
  const put = (c, col, v, id = ids.CPY) => c.req('POST', '/api/sheets/update_values', { spreadsheetId: id, range: `'DATA PEMINJAM'!${col}5`, values: [[v]] });
  assert.equal((await put(cpy, 'U', 'TELAH DIKEMBALIKAN')).status, 200);
  assert.equal(cell(ids.CPY, 'U'), 'TELAH DIKEMBALIKAN');
  assert.equal((await put(cpy, 'X', 'ADA KERUSAKAN')).status, 200);
  assert.equal((await put(cpy, 'X', 'NORMAL')).status, 200);
  assert.equal((await put(cpy, 'X', 'bebas isi')).status, 400);
  assert.equal((await put(cpy, 'U', 'BERANGKAT')).status, 400);
  assert.equal((await put(cpy, 'W', 'x')).status, 400);
  assert.equal((await put(lpg, 'U', 'TELAH DIKEMBALIKAN')).status, 403, 'area lain ditolak');
  assert.equal((await put(lihat, 'U', 'TELAH DIKEMBALIKAN')).status, 403, 'viewer ditolak');
  assert.equal((await put(cpy, 'U', 'TELAH DIKEMBALIKAN', ids.OTHER)).status, 403, 'sheet tak terdaftar ditolak');
});

test('kolom W: hanya rumus HYPERLINK ke Drive dengan nama berkas berpola', async () => {
  const cpy = t.client(); await cpy.login('armada.cpy');
  const f = (formula) => cpy.req('POST', '/api/sheets/update_formulas', { spreadsheetId: ids.CPY, range: "'DATA PEMINJAM'!W5", formulas: [[formula]] });
  // berkas harus benar-benar diunggah lewat server ini dulu
  const up = await cpy.req('POST', '/api/drive/create_file', { code: 'CPY', jenis: 'PULANG', base64Content: jpeg() });
  assert.equal(up.status, 200);
  const fid = up.json.payload.id, title = up.json.payload.title;
  assert.match(title, /^CIPAYUNG_PULANG_\d{12}\.jpeg$/);
  const ok = `=HYPERLINK("https://drive.google.com/file/d/${fid}/view?usp=drivesdk";"${title}")`;
  assert.equal((await f(ok)).status, 200);
  assert.equal((await f(ok.replace(';', ','))).status, 200);
  const fm = await cpy.req('POST', '/api/drive/create_file', { code: 'CPY', jenis: 'FORM_PULANG', base64Content: jpegSof() });
  const okForm = `=HYPERLINK("https://drive.google.com/file/d/${fm.json.payload.id}/view?usp=drivesdk";"${fm.json.payload.title}")`;
  assert.equal((await f(okForm)).status, 200, 'form pemeriksaan juga boleh masuk kolom W');
  const bg = await cpy.req('POST', '/api/drive/create_file', { code: 'CPY', jenis: 'BERANGKAT', base64Content: jpegSof() });
  assert.equal(bg.status, 200);
  assert.match(bg.json.payload.title, /^CIPAYUNG_BERANGKAT_\d{12}\.pdf$/);
  const fb = `=HYPERLINK("https://drive.google.com/file/d/${bg.json.payload.id}/view?usp=drivesdk";"${bg.json.payload.title}")`;
  const fv = (formula, col) => cpy.req('POST', '/api/sheets/update_formulas', { spreadsheetId: ids.CPY, range: `'DATA PEMINJAM'!${col}5`, formulas: [[formula]] });
  assert.equal((await fv(fb, 'V')).status, 200, 'form berangkat ke kolom V');
  assert.equal((await fv(fb, 'W')).status, 400, 'berkas berangkat tidak boleh ke kolom W');
  assert.equal((await fv(okForm, 'V')).status, 400, 'berkas pulang tidak boleh ke kolom V');
  // tautan ke berkas lain (bukan hasil unggahan server) ditolak
  assert.equal((await f(ok.replace(fid, 'BERKAS_MILIK_PENYERANG_123'))).status, 403);
  assert.equal((await f('=HYPERLINK("https://evil.example/x";"a")')).status, 400);
  assert.equal((await f('=IMPORTRANGE("abc";"A1")')).status, 400);
});

test('foto unit & form: subfolder per area dibuat sekali, nama berpola, file lama ke sampah', async () => {
  const cpy = t.client(), lpg = t.client(), lihat = t.client();
  await cpy.login('armada.cpy'); await lpg.login('armada.lpg'); await lihat.login('lihat');
  const up = (c, body) => c.req('POST', '/api/drive/create_file', { base64Content: jpeg(), parentId: 'abaikan', ...body });
  const r = await up(cpy, { code: 'CPY', jenis: 'PULANG' });
  assert.equal(r.status, 200);
  assert.match(r.json.payload.viewUrl, /^https:\/\/drive\.google\.com\/file\/d\//);
  const g = t.google.state;
  const u = g.uploads.at(-1);
  assert.match(u.name, /^CIPAYUNG_PULANG_\d{12}\.jpeg$/);
  const fo = g.folders.find((x) => x.name === 'CIPAYUNG');
  assert.ok(fo, 'subfolder area dibuat');
  assert.deepEqual(fo.parents, ['1ogPsvCHhhVcY17J2bfwdISmThzg9J3VH'], 'induk ditentukan server');
  assert.deepEqual(u.parents, [fo.id]);
  const r2 = await up(cpy, { code: 'CPY', jenis: 'FORM_PULANG', base64Content: jpegSof(), oldId: r.json.payload.id });
  assert.equal(r2.status, 200);
  assert.match(g.uploads.at(-1).name, /^CIPAYUNG_FORM_PULANG_\d{12}\.pdf$/);
  assert.equal(g.uploads.at(-1).mime, 'application/pdf');
  assert.equal((await up(cpy, { code: 'CPY', jenis: 'FORM_PULANG' })).status, 400, 'JPEG tanpa header ukuran tidak bisa dibuat PDF');
  const pdfIn = await up(cpy, { code: 'CPY', jenis: 'FORM_PULANG', base64Content: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(200, 32)]).toString('base64') });
  assert.equal(pdfIn.status, 200, 'PDF langsung diterima');
  assert.match(pdfIn.json.payload.title, /_FORM_PULANG_\d{12}\.pdf$/);
  const ck = await up(cpy, { code: 'CPY', jenis: 'CHECKLIST_BERANGKAT', base64Content: jpeg() });
  assert.equal(ck.status, 200);
  assert.match(ck.json.payload.title, /^CIPAYUNG_CHECKLIST_BERANGKAT_\d{12}\.jpeg$/);
  const ckp = await up(cpy, { code: 'CPY', jenis: 'CHECKLIST_BERANGKAT', base64Content: Buffer.concat([Buffer.from('%PDF-1.4\n'), Buffer.alloc(200, 32)]).toString('base64') });
  assert.match(ckp.json.payload.title, /\.pdf$/);
  assert.equal((await up(cpy, { code: 'CPY', jenis: 'CHECKLIST_BERANGKAT', base64Content: zipB64() })).status, 400, 'ZIP bukan format checklist');
  const z = await up(cpy, { code: 'CPY', jenis: 'KERUSAKAN', base64Content: zipB64() });
  assert.equal(z.status, 200);
  assert.match(z.json.payload.title, /^CIPAYUNG_KERUSAKAN_\d{12}\.zip$/);
  const z2 = await up(cpy, { code: 'CPY', jenis: 'PULANG', base64Content: zipB64() });
  assert.match(z2.json.payload.title, /\.zip$/);
  assert.equal(g.folders.filter((x) => x.name === 'CIPAYUNG').length, 1, 'folder dipakai ulang');
  assert.ok(g.trashed.includes(r.json.payload.id), 'berkas lama masuk sampah');
  assert.equal((await up(lpg, { code: 'CPY', jenis: 'PULANG' })).status, 403);
  assert.equal((await up(lihat, { code: 'CPY', jenis: 'PULANG' })).status, 403);
  assert.equal((await up(cpy, { code: 'XXX', jenis: 'PULANG' })).status, 400);
  assert.equal((await up(cpy, { code: 'CPY', jenis: 'BERANGKAT' })).status, 400);
  assert.equal((await up(cpy, { code: 'CPY', jenis: 'PULANG', base64Content: Buffer.from('bukan gambar '.repeat(30)).toString('base64') })).status, 400);
});

test('log Monitor: 13 kolom, sel berawalan rumus dinetralkan', async () => {
  const adm = t.client(), lihat = t.client(); await adm.login('admin'); await lihat.login('lihat');
  const row = (n) => Array.from({ length: 13 }, (_, i) => (i === 11 ? n : 'x' + i));
  const post = (c, values) => c.req('POST', '/api/sheets/append_values', { spreadsheetId: 'abaikan', range: "'LOG PERUBAHAN'!A1", values: [values] });
  assert.equal((await post(adm, row('=IMPORTXML("http://a")'))).status, 200);
  const last = t.google.state.data[ids.LOG]['LOG PERUBAHAN'].at(-1);
  assert.equal(last[11], "'=IMPORTXML(\"http://a\")");
  assert.equal(last[12], 'Admin', 'pelaku diisi server, bukan klien');
  assert.notEqual(last[0], 'x0', 'waktu diisi server');
  assert.equal((await post(adm, row('x').slice(0, 12))).status, 400);
  assert.equal((await post(lihat, row('x'))).status, 403);
});

test('jenis trip: semua akun non-viewer bisa ubah titikan/langsung, tersimpan dan tercatat', async () => {
  const adm = t.client(), lihat = t.client(); await adm.login('admin'); await lihat.login('lihat');
  const k = 'STRUK-JENIS-1';
  const r = await adm.req('POST', '/api/cek', { key: k, act: 'jenis', jenis: 'TITIKAN', note: 'Langsung → Titikan' });
  assert.equal(r.status, 200);
  assert.equal(r.json.jenis, 'TITIKAN');
  assert.ok(r.json.hist.some((h) => h.act === 'jenis'));
  assert.equal((await adm.req('POST', '/api/cek', { key: k, act: 'jenis', jenis: 'BEBAS' })).status, 400);
  assert.equal((await lihat.req('POST', '/api/cek', { key: k, act: 'jenis', jenis: 'LANGSUNG' })).status, 403);
  const all = await adm.req('GET', '/api/cek');
  assert.equal(all.json.items.find((x) => x.k === k).jenis, 'TITIKAN');
  const back = await adm.req('POST', '/api/cek', { key: k, act: 'jenis', jenis: 'LANGSUNG', note: 'Titikan → Langsung' });
  assert.equal(back.json.jenis, 'LANGSUNG');
});

test('kstat: akun daerah hanya menulis status pengembalian untuk areanya', async () => {
  const cpy = t.client(), lpg = t.client(); await cpy.login('armada.cpy'); await lpg.login('armada.lpg');
  assert.equal((await cpy.req('PUT', '/api/db/kstat/CPY261016001', { data: { returned: true } })).status, 200);
  assert.equal((await lpg.req('PUT', '/api/db/kstat/CPY261016001', { data: { returned: true } })).status, 403);
  assert.equal((await lpg.req('GET', '/api/db/kstat/CPY261016001')).status, 403, 'status area lain tidak terbaca');
  assert.equal((await cpy.req('GET', '/api/db/kstat/CPY261016001')).json.exists, true);
});

test('hasil tinjauan keamanan: rentang raksasa ditolak, metrik tidak bertambah oleh path acak, readyz tidak membocorkan error', async () => {
  const adm = t.client(); await adm.login('admin');
  const big = await adm.req('POST', '/api/sheets/get_values', { spreadsheetId: ids.ACC, range: "'ACC PUSAT'!A1:ZZ999999" });
  assert.equal(big.status, 400);
  for (let i = 0; i < 30; i++) await fetch(t.base + '/api/acak-' + i + '/x');
  const m = await (await fetch(t.base + '/metrics')).text();
  assert.ok(!/acak-/.test(m), 'label metrik tidak memuat path acak');
  const ready = await (await fetch(t.base + '/readyz')).json();
  assert.deepEqual(Object.keys(ready.sheets).sort(), ['areas', 'configured']);
});
