'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const { createRequire } = require('node:module');
const { transformSync } = require('esbuild');

function fixture(sql) {
  let closed = 0;
  const logs = [];
  const module = { exports: {} };
  const actualRequire = createRequire(require('node:path').resolve('netlify/functions/session.mts'));
  const source = transformSync(fs.readFileSync('netlify/functions/session.mts', 'utf8'), { loader: 'ts', format: 'cjs' }).code;
  vm.runInNewContext(source, {
    module, exports: module.exports, Response, Request, URL, Buffer,
    console: { error: (...args) => logs.push(args) },
    Netlify: { env: { get: () => undefined } },
    require: name => name === '@netlify/database' ? { getDatabase: () => ({ sql, pool: { end: async () => { closed++; } } }) } : actualRequire(name),
  });
  return {
    call: () => module.exports.default(new Request('https://example.test/api/session'), { cookies: { get: () => '' } }),
    closed: () => closed, logs,
  };
}

test('session endpoint closes its connection pool after an unauthenticated request', async () => {
  const f = fixture(async () => []);
  const response = await f.call();
  assert.equal(response.status, 401);
  assert.equal((await response.json()).error.code, 'unauthenticated');
  assert.equal(f.closed(), 1);
});

test('session endpoint unwraps database failure and closes its pool without leaking SQL parameters', async () => {
  const sensitive = 'private-query-parameter';
  const f = fixture(async () => { throw Object.assign(new Error(sensitive), { cause: Object.assign(new Error(sensitive), { code: '42501' }) }); });
  const response = await f.call();
  assert.equal(response.status, 503);
  const body = await response.json();
  assert.equal(body.error.code, 'database_permissions');
  assert.equal(f.closed(), 1);
  assert.ok(!JSON.stringify([body, f.logs]).includes(sensitive));
  assert.equal(f.logs[0][1].stage, 'session.read');
});
