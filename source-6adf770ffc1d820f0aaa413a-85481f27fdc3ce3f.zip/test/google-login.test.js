'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { verifyIdentity } = require('../server/google-identity');
const { startApp } = require('./helpers');

test('Identity verification rejects missing, invalid, unconfirmed and unreachable sessions', async () => {
  const endpoint = 'https://identity.test/.netlify/identity';
  await assert.rejects(verifyIdentity('', endpoint), { code: 'google_session' });
  await assert.rejects(verifyIdentity('nf_jwt=test', ''), { code: 'google_unavailable' });
  await assert.rejects(verifyIdentity('nf_jwt=test', endpoint, async () => new Response('{}', { status: 401 })), { code: 'google_session' });
  await assert.rejects(verifyIdentity('nf_jwt=test', endpoint, async () => Response.json({ id: 'id', email: 'test@example.test' })), { code: 'google_unverified' });
  await assert.rejects(verifyIdentity('nf_jwt=test', endpoint, async () => { throw new Error('offline'); }), { code: 'google_unavailable' });
});

test('Google links only through an existing session, preserves roles and rejects conflicting/disabled accounts', async (t) => {
  const endpoint = 'https://identity.test/.netlify/identity';
  const app = await startApp({ NETLIFY_IDENTITY_URL: endpoint });
  t.after(() => app.close());
  await app.addUser('lihat.google', 'viewer');
  await app.addUser('lain.google', 'admin');
  const originalFetch = global.fetch;
  t.mock.method(global, 'fetch', (url, options) => {
    if (url === endpoint + '/user') return Promise.resolve(Response.json({ id: 'verified-subject', email: 'viewer@example.test', confirmed_at: '2026-01-01', user_metadata: { role: 'admin' } }));
    return originalFetch(url, options);
  });
  const google = app.client();
  const cookie = { Cookie: 'nf_jwt=test-session' };
  assert.equal((await google.req('POST', '/api/google/link', {}, cookie)).status, 401);
  assert.equal((await google.req('POST', '/api/login/google', {}, cookie)).status, 403);
  const user = app.client();
  assert.equal((await user.login('lihat.google')).status, 200);
  const linkedCookie = { Cookie: user.cookie + '; nf_jwt=test-session' };
  assert.equal((await user.req('POST', '/api/google/link', {}, linkedCookie)).status, 200);
  assert.equal((await user.req('POST', '/api/google/link', {}, linkedCookie)).status, 200);
  const login = await google.req('POST', '/api/login/google', {}, cookie);
  assert.equal(login.status, 200);
  assert.equal(login.json.user.username, 'lihat.google');
  assert.equal(login.json.user.role, 'viewer');
  assert.match(login.headers.getSetCookie()[0], /HttpOnly/);
  assert.equal((await google.req('GET', '/api/session')).status, 200);
  const other = app.client();
  await other.login('lain.google');
  assert.equal((await other.req('POST', '/api/google/link', {}, { Cookie: other.cookie + '; nf_jwt=test-session' })).status, 409);
  assert.equal((await google.req('POST', '/api/logout', {})).status, 200);
  assert.equal((await google.req('GET', '/api/session')).status, 401);
  // Password login still works after a Google link is created.
  assert.equal((await user.login('lihat.google')).status, 200);
  app.app.db.prepare("UPDATE users SET disabled = 1 WHERE username = 'lihat.google'").run();
  assert.equal((await google.req('POST', '/api/login/google', {}, cookie)).status, 403);
});
