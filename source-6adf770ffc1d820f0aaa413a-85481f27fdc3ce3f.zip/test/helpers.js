'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { load } = require('../server/config');
const { createApp } = require('../server/app');
const { hashPassword } = require('../server/auth');
const { createFakeGoogle } = require('./fake-google');

async function startApp(extraEnv = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'armada-test-'));
  const google = createFakeGoogle();
  const pub = path.join(dir, 'public');
  fs.mkdirSync(path.join(pub, 'assets'), { recursive: true });
  fs.writeFileSync(path.join(pub, 'index.html'), '<!doctype html><title>t</title>' + 'x'.repeat(2000));
  fs.writeFileSync(path.join(pub, 'assets', 'a.js'), 'console.log(1)');
  fs.writeFileSync(path.join(dir, 'secret.txt'), 'RAHASIA');
  const priv = path.join(dir, 'private');
  fs.mkdirSync(priv);
  fs.writeFileSync(path.join(priv, 'ttd_mgr.png'), Buffer.from('PNG-TANDA-TANGAN'));
  const cfg = load({
    DATA_DIR: dir, PUBLIC_DIR: pub, PRIVATE_DIR: priv, PORT: '0', HOST: '127.0.0.1', LOG_LEVEL: 'error',
    GOOGLE_SA_JSON: google.saJson, SHEETS_API_BASE: 'http://google.test', GOOGLE_TOKEN_URL: 'http://google.test/token',
    SHEETS_CACHE_TTL_MS: '0', SHEETS_LOG_ID: google.ids.LOG, DRIVE_API_BASE: 'http://google.test', SHEETS_AREA_REFRESH_MS: '1000', LOGIN_MAX_FAILS: '5', ...extraEnv,
  });
  const logger = { debug() {}, info() {}, warn() {}, error() {} };
  // fetch Google palsu hanya untuk host google.test
  const app = createApp(cfg, { fetchImpl: (u, o) => google.fetchImpl(u.replace('http://google.test', 'http://google.test'), o), logger });
  await new Promise((r) => app.server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${app.server.address().port}`;

  async function addUser(username, role, areas = [], password = 'Password-Uji-1') {
    const now = Date.now();
    app.db.prepare('INSERT INTO users (username, password_hash, role, areas, label, created_at, updated_at) VALUES (?,?,?,?,?,?,?)').run(username, await hashPassword(password), role, JSON.stringify(areas), '', now, now);
    return password;
  }
  // klien sederhana dengan cookie jar
  function client() {
    let cookie = '';
    const c = {
      get cookie() { return cookie; },
      async req(method, p, body, headers = {}) {
        const res = await fetch(base + p, {
          method, redirect: 'manual',
          headers: { ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(method !== 'GET' && method !== 'HEAD' ? { 'X-Requested-With': 'armada-web' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers },
          body: body !== undefined ? JSON.stringify(body) : undefined,
        });
        const sc = res.headers.getSetCookie();
        for (const s of sc) { const [kv] = s.split(';'); const [k, v] = kv.split('='); cookie = v ? `${k}=${v}` : ''; if (/Max-Age=0/.test(s)) cookie = ''; }
        const text = await res.text();
        let json = null; try { json = JSON.parse(text); } catch { /* bukan JSON */ }
        return { status: res.status, headers: res.headers, json, text };
      },
      async login(u, p = 'Password-Uji-1') { return c.req('POST', '/api/login', { username: u, password: p }); },
    };
    return c;
  }
  return { app, cfg, base, google, addUser, client, dir, close: async () => { await app.close(); fs.rmSync(dir, { recursive: true, force: true }); } };
}

module.exports = { startApp };
