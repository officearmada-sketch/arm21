'use strict';
// Google palsu untuk tes: endpoint token + Sheets values GET/PUT dengan data dalam memori.
const crypto = require('node:crypto');

const ids = {
  ACC: '1uwenWPo9NR9rkTfZpHuJaXQFEGnspVjg0Ty6K4xpSDI',
  FORM: '1V18f6If7Emm_bgpfuMUnLiJDCzA-4w1bAnM7D5EhJjw',
  CPY: 'AREA_CPY_aaaaaaaaaaaaaaaaaaaa',
  LPG: 'AREA_LPG_bbbbbbbbbbbbbbbbbbbb',
  OTHER: 'OTHER_SHEET_cccccccccccccccccc',
  LOG: 'LOG_SHEET_dddddddddddddddddddd',
  SPPD: '19BQ1RVmu04zoehzE_SNJYuurRAH9hgysJU2z_370Q5M',
  EMP: '1h5jyC0dui20lPWCQLaKguzMuVvcHtjjIVPMkd4jrzNA',
};
const colN = (s) => [...s].reduce((a, c) => a * 26 + c.charCodeAt(0) - 64, 0);

function fixtures() {
  const H = Array.from({ length: 24 }, (_, i) => 'H' + i);
  return {
    [ids.ACC]: {
      MASTER: [['CPY', 'CIPAYUNG', `https://docs.google.com/spreadsheets/d/${ids.CPY}/edit?gid=0#gid=0`], ['LPG', 'LAMPUNG', `https://docs.google.com/spreadsheets/d/${ids.LPG}/edit?gid=0#gid=0`]],
      'ACC PUSAT': [[], ['x', 'CPY261016001', 'jokowi'], ['x', 'LPG261017001', 'budi']],
    },
    [ids.FORM]: { DATA: [['ts', 'no'], ['10/16/2026 18:41:49', 'CPY261016001']] },
    [ids.CPY]: { 'DATA PEMINJAM': [[], [], [], H, ['t', 'CPY261016001', 'jokowi']] },
    [ids.LPG]: { 'DATA PEMINJAM': [[], [], [], H, ['t', 'LPG261017001', 'budi']] },
    [ids.LOG]: { 'LOG PERUBAHAN': [['WAKTU', 'AKSI']] },
    [ids.SPPD]: { 'LIST PERJALANAN DINAS NEW': [[], ['NO', 'NO. SPPD', 'KATEGORI'], [], ['1', 'SPPD/PUSAT/01', 'RANGE 1', 'Sabtu, 24 Oktober 2026', 'Sabtu, 24 Oktober 2026', '100959', '', '', '', '', '', 'MOBIL INVENTARIS', '', '', 'KE AGEN KREKOT AGENDA PERBAIKAN KOMPUTER']] },
    [ids.EMP]: { STAFF: [['NIB', 'NAMA'], ['100959', 'MUHAMMAD ALFARABY']] },
    [ids.OTHER]: { Sheet1: [['a', 'b'], ['1', '2']] },
  };
}

function parseRange(range) {
  let sheet = null, a1 = range;
  const q = range.match(/^'((?:[^']|'')+)'!(.*)$/);
  if (q) { sheet = q[1].replace(/''/g, "'"); a1 = q[2]; }
  else if (range.includes('!')) { [sheet, a1] = range.split('!'); }
  const m = a1.match(/^([A-Z]+)(\d*)(?::([A-Z]+)(\d*))?$/);
  return { sheet, c1: colN(m[1]) - 1, r1: (m[2] ? +m[2] : 1) - 1, c2: m[3] ? colN(m[3]) - 1 : colN(m[1]) - 1, r2: m[4] ? +m[4] - 1 : m[2] ? +m[2] - 1 : 1e9 };
}

function createFakeGoogle(opts = {}) {
  const { privateKey, publicKey } = crypto.generateKeyPairSync('rsa', { modulusLength: 2048 });
  const state = { data: opts.fixtures ? opts.fixtures() : fixtures(), calls: [], tokenCalls: 0, failNext: 0, denyIds: new Set() };
  const json = (status, obj) => ({ ok: status < 400, status, statusText: String(status), json: async () => obj });

  async function fetchImpl(url, opts = {}) {
    const u = new URL(url), method = opts.method || 'GET';
    if (u.pathname === '/token') {
      state.tokenCalls++;
      const a = new URLSearchParams(opts.body).get('assertion') || '';
      const [h, c, s] = a.split('.');
      const ok = crypto.verify('RSA-SHA256', Buffer.from(`${h}.${c}`), publicKey, Buffer.from(s, 'base64url'));
      return ok ? json(200, { access_token: 'tok-' + state.tokenCalls, expires_in: 3600 }) : json(400, { error: 'invalid_grant' });
    }
    if (u.pathname === '/drive/v3/files' || /^\/drive\/v3\/files\/[^/]+$/.test(u.pathname)) {
      if (!(opts.headers && /^Bearer tok-/.test(opts.headers.Authorization))) return json(401, { error: { message: 'no auth' } });
      state.folders = state.folders || []; state.trashed = state.trashed || [];
      if (method === 'GET') {
        const nm = (u.searchParams.get('q') || '').match(/name = '([^']+)'/);
        return json(200, { files: state.folders.filter((f) => nm && f.name === nm[1]).map((f) => ({ id: f.id })) });
      }
      if (method === 'POST') { const b = JSON.parse(opts.body); const f = { id: 'FAKEFOLDER_' + (state.folders.length + 1) + '_abcdefghij', name: b.name, parents: b.parents }; state.folders.push(f); return json(200, { id: f.id }); }
      if (method === 'PATCH') { state.trashed.push(u.pathname.split('/').pop()); return json(200, { id: 'x' }); }
    }
    if (u.pathname === '/upload/drive/v3/files' && method === 'POST') {
      if (!(opts.headers && /^Bearer tok-/.test(opts.headers.Authorization))) return json(401, { error: { message: 'no auth' } });
      state.uploads = state.uploads || [];
      const txt = Buffer.from(opts.body).toString('latin1');
      const meta = JSON.parse(txt.slice(txt.indexOf('{'), txt.indexOf('}') + 1));
      state.uploads.push({ name: meta.name, parents: meta.parents, mime: meta.mimeType, size: opts.body.length });
      return json(200, { id: 'FAKEFILEID_' + state.uploads.length + '_abcdef' });
    }
    const m = u.pathname.match(/^\/v4\/spreadsheets\/([^/]+)\/values\/(.+)$/);
    if (!m) return json(404, { error: { message: 'nf' } });
    if (!(opts.headers && /^Bearer tok-/.test(opts.headers.Authorization))) return json(401, { error: { message: 'no auth' } });
    const id = m[1], range = decodeURIComponent(m[2]);
    state.calls.push([method, id, range]);
    if (method === 'POST' && range.endsWith(':append')) {
      const body = JSON.parse(opts.body), sh0 = (state.data[id] || {})['LOG PERUBAHAN'];
      if (!sh0) return json(404, { error: { message: 'nf' } });
      sh0.push(body.values[0]);
      return json(200, { updates: { updatedRows: 1 } });
    }
    if (state.failNext > 0) { state.failNext--; return json(503, { error: { message: 'busy' } }); }
    const wb = state.data[id];
    if (!wb || state.denyIds.has(id)) return json(404, { error: { message: 'Requested entity was not found.' } });
    const p = parseRange(range);
    const name = p.sheet || Object.keys(wb)[0], sh = wb[name];
    if (!sh) return json(400, { error: { message: 'Unable to parse range: ' + range } });
    if (method === 'GET') {
      const out = [];
      for (let r = p.r1; r <= Math.min(p.r2, sh.length - 1); r++) {
        const row = (sh[r] || []).slice(p.c1, p.c2 + 1).map((x) => (typeof x === 'boolean' ? (x ? 'TRUE' : 'FALSE') : x));
        while (row.length && row[row.length - 1] === '') row.pop();
        out.push(row);
      }
      while (out.length && !out[out.length - 1].length) out.pop();
      return json(200, { range, majorDimension: 'ROWS', ...(out.length ? { values: out } : {}) });
    }
    if (method === 'PUT') {
      const body = JSON.parse(opts.body);
      sh[p.r1] = sh[p.r1] || [];
      while (sh[p.r1].length <= p.c1) sh[p.r1].push('');
      sh[p.r1][p.c1] = body.values[0][0];
      return json(200, { updatedCells: 1, updatedRange: range });
    }
    return json(405, {});
  }
  return { fetchImpl, state, ids, saJson: JSON.stringify({ client_email: 'armada@test.iam.gserviceaccount.com', private_key: privateKey.export({ type: 'pkcs8', format: 'pem' }) }) };
}

module.exports = { createFakeGoogle, ids };
