'use strict';
// Pemakaian Unit: akses baca SPPD/karyawan, aturan koleksi "pakai" (per area, kolom milik Armada Pusat), unggahan Drive.
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp } = require('./helpers');
const { ids } = require('./fake-google');

let t;
test.before(async () => {
  t = await startApp();
  await t.addUser('admin', 'admin');
  await t.addUser('pusat', 'pusat');
  await t.addUser('armada.cpy', 'daerah', ['CPY']);
  await t.addUser('armada.lpg', 'daerah', ['LPG']);
  await t.addUser('lihat', 'viewer');
});
test.after(async () => { await t.close(); });

const jpegSof = () => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x04, 0, 0, 0xff, 0xc0, 0x00, 0x11, 0x08, 0x00, 0x20, 0x00, 0x30, 0x03, 1, 0x22, 0, 2, 0x11, 1, 3, 0x11, 1]), Buffer.alloc(300, 7)]).toString('base64');
const login = async (u) => { const c = t.client(); await c.login(u); return c; };
const rec = (o = {}) => ({ sppd: 'SPPD/PUSAT/01', nib: ['100959'], nama: [{ nib: '100959', name: 'MUHAMMAD ALFARABY' }], agenda: 'KE AGEN', nopol: 'B 9134 KXW', kode: 'CPY', area: 'CIPAYUNG', ar: false, pu: false, dep: false, ...o });
const ID = 'SPPD_PUSAT_01';

test('baca SPPD dan karyawan: hanya admin dan Armada Pusat', async () => {
  const rd = (c, id, range) => c.req('POST', '/api/sheets/get_values', { spreadsheetId: id, range });
  for (const [u, ok] of [['admin', true], ['pusat', true], ['armada.cpy', false], ['lihat', false]]) {
    const c = await login(u);
    const a = await rd(c, ids.SPPD, "'LIST PERJALANAN DINAS NEW'!A1:Z3"), b = await rd(c, ids.EMP, "'STAFF'!A2:B");
    assert.equal(a.status, ok ? 200 : 403, u + ' SPPD');
    assert.equal(b.status, ok ? 200 : 403, u + ' karyawan');
  }
  const p = await login('pusat');
  const r = await rd(p, ids.SPPD, "'LIST PERJALANAN DINAS NEW'!A4:Z");
  assert.equal(r.json.payload.values[0][1], 'SPPD/PUSAT/01');
  assert.equal((await rd(p, ids.OTHER, 'Sheet1!A1:B2')).status, 403, 'sheet tak terdaftar tetap ditolak');
});

test('koleksi pakai: buat hanya staf, akun daerah hanya areanya dan tanpa kolom Armada Pusat', async () => {
  const pusat = await login('pusat'), cpy = await login('armada.cpy'), lpg = await login('armada.lpg'), lihat = await login('lihat');
  const put = (c, d, id = ID) => c.req('PUT', '/api/db/pakai/' + id, { data: d });
  assert.equal((await put(lihat, rec())).status, 403, 'viewer tidak boleh menulis');
  assert.equal((await put(cpy, rec())).status, 403, 'akun daerah tidak boleh membuat pengajuan');
  assert.equal((await put(pusat, rec())).status, 200);
  // baca: area lain tidak melihat
  assert.equal((await cpy.req('GET', '/api/db/pakai/' + ID)).json.exists, true);
  assert.equal((await lpg.req('GET', '/api/db/pakai/' + ID)).status, 403);
  assert.equal((await cpy.req('GET', '/api/db/pakai')).json.docs.length, 1);
  assert.equal((await lpg.req('GET', '/api/db/pakai')).json.docs.length, 0);
  assert.equal((await lihat.req('GET', '/api/db/pakai')).status, 403);
  // ACC area oleh akun daerah sendiri boleh
  assert.equal((await put(cpy, rec({ ac: true, acBy: 'armada.cpy' }))).status, 200);
  // kolom milik Armada Pusat tidak boleh diubah akun daerah
  assert.equal((await put(cpy, rec({ ac: true, ar: true }))).status, 403, 'ACC Armada Pusat');
  assert.equal((await put(cpy, rec({ ac: true, dep: true }))).status, 403, 'berangkat');
  assert.equal((await put(cpy, rec({ ac: true, kode: 'LPG' }))).status, 403, 'pindah area');
  assert.equal((await put(cpy, rec({ ac: true, nopol: 'X 1 Y' }))).status, 403, 'ganti mobil');
  // area lain tidak boleh mengubah
  assert.equal((await put(lpg, rec({ ac: true }))).status, 403);
  // staf boleh ACC dan berangkat
  assert.equal((await put(pusat, rec({ ac: true, ar: true, pu: true, dep: true }))).status, 200);
});

test('koleksi pakai: yang sudah berangkat tidak bisa dihapus, yang belum bisa oleh staf saja', async () => {
  const pusat = await login('pusat'), cpy = await login('armada.cpy');
  assert.equal((await pusat.req('DELETE', '/api/db/pakai/' + ID)).status, 409);
  await pusat.req('PUT', '/api/db/pakai/DRAFT_1', { data: rec({ sppd: 'DRAFT/1' }) });
  assert.equal((await cpy.req('DELETE', '/api/db/pakai/DRAFT_1')).status, 403);
  assert.equal((await pusat.req('DELETE', '/api/db/pakai/DRAFT_1')).status, 200);
});

test('unggah form pemakaian ke Drive: PDF di subfolder area, hanya akun yang berwenang', async () => {
  const pusat = await login('pusat'), cpy = await login('armada.cpy'), lpg = await login('armada.lpg'), lihat = await login('lihat');
  const up = (c, jenis, code = 'CPY') => c.req('POST', '/api/drive/create_file', { code, jenis, base64Content: jpegSof() });
  const a = await up(pusat, 'PAKAI_BERANGKAT');
  assert.equal(a.status, 200);
  assert.match(a.json.payload.title, /^CIPAYUNG_PAKAI_BERANGKAT_\d{12}\.pdf$/);
  const b = await up(cpy, 'PAKAI_PULANG');
  assert.equal(b.status, 200);
  assert.match(b.json.payload.title, /^CIPAYUNG_PAKAI_PULANG_\d{12}\.pdf$/);
  assert.equal((await up(lpg, 'PAKAI_PULANG')).status, 403, 'area lain ditolak');
  assert.equal((await up(lihat, 'PAKAI_PULANG')).status, 403, 'viewer ditolak');
  assert.equal((await up(pusat, 'PAKAI_LAIN')).status, 400, 'jenis tak dikenal');
});
