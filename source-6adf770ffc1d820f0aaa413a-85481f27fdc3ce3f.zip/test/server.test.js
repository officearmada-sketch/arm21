'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp } = require('./helpers');

let t;
test.before(async () => {
  t = await startApp();
  await t.addUser('admin', 'admin');
  await t.addUser('armada.pusat', 'pusat');
  await t.addUser('manager', 'pusat');
  await t.addUser('armada.lpg', 'daerah', ['LPG']);
  await t.addUser('armada.cpy', 'daerah', ['CPY']);
  await t.addUser('lihat', 'viewer');
});
test.after(async () => { await t.close(); });

test('login: berhasil, cookie HttpOnly+SameSite, kunci data hanya untuk yang login', async () => {
  const c = t.client();
  assert.equal((await c.req('GET', '/api/session')).status, 401);
  const r = await c.login('armada.lpg');
  assert.equal(r.status, 200);
  assert.equal(r.json.user.label, 'Armada Lampung');
  assert.equal(r.json.user.role, 'daerah');
  assert.ok(r.json.key);
  const sc = r.headers.getSetCookie()[0];
  assert.match(sc, /HttpOnly/); assert.match(sc, /SameSite=Lax/);
  assert.equal((await c.req('GET', '/api/session')).json.user.username, 'armada.lpg');
  assert.equal((await c.req('POST', '/api/logout', {})).status, 200);
  assert.equal((await c.req('GET', '/api/session')).status, 401);
});

test('login: pesan sama untuk user tak dikenal dan password salah; akun terkunci setelah 5 gagal', async () => {
  const c = t.client();
  const a = await c.login('tidak.ada', 'x1234567');
  const b = await c.login('lihat', 'salah-salah');
  assert.equal(a.status, 401); assert.equal(b.status, 401);
  assert.equal(a.json.error.message, b.json.error.message);
  for (let i = 0; i < 4; i++) await c.login('lihat', 'salah-salah');
  const locked = await c.login('lihat'); // password benar tapi sudah terkunci
  assert.equal(locked.status, 429);
  assert.ok(locked.headers.get('retry-after'));
  t.app.db.prepare("UPDATE users SET failed_count = 0, locked_until = 0 WHERE username = 'lihat'").run();
});

test('CSRF: metode tulis tanpa header khusus atau dengan Origin asing ditolak', async () => {
  const c = t.client();
  await c.login('admin');
  const noHdr = await fetch(t.base + '/api/logout', { method: 'POST', headers: { Cookie: c.cookie, 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(noHdr.status, 403);
  const evil = await c.req('PUT', '/api/db/config/x', { data: {} }, { Origin: 'https://evil.example' });
  assert.equal(evil.status, 403);
});

test('doc store: aturan per koleksi ditegakkan server', async () => {
  const admin = t.client(), lihat = t.client(), lpg = t.client();
  await admin.login('admin'); await lihat.login('lihat'); await lpg.login('armada.lpg');
  assert.equal((await admin.req('PUT', '/api/db/trips/2026-10-01', { data: { iv: 'a', ct: 'b' } })).status, 200);
  assert.equal((await lihat.req('PUT', '/api/db/trips/2026-10-02', { data: { iv: 'a', ct: 'b' } })).status, 403);
  // Armada Pusat memakai Monitor sebagai admin data (impor harian), tetapi tidak boleh mengubah konfigurasi
  const pst = t.client(); await pst.login('armada.pusat');
  assert.equal((await pst.req('PUT', '/api/db/trips/2026-10-03', { data: { iv: 'a', ct: 'b' } })).status, 200);
  assert.equal((await pst.req('POST', '/api/db/imports', { data: { at: 1, n: 3 } })).status, 201);
  assert.equal((await pst.req('DELETE', '/api/db/trips/2026-10-03')).status, 200);
  assert.equal((await pst.req('PUT', '/api/db/config/x', { data: { a: 1 } })).status, 403);
  assert.equal((await lpg.req('PUT', '/api/db/imports/x', { data: { a: 1 } })).status, 403);
  // laporan pengembalian: daerah hanya untuk kode areanya, viewer tidak boleh
  assert.equal((await lpg.req('PUT', '/api/db/kembali/LPG261017001', { data: { rusak: false, ket: 'ok' } })).status, 200);
  assert.equal((await lpg.req('PUT', '/api/db/kembali/CPY261016001', { data: { rusak: false } })).status, 403);
  assert.equal((await lihat.req('PUT', '/api/db/kembali/LPG261017001', { data: { rusak: false } })).status, 403);
  assert.equal((await pst.req('PUT', '/api/db/kembali/CPY261016001', { data: { rusak: true, ket: 'baret' } })).status, 200);
  assert.equal((await lpg.req('GET', '/api/db/kembali/LPG261017001')).json.exists, true);
  assert.equal((await lpg.req('GET', '/api/db/kembali/CPY261016001')).status, 403, 'daerah tidak membaca laporan area lain');
  assert.equal((await lihat.req('GET', '/api/db/kembali/LPG261017001')).status, 403, 'viewer tidak membaca foto kondisi unit');
  assert.ok(!(await lpg.req('GET', '/api/db/kembali')).json.docs.some((d) => d.id.startsWith('CPY')), 'daftar disaring per area');
  assert.equal((await lihat.req('POST', '/api/db/imports', { data: { a: 1 } })).status, 403);
  assert.equal((await lpg.req('DELETE', '/api/db/trips/2026-10-01')).status, 403);
  const g = await lihat.req('GET', '/api/db/trips/2026-10-01');
  assert.equal(g.json.exists, true);
  assert.equal((await lihat.req('GET', '/api/db/trips')).json.docs.length, 1);
  // log: akun non-viewer boleh menambah, hanya menambah (tidak menimpa), pelaku diisi server
  assert.equal((await lihat.req('POST', '/api/db/log', { data: { aksi: 'x' } })).status, 403);
  const add = await lpg.req('POST', '/api/db/log', { data: { aksi: 'acc_area', by: 'orang.lain' } });
  assert.equal(add.status, 201);
  const logs = (await admin.req('GET', '/api/db/log?orderBy=serverAt&dir=desc&limit=5')).json.docs;
  assert.equal(logs[0].data.by, 'armada.lpg');
  const lid = add.json.id;
  assert.equal((await admin.req('PUT', '/api/db/log/' + lid, { data: { aksi: 'timpa' } })).status, 403, 'entri log tidak bisa ditimpa');
  assert.equal((await admin.req('GET', '/api/db/..%2Fusers')).status, 400);
  assert.equal((await t.client().req('GET', '/api/db/trips')).status, 401);
});

test('catatan koreksi: semua akun boleh, pelaku dicatat server dari sesi', async () => {
  const lpg = t.client(), lihat = t.client(), mgr = t.client();
  await lpg.login('armada.lpg'); await lihat.login('lihat'); await mgr.login('manager');
  const k = 'STRUK-001';
  // klien mencoba memalsukan pelaku: diabaikan
  const n1 = await lpg.req('POST', '/api/cek', { key: k, act: 'note', note: 'jam tiba salah input', oleh: 'Armada Pusat' });
  assert.equal(n1.status, 200);
  assert.equal(n1.json.oleh, 'Armada Lampung');
  assert.equal(n1.json.cek, '');
  assert.equal((await lpg.req('POST', '/api/cek', { key: k, act: 'clear', note: '' })).status, 400); // clear wajib keterangan
  const c1 = await mgr.req('POST', '/api/cek', { key: k, act: 'clear', note: 'sudah dicek ke driver' });
  assert.equal(c1.json.cek, 'CLEAR'); assert.equal(c1.json.oleh, 'Manager Armada');
  assert.equal((await lihat.req('POST', '/api/cek', { key: k, act: 'open', note: 'ternyata masih salah' })).status, 403, 'viewer tidak boleh mengubah koreksi');
  const o1 = await mgr.req('POST', '/api/cek', { key: k, act: 'open', note: 'ternyata masih salah' });
  assert.equal(o1.json.oleh, 'Manager Armada'); assert.equal(o1.json.cek, '');
  assert.deepEqual(o1.json.hist.map((h) => [h.by, h.act]), [['Manager Armada', 'open'], ['Manager Armada', 'clear'], ['Armada Lampung', 'note']]);
  const all = (await lpg.req('GET', '/api/cek')).json.items;
  assert.equal(all.length, 1); assert.equal(all[0].k, k);
  assert.equal((await t.client().req('POST', '/api/cek', { key: k, act: 'note', note: 'x' })).status, 401);
  assert.equal((await lpg.req('POST', '/api/cek', { key: k, act: 'hapus', note: 'x' })).status, 400);
});

test('Sheets: baca dibatasi per peran dan area', async () => {
  const { ids } = t.google;
  const r = (u) => async (id, range) => { const c = t.client(); await c.login(u); return c.req('POST', '/api/sheets/get_values', { spreadsheetId: id, range }); };
  const lpg = r('armada.lpg'), pusat = r('armada.pusat'), admin = r('admin'), lihat = r('lihat');
  const ok = await lpg(ids.LPG, "'DATA PEMINJAM'!B5:Y3000");
  assert.equal(ok.status, 200); assert.equal(ok.json.payload.values[0][0], 'LPG261017001');
  assert.equal((await lpg(ids.CPY, "'DATA PEMINJAM'!B5:Y3000")).status, 403);   // area lain
  assert.equal((await lpg(ids.ACC, "'ACC PUSAT'!A2:Y5000")).status, 403);       // spreadsheet pusat
  assert.equal((await lpg(ids.FORM, "'DATA'!A2:Q5000")).status, 403);
  assert.equal((await lpg(ids.LPG, "'MASTER'!A1:C5")).status, 403);             // bukan sheet DATA PEMINJAM
  assert.equal((await pusat(ids.ACC, "'ACC PUSAT'!A2:Y5000")).status, 200);
  assert.equal((await pusat(ids.CPY, "'DATA PEMINJAM'!B5:Y3000")).status, 200);
  assert.equal((await pusat(ids.OTHER, 'A1:B2')).status, 403);                  // tidak terdaftar
  assert.equal((await admin(ids.OTHER, 'A1:AZ20000')).status, 200);             // admin: impor Monitor
  assert.equal((await lihat(ids.LPG, "'DATA PEMINJAM'!B5:Y3000")).status, 403);
  assert.equal((await admin('../etc/passwd', 'A1')).status, 400);
  assert.equal((await admin(ids.ACC, "A1:B2'; DROP")).status, 400);
  assert.equal((await t.client().req('POST', '/api/sheets/get_values', { spreadsheetId: ids.LPG, range: 'A1' })).status, 401);
});

test('Sheets: tulis hanya sel ACC yang diizinkan, sesuai peran', async () => {
  const { ids, state } = t.google;
  const w = (u) => async (id, range, v = true) => { const c = t.client(); await c.login(u); return c.req('POST', '/api/sheets/update_values', { spreadsheetId: id, range, values: [[v]] }); };
  const lpg = w('armada.lpg'), pusat = w('armada.pusat'), cpy = w('armada.cpy');
  assert.equal((await lpg(ids.LPG, "'DATA PEMINJAM'!Y5")).status, 200);          // ACC area sendiri
  assert.equal(state.data[ids.LPG]['DATA PEMINJAM'][4][24], true);
  assert.equal((await lpg(ids.LPG, "'DATA PEMINJAM'!R5")).status, 403);          // ACC Armada Pusat bukan haknya
  assert.equal((await cpy(ids.LPG, "'DATA PEMINJAM'!Y5")).status, 403);          // area lain
  assert.equal((await lpg(ids.ACC, "'ACC PUSAT'!Y2")).status, 403);
  assert.equal((await pusat(ids.LPG, "'DATA PEMINJAM'!R5")).status, 200);
  assert.equal((await pusat(ids.ACC, "'ACC PUSAT'!Y2")).status, 200);
  assert.equal((await pusat(ids.LPG, "'DATA PEMINJAM'!A5")).status, 403);        // kolom lain dilarang
  assert.equal((await pusat(ids.LPG, "'DATA PEMINJAM'!R5:R9")).status, 403);     // banyak sel dilarang
  assert.equal((await pusat(ids.LPG, "'DATA PEMINJAM'!R5", 'rm -rf')).status, 400);
  assert.equal((await pusat(ids.OTHER, 'A1')).status, 403);
  const c = t.client(); await c.login('armada.pusat');
  assert.equal((await c.req('POST', '/api/sheets/update_values', { spreadsheetId: ids.LPG, range: "'DATA PEMINJAM'!R5", values: [[true, false]] })).status, 400);
  // tulisan tercatat di audit
  const rows = t.app.db.prepare("SELECT username, target FROM audit WHERE action = 'sheet.write' ORDER BY id").all();
  assert.deepEqual({ ...rows[0] }, { username: 'armada.lpg', target: 'acc_area.LPG' });
});

test('Sheets: cache dibuang setelah tulis; kegagalan sementara Google di-retry; akses ditolak Google jadi 502 jelas', async () => {
  const { ids, state } = t.google;
  const pusat = t.client(); await pusat.login('armada.pusat');
  const rd = () => pusat.req('POST', '/api/sheets/get_values', { spreadsheetId: ids.LPG, range: "'DATA PEMINJAM'!R5" });
  await pusat.req('POST', '/api/sheets/update_values', { spreadsheetId: ids.LPG, range: "'DATA PEMINJAM'!R5", values: [[false]] });
  assert.equal((await rd()).json.payload.values[0][0], 'FALSE');
  state.failNext = 1; // satu 503 lalu normal
  assert.equal((await rd()).status, 200);
  state.denyIds.add(ids.LPG);
  const denied = await rd();
  assert.equal(denied.status, 502); assert.equal(denied.json.error.code, 'sheets_denied');
  state.denyIds.clear();
});

test('admin: kelola akun, lindungi admin terakhir, hanya admin', async () => {
  const admin = t.client(), pusat = t.client();
  await admin.login('admin'); await pusat.login('armada.pusat');
  assert.equal((await pusat.req('GET', '/api/admin/users')).status, 403);
  const mk = await admin.req('POST', '/api/admin/users', { username: 'armada.pkb', password: 'Rahasia-Baru-123', role: 'daerah', areas: ['PKB'] });
  assert.equal(mk.status, 201); assert.equal(mk.json.user.label, 'Armada Pekanbaru');
  assert.equal((await admin.req('POST', '/api/admin/users', { username: 'armada.pkb', password: 'Rahasia-Baru-123', role: 'viewer' })).status, 409);
  assert.equal((await admin.req('POST', '/api/admin/users', { username: 'x', password: 'Rahasia-Baru-123', role: 'viewer' })).status, 400);
  assert.equal((await admin.req('POST', '/api/admin/users', { username: 'daerah.kosong', password: 'Rahasia-Baru-123', role: 'daerah', areas: [] })).status, 400);
  assert.equal((await admin.req('POST', '/api/admin/users', { username: 'lemah', password: 'abc', role: 'viewer' })).status, 400);
  const last = await admin.req('PATCH', '/api/admin/users/admin', { disabled: true });
  assert.equal(last.status, 409);
  // nonaktifkan akun -> sesinya langsung mati
  const pkb = t.client(); assert.equal((await pkb.login('armada.pkb', 'Rahasia-Baru-123')).status, 200);
  assert.equal((await admin.req('PATCH', '/api/admin/users/armada.pkb', { disabled: true })).status, 200);
  assert.equal((await pkb.req('GET', '/api/session')).status, 401);
  assert.equal((await pkb.login('armada.pkb', 'Rahasia-Baru-123')).status, 401);
  assert.ok((await admin.req('GET', '/api/admin/audit?limit=20')).json.items.some((a) => a.action === 'user.create'));
});

test('admin: status sistem hanya untuk admin, tanpa rahasia; ubah peran mengakhiri sesi; reset password', async () => {
  const admin = t.client(), pusat = t.client();
  await admin.login('admin'); await pusat.login('armada.pusat');
  assert.equal((await pusat.req('GET', '/api/admin/status')).status, 403);
  assert.equal((await t.client().req('GET', '/api/admin/status')).status, 401);
  const st = await admin.req('GET', '/api/admin/status');
  assert.equal(st.status, 200);
  assert.ok(st.json.counts.users >= 3 && st.json.counts.sessions >= 2);
  assert.equal(st.json.sheets.configured, true);
  assert.ok(!/PRIVATE KEY|private_key|dataKey|password_hash/i.test(st.text), 'status tidak boleh memuat rahasia');
  assert.ok(!('key' in st.json) && !('dataKey' in st.json));
  await t.addUser('target.role', 'viewer', [], 'Password-Lama-1');
  const tg = t.client(); await tg.login('target.role', 'Password-Lama-1');
  const up = await admin.req('PATCH', '/api/admin/users/target.role', { role: 'daerah', areas: ['LPG'] });
  assert.equal(up.status, 200); assert.equal(up.json.user.label, 'Armada Lampung');
  assert.equal((await tg.req('GET', '/api/session')).status, 401, 'sesi lama harus berakhir setelah peran berubah');
  const rs = await admin.req('PATCH', '/api/admin/users/target.role', { password: 'Reset-Dari-Admin-9' });
  assert.equal(rs.status, 200);
  assert.equal((await t.client().login('target.role', 'Reset-Dari-Admin-9')).status, 200);
  assert.ok(!JSON.stringify(rs.json).includes('Reset-Dari-Admin-9'), 'password tidak boleh dikembalikan');
  assert.equal((await admin.req('PATCH', '/api/admin/users/target.role', { password: 'pendek' })).status, 400);
  assert.equal((await admin.req('PATCH', '/api/admin/users/tidak.ada', { disabled: true })).status, 404);
});

test('ganti password: butuh password lama, mengakhiri semua sesi', async () => {
  await t.addUser('ganti.pw', 'viewer', [], 'Password-Lama-1');
  const c = t.client(); await c.login('ganti.pw', 'Password-Lama-1');
  assert.equal((await c.req('POST', '/api/password', { current: 'salah-salah-1', next: 'Password-Baru-22' })).status, 403);
  assert.equal((await c.req('POST', '/api/password', { current: 'Password-Lama-1', next: 'Password-Baru-22' })).status, 200);
  assert.equal((await c.req('GET', '/api/session')).status, 401);
  assert.equal((await t.client().login('ganti.pw', 'Password-Baru-22')).status, 200);
});

test('statis, header keamanan, dan penjagaan path traversal', async () => {
  const c = t.client();
  const idx = await c.req('GET', '/');
  assert.equal(idx.status, 200);
  assert.match(idx.headers.get('content-security-policy'), /script-src 'self'/);
  assert.equal(idx.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await c.req('GET', '/assets/a.js')).status, 200);
  for (const p of ['/..%2fsecret.txt', '/%2e%2e/secret.txt', '/assets/..%2f..%2fsecret.txt', '/..\\secret.txt', '/assets/%00.js']) {
    const r = await fetch(t.base + p); assert.notEqual(r.status, 200, p); assert.ok(!(await r.text()).includes('RAHASIA'), p);
  }
  assert.equal((await c.req('GET', '/nggak-ada.html')).status, 404);
  assert.equal((await c.req('GET', '/api/tidak-ada')).status, 404);
  assert.equal((await c.req('DELETE', '/api/session')).status, 405);
  const gz = await fetch(t.base + '/', { headers: { 'Accept-Encoding': 'gzip' } });
  assert.equal(gz.headers.get('content-encoding'), 'gzip');
  const etag = gz.headers.get('etag');
  assert.equal((await fetch(t.base + '/', { headers: { 'If-None-Match': etag } })).status, 304);
});

test('sistem: healthz, readyz, metrics (lokal atau token)', async () => {
  const c = t.client();
  assert.equal((await c.req('GET', '/healthz')).json.ok, true);
  const rd = await c.req('GET', '/readyz');
  assert.equal(rd.json.db, 'ok'); assert.equal(rd.json.sheets.configured, true);
  const m = await c.req('GET', '/metrics');
  assert.equal(m.status, 200);
  assert.match(m.text, /http_requests_total/);
  const viaProxy = await c.req('GET', '/metrics', undefined, { 'X-Forwarded-For': '8.8.8.8' });
  assert.equal(viaProxy.status, 403);
});

test('body terlalu besar dan JSON rusak ditolak rapi', async () => {
  const c = t.client(); await c.login('admin');
  const bad = await fetch(t.base + '/api/db/config/x', { method: 'PUT', headers: { Cookie: c.cookie, 'Content-Type': 'application/json', 'X-Requested-With': 'armada-web' }, body: '{rusak' });
  assert.equal(bad.status, 400);
  const big = await fetch(t.base + '/api/db/config/x', { method: 'PUT', headers: { Cookie: c.cookie, 'Content-Type': 'application/json', 'X-Requested-With': 'armada-web' }, body: JSON.stringify({ data: { x: 'a'.repeat(7 * 1024 * 1024) } }) });
  assert.equal(big.status, 413);
});

test('aset privat (tanda tangan): hanya akun login bukan viewer; bukan bagian folder public', async () => {
  const anon = t.client();
  assert.equal((await anon.req('GET', '/api/asset/ttd_mgr.png')).status, 401);
  assert.equal((await anon.req('GET', '/assets/ttd_mgr.png')).status, 404);
  assert.equal((await anon.req('GET', '/ttd_mgr.png')).status, 404);
  const v = t.client(); await v.login('lihat');
  assert.equal((await v.req('GET', '/api/asset/ttd_mgr.png')).status, 403);
  const d = t.client(); await d.login('armada.lpg');
  const ok = await d.req('GET', '/api/asset/ttd_mgr.png');
  assert.equal(ok.status, 200);
  assert.equal(ok.headers.get('content-type'), 'image/png');
  assert.match(ok.headers.get('cache-control'), /private/);
  assert.equal((await d.req('GET', '/api/asset/ttd_staf.png')).status, 404); // terdaftar tetapi belum dipasang
  for (const n of ['..%2fsecret.txt', 'secret.txt', '%2e%2e%2fpackage.json']) assert.equal((await d.req('GET', '/api/asset/' + n)).status, 404, n);
});

test('daftar area: staf semua area, akun daerah hanya areanya, anonim ditolak', async () => {
  assert.equal((await t.client().req('GET', '/api/areas')).status, 401);
  const p = t.client(); await p.login('armada.pusat');
  const all = (await p.req('GET', '/api/areas')).json.areas;
  assert.deepEqual(Object.keys(all).sort(), ['CPY', 'LPG']);
  assert.equal(all.LPG.name, 'LAMPUNG'); assert.equal(all.LPG.sheetId, t.google.ids.LPG);
  const d = t.client(); await d.login('armada.lpg');
  assert.deepEqual(Object.keys((await d.req('GET', '/api/areas')).json.areas), ['LPG']);
  const v = t.client(); await v.login('lihat');
  assert.deepEqual((await v.req('GET', '/api/areas')).json.areas, {});
});
