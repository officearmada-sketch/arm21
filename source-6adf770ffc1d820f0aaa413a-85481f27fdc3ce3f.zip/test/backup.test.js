'use strict';
// Backup dan pemulihan: dibuat saat server masih berjalan (WAL), lalu dipulihkan ke folder baru dan dibuka lagi.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { spawnSync } = require('node:child_process');
const { DatabaseSync } = require('node:sqlite');
const { startApp } = require('./helpers');

const ROOT = path.resolve(__dirname, '..');
const run = (script, env, args = []) => spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(ROOT, 'scripts', script), ...args], { env: { ...process.env, ...env }, encoding: 'utf8' });

let t;
test.before(async () => { t = await startApp(); await t.addUser('admin', 'admin'); });
test.after(async () => { await t.close(); });

test('backup online lalu restore ke folder baru: data dan akun utuh, cadangan rusak ditolak', async () => {
  const c = t.client(); await c.login('admin');
  assert.equal((await c.req('PUT', '/api/db/config/k', { data: { v: 'penting' } })).status, 200);
  assert.equal((await c.req('POST', '/api/cek', { key: 'STUT/1', act: 'note', note: 'catatan uji' })).status, 200);

  const bdir = fs.mkdtempSync(path.join(os.tmpdir(), 'armada-bk-'));
  const b = run('backup.js', { DATA_DIR: t.dir, BACKUP_DIR: bdir, BACKUP_KEEP: '2' });
  assert.equal(b.status, 0, b.stderr);
  assert.match(b.stdout, /backup_ok/);
  const files = fs.readdirSync(bdir).filter((f) => f.endsWith('.db.gz'));
  assert.equal(files.length, 1);

  // rotasi: backup berulang tidak menumpuk melebihi BACKUP_KEEP
  for (const stamp of ['2020-01-01-00-00-00', '2020-01-02-00-00-00', '2020-01-03-00-00-00']) fs.copyFileSync(path.join(bdir, files[0]), path.join(bdir, `armada-${stamp}.db.gz`));
  assert.equal(run('backup.js', { DATA_DIR: t.dir, BACKUP_DIR: bdir, BACKUP_KEEP: '2' }).status, 0);
  assert.equal(fs.readdirSync(bdir).filter((f) => f.endsWith('.db.gz')).length, 2);

  // restore ke folder baru
  const newDir = fs.mkdtempSync(path.join(os.tmpdir(), 'armada-restore-'));
  const latest = fs.readdirSync(bdir).filter((f) => f.endsWith('.db.gz')).sort().pop();
  const r = run('restore.js', { DATA_DIR: newDir }, [path.join(bdir, latest)]);
  assert.equal(r.status, 0, r.stderr);
  const db = new DatabaseSync(path.join(newDir, 'armada.db'), { readOnly: true });
  assert.equal(db.prepare("SELECT COUNT(*) n FROM users WHERE username='admin'").get().n, 1);
  assert.equal(JSON.parse(db.prepare("SELECT data FROM docs WHERE path='config/k'").get().data).v, 'penting');
  assert.equal(db.prepare("SELECT catatan FROM cek WHERE key='STUT/1'").get().catatan, 'catatan uji');
  db.close();

  // cadangan rusak/kosong ditolak dan tidak menimpa apa pun
  const bad = path.join(bdir, 'rusak.db.gz');
  fs.writeFileSync(bad, zlib.gzipSync(Buffer.from('bukan database sqlite')));
  const dir2 = fs.mkdtempSync(path.join(os.tmpdir(), 'armada-restore2-'));
  assert.notEqual(run('restore.js', { DATA_DIR: dir2 }, [bad]).status, 0);
  assert.ok(!fs.existsSync(path.join(dir2, 'armada.db')));
  for (const d of [bdir, newDir, dir2]) fs.rmSync(d, { recursive: true, force: true });
});
