'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { PGlite } = require('@electric-sql/pglite');
const { setupAdmin } = require('../server/setup-admin');
const { verifyPassword } = require('../server/auth');
const fs = require('node:fs');
const { randomBytes } = require('node:crypto');

async function database(t) {
  const db = new PGlite();
  t.after(() => db.close());
  await db.exec(fs.readFileSync('netlify/database/migrations/20261026124030_create_app_tables/migration.sql', 'utf8'));
  await db.exec(fs.readFileSync('netlify/database/migrations/20261026134920_add_identity_links/migration.sql', 'utf8'));
  await db.query("INSERT INTO users (username, role, created_at, updated_at) VALUES ('empty.admin', 'admin', 0, 0)");
  return db;
}

test('first admin claims an empty account from environment credentials, hashes, audits and closes setup', async t => {
  const db = await database(t);
  const password = randomBytes(24).toString('hex');
  await setupAdmin(db, 'chosen.admin', password, '127.0.0.1');
  const { rows } = await db.query('SELECT * FROM users');
  assert.equal(rows.length, 1);
  assert.equal(rows[0].role, 'admin');
  assert.equal(rows[0].username, 'chosen.admin');
  assert.equal(await verifyPassword(password, rows[0].password_hash), true);
  assert.equal((await db.query('SELECT * FROM identity_links')).rows.length, 0);
  assert.equal((await db.query('SELECT action FROM audit')).rows[0].action, 'admin.setup.environment');
  assert.equal(await setupAdmin(db, 'other.admin', password), false);
  assert.equal((await db.query('SELECT * FROM users')).rows.length, 1);
});

test('duplicate usernames roll back the claim and existing accounts retain their role', async t => {
  const db = await database(t);
  await db.query("INSERT INTO users (username, role, created_at, updated_at) VALUES ('existing.viewer', 'viewer', 0, 0)");
  await assert.rejects(setupAdmin(db, 'existing.viewer', randomBytes(24).toString('hex')), { code: 'username_used' });
  assert.equal((await db.query('SELECT * FROM identity_links')).rows.length, 0);
  assert.equal((await db.query("SELECT password_hash FROM users WHERE role = 'admin'")).rows[0].password_hash, '');
  assert.equal((await db.query("SELECT role FROM users WHERE username = 'existing.viewer'")).rows[0].role, 'viewer');
});

test('disabled initialized administrators also close setup, preventing replacement', async t => {
  const db = await database(t);
  await db.query("UPDATE users SET password_hash = 'already-set', disabled = true");
  assert.equal(await setupAdmin(db, 'new.admin', randomBytes(24).toString('hex')), false);
});

test('invalid environment password leaves the account uninitialized', async t => {
  const db = await database(t);
  await assert.rejects(setupAdmin(db, 'chosen.admin', ''), { code: 'weak_password' });
  assert.equal((await db.query("SELECT password_hash FROM users WHERE role = 'admin'")).rows[0].password_hash, '');
});
