'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { sessionError } = require('../server/session-error');

for (const [cause, expected] of [
  [{ name: 'MissingDatabaseConnectionError' }, 'database_configuration'],
  [{ code: '42501' }, 'database_permissions'],
  [{ code: '25006' }, 'database_permissions'],
  [{ code: '42P01' }, 'database_schema'],
  [{ code: '42703' }, 'database_schema'],
  [{ code: '28P01' }, 'database_configuration'],
  [{ code: 'ETIMEDOUT' }, 'database_unavailable'],
  [{ code: 'ECONNRESET' }, 'database_unavailable'],
  [{ code: '53300' }, 'database_unavailable'],
  [{ code: 'unknown' }, 'service_unavailable'],
]) {
  test(`wrapped ${cause.code || cause.name} errors provide safe login guidance`, () => {
    const sensitive = 'private-query-parameter';
    const error = Object.assign(new Error(sensitive), { cause: Object.assign(new Error(sensitive), cause) });
    const result = sessionError(error);
    assert.equal(result.code, expected);
    assert.ok(result.message.length > 0);
    assert.ok(!JSON.stringify(result).includes(sensitive));
  });
}

test('circular causes do not prevent a safe error response', () => {
  const error = new Error('private');
  error.cause = error;
  assert.equal(sessionError(error).code, 'service_unavailable');
});
