'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');

const source = fs.readFileSync('web/src/monitor/auth.js', 'utf8');

for (const code of ['configuration', 'service_unavailable', 'invalid_credentials', 'username_used', 'weak_password']) {
  test(`login displays the server's actionable ${code} message and allows retry`, async () => {
    const elements = new Map();
    const node = id => {
      if (!elements.has(id)) elements.set(id, { value: '', classList: { toggle() {} }, addEventListener(event, handler) { this[event] = handler; }, focus() {} });
      return elements.get(id);
    };
    const message = code === 'configuration' ? 'DATA_KEY belum diatur. Atur kunci lalu deploy ulang.' : 'Pesan bantuan dari server.';
    const api = {
      async post() { throw Object.assign(new Error(message), { code }); },
      async get() { throw new Error('No existing session'); },
    };
    vm.runInNewContext(source, {
      $: node, TextEncoder, atob, btoa,
      crypto: { subtle: {} }, window: { crypto: { subtle: {} }, __api: api },
      document: { querySelector: () => ({ src: '/logo.png' }) },
      console: { error() {} },
    });
    node('lgUser').value = 'admin';
    node('lgPass').value = 'example-input';
    await node('lgForm').submit({ preventDefault() {} });
    assert.equal(node('lgMsg').textContent, message);
    assert.equal(node('lgGo').disabled, false);
    assert.equal(node('lgPass').value, '');
  });
}
