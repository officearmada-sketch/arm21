
(()=>{
const SERVER='Google Sheets';
const ACC_ID='1uwenWPo9NR9rkTfZpHuJaXQFEGnspVjg0Ty6K4xpSDI';
const FORM_ID='1V18f6If7Emm_bgpfuMUnLiJDCzA-4w1bAnM7D5EhJjw';
let TTD_STAF='',TTD_MGR='',CHK='';/* tanda tangan dan template: diambil dari server setelah login, tidak ada di berkas publik */
const NAMA_PUSAT='IZAKI ARVIO MUTTAQIN';
const NAMA_MGR='ABDURRAHMAN';
const SEED=[['PST','PUSAT'],['CPY','CIPAYUNG'],['MRD','MARUNDA'],['BDG','BANDUNG'],['CKR','CIKARANG'],['KLW','KALIWUNGU'],['BGR','BOGOR'],['LGD','LEGUNDI'],['MDN','MADIUN'],['TGR','TANGERANG'],['BJM','BANJARMASIN'],['PRB','PROBOLINGGO'],['MKS','MAKASSAR'],['DLS','DELISERDANG'],['LPG','LAMPUNG']];
const BULAN=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtN=n=>Number(n).toLocaleString('id-ID');
const pad=n=>String(n).padStart(2,'0');
const tglL=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()]} ${d.getFullYear()}`:'';
const tglS=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()].slice(0,3)} ${d.getFullYear()}`:'–';
const jam=d=>d?`${pad(d.getHours())}:${pad(d.getMinutes())}`:'';
let mcp=null,db=null,user=null;
const ME={id:null,role:null,areas:[]};
const REAL={role:null,areas:[]};
let DBROWS=[],DBSEEN=null,DBUNSUB=null,DBAT=0,DBERR='',DBNEW=new Set();
let SIM=null,SIMO={};/* mode uji peran: tidak pernah menulis ke spreadsheet */
let AREAS={},ROWS=[],LOADED=0,PROBLEMS=[],SYNC=[];
const OVR={};/* hasil tulis yang belum sampai ke sheet gabungan (IMPORTRANGE butuh beberapa detik) */
const S={area:'ALL',q:'',st:'ALL',tab:'list',cur:null,busy:false,confirm:null};

async function loadPrivateAssets(){
  const get=async n=>{try{const r=await fetch('/api/asset/'+n,{credentials:'same-origin'});if(!r.ok)return '';const b=await r.blob();
    return await new Promise(res=>{const f=new FileReader();f.onload=()=>res(String(f.result));f.onerror=()=>res('');f.readAsDataURL(b)})}catch(e){return ''}};
  [TTD_STAF,TTD_MGR,CHK]=await Promise.all([get('ttd_staf.png'),get('ttd_mgr.png'),get('chk.jpg')]);
}

/* ---------- sumber data: Google Sheets lewat server ---------- */
async function getVals(id,range){
  const r=await mcp.callTool(SERVER,'get_values',{spreadsheetId:id,range},{cache:false});
  let v=r&&r.payload&&r.payload.values;
  if(!v){try{v=JSON.parse(r.content[0].text).values}catch(e){v=null}}
  return v||[];
}
const putVals=(id,range,values)=>mcp.callTool(SERVER,'update_values',{spreadsheetId:id,range,values},{cache:false});
function errText(e,ctx){
  const c=e&&e.code,m=(e&&e.message)||'',w=ctx||'Spreadsheet';
  if(c==='unauthenticated')return 'Sesi berakhir. Muat ulang halaman lalu masuk lagi.';
  if(c==='forbidden')return m||'Akun Anda tidak berwenang untuk data ini.';
  if(c==='sheets_denied')return w+': Google menolak akses. Bagikan spreadsheet ini ke akun layanan server (email service account) sebagai Editor, lalu klik Muat ulang.';
  if(c==='sheets_not_configured')return 'Server belum disambungkan ke Google Sheets. Hubungi admin sistem.';
  if(c==='sheets_auth_failed')return 'Server gagal masuk ke Google. Periksa kunci service account.';
  if(c==='sheets_unavailable')return 'Google Sheets sedang tidak merespons. Coba muat ulang sebentar lagi.';
  if(c==='sheets_error')return w+': '+m.slice(0,160);
  if(c==='rate_limited')return 'Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.';
  if(c==='network')return 'Server tidak bisa dihubungi. Periksa koneksi internet Anda.';
  if(c==='bad_request')return m||'Permintaan tidak valid.';
  return 'Gagal mengakses Google Sheets ('+(c||'error')+').';
}

/* ---------- tanggal ---------- */
function parseDT(s,order){
  const m=String(s||'').trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if(!m)return null;
  const a=+m[1],b=+m[2],d=order==='dmy'?a:b,mo=order==='dmy'?b:a;
  const t=new Date(+m[3],mo-1,d,+(m[4]||0),+(m[5]||0),+(m[6]||0));
  return isNaN(t)||t.getMonth()!==mo-1?null:t;
}
function detectOrder(vals){
  let dmy=0,mdy=0;
  for(const r of vals){
    for(const i of [0,15,16,18]){
      const m=String(r[i]||'').match(/^(\d{1,2})\/(\d{1,2})\//);if(!m)continue;
      if(+m[1]>12)dmy+=3;else if(+m[2]>12)mdy+=3;
    }
    const n=String(r[1]||'').match(/^[A-Z]{3}(\d{2})(\d{2})(\d{2})\d{3}$/),t=String(r[0]||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if(n&&t){
      const y=2000+ +n[1],mo=+n[2],d=+n[3];
      if(+t[3]===y&&+t[1]===d&&+t[2]===mo)dmy++;
      if(+t[3]===y&&+t[2]===d&&+t[1]===mo)mdy++;
    }
  }
  return mdy>dmy?'mdy':'dmy';
}
const B=v=>v===true||String(v).toUpperCase()==='TRUE';
/* Cocokkan area: kode persis, lalu nama lengkap area (kolom ASAL), lalu awalan kode (JMB = JMBR). */
const nz=x=>String(x||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
function areaCode(nomor,asal){
  const L=((String(nomor||'').toUpperCase().match(/^[A-Z]+/)||[''])[0])||String(nomor||'').slice(0,3).toUpperCase();
  const ks=Object.keys(AREAS);
  if(AREAS[L])return L;
  const na=nz(asal);
  if(na){
    const hit=ks.filter(c=>nz(AREAS[c].name)===na);
    if(hit.length)return hit.find(c=>AREAS[c].sheetId)||hit[0];
    const hit2=ks.filter(c=>nz(AREAS[c].name).length>=4&&(na.includes(nz(AREAS[c].name))||nz(AREAS[c].name).includes(na)&&na.length>=4));
    if(hit2.length===1)return hit2[0];
  }
  if(L.length>=2){const p=ks.filter(c=>c.startsWith(L)||L.startsWith(c));if(p.length)return p.find(c=>AREAS[c].sheetId)||p[0]}
  return L.slice(0,3)||L;
}
/* Samakan kode area yang berbeda penulisan (JMB/JMBR) agar semuanya menunjuk ke spreadsheet yang terdaftar. */
function reconcileAreas(){
  let ks=Object.keys(AREAS);
  for(const c of ks){
    const a=AREAS[c];if(a.sheetId)continue;
    const alt=ks.find(k=>k!==c&&AREAS[k].sheetId&&(nz(AREAS[k].name)===nz(a.name)||k.startsWith(c)||c.startsWith(k)));
    if(alt)delete AREAS[c];/* alias tanpa spreadsheet: gabung ke area terdaftar */
  }
  ks=Object.keys(AREAS);
  const canon=c=>{
    if(AREAS[c]&&AREAS[c].sheetId)return c;
    const k=ks.find(k=>AREAS[k].sheetId&&(nz(AREAS[k].name)===nz(c)||k.startsWith(c)||c.startsWith(k)));
    return k||c;
  };
  const f=l=>[...new Set((l||[]).map(canon))];
  ME.areas=f(ME.areas);REAL.areas=f(REAL.areas);
}
function mkRow(r,order,src){
  const g=i=>String(r[i]==null?'':r[i]).trim(),nomor=g(1);
  if(!nomor)return null;
  return {nomor,code:areaCode(nomor,g(9)),ts:parseDT(g(0),order),nama:g(2),ktp:g(3),sim:g(4),wa:g(5),telp:g(6),sp:g(7),nopol:g(8),asal:g(9),tujLok:g(10),tuj:g(11),jenis:g(12),merk:g(13),grup:g(14),pinjam:parseDT(g(15),order),kembali:parseDT(g(16),order),ar:B(r[17]),tglAcc:parseDT(g(18),order),pu:src==='ACC'&&r.length>24&&String(r[24]).trim()!==''?B(r[24]):B(r[19]),ac:src!=='ACC'&&src!=='FORM'?B(r[24]):false,back:/DIKEMBALIKAN/i.test(g(20)),src};
}
const areaName=r=>(AREAS[r.code]&&AREAS[r.code].name)||r.asal||r.code;
function stat(r){
  if(r.back)return {k:'back',t:'Telah dikembalikan',d:'Unit sudah dikembalikan dan form pemeriksaan sudah diunggah'};
  if(r.ar&&r.pu)return {k:'go',t:'Berangkat',d:'Disetujui Armada Pusat dan Manager'};
  if(r.ar)return {k:'park',t:'Diparkir',d:'ACC Armada Pusat selesai, menunggu ACC Manager Armada'};
  if(r.pu)return {k:'first',t:'ACC Armada Pusat dulu',d:'ACC Manager Armada sudah, ACC Armada Pusat belum dicentang'};
  if(r.ac)return {k:'wait',t:'ACC area',d:'Sudah di-ACC area, menunggu ACC Armada Pusat'};
  return {k:'wait',t:'Menunggu ACC',d:'Belum ada persetujuan'};
}
const isAdminLike=()=>ME.role==='admin'||ME.role==='pusat';
const canAR=r=>isAdminLike();
const canAC=r=>isAdminLike()||(ME.role==='daerah'&&ME.areas.includes(r.code));
const canPU=()=>isAdminLike();
const NAMES={PST:'PUSAT',CPY:'CIPAYUNG',MRD:'MARUNDA',BDG:'BANDUNG',CKR:'CIKARANG',KLW:'KALIWUNGU',BGR:'BOGOR',LGD:'LEGUNDI',MDN:'MADIUN',TGR:'TANGERANG',BJM:'BANJARMASIN',PRB:'PROBOLINGGO',MKS:'MAKASSAR',DLS:'DELISERDANG',LPG:'LAMPUNG',PJG:'PEJAGAN',PKB:'PEKANBARU',SLK:'SOLOK',PLB:'PALEMBANG',JMBR:'JEMBRANA',BPN:'BALIKPAPAN',PNK:'PONTIANAK'};
const unitTitle=()=>ME.role==='daerah'&&ME.areas.length?('ARMADA '+ME.areas.map(c=>((AREAS[c]&&AREAS[c].name)||NAMES[c]||c).toUpperCase()).join(', ')):'ARMADA PUSAT';
const roleLabel=()=>ME.role==='admin'?'Admin':ME.role==='pusat'?'Armada Pusat':'Armada Daerah'+(ME.areas.length?' · '+ME.areas.map(c=>(AREAS[c]&&AREAS[c].name)||c).join(', '):'');

/* ---------- area dan data ---------- */
async function loadAreas(){
  AREAS={};SEED.forEach(([c,n])=>AREAS[c]={name:n,sheetId:''});
  try{
    const r=await window.__api.get('/api/areas');
    for(const [c,a] of Object.entries(r.areas||{}))AREAS[c]={name:a.name||(AREAS[c]&&AREAS[c].name)||c,sheetId:a.sheetId||''};
    if(r.error)PROBLEMS.push('Daftar area dari sheet MASTER belum terbaca: '+String(r.error).slice(0,120));
  }catch(e){PROBLEMS.push(errText(e,'Daftar area'))}
  reconcileAreas();
}
async function fillAc(rows){
  const codes=[...new Set(rows.map(r=>r.code))].filter(c=>AREAS[c]&&AREAS[c].sheetId);
  await Promise.all(codes.map(async c=>{
    try{
      const v=await getVals(AREAS[c].sheetId,"'DATA PEMINJAM'!B5:Y3000"),m=new Map();
      v.forEach(x=>{const n=String((x&&x[0])||'').trim();if(n)m.set(n,B(x[23]))});
      rows.forEach(r=>{if(r.code===c)r.ac=!!m.get(r.nomor)});
    }catch(e){}
  }));
}
/* Pengajuan yang sudah ada di database formulir tetapi belum ditarik ke ACC PUSAT (biasanya izin IMPORTRANGE area belum diberikan) */
async function checkSync(rows){
  SYNC=[];
  if(!isAdminLike()||SIM)return;
  try{
    const v=await getVals(FORM_ID,"'DATA'!A2:Q5000"),o=detectOrder(v),have=new Set(rows.map(r=>r.nomor));
    SYNC=v.map(r=>mkRow(r,o,'FORM')).filter(Boolean).filter(r=>!have.has(r.nomor)&&r.ts&&Date.now()-r.ts>10*60000);
  }catch(e){}
}
async function loadData(){
  PROBLEMS=PROBLEMS.slice(0,0);
  let rows=[];
  if(isAdminLike()||SIM){
    try{
      let v=await getVals(ACC_ID,"'ACC PUSAT'!A2:Y5000"),o=detectOrder(v);
      rows=v.map(r=>mkRow(r,o,'ACC')).filter(Boolean);
      /* IMPORTRANGE kadang sesaat mengosongkan satu area saat menyegarkan: bila ada form lama yang belum tampak, baca ulang sekali */
      if(isAdminLike()&&!SIM){
        try{
          const f=await getVals(FORM_ID,"'DATA'!A2:Q5000"),fo=detectOrder(f);
          const miss=()=>{const have=new Set(rows.map(r=>r.nomor));return f.map(r=>mkRow(r,fo,'FORM')).filter(Boolean).some(r=>!have.has(r.nomor)&&r.ts&&Date.now()-r.ts>10*60000)};
          if(Date.now()-(window.__syncRetry||0)>60000&&miss()){window.__syncRetry=Date.now();await new Promise(z=>setTimeout(z,2500));v=await getVals(ACC_ID,"'ACC PUSAT'!A2:Y5000");o=detectOrder(v);rows=v.map(r=>mkRow(r,o,'ACC')).filter(Boolean)}
        }catch(e){}
      }
      if(ME.role==='daerah')rows=rows.filter(r=>ME.areas.includes(r.code));
      await fillAc(rows);
    }catch(e){PROBLEMS.push(errText(e,'ACC ARMADA PUSAT'))}
  }else{
    for(const c of ME.areas){
      const a=AREAS[c];
      if(!a||!a.sheetId){PROBLEMS.push('Spreadsheet area '+((a&&a.name)||c)+' belum didaftarkan. Minta admin menyinkronkannya.');continue}
      try{
        const v=await getVals(a.sheetId,"'DATA PEMINJAM'!A5:Y3000"),o=detectOrder(v);
        rows.push(...v.map(r=>mkRow(r,o,c)).filter(Boolean).map(r=>(r.code=c,r)));
      }catch(e){PROBLEMS.push(errText(e,'Area '+a.name))}
    }
  }
  if(db&&!SIM){try{const sn=await db.collection('kstat').get(),m=new Map();sn.docs.forEach(d=>m.set(d.id,d.data()));rows.forEach(r=>{const x=m.get(r.nomor);if(x){r.kst=x;if(x.returned)r.back=true}})}catch(e){}}
  const now=Date.now();
  for(const r of rows){const o=OVR[r.nomor];if(!o)continue;if(now-o.t>180000){delete OVR[r.nomor];continue}for(const k of ['ar','pu','ac']){if(k in o){if(r[k]===o[k])delete o[k];else{r[k]=o[k];if(k==='ar'&&o.ar&&!r.tglAcc)r.tglAcc=new Date(o.t)}}}if(!('ar' in o)&&!('pu' in o)&&!('ac' in o))delete OVR[r.nomor]}
  if(SIM)for(const r of rows){const o=SIMO[r.nomor];if(!o)continue;if('ar' in o){r.ar=o.ar;if(o.ar&&!r.tglAcc)r.tglAcc=new Date(o.t)}if('pu' in o)r.pu=o.pu;if('ac' in o)r.ac=o.ac}
  const seen=new Map();rows.forEach(r=>seen.set(r.nomor,r));
  ROWS=[...seen.values()].sort((a,b)=>((b.ts?+b.ts:0)-(a.ts?+a.ts:0))||b.nomor.localeCompare(a.nomor));
  await checkSync(ROWS);
  LOADED=Date.now();
}

/* ---------- tampilan ---------- */
function gate(h,p,btn){
  $('gate').hidden=false;$('app').hidden=true;
  $('gate').innerHTML=`<h2>${esc(h)}</h2><p>${esc(p)}</p>`+(btn?`<button class="btn" id="gateBtn" type="button">${esc(btn)}</button>`:'');
  if(btn)$('gateBtn').onclick=boot;
}
function visibleRows(base){
  const q=S.q.trim().toLowerCase();
  return ROWS.filter(r=>{
    if(base)return true;
    if(S.area!=='ALL'&&r.code!==S.area)return false;
    if(q&&!(r.nomor+' '+r.nama+' '+r.nopol+' '+r.tuj+' '+r.tujLok).toLowerCase().includes(q))return false;
    const s=stat(r).k;
    if(S.st==='WAIT'&&r.ar)return false;
    if(S.st==='PARK'&&s!=='park')return false;
    if(S.st==='GO'&&s!=='go')return false;
    return true;
  });
}
function render(){
  $('gate').hidden=true;$('app').hidden=false;
  {const u=$('unitName');if(u)u.textContent=unitTitle()}
  $('roleTag').hidden=false;$('roleTag').textContent=roleLabel();
  $('reload').hidden=false;
  $('stamp').textContent=LOADED?'Dibaca '+pad(new Date(LOADED).getHours())+':'+pad(new Date(LOADED).getMinutes()):'';
  const b=$('banner');const syncMsg=SYNC.length?[SYNC.length+' pengajuan sudah ada di database formulir tetapi belum masuk ke ACC PUSAT: '+SYNC.slice(0,5).map(r=>r.nomor+' ('+areaName(r)+')').join(', ')+(SYNC.length>5?' dan '+(SYNC.length-5)+' lainnya':'')+'. Biasanya izin akses (Allow access) untuk area itu belum diberikan. Buka sheet ACC PUSAT, tab IZIN AKSES.']:[];
  const msgs=(SIM?['Mode uji peran aktif: Anda melihat halaman sebagai '+roleLabel()+'. Tidak ada perubahan yang dikirim ke spreadsheet.']:[]).concat(PROBLEMS,syncMsg);b.hidden=!msgs.length;b.innerHTML=msgs.map(esc).join('<br>');b.classList.toggle('info',!!SIM&&!PROBLEMS.length&&!syncMsg.length);
  $('tab-users').hidden=REAL.role!=='admin'||!!SIM||!!window.__acct;
  $('tab-db').hidden=!isAdminLike();
  if($('tab-db').hidden&&S.tab==='db')tab('list');
  const area=ROWS.filter(r=>S.area==='ALL'||r.code===S.area);
  const nW=area.filter(r=>!r.ar).length,nP=area.filter(r=>r.ar&&!r.pu).length,nG=area.filter(r=>r.ar&&r.pu).length;
  $('tiles').innerHTML=`<div class="panel tile"><span class="k">Total pengajuan</span><span class="v num">${fmtN(area.length)}</span><span class="s">${S.area==='ALL'?'semua area':esc((AREAS[S.area]||{}).name||S.area)}</span></div>
  <div class="panel tile t-wait"><span class="k">Menunggu ACC Armada Pusat</span><span class="v num">${fmtN(nW)}</span><span class="s">${fmtN(area.filter(r=>!r.ar&&r.ac).length)} sudah di-ACC area</span></div>
  <div class="panel tile t-park"><span class="k">Diparkir</span><span class="v num">${fmtN(nP)}</span><span class="s">menunggu ACC Manager Armada</span></div>
  <div class="panel tile t-go"><span class="k">Berangkat</span><span class="v num">${fmtN(nG)}</span><span class="s">sudah disetujui lengkap</span></div>`;
  // chip area
  const cnt={};ROWS.forEach(r=>cnt[r.code]=(cnt[r.code]||0)+1);
  const codes=isAdminLike()?Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]):ME.areas.slice();
  let ch=codes.length>1?`<button class="chip" type="button" data-a="ALL" aria-pressed="${S.area==='ALL'}">Semua area<span class="c">${fmtN(ROWS.length)}</span></button>`:'';
  ch+=codes.map(c=>`<button class="chip" type="button" data-a="${esc(c)}" aria-pressed="${S.area===c}">${esc((AREAS[c]||{}).name||c)}<span class="c">${fmtN(cnt[c]||0)}</span></button>`).join('');
  $('areaChips').innerHTML=ch;
  const rows=visibleRows();
  $('count').textContent=`${fmtN(rows.length)} pengajuan · klik baris untuk melihat form fisik dan menyetujui`;
  if(!rows.length){$('tbl').innerHTML=`<div class="empty">${ROWS.length?'Tidak ada pengajuan yang cocok dengan filter ini.':'Belum ada data pengajuan yang bisa dibaca untuk akun ini.'}</div>`;return}
  $('tbl').innerHTML=`<table><thead><tr><th>No. form</th><th>Peminjam</th><th>Area</th><th>Tujuan</th><th>Pinjam sampai kembali</th><th>ACC area</th><th>ACC Armada Pusat</th><th>ACC Manager Armada</th><th>Status</th></tr></thead><tbody>${rows.slice(0,300).map(r=>{const s=stat(r);return `<tr tabindex="0" data-n="${esc(r.nomor)}"><td class="num">${esc(r.nomor)}</td><td>${esc(r.nama)}<small class="num">${esc(r.nopol)}${r.jenis?' · '+esc(r.jenis):''}</small></td><td>${esc(areaName(r))}</td><td>${esc(r.tujLok)}<small>${esc(r.tuj)}</small></td><td class="num">${tglS(r.pinjam)}<small>sampai ${tglS(r.kembali)}</small></td><td>${r.ac?'<span class="pill p-park">Sudah</span>':'<span class="pill p-na">Belum</span>'}</td><td>${r.ar?`<span class="pill p-park">Sudah</span><small class="num">${tglS(r.tglAcc)} ${jam(r.tglAcc)}</small>`:'<span class="pill p-na">Belum</span>'}</td><td>${r.pu?'<span class="pill p-go">Sudah</span>':'<span class="pill p-na">Belum</span>'}</td><td><span class="pill p-${s.k}">${s.t}</span></td></tr>`}).join('')}</tbody></table>`+(rows.length>300?`<div class="empty">Menampilkan 300 pengajuan terbaru. Persempit dengan pencarian atau filter area.</div>`:'');
}

/* ---------- form fisik ---------- */
function checklistHTML(r){
  const v=(l,t,w,s)=>`<div class="v" style="left:${l}%;top:${t}%;max-width:${w}%">${esc(s||'')}</div>`;
  return `<div class="paper ck" id="paperck"><div class="in"><img class="bg" src="${CHK}" alt="">
  ${v(20.3,20.9,16.8,r.asal)}${v(20.3,23.5,16.8,[r.jenis,r.merk].filter(Boolean).join(' '))}${v(20.3,26.5,16.8,r.nama)}
  ${v(51.9,20.9,18,tglL(r.pinjam))}${v(51.9,23.5,18,r.nopol)}</div></div>`;
}
function formHTML(r){
  const a=r.ar,p=r.pu,nmArea=areaName(r);
  const f=(k,v)=>`<dt>${k}</dt><span class="c">:</span><dd>${esc(v||'')}</dd>`;
  return `<div class="paper" id="paper">
  <div class="hd"><img src="${document.querySelector('.logo').src}" alt=""><h1>FORMULIR PEMINJAMAN UNIT OPERASIONAL MANAGEMEN</h1></div>
  <dl>${f('NO. FORM PEMINJAMAN',r.nomor)}${f('NAMA',r.nama)}${f('NO. KTP',r.ktp)}${f('NO SIM',r.sim)}${f('ALAMAT TUJUAN',r.tujLok)}${f('NO WHATSAPP',r.wa)}${f('NO TELFON AKTIF',r.telp)}<div class="gap"></div>${f('STATUS PEMINJAM',r.sp)}${f('NOPOL UNIT ARMADA',r.nopol)}${f('JENIS UNIT ARMADA',r.jenis)}${f('MERK UNIT ARMADA',r.merk)}${f('LOKASI TERAKHIR UNIT',r.asal)}${f('GROUP UNIT',r.grup)}${f('TANGGAL PINJAM',tglL(r.pinjam))}${f('PELAPORAN TANGGAL KEMBALI',tglL(r.kembali))}</dl>
  <h2>Aturan Peminjaman Unit Armada Baraka Express</h2>
  <ol><li>Setiap peminjaman unit kendaraan menjadi tanggung jawab penuh peminjam, termasuk segala akibat, risiko, dan kerusakan yang terjadi selama masa penggunaan.</li><li>Peminjam wajib menjaga dan menggunakan kendaraan dengan baik; segala bentuk kerusakan, kehilangan, atau konsekuensi hukum yang timbul selama peminjaman sepenuhnya menjadi tanggung jawab peminjam.</li><li>Unit kendaraan yang dipinjam harus dikembalikan dalam kondisi semula. Apabila terjadi kerusakan atau kehilangan, seluruh biaya perbaikan dan/atau penggantian ditanggung oleh peminjam.</li><li>Peminjaman kendaraan bersifat tanggung jawab pribadi; segala akibat yang timbul selama penggunaan, baik kerusakan ringan maupun berat, menjadi beban peminjam.</li></ol>
  <p>Dengan ini menyatakan dengan kondisi sadar bahwa saya meminjam kendaraan milik perusahaan PT Baraka Sarana Tama sesuai dengan data diatas dan menyetujui Aturan Peminjaman Unit Armada Baraka Express secara jelas.</p>
  <div class="sig">
    <div><div class="h">PEMINJAM</div><div class="box"></div><div class="nm">${esc(r.nama)}</div></div>
    <div><div class="h">STAF ARMADA</div><div class="box"></div><div class="nm">ARMADA ${esc(nmArea)}</div></div>
    <div><div class="h">ARMADA PUSAT</div><div class="box" data-ttd="staf" data-on="${a?1:0}">${a?`<img src="${TTD_STAF}" alt="Tanda tangan Armada Pusat">`:''}</div><div class="nm">${NAMA_PUSAT}</div></div>
    <div style="grid-column:2;margin-top:14px"><div class="h">MANAGER ARMADA</div><div class="box" data-ttd="mgr" data-on="${p?1:0}">${p?`<img src="${TTD_MGR}" alt="Tanda tangan dan stempel Manager Armada">`:''}</div><div class="nm">${NAMA_MGR}</div></div>
  </div></div>`;
}
async function savePdf(r,btn){
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){$('pdfMsg').textContent='Penyimpanan file tidak tersedia di tampilan ini.';return}
  if(!window.html2canvas||!window.jspdf){$('pdfMsg').textContent='Pustaka PDF belum termuat. Pakai tombol Cetak form.';return}
  btn.disabled=true;$('pdfMsg').textContent='Menyiapkan PDF …';
  const host=document.createElement('div');host.style.cssText='position:fixed;left:-9999px;top:0;width:813px;background:#fff';
  const pcss='.paper{--paper:#fff;--ink:#0b0b0b}\n'+document.querySelector('style').textContent.split('\n').filter(l=>l.startsWith('.paper')).join('\n');
  host.innerHTML='<style>'+pcss+'</style>'+formHTML(r)+checklistHTML(r);(window.__realDoc||document).body.appendChild(host);
  try{
    await Promise.all([...host.querySelectorAll('img')].map(i=>i.decode?i.decode().catch(()=>{}):0));
    const {jsPDF}=window.jspdf,doc=new jsPDF({unit:'pt',format:[609.45,935.43]});
    const pw=doc.internal.pageSize.getWidth(),ph=doc.internal.pageSize.getHeight();
    let first=true;
    for(const el of host.children){
      if(!el.classList.contains('paper'))continue;
      const cv=await html2canvas(el,{scale:2,backgroundColor:'#ffffff'});
      let w=pw,h=cv.height*w/cv.width;if(h>ph){h=ph;w=cv.width*h/cv.height}
      if(!first)doc.addPage();first=false;
      doc.addImage(cv.toDataURL('image/jpeg',.92),'JPEG',(pw-w)/2,0,w,h);
    }
    await dl.save({filename:`Form Peminjaman ${r.nomor}.pdf`,data:doc.output('blob')});
    $('pdfMsg').textContent='PDF siap disimpan.';
  }catch(e){$('pdfMsg').textContent=(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'PDF gagal dibuat ('+((e&&e.code)||'error')+').'}
  finally{host.remove();btn.disabled=false}
}

async function saveHtml(r){
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){$('pdfMsg').textContent='Penyimpanan file tidak tersedia di tampilan ini.';return}
  const css=document.querySelector('style').textContent.split('\n').filter(l=>l.startsWith('.paper')).join('\n');
  const html='<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Form Peminjaman '+esc(r.nomor)+'</title><style>@page{size:215mm 330mm;margin:0}body{margin:0;background:#fff;--paper:#fff;--ink:#0b0b0b}'+css+'.paper{margin:0 auto}.paper.ck{height:1247px}</style></head><body>'+formHTML(r)+checklistHTML(r)+'<script>addEventListener("load",function(){setTimeout(function(){print()},500)})<\/script></body></html>';
  try{await dl.save({filename:'Form Peminjaman '+r.nomor+'.html',data:new Blob([html],{type:'text/html'})});$('pdfMsg').textContent='File siap disimpan. Buka file itu dan dialog cetak akan muncul sendiri.'}
  catch(e){$('pdfMsg').textContent=(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'Gagal menyiapkan file ('+((e&&e.code)||'error')+').'}
}

/* ---------- laci detail dan persetujuan ---------- */
function openRow(n,from){
  const r=ROWS.find(x=>x.nomor===n)||DBROWS.find(x=>x.nomor===n);if(!r)return;S.cur=n;S.confirm=null;S.from=from;
  $('drT').textContent=r.nama;$('drS').textContent=r.nomor;
  drawDetail(r);
  $('veil').classList.add('on');$('dr').classList.add('on');$('dr').setAttribute('aria-hidden','false');$('drX').focus();
}
function closeRow(){
  if(!$('dr').classList.contains('on'))return;
  $('veil').classList.remove('on');$('dr').classList.remove('on');$('dr').setAttribute('aria-hidden','true');S.cur=null;
  if(S.from&&document.contains(S.from))S.from.focus();
}
function drawDetail(r){
  const s=stat(r),nf=r.src==='FORM';
  const mk=(k,lbl,ok,hint)=>nf?`<button class="btn alt" disabled type="button">${lbl}</button>`:!ok?`<button class="btn alt" disabled type="button">${lbl}</button><span class="hint">${hint}</span>`
    :`<button class="btn ${r[k]?'warn':''}" id="b${k.toUpperCase()}" type="button" data-k="${k}" ${S.busy?'disabled':''}>${S.confirm===k?'Klik lagi untuk memastikan':r[k]?'Batalkan '+lbl:lbl}</button>`;
  const acBtn=mk('ac','ACC area',canAC(r),'Area ini bukan wewenang akun Anda.');
  const arBtn=mk('ar','ACC Armada Pusat',canAR(r),'Hanya Armada Pusat dan Admin.');
  const puBtn=nf?`<button class="btn alt" disabled type="button">ACC Manager Armada</button><span class="hint">Pengajuan ini belum masuk ke sheet ACC pusat, jadi belum bisa disetujui. Biasanya area belum terdaftar atau data belum tersinkron.</span>`:!canPU()?`<button class="btn alt" disabled type="button">ACC Manager Armada</button><span class="hint">Hanya Armada Pusat dan Admin.</span>`

    :`<button class="btn ${r.pu?'warn':''}" id="bPU" type="button" data-k="pu" ${S.busy?'disabled':''}>${S.confirm==='pu'?'Klik lagi untuk memastikan':r.pu?'Batalkan ACC Manager Armada':'ACC Manager Armada'}</button>`;
  $('drB').innerHTML=`<div><span class="lbl">Persetujuan</span>
    <div class="steps" style="margin-top:8px">
      <div class="step done"><b>1. Diajukan</b><small>${tglS(r.ts)} ${jam(r.ts)}</small></div>
      <div class="step ${r.ac?'done':''}"><b>2. ACC area</b><small>${r.ac?'sudah':'belum'}</small></div>
      <div class="step ${r.ar?'done':''}"><b>3. ACC Armada Pusat</b><small>${r.ar?tglS(r.tglAcc)+' '+jam(r.tglAcc):'belum'}</small></div>
      <div class="step ${r.pu?'done':''}"><b>4. ACC Manager Armada</b><small>${r.pu?'sudah':'belum'}</small></div>
    </div></div>
    <div><span class="pill p-${s.k}">${s.t}</span> <span class="hint">${esc(s.d)}</span></div>
    <div class="act"><div class="act">${acBtn}</div><div class="act">${arBtn}</div><div class="act">${puBtn}</div></div>
    <div class="msg" id="actMsg" role="status"></div>
    <div id="berSec"></div>
    <div id="kemSec"></div>
    <div><span class="lbl">Form fisik</span>
      <div class="act" style="margin:8px 0"><button class="btn alt sm" id="pdfBtn" type="button">Unduh PDF</button><button class="btn alt sm" id="htmlBtn" type="button">Cetak form</button><span class="hint" id="pdfMsg"></span></div>
      <div class="sheetwrap">${formHTML(r)}<div style="height:12px"></div>${checklistHTML(r)}</div>
      <p class="hint">ACC area hanya centang, tanpa tanda tangan. Halaman 2 adalah checklist pemeriksaan kendaraan, terisi otomatis dari data pengajuan. Unduh PDF dan cetak memuat kedua halaman. Tanda tangan Armada Pusat muncul setelah ACC Armada Pusat dicentang. Tanda tangan dan stempel Manager Armada muncul setelah ACC Manager Armada dicentang.</p></div>`;
  $('pdfBtn').onclick=()=>savePdf(r,$('pdfBtn'));$('htmlBtn').onclick=()=>saveHtml(r);
  drawBerangkat(r);drawKembali(r);
  for(const id of ['bAC','bAR','bPU']){const b=$(id);if(b)b.onclick=()=>toggleAcc(r,b.dataset.k)}
}
/* ---------- pengembalian unit: kondisi, keterangan, dan foto form pemeriksaan setelah kembali ---------- */
const KEM_MAX=170000,FOTO_MAX=900000,DRIVE='Google Drive',FOLDER_KEM='1ogPsvCHhhVcY17J2bfwdISmThzg9J3VH'; /* ukuran foto tersimpan (karakter base64), dokumen database maksimal 256 KB */
function shrinkImg(file,max){
  max=max||KEM_MAX;
  return new Promise((res,rej)=>{
    const u=URL.createObjectURL(file),im=new Image();
    im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('Berkas ini bukan gambar yang bisa dibaca.'))};
    im.onload=()=>{
      URL.revokeObjectURL(u);
      let side=1500,q=.82;
      for(let i=0;i<10;i++){
        const k=Math.min(1,side/Math.max(im.width,im.height)),c=document.createElement('canvas');
        c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));
        const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(im,0,0,c.width,c.height);
        const d=c.toDataURL('image/jpeg',q);
        if(d.length<=max)return res(d);
        if(q>.5)q-=.1;else side=Math.round(side*.8);
      }
      rej(new Error('Foto terlalu besar. Coba foto dengan resolusi lebih kecil.'));
    };
    im.src=u;
  });
}
async function rowIn(r){
  const a=AREAS[r.code];if(!a||!a.sheetId)throw {code:'local',message:'Spreadsheet area '+areaName(r)+' belum didaftarkan.'};
  const keys=await getVals(a.sheetId,"'DATA PEMINJAM'!B5:B5000");
  const i=keys.findIndex(x=>String((x&&x[0])||'').trim()===r.nomor);
  if(i<0)throw {code:'local',message:'No. form tidak ditemukan di spreadsheet area. Muat ulang lalu coba lagi.'};
  return {sid:a.sheetId,row:5+i};
}
const b64=d=>d.slice(d.indexOf(',')+1);
const payOf=x=>{let v=x&&x.payload;if(!v){try{v=JSON.parse(x.content[0].text)}catch(e){}}return v||{}};
const stamp=()=>{const d=new Date();return pad(d.getDate())+pad(d.getMonth()+1)+String(d.getFullYear()).slice(2)+pad(d.getHours())+pad(d.getMinutes())+pad(d.getSeconds())};
async function putW(r,url,title){
  const w=await rowIn(r),cell=`'DATA PEMINJAM'!W${w.row}`;
  for(const sep of [';',',']){
    await mcp.callTool(SERVER,'update_formulas',{spreadsheetId:w.sid,range:cell,formulas:[[`=HYPERLINK("${url}"${sep}"${title}")`]]},{cache:false});
    const b=await getVals(w.sid,cell);
    if(String((b[0]&&b[0][0])||'')===title)return true;
  }
  return false;
}
const toPdfData=async d=>({dataUrl:d,ext:'pdf',mime:'application/pdf'}); /* server membungkus JPEG menjadi PDF */
async function driveUp(r,jenis,p,old){
  if(typeof p==='string')p={dataUrl:p};
  const up=payOf(await mcp.callTool(DRIVE,'create_file',{code:r.code,jenis,base64Content:b64(p.dataUrl),oldId:old&&old.id||''},{cache:false}));
  if(!up.id)throw {code:'local',message:'Google Drive tidak mengembalikan ID file.'};
  return {id:up.id,url:up.viewUrl||`https://drive.google.com/file/d/${up.id}/view?usp=drivesdk`,title:up.title,folder:up.folder};
}
function crc32(u){let t=crc32.t;if(!t){t=crc32.t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}}let r=-1;for(let i=0;i<u.length;i++)r=t[(r^u[i])&255]^(r>>>8);return(r^-1)>>>0}
function zipStore(files){
  const parts=[],cen=[],enc=new TextEncoder(),d=new Date();let off=0;
  const dt=((d.getFullYear()-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate(),tm=(d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1);
  for(const f of files){
    const nm=enc.encode(f.name),crc=crc32(f.data),n=f.data.length;
    const h=new DataView(new ArrayBuffer(30));h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x0800,true);h.setUint16(10,tm,true);h.setUint16(12,dt,true);h.setUint32(14,crc,true);h.setUint32(18,n,true);h.setUint32(22,n,true);h.setUint16(26,nm.length,true);
    parts.push(new Uint8Array(h.buffer),nm,f.data);
    const c=new DataView(new ArrayBuffer(46));c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x0800,true);c.setUint16(12,tm,true);c.setUint16(14,dt,true);c.setUint32(16,crc,true);c.setUint32(20,n,true);c.setUint32(24,n,true);c.setUint16(28,nm.length,true);c.setUint32(42,off,true);
    cen.push(new Uint8Array(c.buffer),nm);off+=30+nm.length+n;
  }
  const cs=cen.reduce((a,x)=>a+x.length,0),e=new DataView(new ArrayBuffer(22));
  e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,cs,true);e.setUint32(16,off,true);
  return new Blob([...parts,...cen,new Uint8Array(e.buffer)],{type:'application/zip'});
}
const u8Of=d=>{const s=atob(d.slice(d.indexOf(',')+1)),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u};
const FOTO_BANYAK=10,FOTO_ZIP_MAX=300000;
/* satu foto tetap JPEG; beberapa foto digabung menjadi satu ZIP (tanpa kompresi ulang, JPEG sudah terkompresi) */
async function packPhotos(files,prefix){
  const n=files.length,max=n>1?FOTO_ZIP_MAX:FOTO_MAX,list=[];
  for(const f of files)list.push(await shrinkImg(f,max));
  if(n===1)return {dataUrl:list[0],ext:'jpeg',mime:'image/jpeg',n};
  const blob=zipStore(list.map((d,i)=>({name:prefix+'_'+String(i+1).padStart(2,'0')+'.jpg',data:u8Of(d)})));
  const dataUrl=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('ZIP gagal dibuat.'));fr.readAsDataURL(blob)});
  return {dataUrl,ext:'zip',mime:'application/zip',n};
}

const actor=()=>(window.__acct&&window.__acct.label)||ME.id||'';
/* v2 */
/* ---------- checklist keberangkatan: pemeriksaan dan kelengkapan kendaraan inventaris, diunggah setelah ACC Manager Armada (JPG atau PDF) ---------- */
async function drawBerangkat(r){
  const box=$('berSec');if(!box)return;
  if(!(r.ar&&r.pu)||r.src==='FORM'){box.innerHTML='';return}
  let ks=r.kst||null;
  if(db){try{const sn=await db.doc('kstat/'+r.nomor).get();if(sn.exists)ks=sn.data()||null}catch(e){}}
  if(S.cur!==r.nomor||!$('berSec'))return;
  const can=(canAC(r)||canAR(r))&&!SIM&&!!db;
  const has=!!(ks&&ks.berUrl);
  const fmt=t=>t?tglS(new Date(t))+' '+jam(new Date(t)):'';
  const head=`<span class="lbl">Checklist keberangkatan</span><div style="margin:6px 0">${has?'<span class="pill p-go">Sudah diunggah</span>':'<span class="pill p-na">Belum diunggah</span>'}${has&&ks.berAt?` <span class="hint">${esc(fmt(ks.berAt))}${ks.berBy?' oleh '+esc(ks.berBy):''}</span>`:''}</div>`;
  const ln=has?`<div class="hint" style="margin:6px 0">Berkas di Drive: <a href="${esc(ks.berUrl)}" target="_blank" rel="noopener">${esc(ks.berName||'buka di Drive')}</a></div>`:'';
  if(!can){
    box.innerHTML=`<div>${head}${ln}${has?'':'<p class="hint">Checklist pemeriksaan dan kelengkapan kendaraan inventaris yang sudah dicek sebelum berangkat belum diunggah.</p>'}</div>`;
    return;
  }
  box.innerHTML=`<div>${head}${ln}
    <p class="hint">Unggah checklist pemeriksaan dan kelengkapan kendaraan inventaris yang sudah dicek untuk keberangkatan. Format JPG atau PDF (PDF maksimal 4 MB).</p>
    <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${has?'Ganti checklist':'Pilih file JPG atau PDF'}<input id="berFile" type="file" accept=".jpg,.jpeg,image/jpeg,.pdf,application/pdf" hidden></label><button class="btn" id="berSave" type="button" disabled>${has?'Simpan checklist baru':'Unggah checklist'}</button></div>
    <div class="msg" id="berMsg" role="status"></div></div>`;
  const say=(t,err)=>{const m=$('berMsg');if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
  let pack=null;
  $('berFile').onchange=async ev=>{
    const f=ev.target.files&&ev.target.files[0];pack=null;$('berSave').disabled=true;if(!f)return;
    const isPdf=f.type==='application/pdf'||/\.pdf$/i.test(f.name),isJpg=f.type==='image/jpeg'||/\.jpe?g$/i.test(f.name);
    if(!isPdf&&!isJpg){say('Format harus JPG atau PDF.',true);ev.target.value='';return}
    say('Memproses berkas …');
    try{
      if(isPdf){
        if(f.size>4*1024*1024)throw new Error('PDF terlalu besar (maksimal 4 MB).');
        const d=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('PDF tidak terbaca.'));fr.readAsDataURL(f)});
        if(atob(d.slice(d.indexOf(',')+1,d.indexOf(',')+9)).slice(0,4)!=='%PDF')throw new Error('Berkas ini bukan PDF yang valid.');
        pack={dataUrl:d,ext:'pdf',mime:'application/pdf'};
      }else{
        pack={dataUrl:await shrinkImg(f,FOTO_MAX),ext:'jpg',mime:'image/jpeg'};
      }
      $('berSave').disabled=false;say((isPdf?'PDF':'Foto')+' siap: '+f.name+'. Tekan tombol di sebelahnya untuk menyimpan.');
    }catch(e){pack=null;say(e.message||'Berkas gagal diproses.',true)}
  };
  $('berSave').onclick=async()=>{
    if(!pack)return;
    $('berSave').disabled=true;say('Mengunggah ke Google Drive …');
    try{
      const d0=await driveUp(r,'CHECKLIST_BERANGKAT',pack,ks&&ks.berId?{id:ks.berId,folder:ks.berFolder}:null);
      const now=new Date().toISOString();
      await db.doc('kstat/'+r.nomor).set(Object.assign({nomor:r.nomor},ks||{},{berId:d0.id,berFolder:d0.folder,berUrl:d0.url,berName:d0.title,berAt:now,berBy:actor()}));
      try{if(db&&ME.id)db.collection('log').add({nomor:r.nomor,aksi:'berangkat_checklist',by:ME.id,at:now})}catch(e){}
      r.kst=Object.assign({nomor:r.nomor},ks||{},{berUrl:d0.url});
      say('Checklist keberangkatan tersimpan di Google Drive.');
      try{await mcp.invalidate()}catch(e){}
      await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
    }catch(e){say(e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':e&&e.code==='local'?e.message:errText(e,'Google Drive')+' Tidak ada yang diubah.',true);$('berSave').disabled=false}
  };
}
async function drawKembali(r){
  const box=$('kemSec');if(!box)return;
  if(!(r.ar&&r.pu)||r.src==='FORM'){box.innerHTML='';return}
  let k=null,ks=r.kst||null;
  if(db){
    try{const sn=await db.doc('kembali/'+r.nomor).get();if(sn.exists)k=sn.data()||null}catch(e){}
    try{const sn=await db.doc('kstat/'+r.nomor).get();if(sn.exists)ks=sn.data()||null}catch(e){}
  }
  if(S.cur!==r.nomor||!$('kemSec'))return;
  const can=canAC(r)&&!SIM&&!!db;
  const back=!!(r.back||(ks&&ks.returned));
  const fmt=t=>t?tglS(new Date(t))+' '+jam(new Date(t)):'';
  const img=k&&k.foto?`<div style="margin:8px 0"><img id="kemImg" src="${esc(k.foto)}" alt="Foto form pemeriksaan setelah kembali" style="max-width:100%;max-height:320px;border:1px solid var(--line,#c9d3ee);border-radius:8px;cursor:zoom-in"></div>`:'';
  const formLn=ks&&ks.formUrl?`<div class="hint" style="margin:6px 0">Form di Drive: <a href="${esc(ks.formUrl)}" target="_blank" rel="noopener">${esc(ks.formName||'buka di Drive')}</a></div>`:'';
  const unit=ks&&ks.unitUrl?`<div class="hint" style="margin:6px 0">Foto unit pulang: <a href="${esc(ks.unitUrl)}" target="_blank" rel="noopener">${esc(ks.unitName||'buka di Drive')}</a>${ks.unitAt?' · '+esc(fmt(ks.unitAt)):''}</div>`:'';
  const ketPill=ks&&typeof ks.rusak==='boolean'?`<div style="margin:6px 0"><span class="pill p-${ks.rusak?'park':'go'}">${ks.rusak?'Ada kerusakan':'Normal'}</span>${ks.ket?`<p style="white-space:pre-wrap;margin:8px 0">${esc(ks.ket)}</p>`:''}${ks.dmgUrl?`<div class="hint">Foto kerusakan: <a href="${esc(ks.dmgUrl)}" target="_blank" rel="noopener">${esc(ks.dmgName||'buka di Drive')}</a></div>`:''}</div>`:'';
  const head=`<span class="lbl">Pengembalian unit</span><div style="margin:6px 0">${back?'<span class="pill p-back">Telah dikembalikan</span>':'<span class="pill p-na">Belum dikembalikan</span>'}${k&&k.at?` <span class="hint">form diunggah ${esc(fmt(k.at))}${k.by?' oleh '+esc(k.by):''}</span>`:''}</div>`;
  if(!can){
    box.innerHTML=`<div>${head}${ketPill}${unit}${img}${formLn}</div>`;
  }else{
    const rus=ks&&ks.rusak===true;
    box.innerHTML=`<div>${head}
      <div class="lbl" style="margin-top:8px">1. Upload form pemeriksaan setelah kembali</div>
      ${img}${formLn}
      <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${k&&k.foto?'Ganti foto form':'Pilih foto atau PDF form'}<input id="kemFile" type="file" accept="image/*,application/pdf,.pdf" hidden></label><button class="btn" id="kemSave" type="button" disabled>${back?'Simpan foto form':'Unggah dan tandai dikembalikan'}</button></div>
      <div class="msg" id="kemMsg" role="status"></div>
      ${back?`<div class="lbl" style="margin-top:8px">2. Keterangan unit</div>
      <div class="act" style="margin:6px 0"><label><input type="radio" name="kemR" value="0" ${rus?'':'checked'}> Normal</label> <label><input type="radio" name="kemR" value="1" ${rus?'checked':''}> Ada kerusakan</label></div>
      <textarea id="kemKet" rows="3" maxlength="1500" placeholder="Jelaskan kerusakan (wajib bila ada kerusakan)" style="width:100%;box-sizing:border-box">${esc(ks&&ks.ket||'')}</textarea>
      <div id="dmgBox" class="act" style="margin:6px 0" ${rus?'':'hidden'}><label class="btn alt sm" style="cursor:pointer">${ks&&ks.dmgUrl?'Ganti foto kerusakan':'Foto kerusakan'} (boleh beberapa)<input id="dmgFile" type="file" accept="image/*" multiple hidden></label><span class="hint" id="dmgInfo">Opsional. Beberapa foto disimpan sebagai satu ZIP di Google Drive.</span></div>
      <div class="act" style="margin:6px 0"><button class="btn" id="ketSave" type="button">Simpan keterangan</button></div>
      <div class="msg" id="ketMsg" role="status"></div>
      <div class="lbl" style="margin-top:8px">3. Foto unit pulang</div>${unit}
      <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${ks&&ks.unitUrl?'Ganti foto unit':'Pilih foto unit (boleh beberapa)'}<input id="unitFile" type="file" accept="image/*" multiple hidden></label><span class="hint" id="unitInfo">Boleh pilih beberapa foto; di Google Drive jadi satu file ZIP.</span><button class="btn" id="unitSave" type="button" disabled>Unggah ke Google Drive</button></div>
      <div class="msg" id="unitMsg" role="status"></div>`:'<p class="hint">Setelah form diunggah, status berubah menjadi Telah dikembalikan dan isian keterangan serta foto unit pulang muncul di sini.</p>'}
    </div>`;
    const say=(id,t,err)=>{const m=$(id);if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
    const base=()=>Object.assign({nomor:r.nomor},ks||{});
    const logIt=a=>{try{if(db&&ME.id)db.collection('log').add({nomor:r.nomor,aksi:a,by:ME.id,at:new Date().toISOString()})}catch(e){}};
    let foto='',fotoBig='',fotoPdf=null,unitFiles=[],dmgFiles=[];
    $('kemFile').onchange=async ev=>{
      const f=ev.target.files&&ev.target.files[0];if(!f)return;
      say('kemMsg','Memproses foto …');
      try{
        fotoPdf=null;foto='';fotoBig='';
        if(f.type==='application/pdf'||/\.pdf$/i.test(f.name)){
          if(f.size>4*1024*1024)throw new Error('PDF terlalu besar (maksimal 4 MB).');
          const d=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('PDF tidak terbaca.'));fr.readAsDataURL(f)});
          if(atob(d.slice(d.indexOf(',')+1,d.indexOf(',')+9)).slice(0,4)!=='%PDF')throw new Error('Berkas ini bukan PDF yang valid.');
          fotoPdf={dataUrl:d,ext:'pdf',mime:'application/pdf'};
        }else{foto=await shrinkImg(f);fotoBig=await shrinkImg(f,FOTO_MAX)}
        $('kemSave').disabled=false;say('kemMsg',(fotoPdf?'PDF siap.':'Foto siap.')+' Tekan tombol di sebelahnya untuk menyimpan.')}catch(e){say('kemMsg',e.message||'Foto gagal diproses.',true)}
    };
    $('kemSave').onclick=async()=>{
      if(!foto&&!fotoPdf)return;
      $('kemSave').disabled=true;say('kemMsg','Menyimpan …');
      const now=new Date().toISOString();
      try{
        let warn='',fd=null;
        try{fd=await driveUp(r,'FORM_PULANG',(fotoPdf||await toPdfData(fotoBig)),ks&&ks.formId?{id:ks.formId,folder:ks.formFolder}:null)}catch(e){warn=' Foto form belum masuk Google Drive ('+((e&&e.message)||'cek akses')+').'}
        await db.doc('kembali/'+r.nomor).set({nomor:r.nomor,foto,by:actor(),at:now});
        await db.doc('kstat/'+r.nomor).set(Object.assign(base(),{returned:true,at:now,by:actor()},fd?{formId:fd.id,formUrl:fd.url,formName:fd.title}:{}));
        try{const w=await rowIn(r);await putVals(w.sid,`'DATA PEMINJAM'!U${w.row}`,[['TELAH DIKEMBALIKAN']])}catch(e){warn+=' Status di spreadsheet area belum bisa diubah ('+((e&&e.message)||'cek akses')+').'}
        if(fd){try{if(!(await putW(r,fd.url,fd.title)))warn+=' Link form belum tampil benar di kolom UPLOAD PENGEMBALIAN.'}catch(e){warn+=' Kolom UPLOAD PENGEMBALIAN belum bisa diisi ('+((e&&e.message)||'cek akses')+').'}}
        logIt('kembali_form');
        r.back=true;r.kst=Object.assign(base(),{returned:true},fd?{formUrl:fd.url}:{});
        say('kemMsg','Tersimpan. Status: Telah dikembalikan.'+warn,!!warn);
        await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
      }catch(e){say('kemMsg',e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':'Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);$('kemSave').disabled=false}
    };
    if(back){
      document.querySelectorAll('input[name="kemR"]').forEach(x=>x.onchange=()=>{const on=(document.querySelector('input[name="kemR"]:checked')||{}).value==='1';$('dmgBox').hidden=!on});
      $('dmgFile').onchange=ev=>{dmgFiles=[...(ev.target.files||[])].slice(0,FOTO_BANYAK);$('dmgInfo').textContent=dmgFiles.length?dmgFiles.length+' foto dipilih. Tekan Simpan keterangan.':'Opsional.'};
      $('ketSave').onclick=async()=>{
        const rusak=!!(document.querySelector('input[name="kemR"]:checked')||{}).value&&document.querySelector('input[name="kemR"]:checked').value==='1';
        const ket=$('kemKet').value.trim().slice(0,1500);
        if(rusak&&!ket){say('ketMsg','Isi keterangan kerusakan terlebih dulu.',true);return}
        $('ketSave').disabled=true;say('ketMsg','Menyimpan …');
        try{
          let warn='',dm=null;
          if(rusak&&dmgFiles.length){
            say('ketMsg','Mengunggah foto kerusakan ke Google Drive …');
            try{const pk=await packPhotos(dmgFiles,String(areaName(r)||r.code).trim()+'_KERUSAKAN');const d0=await driveUp(r,'KERUSAKAN',pk,ks&&ks.dmgId?{id:ks.dmgId,folder:ks.dmgFolder}:null);dm={dmgId:d0.id,dmgFolder:d0.folder,dmgUrl:d0.url,dmgName:d0.title,dmgAt:new Date().toISOString()}}
            catch(e){warn=' Foto kerusakan belum masuk Google Drive ('+((e&&e.message)||'cek akses')+').'}
          }
          await db.doc('kstat/'+r.nomor).set(Object.assign(base(),{returned:true,rusak,ket,ketBy:actor(),ketAt:new Date().toISOString()},dm||{}));
          try{const w=await rowIn(r);await putVals(w.sid,`'DATA PEMINJAM'!X${w.row}`,[[rusak?'ADA KERUSAKAN':'NORMAL']])}catch(e){warn+=' Kolom KETERANGAN di spreadsheet area belum bisa diisi ('+((e&&e.message)||'cek akses')+').'}
          logIt('kembali_ket');
          say('ketMsg','Keterangan tersimpan.'+warn,!!warn);
          await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
        }catch(e){say('ketMsg','Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);$('ketSave').disabled=false}
      };
      $('unitFile').onchange=ev=>{
        unitFiles=[...(ev.target.files||[])].slice(0,FOTO_BANYAK);
        $('unitSave').disabled=!unitFiles.length;
        say('unitMsg',unitFiles.length?unitFiles.length+' foto dipilih'+(unitFiles.length>1?' (akan digabung menjadi satu ZIP).':'.'):'');
      };
      $('unitSave').onclick=async()=>{
        if(!unitFiles.length)return;
        $('unitSave').disabled=true;say('unitMsg','Memproses foto …');
        try{
          const pack=await packPhotos(unitFiles,String(areaName(r)||r.code).trim()+'_PULANG');
          say('unitMsg','Mengunggah ke Google Drive …');
          const dr=await driveUp(r,'PULANG',pack,ks&&ks.unitId?{id:ks.unitId,folder:ks.unitFolder}:null);
          const url=dr.url,title=dr.title,up={id:dr.id};
          let warn='';
          try{
            const okc=await putW(r,url,title);
            if(!okc)warn=' Link belum tampil benar di kolom UPLOAD PENGEMBALIAN.';
          }catch(e){warn=' Kolom UPLOAD PENGEMBALIAN di spreadsheet belum bisa diisi ('+((e&&e.message)||'cek akses')+').'}
          await db.doc('kstat/'+r.nomor).set(Object.assign(base(),{returned:true,unitId:up.id,unitFolder:up.folder,unitUrl:url,unitName:title,unitAt:new Date().toISOString(),unitBy:actor()}));
          logIt('kembali_foto');
          say('unitMsg','Foto unit tersimpan di Google Drive.'+warn,!!warn);
          try{await mcp.invalidate()}catch(e){}
          await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
        }catch(e){say('unitMsg',e&&e.code==='local'?e.message:errText(e,'Google Drive')+' Tidak ada yang diubah.',true);$('unitSave').disabled=false}
      };
    }
  }
  const im=$('kemImg');if(im)im.onclick=()=>{const w=window.open();if(w&&k){w.document.write('<img src="'+k.foto+'" style="max-width:100%">');w.document.close()}};
}
let confT=0;
async function toggleAcc(r,k){
  if(S.busy)return;
  if(S.confirm!==k){S.confirm=k;drawDetail(r);clearTimeout(confT);confT=setTimeout(()=>{if(S.confirm===k){S.confirm=null;const x=ROWS.find(z=>z.nomor===S.cur);if(x)drawDetail(x)}},4000);return}
  clearTimeout(confT);S.confirm=null;S.busy=true;drawDetail(r);
  const val=!r[k];
  const say=(t,err)=>{const m=$('actMsg');if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
  if(SIM){
    if(k==='ar'&&!canAR(r)){S.busy=false;say('Akun uji ini tidak bisa ACC Armada Pusat.',true);drawDetail(r);return}
    if(k==='ac'&&!canAC(r)){S.busy=false;say('Akun uji ini tidak berwenang untuk area ini.',true);drawDetail(r);return}
    if(k==='pu'&&!canPU()){S.busy=false;say('Akun uji ini tidak bisa ACC Manager Armada.',true);drawDetail(r);return}
    SIMO[r.nomor]=Object.assign(SIMO[r.nomor]||{t:Date.now()},{[k]:val});
    await loadData();render();S.busy=false;const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
    say('Simulasi: perubahan hanya tampil di sini dan tidak dikirim ke spreadsheet.');return;
  }
  say('Menyimpan ke spreadsheet …');
  try{
    if(k==='ar'&&!canAR(r))throw {code:'local',message:'Hanya Armada Pusat dan Admin yang bisa ACC Armada Pusat.'};
    if(k==='ac'&&!canAC(r))throw {code:'local',message:'Akun Anda tidak berwenang untuk area ini.'};
    if(k==='pu'&&!canPU())throw {code:'local',message:'Hanya Armada Pusat dan Admin yang bisa ACC Manager Armada.'};

    let sid,col,first,sheet;
    if(k==='ar'||k==='ac'){
      const a=AREAS[r.code];if(!a||!a.sheetId)throw {code:'local',message:'Spreadsheet area '+areaName(r)+' belum didaftarkan.'};
      sid=a.sheetId;sheet="'DATA PEMINJAM'";col=k==='ar'?'R':'Y';first=5;
    }else{sid=ACC_ID;sheet="'ACC PUSAT'";col='Y';first=2}
    const keys=await getVals(sid,`${sheet}!B${first}:B5000`);
    const i=keys.findIndex(x=>String((x&&x[0])||'').trim()===r.nomor);
    if(i<0)throw {code:'local',message:'No. form tidak ditemukan di spreadsheet. Muat ulang lalu coba lagi.'};
    const row=first+i;
    await putVals(sid,`${sheet}!${col}${row}`,[[val]]);
    const back=await getVals(sid,`${sheet}!${col}${row}`);
    const ok=B(back[0]&&back[0][0])===val;
    if(ok){OVR[r.nomor]=Object.assign(OVR[r.nomor]||{t:Date.now()},{[k]:val})}
    try{await mcp.invalidate()}catch(e){}
    try{if(db&&ME.id)await db.collection('log').add({nomor:r.nomor,aksi:(val?'acc':'batal')+'_'+(k==='ar'?'armada_pusat':k==='ac'?'area':'manager'),by:ME.id,at:new Date().toISOString()})}catch(e){}
    await loadData();render();
    S.busy=false;const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
    say(ok?(val?'Tersimpan. Persetujuan tercatat di spreadsheet.':'Persetujuan dibatalkan di spreadsheet.'):'Perintah terkirim, tetapi nilai di spreadsheet belum berubah. Periksa hak edit Anda.',!ok);
  }catch(e){
    S.busy=false;const nr=ROWS.find(z=>z.nomor===r.nomor)||r;drawDetail(nr);
    say(e&&e.code==='local'?e.message:errText(e,k==='pu'?'ACC ARMADA PUSAT':'Spreadsheet area')+' Tidak ada yang diubah.',true);
  }
}

/* ---------- pengguna, area, riwayat (admin) ---------- */
let draft=null;
async function renderUsers(){
  const v=$('usersView');v.innerHTML='<div class="panel empty">Memuat …</div>';
  let roles=[],logs=[];
  try{if(db){roles=(await db.collection('roles').get()).docs.map(d=>({id:d.id,...d.data()}))}}catch(e){}
  try{if(db){logs=(await db.collection('log').orderBy('at','desc').limit(20).get()).docs.map(d=>d.data())}}catch(e){}
  const ids=[...new Set([...roles.map(x=>x.id),...logs.map(x=>x.by).filter(Boolean)])];
  let prof={};try{prof=await user.profiles(ids)}catch(e){}
  const nm=id=>(prof[id]&&prof[id].name)||'Pengguna';
  const codes=Object.keys(AREAS);
  const rowHTML=x=>`<div class="urow" data-id="${esc(x.id)}"><img src="${esc((prof[x.id]||{}).avatarUrl||'')}" alt=""><span class="who">${esc(nm(x.id))}</span><span class="pill p-na">${x.role==='pusat'?'Armada Pusat':'Armada Daerah'}</span><span class="hint">${x.role==='daerah'?esc((x.areas||[]).map(c=>(AREAS[c]||{}).name||c).join(', ')||'tanpa area'):'semua area'}</span><button class="link" data-del="${esc(x.id)}" type="button">Hapus</button></div>`;
  v.innerHTML=`<div class="grid2">
   <div class="panel card"><h3>Akses pengguna</h3>
     <p class="hint">Pemilik dan editor halaman otomatis menjadi Admin. Armada Pusat bisa ACC area, ACC Armada Pusat dan ACC Manager Armada untuk semua area. Armada Daerah hanya bisa mencentang ACC area di areanya, tanpa tanda tangan, dan tidak bisa ACC Armada Pusat maupun ACC Manager Armada.</p>
     <div id="ulist">${roles.map(rowHTML).join('')||'<div class="hint">Belum ada pengguna yang ditambahkan.</div>'}</div>
     <div class="lbl">Tambah pengguna</div>
     <input type="text" id="usrQ" placeholder="Cari nama rekan" aria-label="Cari pengguna" autocomplete="off">
     <div id="usrHits"></div><div id="usrDraft"></div>
   </div>
   <div class="panel card"><h3>Spreadsheet per area</h3>
     <p class="hint">Dibaca otomatis dari sheet MASTER di ACC ARMADA PUSAT. Area tanpa spreadsheet belum bisa di-ACC dari halaman ini.</p>
     <ul class="plain">${codes.map(c=>`<li><b class="num">${esc(c)}</b><span>${esc(AREAS[c].name)}</span><span class="pill ${AREAS[c].sheetId?'p-park':'p-na'}">${AREAS[c].sheetId?'terdaftar':'belum ada'}</span></li>`).join('')}</ul>
   </div>
   <div class="panel card"><h3>Riwayat persetujuan</h3>
     <ul class="plain">${logs.map(l=>`<li><span class="num">${esc(String(l.at||'').slice(0,16).replace('T',' '))}</span><b>${esc(String(l.aksi||'').replace('_',' '))}</b><span class="num">${esc(l.nomor)}</span><span class="hint">${esc(nm(l.by))}</span></li>`).join('')||'<li class="hint">Belum ada riwayat.</li>'}</ul>
   </div></div>`;
  v.querySelectorAll('[data-del]').forEach(b=>b.onclick=async()=>{try{await db.doc('roles/'+b.dataset.del).delete()}catch(e){}renderUsers()});
  const q=$('usrQ');
  q.oninput=async()=>{
    const hits=q.value.trim()?await user.search(q.value.trim()):[];
    $('usrHits').innerHTML=hits.map(h=>`<button class="link" type="button" data-pick="${esc(h.id)}" style="display:block">${esc(h.name)}</button>`).join('');
    $('usrHits').querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>{draft={id:b.dataset.pick,name:b.textContent,role:'daerah',areas:[]};drawDraft(codes)});
  };
  if(draft)drawDraft(codes);
}
function drawDraft(codes){
  const d=draft,el=$('usrDraft');if(!el)return;
  el.innerHTML=`<div class="card" style="padding:10px 0"><b></b>
    <select id="dRole" aria-label="Peran"><option value="daerah" ${d.role==='daerah'?'selected':''}>Armada Daerah</option><option value="pusat" ${d.role==='pusat'?'selected':''}>Armada Pusat</option></select>
    <div class="areas" id="dAreas" ${d.role==='pusat'?'hidden':''}>${codes.map(c=>`<label><input type="checkbox" value="${esc(c)}" ${d.areas.includes(c)?'checked':''}>${esc(AREAS[c].name)}</label>`).join('')}</div>
    <div class="act"><button class="btn sm" id="dSave" type="button">Simpan</button><button class="btn alt sm" id="dCancel" type="button">Batal</button><span class="hint" id="dMsg"></span></div></div>`;
  el.querySelector('b').textContent=d.name;
  $('dRole').onchange=e=>{d.role=e.target.value;drawDraft(codes)};
  $('dAreas').onchange=()=>{d.areas=[...$('dAreas').querySelectorAll('input:checked')].map(i=>i.value)};
  $('dCancel').onclick=()=>{draft=null;el.innerHTML=''};
  $('dSave').onclick=async()=>{
    if(d.role==='daerah'&&!d.areas.length){$('dMsg').textContent='Pilih minimal satu area.';return}
    try{await db.doc('roles/'+d.id).set({role:d.role,areas:d.role==='daerah'?d.areas:[]});draft=null;renderUsers()}
    catch(e){$('dMsg').textContent='Gagal menyimpan ('+((e&&e.code)||'error')+').'}
  };
}

/* ---------- database utama: isian Google Form, terbaca otomatis ---------- */
function dbIngest(vals){
  const o=detectOrder(vals);
  DBROWS=vals.map(r=>mkRow(r,o,'FORM')).filter(Boolean).sort((x,y)=>((y.ts?+y.ts:0)-(x.ts?+x.ts:0))||y.nomor.localeCompare(x.nomor));
  const now=new Set(DBROWS.map(r=>r.nomor));
  let fresh=0;
  if(DBSEEN){for(const n of now)if(!DBSEEN.has(n)){DBNEW.add(n);fresh++}}
  DBSEEN=now;DBAT=Date.now();DBERR='';
  if(fresh&&isAdminLike()){loadData().then(()=>{render();renderDb()}).catch(()=>{})}
  renderDb(fresh);
}
async function pollDb(manual){
  try{const v=await getVals(FORM_ID,"'DATA'!A2:Q5000");dbIngest(v||[])}
  catch(e){DBERR=errText(e,'Spreadsheet formulir');renderDb()}
}
function startDb(){
  if(DBUNSUB||!mcp)return;
  $('dbInfo').textContent='Membaca data formulir …';
  pollDb();const t=setInterval(pollDb,60000);DBUNSUB=()=>clearInterval(t);
}
function stopDb(){if(DBUNSUB){try{DBUNSUB()}catch(e){}DBUNSUB=null}}
const dbFiltered=()=>{
  const q=$('dbQ').value.trim().toLowerCase(),ar=$('dbArea').value,rg=$('dbRange').value,start=new Date();start.setHours(0,0,0,0);
  const from=rg==='today'?+start:rg==='7'?+start-6*864e5:0;
  return DBROWS.filter(r=>(!ar||r.code===ar)&&(!from||(r.ts&&+r.ts>=from))&&(!q||(r.nomor+' '+r.nama+' '+r.nopol+' '+r.tujLok+' '+r.tuj).toLowerCase().includes(q)));
};
function renderDb(fresh){
  if(S.tab!=='db')return;
  const sel=$('dbArea'),keep=sel.value,cnt={};DBROWS.forEach(r=>cnt[r.code]=(cnt[r.code]||0)+1);
  sel.innerHTML='<option value="">Semua area</option>'+Object.keys(cnt).sort().map(c=>`<option value="${esc(c)}">${esc((AREAS[c]||{}).name||c)} (${cnt[c]})</option>`).join('');sel.value=cnt[keep]?keep:'';
  const inAcc=new Set(ROWS.map(r=>r.nomor)),today=new Date();today.setHours(0,0,0,0);
  const nToday=DBROWS.filter(r=>r.ts&&+r.ts>=+today).length,nGap=DBROWS.filter(r=>!inAcc.has(r.nomor)).length;
  $('dbTiles').innerHTML=`<div class="panel tile"><span class="k">Total isian formulir</span><span class="v num">${fmtN(DBROWS.length)}</span><span class="s">sejak formulir dibuka</span></div>
   <div class="panel tile t-park"><span class="k">Masuk hari ini</span><span class="v num">${fmtN(nToday)}</span><span class="s">${DBNEW.size?fmtN(DBNEW.size)+' baru sejak halaman dibuka':'otomatis dari Google Form'}</span></div>
   <div class="panel tile ${nGap?'t-wait':'t-go'}"><span class="k">Belum masuk ACC pusat</span><span class="v num">${fmtN(nGap)}</span><span class="s">${nGap?'cek area yang belum terdaftar':'semua sudah tersinkron'}</span></div>`;
  const d=DBAT?new Date(DBAT):null;
  $('dbInfo').innerHTML=(DBERR?`<span class="msg err">${esc(DBERR)}</span> `:'')+(d?`Diperbarui otomatis tiap 1 menit · terakhir ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`:'')+(fresh?` · <b>${fresh} isian baru masuk</b>`:'');
  const rows=dbFiltered();
  $('dbCount').textContent=`${fmtN(rows.length)} dari ${fmtN(DBROWS.length)} isian`;
  if(!rows.length){$('dbTbl').innerHTML='<div class="empty">'+(DBROWS.length?'Tidak ada isian yang cocok dengan filter.':(DBERR?'Data formulir belum bisa dibaca.':'Belum ada isian formulir.'))+'</div>';return}
  $('dbTbl').innerHTML=`<table><thead><tr><th>Waktu isi</th><th>No. form</th><th>Peminjam</th><th>Unit</th><th>Area</th><th>Tujuan</th><th>Pinjam sampai kembali</th><th>Posisi</th></tr></thead><tbody>${rows.slice(0,300).map(r=>`<tr tabindex="0" data-n="${esc(r.nomor)}"><td class="num">${tglS(r.ts)}<small>${jam(r.ts)}</small></td><td class="num">${esc(r.nomor)}${DBNEW.has(r.nomor)?' <span class="pill p-park">Baru</span>':''}</td><td>${esc(r.nama)}<small>${esc(r.sp)}</small></td><td class="num">${esc(r.nopol)}<small>${esc(r.jenis)} ${esc(r.merk)}</small></td><td>${esc(areaName(r))}</td><td>${esc(r.tujLok)}<small>${esc(r.tuj)}</small></td><td class="num">${tglS(r.pinjam)}<small>sampai ${tglS(r.kembali)}</small></td><td>${inAcc.has(r.nomor)?'<span class="pill p-park">Di ACC Manager Armada</span>':'<span class="pill p-first">Belum di ACC Manager Armada</span>'}</td></tr>`).join('')}</tbody></table>`+(rows.length>300?'<div class="empty">Menampilkan 300 isian terbaru. Persempit dengan filter. CSV memuat semua yang tersaring.</div>':'');
}
async function dbCsv(){
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){$('dbInfo').textContent='Penyimpanan file tidak tersedia di tampilan ini.';return}
  const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"';
  const head=['Waktu isi','No. form','Nama','No. KTP','No. SIM','No. WhatsApp','No. telepon aktif','Status peminjam','Nopol','Lokasi terakhir unit','Lokasi tujuan','Tujuan peminjaman','Jenis armada','Merk','Grup unit','Tanggal pinjam','Tanggal kembali'];
  const f=d=>d?`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`:'';
  const ft=d=>d?f(d)+' '+jam(d):'';
  const lines=[head.map(q).join(',')].concat(dbFiltered().map(r=>[ft(r.ts),r.nomor,r.nama,r.ktp,r.sim,r.wa,r.telp,r.sp,r.nopol,r.asal,r.tujLok,r.tuj,r.jenis,r.merk,r.grup,f(r.pinjam),f(r.kembali)].map(q).join(',')));
  try{await dl.save({filename:'Database Peminjaman Unit.csv',data:new Blob(['\ufeff'+lines.join('\r\n')],{type:'text/csv'})})}
  catch(e){$('dbInfo').textContent=(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'Gagal menyiapkan CSV ('+((e&&e.code)||'error')+').'}
}
$('dbQ').oninput=()=>renderDb();$('dbArea').onchange=()=>renderDb();$('dbRange').onchange=()=>renderDb();$('dbCsv').onclick=dbCsv;
$('dbTbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)});
$('dbTbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)}});

/* ---------- boot ---------- */
async function boot(){
  gate('Memuat data peminjaman','Membaca spreadsheet area dan formulir.');
  const cl=window.claude;
  if(!cl||!cl.use){gate('Halaman belum siap','Penghubung ke server tidak termuat. Muat ulang halaman.');return}
  [mcp,db,user]=await Promise.all([cl.use('mcp').catch(()=>null),cl.use('db').catch(()=>null),cl.use('user').catch(()=>null)]);
  let me={id:null,isOwner:false,canEdit:false};
  try{if(user)me=await user.me()}catch(e){}
  ME.id=me.id;ME.role=null;ME.areas=[];
  const AC=window.__acct;
  if(AC){ME.id=AC.user;if(AC.role==='admin')ME.role='admin';else if(AC.role==='pusat')ME.role='pusat';else if(AC.role==='daerah'){ME.role='daerah';ME.areas=(AC.areas||[]).slice()}}
  else if(me.isOwner||me.canEdit)ME.role='admin';
  else if(db&&me.id){
    try{const s=await db.doc('roles/'+me.id).get();if(s.exists){const x=s.data()||{};ME.role=x.role==='pusat'?'pusat':'daerah';ME.areas=Array.isArray(x.areas)?x.areas:[]}}catch(e){}
  }
  REAL.role=ME.role;REAL.areas=ME.areas.slice();
  {const u=$('unitName');if(u)u.textContent=unitTitle()}
  if(!ME.role){gate(AC?'Akun ini tidak punya akses ke fitur ini':'Akun Anda belum punya akses',AC?'Fitur Peminjaman Unit hanya untuk akun Admin, Armada Pusat, dan Armada Daerah. Masuk dengan akun lain.':'Minta admin menambahkan akun Anda dan menentukan areanya.');return}
  if(!mcp){gate('Google Sheets tidak tersedia','Sambungan ke Google Sheets lewat server tidak tersedia.','Coba lagi');return}
  try{await Promise.all([loadAreas().then(loadData),loadPrivateAssets()])}catch(e){gate('Data belum bisa dibaca',errText(e),'Coba lagi');return}
  buildSim();
  if(ME.role==='daerah'&&ME.areas.length&&S.area==='ALL')S.area=ME.areas.length===1?ME.areas[0]:'ALL';
  if(!ROWS.length&&PROBLEMS.length){gate('Data belum bisa dibaca',PROBLEMS.join(' '),'Coba lagi');return}
  render();
}
$('reload').onclick=async()=>{$('reload').disabled=true;try{await mcp.invalidate()}catch(e){}await loadData();render();if(S.cur){const r=ROWS.find(x=>x.nomor===S.cur);if(r)drawDetail(r)}$('reload').disabled=false};
$('areaChips').onclick=e=>{const b=e.target.closest('[data-a]');if(b){S.area=b.dataset.a;render()}};
$('q').oninput=e=>{S.q=e.target.value;render()};
$('stSel').onchange=e=>{S.st=e.target.value;render()};
$('tbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)});
$('tbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)}});
$('drX').onclick=closeRow;$('veil').onclick=closeRow;
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeRow()});
function tab(t){
  S.tab=t;for(const k of ['list','users','db'])$('tab-'+k).setAttribute('aria-selected',t===k);
  $('listView').hidden=t!=='list';$('usersView').hidden=t!=='users';$('dbView').hidden=t!=='db';
  if(t==='users')renderUsers();
  if(t==='db')startDb();else stopDb();
}
$('tab-list').onclick=()=>tab('list');$('tab-users').onclick=()=>tab('users');$('tab-db').onclick=()=>tab('db');
function buildSim(){
  const box=$('simBox');box.hidden=REAL.role!=='admin';
  if(box.hidden)return;
  const sel=$('simSel');
  const codes=Object.keys(AREAS);
  sel.innerHTML='<option value="">Uji peran: akun saya (Admin)</option><option value="pusat">Uji sebagai Manager / Armada Pusat</option>'+codes.map(c=>`<option value="d:${esc(c)}">Uji sebagai Armada Daerah ${esc(AREAS[c].name)}</option>`).join('');
  sel.value=SIM?(SIM.role==='pusat'?'pusat':'d:'+SIM.areas[0]):'';
}
$('simSel').onchange=async e=>{
  const v=e.target.value;SIMO={};closeRow();
  if(!v){SIM=null;ME.role=REAL.role;ME.areas=REAL.areas.slice()}
  else if(v==='pusat'){SIM={role:'pusat',areas:[]};ME.role='pusat';ME.areas=[]}
  else{const c=v.slice(2);SIM={role:'daerah',areas:[c]};ME.role='daerah';ME.areas=[c]}
  S.area=SIM&&SIM.role==='daerah'?SIM.areas[0]:'ALL';
  if(S.tab==='users')tab('list');
  await loadData();render();
};
;(function(){const t=$('themeBtn');if(t)t.onclick=()=>{const r=document.documentElement;r.dataset.theme=r.dataset.theme==='dark'?'light':'dark'}})();
boot();
})();


