import { getSettings, oauthLogin, handleAuthCallback, logout } from '@netlify/identity';

// Process callbacks once, before the Monitor module restores its application session.
window.__googleAuth = {
  ready: handleAuthCallback().then(async result => {
    if (result && result.type !== 'oauth') throw new Error('Tautan ini bukan callback login Google. Hubungi admin untuk bantuan akun.');
    if (!result) return null;
    const linking = sessionStorage.getItem('armada-google-link') === '1';
    sessionStorage.removeItem('armada-google-link');
    if (linking) {
      try { await window.__api.post('/api/google/link', {}, { quiet: true }); }
      catch (error) {
        if (error.code === 'unauthenticated') throw new Error('Sesi Armada tidak terbaca setelah kembali dari Google. Masuk dengan username dan password, lalu pilih Hubungkan Google lagi.');
        throw error;
      }
      return { linked: true };
    }
    const session = await window.__api.post('/api/login/google', {}, { quiet: true });
    return { session };
  }).catch(error => ({ error: error.message || 'Login Google gagal. Silakan coba lagi.' })),
  async start(link = false) {
    const settings = await getSettings();
    if (!settings.providers.google) throw new Error('Login Google belum diaktifkan oleh admin. Gunakan username dan password.');
    if (link) sessionStorage.setItem('armada-google-link', '1');
    else sessionStorage.removeItem('armada-google-link');
    oauthLogin('google');
  },
  async logout() { try { await logout(); } catch { /* Local app logout still completes. */ } },
};
