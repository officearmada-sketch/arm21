(()=>{
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const API=window.__api;
const ROLE={admin:'Admin',pusat:'Armada Pusat',daerah:'Armada Daerah',viewer:'Hanya lihat'};
let USERS=[],AREAS={};
const ME=(window.__acct&&window.__acct.user)||'';
const when=iso=>{if(!iso)return '–';const d=new Date(iso);return isNaN(d)?'–':d.toLocaleString('id-ID',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'})};
const say=(id,t,err)=>{const m=$(id);m.textContent=t||'';m.classList.toggle('err',!!err)};
const errMsg=e=>(e&&e.message)||'Terjadi kesalahan.';
const AL='abcdefghjkmnpqrstuvwxyzACDEFGHJKLMNPQRTUVWXYZ2346789';
const gen=()=>Array.from(crypto.getRandomValues(new Uint8Array(14)),x=>AL[x%AL.length]).join('');

/* ---------- status sistem ---------- */
async function loadSys(){
  say('sysMsg','');
  try{
    const s=await API.get('/api/admin/status'),sh=s.sheets||{};
    const up=s.uptimeSec,upT=up>86400?Math.floor(up/86400)+' hari':up>3600?Math.floor(up/3600)+' jam':Math.max(1,Math.floor(up/60))+' menit';
    const cells=[
      ['Versi',(s.version||'–')+(s.commit&&s.commit!=='dev'?' · '+String(s.commit).slice(0,7):'')],['Berjalan',upT],['Mode',s.env],
      ['Akun aktif',s.counts.users],['Sesi aktif',s.counts.sessions],['Catatan koreksi',s.counts.cek],
      ['Google Sheets',!sh.configured?'Belum dikonfigurasi':sh.error?'Gagal masuk':'Tersambung',!sh.configured||!!sh.error],
      ['Area terbaca',sh.areas+(sh.areas?'':' (cek akses MASTER)'),!sh.areas]];
    $('sys').replaceChildren(...cells.map(([k,v,bad])=>{
      const d=document.createElement('div'),l=document.createElement('span'),b=document.createElement('b');
      l.textContent=k;b.textContent=String(v);if(bad)b.className='bad';d.append(l,b);return d}));
    const msgs=[];
    if(sh.error)msgs.push('Google: '+sh.error);
    if(sh.areasError)msgs.push('Daftar area: '+sh.areasError);
    if((s.lockedUsers||[]).length)msgs.push('Akun terkunci karena salah password: '+s.lockedUsers.map(u=>u.username).join(', ')+'. Reset password untuk membukanya.');
    say('sysMsg',msgs.join(' '),!!msgs.length);
  }catch(e){say('sysMsg',errMsg(e),true)}
}

/* ---------- akun ---------- */
function areaBoxes(el,selected){
  el.innerHTML=Object.entries(AREAS).map(([c,n])=>`<label><input type="checkbox" value="${esc(c)}"${selected.includes(c)?' checked':''}>${esc(n)}</label>`).join('');
}
const picked=el=>[...el.querySelectorAll('input:checked')].map(i=>i.value);
const actions=u=>u.username===ME
  ?'<small>Akun Anda. Ganti password lewat tombol di bilah atas.</small>'
  :`<div class="acts"><button class="btn alt sm" data-a="pw" type="button">Reset password</button><button class="btn alt sm" data-a="edit" type="button">Ubah peran/area</button><button class="btn ${u.disabled?'alt':'warn'} sm" data-a="toggle" type="button">${u.disabled?'Aktifkan':'Nonaktifkan'}</button></div>`;
function renderUsers(){
  $('usrBody').innerHTML=USERS.map(u=>`<tr data-u="${esc(u.username)}">
    <td><b>${esc(u.username)}</b><br><small class="num">${esc(u.label)}</small></td>
    <td><span class="pill role">${esc(ROLE[u.role]||u.role)}</span></td>
    <td>${u.role==='daerah'?esc(u.areas.map(c=>AREAS[c]||c).join(', ')):'–'}</td>
    <td><span class="pill ${u.disabled?'off':'ok'}">${u.disabled?'Nonaktif':'Aktif'}</span></td>
    <td class="num">${esc(when(u.lastLoginAt))}</td>
    <td>${actions(u)}</td></tr>`).join('')||'<tr><td colspan="6">Belum ada akun.</td></tr>';
}
async function loadUsers(){
  try{const r=await API.get('/api/admin/users');USERS=r.users;AREAS=r.areas;renderUsers();areaBoxes($('nAreas'),[]);toggleAreas()}
  catch(e){say('usrMsg',errMsg(e),true)}
}
const toggleAreas=()=>{$('nAreas').hidden=$('nRole').value!=='daerah'};
function showSecret(text){$('secretTxt').textContent=text;$('secret').hidden=false}
$('secretClose').onclick=()=>{$('secret').hidden=true;$('secretTxt').textContent='';delete $('secretTxt').dataset.pw;say('usrMsg','')};
$('secretCopy').onclick=async()=>{try{await navigator.clipboard.writeText($('secretTxt').dataset.pw||'');say('usrMsg','Password disalin.')}catch(e){say('usrMsg','Salin manual dari kotak di atas.',true)}};
function secret(user,pw){$('secretTxt').dataset.pw=pw;showSecret(`${user} · password: ${pw}`);say('usrMsg','Catat password ini sekarang dan sampaikan ke pemiliknya. Setelah kotak ditutup tidak bisa dilihat lagi.')}
$('addBtn').onclick=()=>{$('addForm').hidden=!$('addForm').hidden;if(!$('addForm').hidden){$('nPass').value=gen();$('nUser').focus()}};
$('nRole').onchange=toggleAreas;
$('nGen').onclick=()=>{$('nPass').value=gen()};
$('addForm').addEventListener('submit',async ev=>{
  ev.preventDefault();$('nSave').disabled=true;say('usrMsg','Menyimpan …');
  const body={username:$('nUser').value.trim(),role:$('nRole').value,password:$('nPass').value,areas:picked($('nAreas'))};
  try{
    await API.post('/api/admin/users',body);
    secret(body.username,body.password);
    $('addForm').hidden=true;$('nUser').value='';
    await loadUsers();loadAudit();
  }catch(e){say('usrMsg',errMsg(e),true)}
  finally{$('nSave').disabled=false}
});
$('usrBody').addEventListener('click',async ev=>{
  const b=ev.target.closest('button[data-a]');if(!b)return;
  const name=b.closest('tr').dataset.u,u=USERS.find(x=>x.username===name);if(!u)return;
  try{
    if(b.dataset.a==='pw'){
      const pw=gen();b.disabled=true;
      await patchUser(name,{password:pw});secret(name,pw);
    }else if(b.dataset.a==='toggle'){
      b.disabled=true;await patchUser(name,{disabled:!u.disabled});say('usrMsg',u.disabled?'Akun diaktifkan.':'Akun dinonaktifkan dan sesinya diakhiri.');
    }else if(b.dataset.a==='edit'){
      editRow(b.closest('tr'),u);return;
    }
    await loadUsers();loadAudit();
  }catch(e){say('usrMsg',errMsg(e),true);b.disabled=false}
});
const patchUser=(name,body)=>API.patch('/api/admin/users/'+encodeURIComponent(name),body);
function editRow(tr,u){
  tr.innerHTML=`<td colspan="6"><div class="form" style="margin:6px 0">
    <div class="f"><label>Username</label><b>${esc(u.username)}</b></div>
    <div class="f"><label for="eRole">Peran</label><select id="eRole">${Object.entries(ROLE).map(([k,v])=>`<option value="${k}"${k===u.role?' selected':''}>${v}</option>`).join('')}</select></div>
    <div class="areas" id="eAreas"></div>
    <div class="f"><button class="btn" id="eSave" type="button">Simpan</button></div>
    <div class="f"><button class="btn alt" id="eCancel" type="button">Batal</button></div></div></td>`;
  const ar=tr.querySelector('#eAreas'),rs=tr.querySelector('#eRole');
  areaBoxes(ar,u.areas);const t=()=>{ar.hidden=rs.value!=='daerah'};t();rs.onchange=t;
  tr.querySelector('#eCancel').onclick=renderUsers;
  tr.querySelector('#eSave').onclick=async()=>{
    try{await patchUser(u.username,{role:rs.value,areas:picked(ar)});say('usrMsg','Perubahan disimpan. Sesi pengguna itu diakhiri agar peran barunya berlaku.');await loadUsers();loadAudit()}
    catch(e){say('usrMsg',errMsg(e),true)}
  };
}

/* ---------- log aktivitas ---------- */
async function loadAudit(){
  try{
    const r=await API.get('/api/admin/audit?limit=100');
    $('audBody').innerHTML=r.items.map(a=>`<tr><td class="num">${esc(when(a.at))}</td><td>${esc(a.username||'–')}</td><td>${esc(a.action)}</td><td>${esc(a.target||'')}</td><td><small>${esc(a.detail||'')}</small></td><td class="num">${esc(a.ip||'')}</td></tr>`).join('')||'<tr><td colspan="6">Belum ada aktivitas.</td></tr>';
  }catch(e){$('audBody').innerHTML=`<tr><td colspan="6" class="bad">${esc(errMsg(e))}</td></tr>`}
}
$('sysReload').onclick=loadSys;$('audReload').onclick=loadAudit;
$('themeBtn').onclick=()=>{const r=document.documentElement,d=r.dataset.theme==='dark'||(r.dataset.theme!=='light'&&matchMedia('(prefers-color-scheme:dark)').matches);r.dataset.theme=d?'light':'dark'};
loadSys();loadUsers();loadAudit();
})();
