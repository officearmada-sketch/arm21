/*MODS*/
(function(){
  const RD=document;window.__realDoc=RD;
  const done={};
  function mount(key){
    if(done[key])return;done[key]=true;
    const m=MODS[key],host=RD.getElementById('h-'+key),sr=host.attachShadow({mode:'open'});
    const st=RD.createElement('style');st.textContent=m.css;
    const mb=RD.createElement('div');mb.className='mbody';mb.innerHTML=m.html;
    sr.append(st,mb);
    const own=['pointerleave','visibilitychange'];
    const shim={
      getElementById:id=>sr.getElementById(id),
      querySelector:s=>sr.querySelector(s),
      querySelectorAll:s=>sr.querySelectorAll(s),
      createElement:t=>RD.createElement(t),
      body:mb,documentElement:host,
      contains:n=>!!n&&sr.contains(n),
      get hidden(){return RD.hidden||host.hidden},
      get activeElement(){return sr.activeElement},
      addEventListener:(t,f,o)=>(own.includes(t)?RD:sr).addEventListener(t,f,o),
      removeEventListener:(t,f,o)=>(own.includes(t)?RD:sr).removeEventListener(t,f,o)
    };
    try{m.run(shim)
      if(key==='peminjaman'){const un=sr.getElementById('unitName'),nb=RD.querySelector('.brand b');
        if(un&&nb)new MutationObserver(()=>{nb.textContent=un.textContent}).observe(un,{childList:true,characterData:true,subtree:true})}
    }catch(e){const d=RD.createElement('div');d.className='fail';d.textContent='Fitur ini gagal dimuat: '+(e&&e.message||e);mb.prepend(d)}
  }
  RD.getElementById('googleLinkBtn').onclick=async()=>{
    const button=RD.getElementById('googleLinkBtn'),message=RD.getElementById('googleLinkMsg');
    button.disabled=true;message.hidden=false;message.textContent='Menghubungkan Google …';
    try{await window.__googleAuth.start(true)}catch(e){message.textContent=e.message||'Google tidak tersedia.';button.disabled=false}
  };
  let unlocked=false,want='monitor';
  const isAdmin=()=>!!(window.__acct&&window.__acct.role==='admin');
  const allowed=k=>k!=='admin'||isAdmin();
  function show(key,focus){
    if(!unlocked||!allowed(key))key='monitor';
    for(const k of Object.keys(MODS)){
      const on=k===key;RD.getElementById('h-'+k).hidden=!on;
      const b=RD.getElementById('t-'+k);b.setAttribute('aria-selected',on);b.tabIndex=on?0:-1;
    }
    mount(key);
    try{localStorage.setItem('armada-tab',key)}catch(e){}
    if(focus)scrollTo(0,0);
  }
  for(const b of RD.querySelectorAll('.mt'))b.onclick=()=>{want=b.dataset.m;show(b.dataset.m,true);try{history.replaceState(null,'','#'+b.dataset.m)}catch(e){}};
  RD.querySelector('.mods').addEventListener('keydown',e=>{
    if(e.key!=='ArrowRight'&&e.key!=='ArrowLeft')return;
    const ks=Object.keys(MODS).filter(allowed),cur=ks.findIndex(k=>RD.getElementById('t-'+k).getAttribute('aria-selected')==='true');
    const nx=ks[(cur+(e.key==='ArrowRight'?1:ks.length-1))%ks.length];show(nx,true);RD.getElementById('t-'+nx).focus();
  });
  let first='monitor';
  try{const h=location.hash.slice(1);if(MODS[h])first=h;else{const s=localStorage.getItem('armada-tab');if(MODS[s])first=s}}catch(e){}
  want=first;
  RD.getElementById('mods').hidden=true;
  show('monitor',false);
  // Satu login untuk semua fitur: kunci dipakai dari layar masuk Monitor, fitur lain terbuka setelah berhasil masuk.
  const sr=RD.getElementById('h-monitor').shadowRoot,app=sr&&sr.getElementById('app');
  if(sr){
    const h2=sr.querySelector('#login h2');if(h2)h2.textContent='Masuk ke Armada Pusat';
    const note=sr.getElementById('lgMsg');if(note)note.textContent='Satu akun untuk Monitor Ketepatan, Peminjaman Unit, dan Pemakaian Unit. Hubungi admin untuk mendapatkan akun.';
  }
  function sync(){
    const on=!!app&&!app.hidden;
    if(on===unlocked)return;
    unlocked=on;RD.getElementById('mods').hidden=!on;RD.getElementById('googleLinkBtn').hidden=!on;
    RD.getElementById('t-admin').hidden=!(on&&isAdmin());RD.getElementById('pwBtn').hidden=!on;
    if(on){if(want!=='monitor')show(want,false)}else show('monitor',false);
  }
  if(app){new MutationObserver(sync).observe(app,{attributes:true,attributeFilter:['hidden']});sync()}
})();

/* Sesi berakhir (cookie kedaluwarsa atau dicabut): tampilkan satu pesan jelas, bukan error acak di tiap fitur */
window.addEventListener('armada-expired',()=>{const e=document.getElementById('expired');if(e)e.hidden=false});
{const b=document.getElementById('expGo');if(b)b.onclick=()=>location.reload()}

/* Ganti password sendiri (semua peran). Setelah berhasil, server mengakhiri semua sesi dan pengguna masuk lagi. */
{
  const R=document,dlg=R.getElementById('pwDlg'),f=R.getElementById('pwForm'),msg=R.getElementById('pwMsg'),go=R.getElementById('pwGo');
  const say=(t,err)=>{msg.textContent=t||'';msg.classList.toggle('err',!!err)};
  R.getElementById('pwBtn').onclick=()=>{f.reset();say('');go.disabled=false;dlg.showModal();R.getElementById('pwCur').focus()};
  R.getElementById('pwCancel').onclick=()=>dlg.close();
  f.addEventListener('submit',async ev=>{
    ev.preventDefault();
    const cur=R.getElementById('pwCur').value,n1=R.getElementById('pwNew').value,n2=R.getElementById('pwNew2').value;
    if(n1.length<8)return say('Password baru minimal 8 karakter.',1);
    if(n1!==n2)return say('Password baru dan pengulangannya tidak sama.',1);
    if(n1===cur)return say('Password baru harus berbeda dari yang lama.',1);
    go.disabled=true;say('Menyimpan …');
    try{
      await window.__api.post('/api/password',{current:cur,next:n1},{quiet:true});
      say('Password diganti. Anda akan diminta masuk lagi.');
      setTimeout(()=>location.reload(),1500);
    }catch(e){say(e.message||'Gagal mengganti password.',1);go.disabled=false}
  });
}
