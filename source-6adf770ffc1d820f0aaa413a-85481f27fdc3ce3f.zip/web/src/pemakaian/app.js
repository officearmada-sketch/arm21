(()=>{
/* Pemakaian Unit: SPPD perjalanan dinas (MOBIL INVENTARIS) + mobil grup OPERASIONAL menjadi form pemakaian dan checklist,
   lengkap dengan ACC area, ACC Armada Pusat, ACC Manager Armada, konfirmasi berangkat, upload form berangkat dan pulang, serta riwayat. */
const SERVER='Google Sheets',DRIVE='Google Drive';
const SPPD_ID='19BQ1RVmu04zoehzE_SNJYuurRAH9hgysJU2z_370Q5M';
const SPPD_SHEET="'LIST PERJALANAN DINAS NEW'";
const MASTER_ID='1V18f6If7Emm_bgpfuMUnLiJDCzA-4w1bAnM7D5EhJjw';
const EMP_ID='1h5jyC0dui20lPWCQLaKguzMuVvcHtjjIVPMkd4jrzNA';
const EMP_SHEETS=['STAFF','NON-STAFF','SOPIR','TKBM'];
const TIPE_OK='MOBIL INVENTARIS';
const GRUP_OK='OPERASIONAL';
const NAMA_PUSAT='IZAKI ARVIO MUTTAQIN';
const NAMA_MGR='ABDURRAHMAN';
const FOTO_MAX=900000,PDF_MAX=4*1024*1024;/* foto: karakter base64; PDF: byte (server menerima maksimal sekitar 4,4 MB per berkas) */
let TTD_STAF='',TTD_MGR='',CHK='';/* tanda tangan dan template: diambil dari server setelah login, tidak ada di berkas publik */
const BULAN=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const fmtN=n=>Number(n).toLocaleString('id-ID');
const tglL=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()]} ${d.getFullYear()}`:'';
const tglS=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()].slice(0,3)} ${d.getFullYear()}`:'';
const jam=d=>d?`${pad(d.getHours())}:${pad(d.getMinutes())}`:'';
let mcp=null,db=null,user=null;
const ME={id:null,role:null,areas:[]};
let TRIPS=[],CARS=[],EMP=new Map(),REC=new Map(),LOADED=0,PROBLEMS=[];
const S={tab:'pick',q:'',sppd:null,car:'',open:false,busy:false,confirm:null,pq:'',hq:'',hst:'ALL'};
const isAdminLike=()=>ME.role==='admin'||ME.role==='pusat';
const canCreate=()=>isAdminLike();
const canAC=r=>isAdminLike()||(ME.role==='daerah'&&ME.areas.includes(r.kode));
const actor=()=>(window.__acct&&window.__acct.label)||ME.id||'';

async function loadPrivateAssets(){
  const get=async n=>{try{const r=await fetch('/api/asset/'+n,{credentials:'same-origin'});if(!r.ok)return '';const b=await r.blob();
    return await new Promise(res=>{const f=new FileReader();f.onload=()=>res(String(f.result));f.onerror=()=>res('');f.readAsDataURL(b)})}catch(e){return ''}};
  [TTD_STAF,TTD_MGR,CHK]=await Promise.all([get('ttd_staf.png'),get('ttd_mgr.png'),get('chk.jpg')]);
}

/* ---------- konektor ---------- */
const openEnd=rg=>String(rg).replace(/([A-Z]+\d+):([A-Z]+)\d+$/,'$1:$2');
async function getVals(id,range){
  const run=async rg=>{
    const r=await mcp.callTool(SERVER,'get_values',{spreadsheetId:id,range:rg},{cache:false});
    let v=r&&r.payload&&r.payload.values;
    if(!v){try{v=JSON.parse(r.content[0].text).values}catch(e){v=null}}
    return v||[];
  };
  /* panggilan konektor kadang menggantung: batasi 25 detik, ulangi sekali */
  const tm=(p,ms)=>new Promise((ok,no)=>{const t=setTimeout(()=>no({code:'timeout',message:'Spreadsheet terlalu lama merespons'}),ms);p.then(v=>{clearTimeout(t);ok(v)},e=>{clearTimeout(t);no(e)})});
  try{
    try{return await tm(run(range),25000)}
    catch(e){if(e&&e.code==='timeout')return await tm(run(range),25000);throw e}
  }
  catch(e){
    /* bad_request biasanya karena batas baris melewati ukuran grid sheet: coba lagi tanpa batas baris bawah */
    if(e&&e.code==='bad_request'){const alt=openEnd(range);if(alt!==range)return await run(alt)}
    throw e;
  }
}
function errText(e,ctx){
  const c=e&&e.code,m=(e&&e.message)||'',w=ctx||'Spreadsheet';
  if(c==='unauthenticated')return 'Sesi berakhir. Muat ulang halaman lalu masuk lagi.';
  if(c==='forbidden')return m||'Akun Anda tidak berwenang untuk data ini.';
  if(c==='sheets_denied')return w+': Google menolak akses. Bagikan spreadsheet ini ke akun layanan server (email service account) sebagai Editor, lalu klik Muat ulang.';
  if(c==='sheets_not_configured')return 'Server belum disambungkan ke Google Sheets. Hubungi admin sistem.';
  if(c==='sheets_auth_failed')return 'Server gagal masuk ke Google. Periksa kunci service account.';
  if(c==='sheets_unavailable')return 'Google Sheets sedang tidak merespons. Coba muat ulang sebentar lagi.';
  if(c==='sheets_error')return w+': '+m.slice(0,160);
  if(c==='drive_error'||c==='drive_unavailable')return m||'Google Drive tidak merespons.';
  if(c==='timeout')return 'Spreadsheet terlalu lama merespons. Coba muat ulang.';
  if(c==='rate_limited')return 'Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.';
  if(c==='network')return 'Server tidak bisa dihubungi. Periksa koneksi internet Anda.';
  if(c==='bad_request')return m||'Permintaan tidak valid.';
  return 'Gagal mengakses Google Sheets ('+(c||'error')+').';
}

/* ---------- tanggal ---------- */
const BLN_IDX={};BULAN.forEach((b,i)=>{BLN_IDX[b.toLowerCase()]=i;BLN_IDX[b.slice(0,3).toLowerCase()]=i});
BLN_IDX['agu']=7;BLN_IDX['agt']=7;BLN_IDX['okt']=9;BLN_IDX['des']=11;BLN_IDX['mei']=4;BLN_IDX['nop']=10;BLN_IDX['nov']=10;
/* sel tanggal SPPD berbentuk teks "Kamis, 20 Agustus 2026"; terima juga 20/08/2026 */
function parseTgl(s){
  const t=String(s||'').trim();if(!t)return null;
  let m=t.match(/(\d{1,2})\s+([A-Za-z]+)\.?\s+(\d{4})/);
  if(m){const mo=BLN_IDX[m[2].toLowerCase()];if(mo!=null){const d=new Date(+m[3],mo,+m[1]);return d.getMonth()===mo?d:null}}
  m=t.match(/(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})/);
  if(m){const d=new Date(+m[3],+m[2]-1,+m[1]);return d.getMonth()===+m[2]-1?d:null}
  return null;
}
const dStr=d=>d?`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`:'';
const dPar=s=>{const m=String(s||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);return m?new Date(+m[1],+m[2]-1,+m[3]):null};
const isoD=s=>{const d=s?new Date(s):null;return d&&!isNaN(d)?d:null};

/* ---------- data ---------- */
const g=(r,i)=>String(r&&r[i]!=null?r[i]:'').trim();
/* kolom dicari dari judul di baris 1-3 sheet, karena sheet SPPD pernah menambah kolom (mis. JARAK PERJALANAN) dan menggeser agenda */
function tripCols(h){
  const up=(r,i)=>String((h[r]&&h[r][i])||'').trim().toUpperCase();
  const width=Math.max(...h.map(r=>r.length),14);
  const find=(rows,re)=>{for(const r of rows)for(let i=0;i<width;i++)if(re.test(up(r,i)))return i;return -1};
  const cSppd=find([1,0],/^NO\.?\s*SPPD/),cB=find([1,0],/^TANGGAL BERANGKAT/),cP=find([1,0],/^TANGGAL PULANG/);
  const cTipe=find([2,1],/^TIPE KENDARAAN/),cAg=find([1,2],/^AGENDA/),cKar=find([1,0],/^KARYAWAN/);
  const col={sppd:cSppd>=0?cSppd:1,b:cB>=0?cB:3,p:cP>=0?cP:4,tipe:cTipe>=0?cTipe:11,agenda:cAg>=0?cAg:14};
  const lo=cKar>=0?cKar:5,nib=[];
  for(let i=lo;i<col.tipe;i++)if(/^[1-6]$/.test(up(2,i)))nib.push(i);
  col.nib=nib.length?nib:[5,6,7,8,9,10];
  return col;
}
async function loadTrips(){
  const [head,v]=await Promise.all([getVals(SPPD_ID,SPPD_SHEET+'!A1:Z3'),getVals(SPPD_ID,SPPD_SHEET+'!A4:Z')]);
  const C=tripCols(head);
  const out=[];
  v.forEach((r,i)=>{
    const sppd=g(r,C.sppd);if(!sppd)return;
    if(g(r,C.tipe).toUpperCase()!==TIPE_OK)return;
    const nib=C.nib.map(k=>g(r,k)).filter(x=>x&&x!=='0');
    out.push({sppd,bTxt:g(r,C.b),pTxt:g(r,C.p),berangkat:parseTgl(g(r,C.b)),pulang:parseTgl(g(r,C.p)),nib,agenda:g(r,C.agenda),idx:i});
  });
  out.sort((a,b)=>((b.berangkat?+b.berangkat:0)-(a.berangkat?+a.berangkat:0))||b.idx-a.idx);
  return out;
}
async function loadCars(){
  const v=await getVals(MASTER_ID,"'MASTER'!A1:Q3000");
  const seen=new Set(),out=[];
  for(const r of v){
    const nopol=g(r,0);if(!nopol)continue;
    if(g(r,11).toUpperCase()!==GRUP_OK)continue;
    const k=nopol.toUpperCase().replace(/\s+/g,' ');if(seen.has(k))continue;seen.add(k);
    out.push({nopol,jenis:g(r,1),merk:g(r,5),tipe:g(r,6),lokasi:g(r,12)||g(r,10)||g(r,16),grup:g(r,11),kode:g(r,15),area:g(r,16)||g(r,12)||g(r,10)});
  }
  out.sort((a,b)=>a.nopol.localeCompare(b.nopol));
  return out;
}
async function loadEmp(){
  const map=new Map(),bad=[];
  await Promise.all(EMP_SHEETS.map(async sh=>{
    try{
      const v=await getVals(EMP_ID,`'${sh}'!A2:B`);
      v.forEach(r=>{const n=g(r,0),nm=g(r,1);if(n&&nm&&!map.has(n))map.set(n,nm)});
    }catch(e){bad.push(sh+': '+errText(e,'Database karyawan'))}
  }));
  if(bad.length)PROBLEMS.push('Sebagian database karyawan belum terbaca ('+bad.join(' | ')+'). Nama yang belum ditemukan tampil sebagai NIB.');
  return map;
}
async function loadRecs(){
  const sn=await db.collection('pakai').get(),m=new Map();
  sn.docs.forEach(d=>{const x=d.data()||{};if(x.sppd)m.set(d.id,Object.assign({},x,{id:d.id}))});
  return m;
}
let LOADING=false;
/* tahap 1: pengajuan dan daftar SPPD (cukup untuk membuka dropdown); tahap 2: mobil dan nama karyawan di latar belakang */
async function loadData(onFirst){
  PROBLEMS=[];
  const pr=db?loadRecs():Promise.reject({code:'local',message:'Database halaman tidak tersedia.'});
  const pt=canCreate()?loadTrips():null,pc=canCreate()?loadCars():null,pe=canCreate()?loadEmp():null;
  const first=await Promise.allSettled(pt?[pr,pt]:[pr]);
  if(first[0].status==='fulfilled')REC=first[0].value;else{REC=new Map();PROBLEMS.push('Data pemakaian tersimpan belum terbaca: '+((first[0].reason&&first[0].reason.message)||'cek akses')+'.')}
  if(pt){
    const a=first[1];
    if(a.status==='fulfilled')TRIPS=a.value;else{TRIPS=[];PROBLEMS.push(errText(a.reason,'Daftar perjalanan dinas'))}
    CARS=[];EMP=new Map();LOADING=true;
  }
  LOADED=Date.now();
  if(onFirst)onFirst();
  if(pt){
    const [b,c]=await Promise.allSettled([pc,pe]);
    if(b.status==='fulfilled')CARS=b.value;else{CARS=[];PROBLEMS.push(errText(b.reason,'Master armada'))}
    if(c.status==='fulfilled')EMP=c.value;else{EMP=new Map();PROBLEMS.push(errText(c.reason,'Database karyawan'))}
    LOADING=false;LOADED=Date.now();
  }
}
const ridOf=s=>String(s).replace(/[^A-Za-z0-9]+/g,'_').replace(/^_+|_+$/g,'');
const names=t=>t.nama||t.nib.map(n=>({nib:n,name:EMP.get(n)||''}));
/* "KE PORT CIKARANG (DAWUAN) AGENDA ..." dipecah menjadi tujuan dan agenda */
function splitAgenda(s){
  const t=String(s||'').trim();
  const m=t.match(/^(.*?)\s*\bAGENDA\b\s*(.*)$/is);
  if(!m)return {tujuan:t,agenda:t};
  const tuj=m[1].replace(/^KE\s+/i,'').trim();
  return {tujuan:tuj||t,agenda:m[2].trim()||t};
}
const tripOf=r=>({sppd:r.sppd,nib:r.nib||[],nama:r.nama||[],agenda:r.agenda||'',bTxt:r.bTxt||'',pTxt:r.pTxt||'',berangkat:dPar(r.berangkat),pulang:dPar(r.pulang)});
const carOf=r=>({nopol:r.nopol,jenis:r.jenis||'',merk:r.merk||'',tipe:r.tipe||'',lokasi:r.lokasi||'',grup:r.grup||'',kode:r.kode||'',area:r.area||''});
const recOf=()=>S.sppd?REC.get(ridOf(S.sppd))||null:null;
/* pasangan SPPD, mobil, dan data tersimpan yang sedang dilihat */
function view(){
  const rec=recOf();
  if(rec)return {rec,t:tripOf(rec),c:carOf(rec)};
  const t=TRIPS.find(x=>x.sppd===S.sppd)||null,c=CARS.find(x=>x.nopol===S.car)||null;
  return {rec:null,t,c};
}
const safeName=s=>String(s).replace(/[\\/:*?"<>|]+/g,'-').replace(/\s+/g,' ').trim();
function stat(r){
  if(r.returned)return {k:'back',t:'Telah kembali',d:'Form kepulangan sudah diunggah'};
  if(r.dep)return {k:'go',t:'Berangkat',d:'Unit sudah diberangkatkan, menunggu form kepulangan'};
  if(r.ar&&r.pu)return {k:'park',t:'Siap berangkat',d:'Semua ACC lengkap, tekan Berangkat saat unit jalan'};
  if(r.ar)return {k:'park',t:'Menunggu ACC Manager',d:'ACC Armada Pusat selesai, menunggu ACC Manager Armada'};
  if(r.ac)return {k:'wait',t:'ACC area',d:'Sudah di-ACC area, menunggu ACC Armada Pusat'};
  return {k:'wait',t:'Menunggu ACC',d:'Belum ada persetujuan'};
}
const inScope=r=>isAdminLike()||(ME.role==='daerah'&&ME.areas.includes(r.kode));

/* ---------- simpan ke database ---------- */
async function patch(rec,ch,aksi){
  let cur=rec;
  try{const sn=await db.doc('pakai/'+rec.id).get();if(sn.exists)cur=Object.assign({},sn.data(),{id:rec.id})}catch(e){}
  const nx=Object.assign({},cur,ch,{id:rec.id});
  const body=Object.assign({},nx);delete body.id;
  await db.doc('pakai/'+rec.id).set(body);
  REC.set(rec.id,nx);
  try{if(aksi&&ME.id)db.collection('log').add({nomor:rec.sppd,aksi,by:ME.id,at:new Date().toISOString()})}catch(e){}
  return nx;
}

/* ---------- tampilan: umum ---------- */
function gate(h,p,btn){
  $('gate').hidden=false;$('app').hidden=true;
  $('gate').innerHTML=`<h2>${esc(h)}</h2><p>${esc(p)}</p>`+(btn?`<button class="btn" id="gateBtn" type="button">${esc(btn)}</button>`:'');
  if(btn)$('gateBtn').onclick=boot;
}
const roleLabel=()=>ME.role==='admin'?'Admin':ME.role==='pusat'?'Armada Pusat':'Armada Daerah'+(ME.areas.length?' · '+ME.areas.join(', '):'');
const recs=()=>[...REC.values()].filter(inScope);
function tripLabel(t){
  const b=t.berangkat?tglS(t.berangkat):(t.bTxt||'-'),p=t.pulang?tglS(t.pulang):(t.pTxt||'-');
  return b+(p&&p!==b?' sampai '+p:'');
}
function tripItem(t,on){
  const rc=REC.get(ridOf(t.sppd)),st=rc?stat(rc):null;
  return `<button type="button" class="spi${on?' on':''}" role="option" aria-selected="${on}" data-s="${esc(t.sppd)}">
    <span class="spt"><b class="num">${esc(t.sppd)}</b><span class="spd">${esc(tripLabel(t))}</span>${st?`<span class="pill p-${st.k}">${esc(st.t)}</span>`:''}</span>
    <span class="spn">${t.nib.map(n=>`<i class="num">${esc(n)}</i>`).join('')||'<em>tanpa NIB</em>'}</span>
    <small>${esc(t.agenda||'-')}</small></button>`;
}
function filteredTrips(){
  const q=S.q.trim().toLowerCase();
  if(!q)return TRIPS;
  return TRIPS.filter(t=>(t.sppd+' '+t.nib.join(' ')+' '+t.agenda+' '+t.bTxt+' '+t.pTxt+' '+names(t).map(n=>n.name).join(' ')).toLowerCase().includes(q));
}
function drawList(){
  const rows=filteredTrips();
  $('spCount').textContent=rows.length===TRIPS.length?fmtN(TRIPS.length)+' SPPD mobil inventaris':fmtN(rows.length)+' dari '+fmtN(TRIPS.length)+' SPPD';
  $('spList').innerHTML=rows.length?rows.slice(0,150).map(t=>tripItem(t,t.sppd===S.sppd)).join('')+(rows.length>150?`<div class="hint" style="padding:8px 12px">Menampilkan 150 teratas. Persempit dengan kolom cari.</div>`:''):'<div class="empty">Tidak ada SPPD mobil inventaris yang cocok.</div>';
}
function drawTrigger(){
  const {t}=view();
  $('spBtn').setAttribute('aria-expanded',S.open);
  $('spPanel').hidden=!S.open;
  if(!t){$('spBtn').innerHTML='<span class="ph">Pilih SPPD perjalanan dinas</span><span class="car">▾</span>';return}
  $('spBtn').innerHTML=`<span class="sel"><b class="num">${esc(t.sppd)}</b><span>${esc(tripLabel(t))}</span><span class="num">NIB ${esc(t.nib.join(', ')||'-')}</span><small>${esc(t.agenda||'-')}</small></span><span class="car">▾</span>`;
}
function render(){
  $('gate').hidden=true;$('app').hidden=false;
  $('roleTag').hidden=false;$('roleTag').textContent=roleLabel();
  $('reload').hidden=false;
  $('stamp').textContent=LOADED?'Dibaca '+pad(new Date(LOADED).getHours())+':'+pad(new Date(LOADED).getMinutes()):'';
  const b=$('banner');b.hidden=!PROBLEMS.length;b.innerHTML=PROBLEMS.map(esc).join('<br>');
  const all=recs();
  const nW=all.filter(r=>!r.dep&&!r.returned&&!(r.ar&&r.pu)).length,nR=all.filter(r=>!r.dep&&!r.returned&&r.ar&&r.pu).length,nG=all.filter(r=>r.dep&&!r.returned).length,nB=all.filter(r=>r.returned).length;
  $('tiles').innerHTML=`<div class="panel tile t-wait"><span class="k">Menunggu ACC</span><span class="v num">${fmtN(nW)}</span><span class="s">belum lengkap persetujuannya</span></div>
  <div class="panel tile t-park"><span class="k">Siap berangkat</span><span class="v num">${fmtN(nR)}</span><span class="s">ACC lengkap, belum berangkat</span></div>
  <div class="panel tile t-go"><span class="k">Sedang berangkat</span><span class="v num">${fmtN(nG)}</span><span class="s">menunggu form kepulangan</span></div>
  <div class="panel tile"><span class="k">Telah kembali</span><span class="v num">${fmtN(nB)}</span><span class="s">arsip pemakaian selesai</span></div>`;
  $('tab-proc').innerHTML='Dalam proses'+(all.filter(r=>!r.dep&&!r.returned).length?` <span class="tcnt">${fmtN(all.filter(r=>!r.dep&&!r.returned).length)}</span>`:'');
  $('pickCard').hidden=!canCreate();
  drawTrigger();drawList();
  const rec=recOf(),keep=rec?rec.nopol:S.car;
  $('carSel').innerHTML='<option value="">Pilih mobil operasional</option>'+CARS.map(c=>`<option value="${esc(c.nopol)}">${esc(c.nopol)} · ${esc([c.jenis,c.merk].filter(Boolean).join(' '))}${c.area?' · '+esc(c.area):''}</option>`).join('')+(rec&&!CARS.some(c=>c.nopol===rec.nopol)?`<option value="${esc(rec.nopol)}">${esc(rec.nopol)}</option>`:'');
  $('carSel').value=keep||'';
  $('carSel').disabled=!!rec;
  $('carHint').textContent=rec?'Mobil terkunci sejak pemakaian diajukan. Batalkan pengajuan bila ingin mengganti mobil.':LOADING?'Memuat daftar mobil…':CARS.length?'Hanya mobil grup '+GRUP_OK+' dari sheet MASTER yang bisa dipilih.':'Belum ada mobil grup '+GRUP_OK+' yang terbaca dari sheet MASTER.';
  drawResult();drawTab();
}

/* ---------- form fisik dan checklist ---------- */
const logoSrc=()=>{try{return (window.__realDoc||window.document).querySelector('.brand img').src}catch(e){return ''}};
function namaHTML(t){
  const n=names(t);
  return n.length?n.map((x,i)=>`${n.length>1?(i+1)+'. ':''}${esc(x.name||('NIB '+x.nib))}`).join('<br>'):'';
}
function checklistHTML(t,c){
  const v=(l,tp,w,s,cls)=>`<div class="v${cls?' '+cls:''}" style="left:${l}%;top:${tp}%;max-width:${w}%">${s}</div>`;
  const nm=names(t).map(x=>x.name||('NIB '+x.nib));
  return `<div class="paper ck" id="paperck"><div class="in"><img class="bg" src="${CHK}" alt="">
  ${v(20.3,20.9,16.8,esc(c.lokasi))}${v(20.3,23.5,16.8,esc([c.jenis,c.merk].filter(Boolean).join(' ')))}${v(20.3,26.5,17.6,nm.map(esc).join('<br>'),'wr')}
  ${v(51.9,20.9,18,esc(tglL(t.berangkat)||t.bTxt))}${v(51.9,23.5,18,esc(c.nopol))}</div></div>`;
}
function formHTML(t,c,rec){
  const f=(k,h)=>`<dt>${k}</dt><span class="c">:</span><dd>${h||''}</dd>`;
  const sp=splitAgenda(t.agenda),n=names(t),a=!!(rec&&rec.ar),p=!!(rec&&rec.pu);
  const pemakai=n.map(x=>`<div>${esc(x.name||('NIB '+x.nib))}</div>`).join('');
  return `<div class="paper" id="paper">
  <div class="hd"><img src="${logoSrc()}" alt=""><h1>FORMULIR PEMAKAIAN UNIT OPERASIONAL MANAGEMEN</h1></div>
  <dl>${f('NO. FORM PEMAKAIAN',esc(t.sppd))}${f('NAMA',namaHTML(t))}${f('ALAMAT TUJUAN',esc(sp.tujuan))}<div class="gap"></div>${f('NOPOL UNIT ARMADA',esc(c.nopol))}${f('JENIS UNIT ARMADA',esc(c.jenis))}${f('MERK UNIT ARMADA',esc(c.merk))}${f('LOKASI TERAKHIR UNIT',esc(c.lokasi))}${f('GROUP UNIT',esc(c.grup))}${f('TANGGAL PAKAI',esc(tglL(t.berangkat)||t.bTxt))}${f('PELAPORAN TANGGAL KEMBALI',esc(tglL(t.pulang)||t.pTxt))}</dl>
  <h2>Aturan Pemakaian Unit Armada Baraka Express</h2>
  <ol><li>Setiap pemakaian unit kendaraan menjadi tanggung jawab penuh pemakai, termasuk segala akibat, risiko, dan kerusakan yang terjadi selama masa penggunaan.</li><li>Pemakai wajib menjaga dan menggunakan kendaraan dengan baik; segala bentuk kerusakan, kehilangan, atau konsekuensi hukum yang timbul selama pemakaian sepenuhnya menjadi tanggung jawab pemakai.</li><li>Unit kendaraan yang dipakai harus dikembalikan dalam kondisi semula. Apabila terjadi kerusakan atau kehilangan, seluruh biaya perbaikan dan/atau penggantian ditanggung oleh pemakai.</li><li>Pemakaian kendaraan bersifat tanggung jawab pribadi; segala akibat yang timbul selama penggunaan, baik kerusakan ringan maupun berat, menjadi beban pemakai.</li></ol>
  <p>Dengan ini menyatakan dengan kondisi sadar bahwa saya memakai kendaraan milik perusahaan PT Baraka Sarana Tama sesuai dengan data diatas dan menyetujui Aturan Pemakaian Unit Armada Baraka Express secara jelas.</p>
  <div class="sig">
    <div><div class="h">PEMAKAI</div><div class="box"></div><div class="nm">${pemakai}</div></div>
    <div><div class="h">STAF ARMADA</div><div class="box"></div><div class="nm">ARMADA ${esc(String(c.area||'').toUpperCase())}</div></div>
    <div><div class="h">ARMADA PUSAT</div><div class="box" data-ttd="staf" data-on="${a?1:0}">${a?`<img src="${TTD_STAF}" alt="Tanda tangan Armada Pusat">`:''}</div><div class="nm">${NAMA_PUSAT}</div></div>
    <div style="grid-column:2;margin-top:14px"><div class="h">MANAGER ARMADA</div><div class="box" data-ttd="mgr" data-on="${p?1:0}">${p?`<img src="${TTD_MGR}" alt="Tanda tangan dan stempel Manager Armada">`:''}</div><div class="nm">${NAMA_MGR}</div></div>
  </div></div>`;
}
const say=(id,t,err)=>{const m=$(id);if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
const paperCss=()=>'.paper{--paper:#fff;--ink:#0b0b0b}\n'+document.querySelector('style').textContent.split('\n').filter(l=>l.startsWith('.paper')).join('\n');

/* ---------- detail pemakaian ---------- */
function drawCancel(){
  const b=$('delTop');if(!b)return;
  const rec=recOf(),ok=!!rec&&(isAdminLike()||canAC(rec))&&!rec.dep&&!rec.returned;
  b.hidden=!ok;if(!ok)return;
  b.textContent=S.confirm==='del'?'Klik lagi untuk memastikan':'Batalkan pengajuan';
  b.disabled=!!S.busy;b.onclick=()=>delRec(rec);
}
function drawResult(){drawCancel();drawResult0()}
function drawResult0(){
  const {rec,t,c}=view(),box=$('result');
  if(!t||!c){
    box.innerHTML=`<div class="panel empty">${canCreate()?`${!t?'Pilih SPPD terlebih dulu':'Pilih mobil operasional'}${!t&&!c?', lalu pilih mobil.':'.'} Form pemakaian dan checklist terisi otomatis setelah keduanya dipilih.`:'Pilih satu pemakaian dari tab Dalam proses atau Riwayat untuk melihat detailnya.'}</div>`;
    return;
  }
  const n=names(t),miss=n.filter(x=>!x.name).length;
  let ctrl='';
  if(!rec){
    ctrl=`<div class="act"><button class="btn" id="mk" type="button" ${S.busy?'disabled':''}>Ajukan pemakaian</button><span class="hint">Menyimpan pasangan SPPD dan mobil ini agar bisa di-ACC, diberangkatkan, dan masuk riwayat.</span></div><div class="msg" id="actMsg" role="status"></div>`;
  }else{
    const s=stat(rec);
    const mk=(k,lbl,ok,hint)=>!ok?`<button class="btn alt" disabled type="button">${lbl}</button><span class="hint">${hint}</span>`
      :`<button class="btn ${rec[k]?'warn':''}" data-k="${k}" type="button" ${S.busy?'disabled':''}>${S.confirm===k?'Klik lagi untuk memastikan':rec[k]?'Batalkan '+lbl:lbl}</button>`;
    const fmt=iso=>{const d=isoD(iso);return d?tglS(d)+' '+jam(d):''};
    ctrl=`<div class="steps">
      <div class="step done"><b>1. Diajukan</b><small>${fmt(rec.createdAt)}</small></div>
      <div class="step ${rec.ac?'done':''}"><b>2. ACC area</b><small>${rec.ac?fmt(rec.acAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.ar?'done':''}"><b>3. ACC Armada Pusat</b><small>${rec.ar?fmt(rec.arAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.pu?'done':''}"><b>4. ACC Manager Armada</b><small>${rec.pu?fmt(rec.puAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.dep?'done':''}"><b>5. Berangkat</b><small>${rec.dep?fmt(rec.depAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.returned?'done':''}"><b>6. Kembali</b><small>${rec.returned?fmt(rec.retAt)||'sudah':'belum'}</small></div>
    </div>
    <div><span class="pill p-${s.k}">${esc(s.t)}</span> <span class="hint">${esc(s.d)}</span></div>
    <div class="act"><div class="act">${mk('ac','ACC area',canAC(rec)&&!rec.dep,rec.dep?'Sudah berangkat.':'Area ini bukan wewenang akun Anda.')}</div><div class="act">${mk('ar','ACC Armada Pusat',isAdminLike()&&!rec.pu&&!rec.dep,rec.pu?'Batalkan ACC Manager Armada dulu.':rec.dep?'Sudah berangkat.':'Hanya Armada Pusat dan Admin.')}</div><div class="act">${mk('pu','ACC Manager Armada',isAdminLike()&&rec.ar&&!rec.dep,!isAdminLike()?'Hanya Armada Pusat dan Admin.':rec.dep?'Sudah berangkat.':'ACC Armada Pusat harus dicentang lebih dulu.')}</div></div>
    <div class="msg" id="actMsg" role="status"></div>
    <div id="berSec"></div>
    <div class="dep"><span class="lbl">Konfirmasi keberangkatan</span>
      <div class="act" style="margin:6px 0">${rec.dep?`<span class="pill p-go">Sudah berangkat</span><span class="hint">${esc(fmt(rec.depAt))}${rec.depBy?' · '+esc(rec.depBy):''}</span>${isAdminLike()&&!rec.returned?`<button class="btn warn sm" data-k="dep" type="button" ${S.busy?'disabled':''}>${S.confirm==='dep'?'Klik lagi untuk memastikan':'Batalkan berangkat'}</button>`:''}`
        :`${isAdminLike()&&rec.ar&&rec.pu?`<button class="btn" data-k="dep" type="button" ${S.busy?'disabled':''}>${S.confirm==='dep'?'Klik lagi untuk memastikan':'Berangkat'}</button><span class="hint">Tekan saat unit benar-benar jalan.</span>`:`<button class="btn alt" disabled type="button">Berangkat</button><span class="hint">${!isAdminLike()?'Hanya Armada Pusat dan Admin.':'Menunggu ACC Armada Pusat dan ACC Manager Armada.'}</span>`}`}</div></div>
    <div id="pulSec"></div>`;
  }
  box.innerHTML=`<div class="panel card">
    <div class="lbl">Ringkasan pemakaian</div>
    <div class="sum">
      <div><span class="k">No. SPPD</span><b class="num">${esc(t.sppd)}</b></div>
      <div><span class="k">Berangkat sampai pulang</span><b>${esc(tglL(t.berangkat)||t.bTxt)}${t.pulang&&t.berangkat&&+t.pulang!==+t.berangkat?' sampai '+esc(tglL(t.pulang)):''}</b></div>
      <div><span class="k">Karyawan</span><b>${n.map(x=>esc(x.name||'(belum ada di database)')+' <span class="num hint">'+esc(x.nib)+'</span>').join('<br>')||'-'}</b></div>
      <div><span class="k">Mobil</span><b>${esc(c.nopol)}</b><span class="hint">${esc([c.jenis,c.merk,c.tipe].filter(Boolean).join(' '))} · ${esc(c.area||c.lokasi)}</span></div>
      <div class="wide"><span class="k">Agenda</span><b>${esc(t.agenda||'-')}</b></div>
    </div>
    ${miss&&!rec?`<div class="msg err">${miss} NIB belum ditemukan di database karyawan, jadi form memakai NIB sebagai pengganti nama.</div>`:''}
    ${ctrl}
  </div>
  <div class="panel card"><span class="lbl">Dokumen</span>
    <div class="act"><button class="btn" id="dlForm" type="button">Unduh form pemakaian (PDF)</button><button class="btn" id="dlCk" type="button">Unduh checklist pemeriksaan (PDF)</button><button class="btn alt" id="prAll" type="button">Cetak keduanya</button></div>
    <div class="msg" id="dlMsg" role="status"></div>
    <p class="hint">Tanda tangan Armada Pusat muncul setelah ACC Armada Pusat dicentang, tanda tangan Manager Armada setelah ACC Manager Armada. ACC area hanya centang, tanpa tanda tangan.</p>
  </div>
  <div><span class="lbl">Pratinjau form pemakaian</span><div class="sheetwrap" style="margin-top:8px">${formHTML(t,c,rec)}</div></div>
  <div><span class="lbl">Pratinjau checklist pemeriksaan</span><div class="sheetwrap" style="margin-top:8px">${checklistHTML(t,c)}</div></div>
  ${rec&&isAdminLike()&&!rec.dep&&!rec.returned?`<div class="act"><button class="btn alt sm" id="delRec" type="button">${S.confirm==='del'?'Klik lagi untuk memastikan':'Batalkan pengajuan ini'}</button><span class="hint">Menghapus pengajuan beserta semua ACC. Berkas di Drive tidak ikut terhapus.</span></div>`:''}`;
  $('dlForm').onclick=()=>savePdf('form');
  $('dlCk').onclick=()=>savePdf('ck');
  $('prAll').onclick=saveHtml;
  const mkb=$('mk');if(mkb)mkb.onclick=createRec;
  box.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>toggle(rec,b.dataset.k));
  const dr=$('delRec');if(dr)dr.onclick=()=>delRec(rec);
  if(rec){drawUpload(rec,'ber');drawUpload(rec,'pul')}
}
async function createRec(){
  const {t,c}=view();if(!t||!c||S.busy||!canCreate())return;
  S.busy=true;say('actMsg','Menyimpan pengajuan …');
  const nm=names(t);
  const rec={id:ridOf(t.sppd),sppd:t.sppd,nib:t.nib.slice(),nama:nm,agenda:t.agenda,bTxt:t.bTxt,pTxt:t.pTxt,berangkat:dStr(t.berangkat),pulang:dStr(t.pulang),
    nopol:c.nopol,jenis:c.jenis,merk:c.merk,tipe:c.tipe,lokasi:c.lokasi,grup:c.grup,kode:c.kode,area:c.area,
    ac:false,ar:false,pu:false,dep:false,returned:false,createdAt:new Date().toISOString(),createdBy:actor()};
  try{
    const ex=await db.doc('pakai/'+rec.id).get();
    if(ex.exists){REC.set(rec.id,Object.assign({},ex.data(),{id:rec.id}));S.car=ex.data().nopol||'';say('actMsg','SPPD ini sudah diajukan sebelumnya. Menampilkan data yang tersimpan.')}
    else await patch(rec,{},'pakai_ajukan');
  }catch(e){S.busy=false;say('actMsg',e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':'Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);return}
  S.busy=false;S.car=c.nopol;render();
}
let confT=0;
async function toggle(rec,k){
  if(S.busy)return;
  if(S.confirm!==k){S.confirm=k;drawResult();clearTimeout(confT);confT=setTimeout(()=>{if(S.confirm===k){S.confirm=null;drawResult()}},4000);return}
  clearTimeout(confT);S.confirm=null;S.busy=true;drawResult();
  try{
    const cur=REC.get(rec.id)||rec,val=!cur[k],now=new Date().toISOString();
    if(k==='ac'&&!canAC(cur))throw {code:'local',message:'Akun Anda tidak berwenang untuk area ini.'};
    if((k==='ar'||k==='pu'||k==='dep')&&!isAdminLike())throw {code:'local',message:'Hanya Armada Pusat dan Admin.'};
    if(k==='pu'&&val&&!cur.ar)throw {code:'local',message:'ACC Armada Pusat harus dicentang lebih dulu.'};
    if(k==='ar'&&!val&&cur.pu)throw {code:'local',message:'Batalkan ACC Manager Armada dulu.'};
    if(k==='dep'&&val&&!(cur.ar&&cur.pu))throw {code:'local',message:'ACC Armada Pusat dan ACC Manager Armada harus lengkap dulu.'};
    if(k==='dep'&&!val&&cur.returned)throw {code:'local',message:'Unit sudah kembali, status berangkat tidak bisa dibatalkan.'};
    const ch=k==='dep'?{dep:val,depAt:val?now:'',depBy:val?actor():''}:{[k]:val,[k+'At']:val?now:'',[k+'By']:val?actor():''};
    const nm=({ac:'acc_area',ar:'acc_armada_pusat',pu:'acc_manager',dep:'berangkat'})[k];
    await patch(cur,ch,'pakai_'+(val?'':'batal_')+nm);
    S.busy=false;render();
    say('actMsg',k==='dep'?(val?'Tersimpan. Pemakaian masuk riwayat dengan status Berangkat.':'Status berangkat dibatalkan.'):(val?'Tersimpan. Persetujuan tercatat.':'Persetujuan dibatalkan.'));
  }catch(e){
    S.busy=false;drawResult();
    say('actMsg',e&&e.code==='local'?e.message:e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':'Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);
  }
}
async function delRec(rec){
  if(S.busy)return;
  if(S.confirm!=='del'){S.confirm='del';drawResult();clearTimeout(confT);confT=setTimeout(()=>{if(S.confirm==='del'){S.confirm=null;drawResult()}},4000);return}
  clearTimeout(confT);S.confirm=null;S.busy=true;
  try{
    const cur=REC.get(rec.id)||rec;
    if(cur.dep||cur.returned)throw {code:'local',message:'Pemakaian yang sudah berangkat tidak bisa dibatalkan.'};
    await db.doc('pakai/'+rec.id).delete();REC.delete(rec.id);
    try{if(ME.id)db.collection('log').add({nomor:rec.sppd,aksi:'pakai_hapus',by:ME.id,at:new Date().toISOString()})}catch(e){}
    S.busy=false;S.car='';render();
  }catch(e){S.busy=false;drawResult();say('actMsg',e&&e.code==='local'?e.message:'Gagal membatalkan: '+((e&&e.message)||'coba lagi'),true)}
}

/* ---------- unduh dokumen ---------- */
async function savePdf(kind){
  const {rec,t,c}=view();if(!t||!c||S.busy)return;
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){say('dlMsg','Penyimpanan file tidak tersedia di tampilan ini.',true);return}
  if(!window.html2canvas||!window.jspdf){say('dlMsg','Pustaka PDF belum termuat. Muat ulang halaman atau pakai Cetak keduanya.',true);return}
  S.busy=true;$('dlForm').disabled=true;$('dlCk').disabled=true;say('dlMsg','Menyiapkan PDF …');
  const host=window.document.createElement('div');host.style.cssText='position:fixed;left:-9999px;top:0;width:813px;background:#fff';
  host.innerHTML='<style>'+paperCss()+'</style>'+(kind==='form'?formHTML(t,c,rec):checklistHTML(t,c));
  (window.__realDoc||window.document).body.appendChild(host);
  try{
    await Promise.all([...host.querySelectorAll('img')].map(i=>i.decode?i.decode().catch(()=>{}):0));
    const {jsPDF}=window.jspdf,doc=new jsPDF({unit:'pt',format:[609.45,935.43]});
    const pw=doc.internal.pageSize.getWidth(),ph=doc.internal.pageSize.getHeight();
    const el=host.querySelector('.paper');
    const cv=await window.html2canvas(el,{scale:2,backgroundColor:'#ffffff'});
    let w=pw,h=cv.height*w/cv.width;if(h>ph){h=ph;w=cv.width*h/cv.height}
    doc.addImage(cv.toDataURL('image/jpeg',.92),'JPEG',(pw-w)/2,0,w,h);
    const fn=kind==='form'?`Form Pemakaian ${safeName(t.sppd)}.pdf`:`Checklist Pemeriksaan ${safeName(c.nopol)} ${safeName(t.sppd)}.pdf`;
    await dl.save({filename:fn,data:doc.output('blob')});
    say('dlMsg',kind==='form'?'Form pemakaian siap disimpan.':'Checklist pemeriksaan siap disimpan.');
  }catch(e){say('dlMsg',(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'PDF gagal dibuat ('+((e&&e.code)||(e&&e.message)||'error')+').',true)}
  finally{host.remove();S.busy=false;if($('dlForm')){$('dlForm').disabled=false;$('dlCk').disabled=false}}
}
async function saveHtml(){
  const {rec,t,c}=view();if(!t||!c)return;
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){say('dlMsg','Penyimpanan file tidak tersedia di tampilan ini.',true);return}
  const html='<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Form Pemakaian '+esc(t.sppd)+'</title><style>@page{size:215mm 330mm;margin:0}body{margin:0;background:#fff;--paper:#fff;--ink:#0b0b0b}'+paperCss()+'.paper{margin:0 auto}.paper.ck{height:1247px}</style></head><body>'+formHTML(t,c,rec)+checklistHTML(t,c)+'<script>addEventListener("load",function(){setTimeout(function(){print()},500)})<\/script></body></html>';
  try{await dl.save({filename:'Form Pemakaian '+safeName(t.sppd)+'.html',data:new Blob([html],{type:'text/html'})});say('dlMsg','File siap disimpan. Buka file itu dan dialog cetak akan muncul sendiri.')}
  catch(e){say('dlMsg',(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'Gagal menyiapkan file ('+((e&&e.code)||'error')+').',true)}
}

/* ---------- upload ke Google Drive: form berangkat dan form pulang ---------- */
const b64=d=>d.slice(d.indexOf(',')+1);
const payOf=x=>{let v=x&&x.payload;if(!v){try{v=JSON.parse(x.content[0].text)}catch(e){}}return v||{}};
/* server menyimpan ke subfolder area di Drive (membuat bila belum ada), mengubah JPEG menjadi PDF, dan membuang berkas lama area yang sama */
async function driveUp(rec,jenis,p,old){
  const up=payOf(await mcp.callTool(DRIVE,'create_file',{code:rec.kode,jenis,base64Content:b64(p.dataUrl),oldId:old&&old.id||''},{cache:false}));
  if(!up.id)throw {code:'local',message:'Google Drive tidak mengembalikan ID file.'};
  return {id:up.id,url:up.viewUrl||`https://drive.google.com/file/d/${up.id}/view?usp=drivesdk`,title:up.title,folder:up.folder};
}
function shrinkImg(file,max){
  return new Promise((res,rej)=>{
    const u=URL.createObjectURL(file),im=new Image();
    im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('Berkas ini bukan gambar yang bisa dibaca.'))};
    im.onload=()=>{
      URL.revokeObjectURL(u);
      let side=1500,q=.82;
      for(let i=0;i<10;i++){
        const k=Math.min(1,side/Math.max(im.width,im.height)),c=window.document.createElement('canvas');
        c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));
        const gx=c.getContext('2d');gx.fillStyle='#fff';gx.fillRect(0,0,c.width,c.height);gx.drawImage(im,0,0,c.width,c.height);
        const d=c.toDataURL('image/jpeg',q);
        if(d.length<=max)return res(d);
        if(q>.5)q-=.1;else side=Math.round(side*.8);
      }
      rej(new Error('Foto terlalu besar. Coba foto dengan resolusi lebih kecil.'));
    };
    im.src=u;
  });
}
/* JPG atau PDF menjadi paket siap unggah */
async function prepFile(f,say2){
  const isPdf=f.type==='application/pdf'||/\.pdf$/i.test(f.name),isImg=/^image\//.test(f.type)||/\.(jpe?g|png|webp)$/i.test(f.name);
  if(!isPdf&&!isImg)throw new Error('Format harus foto (JPG) atau PDF.');
  if(isPdf){
    const d=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('PDF tidak terbaca.'));fr.readAsDataURL(f)});
    if(atob(d.slice(d.indexOf(',')+1,d.indexOf(',')+9)).slice(0,4)!=='%PDF')throw new Error('Berkas ini bukan PDF yang valid.');
    if(f.size>PDF_MAX)throw new Error('PDF terlalu besar ('+Math.round(f.size/1024/1024*10)/10+' MB, maksimal 4 MB). Kecilkan PDF atau unggah foto JPG.');
    return {dataUrl:d,ext:'pdf',mime:'application/pdf'};
  }
  return {dataUrl:await shrinkImg(f,FOTO_MAX),ext:'jpg',mime:'image/jpeg'};
}
const UP={
  ber:{box:'berSec',title:'Form keberangkatan (checklist pemeriksaan)',jenis:'PAKAI_BERANGKAT',idK:'berId',folK:'berFolder',urlK:'berUrl',nmK:'berName',atK:'berAt',byK:'berBy',
    show:r=>r.ar&&r.pu,hint:'Unggah checklist pemeriksaan dan kelengkapan kendaraan yang sudah dicek sebelum berangkat. Format JPG atau PDF (maksimal 4 MB).',wait:'Form keberangkatan bisa diunggah setelah ACC Armada Pusat dan ACC Manager Armada lengkap.'},
  pul:{box:'pulSec',title:'Form kepulangan (pemeriksaan setelah kembali)',jenis:'PAKAI_PULANG',idK:'formId',folK:'formFolder',urlK:'formUrl',nmK:'formName',atK:'formAt',byK:'formBy',
    show:r=>r.dep||r.returned,hint:'Unggah foto atau PDF form pemeriksaan setelah unit kembali. Setelah tersimpan, status berubah menjadi Telah kembali.',wait:'Form kepulangan bisa diunggah setelah unit diberangkatkan.'}
};
function drawUpload(rec,kind){
  const u=UP[kind],box=$(u.box);if(!box)return;
  const fmt=iso=>{const d=isoD(iso);return d?tglS(d)+' '+jam(d):''};
  const has=!!rec[u.urlK],can=canAC(rec)&&!!db&&u.show(rec);
  const head=`<span class="lbl">${esc(u.title)}</span><div style="margin:6px 0">${has?'<span class="pill p-go">Sudah diunggah</span>':'<span class="pill p-na">Belum diunggah</span>'}${has&&rec[u.atK]?` <span class="hint">${esc(fmt(rec[u.atK]))}${rec[u.byK]?' · '+esc(rec[u.byK]):''}</span>`:''}</div>`;
  const ln=has?`<div class="hint" style="margin:6px 0">Berkas di Drive: <a href="${esc(rec[u.urlK])}" target="_blank" rel="noopener">${esc(rec[u.nmK]||'buka di Drive')}</a></div>`:'';
  if(!u.show(rec)){box.innerHTML=`<div>${head}${ln}<p class="hint">${esc(u.wait)}</p></div>`;return}
  if(!can){box.innerHTML=`<div>${head}${ln}</div>`;return}
  box.innerHTML=`<div>${head}${ln}<p class="hint">${esc(u.hint)}</p>
    <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${has?'Ganti berkas':'Pilih foto atau PDF'}<input id="${kind}File" type="file" accept="image/*,.pdf,application/pdf" hidden></label><button class="btn" id="${kind}Save" type="button" disabled>${kind==='pul'?'Simpan dan tandai kembali':'Simpan ke Drive'}</button></div>
    <div class="msg" id="${kind}Msg" role="status"></div></div>`;
  const m=(t,err)=>say(kind+'Msg',t,err);
  let pack=null;
  $(kind+'File').onchange=async ev=>{
    const f=ev.target.files&&ev.target.files[0];pack=null;$(kind+'Save').disabled=true;if(!f)return;
    m('Memproses berkas …');
    try{pack=await prepFile(f,m);$(kind+'Save').disabled=false;m('Berkas siap: '+f.name+(pack.cut?' (10 halaman pertama)':'')+'. Tekan tombol di sebelahnya untuk menyimpan.')}
    catch(e){pack=null;m(e.message||'Berkas gagal diproses.',true)}
  };
  $(kind+'Save').onclick=async()=>{
    if(!pack)return;
    $(kind+'Save').disabled=true;m('Mengunggah ke Google Drive …');
    try{
      const cur=REC.get(rec.id)||rec;
      const d0=await driveUp(cur,u.jenis,pack,cur[u.idK]?{id:cur[u.idK],folder:cur[u.folK]}:null);
      const now=new Date().toISOString();
      const ch={[u.idK]:d0.id,[u.folK]:d0.folder,[u.urlK]:d0.url,[u.nmK]:d0.title,[u.atK]:now,[u.byK]:actor()};
      if(kind==='pul'){ch.returned=true;ch.retAt=now;ch.retBy=actor()}
      await patch(cur,ch,'pakai_upload_'+(kind==='ber'?'berangkat':'pulang'));
      try{await mcp.invalidate()}catch(e){}
      render();
      say(kind+'Msg',kind==='pul'?'Form kepulangan tersimpan. Status: Telah kembali.':'Form keberangkatan tersimpan di Google Drive.');
    }catch(e){m(e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':e&&e.code==='local'?e.message:errText(e,'Google Drive')+' Tidak ada yang diubah.',true);$(kind+'Save').disabled=false}
  };
}

/* ---------- daftar: dalam proses dan riwayat ---------- */
function listRows(kind){
  const q=(kind==='proc'?S.pq:S.hq).trim().toLowerCase();
  let a=recs().filter(r=>kind==='proc'?(!r.dep&&!r.returned):(r.dep||r.returned));
  if(kind==='hist'){
    if(S.hst==='GO')a=a.filter(r=>r.dep&&!r.returned);
    if(S.hst==='BACK')a=a.filter(r=>r.returned);
  }
  if(q)a=a.filter(r=>(r.sppd+' '+r.nopol+' '+(r.area||'')+' '+(r.nama||[]).map(n=>n.name+' '+n.nib).join(' ')+' '+(r.agenda||'')).toLowerCase().includes(q));
  const key=kind==='proc'?'createdAt':'depAt';
  return a.sort((x,y)=>String(y[key]||'').localeCompare(String(x[key]||''))||y.sppd.localeCompare(x.sppd));
}
function drawListTab(kind){
  const rows=listRows(kind),cnt=$(kind==='proc'?'pCount':'hCount'),tb=$(kind==='proc'?'pTbl':'hTbl');
  cnt.textContent=`${fmtN(rows.length)} pemakaian · klik baris untuk membuka detail`;
  if(!rows.length){tb.innerHTML=`<div class="empty">${kind==='proc'?'Tidak ada pemakaian yang sedang diproses.':'Belum ada pemakaian yang diberangkatkan.'}</div>`;return}
  const fmt=iso=>{const d=isoD(iso);return d?tglS(d)+' '+jam(d):'–'};
  tb.innerHTML=`<table><thead><tr><th>${kind==='proc'?'Diajukan':'Berangkat'}</th><th>No. SPPD</th><th>Karyawan</th><th>Mobil</th><th>Area</th><th>Status</th><th>Berkas</th></tr></thead><tbody>${rows.slice(0,300).map(r=>{
    const s=stat(r);
    return `<tr tabindex="0" data-id="${esc(r.id)}"><td class="num">${esc(fmt(kind==='proc'?r.createdAt:r.depAt))}</td><td><b class="num">${esc(r.sppd)}</b><small>${esc(r.agenda||'')}</small></td><td>${(r.nama||[]).map(n=>esc(n.name||('NIB '+n.nib))).join('<br>')}</td><td><b>${esc(r.nopol)}</b><small>${esc([r.jenis,r.merk].filter(Boolean).join(' '))}</small></td><td>${esc(r.area||r.kode||'')}</td><td><span class="pill p-${s.k}">${esc(s.t)}</span></td><td>${r.berUrl?`<a href="${esc(r.berUrl)}" target="_blank" rel="noopener">Berangkat</a>`:''}${r.berUrl&&r.formUrl?' · ':''}${r.formUrl?`<a href="${esc(r.formUrl)}" target="_blank" rel="noopener">Pulang</a>`:''}${!r.berUrl&&!r.formUrl?'<span class="hint">belum ada</span>':''}</td></tr>`}).join('')}</tbody></table>`;
}
function drawTab(){
  for(const k of ['pick','proc','hist'])$('tab-'+k).setAttribute('aria-selected',S.tab===k);
  $('vPick').hidden=S.tab!=='pick';$('vProc').hidden=S.tab!=='proc';$('vHist').hidden=S.tab!=='hist';
  if(S.tab==='proc')drawListTab('proc');
  if(S.tab==='hist')drawListTab('hist');
}
function openRec(id){
  const r=REC.get(id);if(!r)return;
  S.sppd=r.sppd;S.car=r.nopol;S.tab='pick';S.confirm=null;render();
  try{window.scrollTo(0,0)}catch(e){}
}

/* ---------- interaksi ---------- */
function setOpen(v){S.open=v;drawTrigger();if(v){const q=$('spQ');setTimeout(()=>q&&q.focus(),0)}}
$('spBtn').onclick=()=>setOpen(!S.open);
$('spQ').oninput=e=>{S.q=e.target.value;drawList()};
$('spList').addEventListener('click',e=>{
  const b=e.target.closest('[data-s]');if(!b)return;
  S.sppd=b.dataset.s;const rc=recOf();S.car=rc?rc.nopol:'';S.open=false;S.confirm=null;render();
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&S.open){setOpen(false);$('spBtn').focus()}});
document.addEventListener('click',e=>{if(S.open&&!e.target.closest('.spwrap'))setOpen(false)});
$('carSel').onchange=e=>{S.car=e.target.value;drawResult()};
for(const k of ['pick','proc','hist'])$('tab-'+k).onclick=()=>{S.tab=k;S.confirm=null;drawTab()};
$('pQ').oninput=e=>{S.pq=e.target.value;drawListTab('proc')};
$('hQ').oninput=e=>{S.hq=e.target.value;drawListTab('hist')};
$('hSt').onchange=e=>{S.hst=e.target.value;drawListTab('hist')};
$('pTbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-id]');if(tr&&!e.target.closest('a'))openRec(tr.dataset.id)});
$('hTbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-id]');if(tr&&!e.target.closest('a'))openRec(tr.dataset.id)});
$('pTbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-id]');if(tr)openRec(tr.dataset.id)}});
$('hTbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-id]');if(tr)openRec(tr.dataset.id)}});
/* muat ulang: pilihan SPPD, mobil, dan pencarian ikut dikosongkan */
$('reload').onclick=async()=>{
  $('reload').disabled=true;
  S.sppd=null;S.car='';S.q='';S.open=false;S.confirm=null;S.pq='';S.hq='';S.hst='ALL';
  $('spQ').value='';$('pQ').value='';$('hQ').value='';$('hSt').value='ALL';
  try{await mcp.invalidate()}catch(e){}
  try{await loadData(render);render()}finally{$('reload').disabled=false}
};
;(function(){const t=$('themeBtn');if(t)t.onclick=()=>{const r=document.documentElement;r.dataset.theme=r.dataset.theme==='dark'?'light':'dark'}})();
const lg=$('logoImg');if(lg)lg.src=logoSrc();

/* ---------- boot ---------- */
async function boot(){
  gate('Memuat data pemakaian','Menyiapkan akses dan membaca spreadsheet.');
  const cl=window.claude;
  if(!cl||!cl.use){gate('Halaman belum siap','Muat ulang halaman ini lalu masuk lagi.','Coba lagi');return}
  [mcp,db,user]=await Promise.all([cl.use('mcp').catch(()=>null),cl.use('db').catch(()=>null),cl.use('user').catch(()=>null)]);
  let me={id:null,isOwner:false,canEdit:false};
  try{if(user)me=await user.me()}catch(e){}
  ME.id=me.id;ME.role=null;ME.areas=[];
  const AC=window.__acct;
  if(AC){
    ME.id=AC.user;
    if(AC.role==='admin'||AC.role==='pusat')ME.role=AC.role;
    else if(AC.role==='daerah'&&(AC.areas||[]).length){ME.role='daerah';ME.areas=AC.areas.slice()}
  }
  else if(me.isOwner||me.canEdit)ME.role='admin';
  else if(db&&me.id){
    try{const s=await db.doc('roles/'+me.id).get();if(s.exists){const x=s.data()||{};if(x.role==='pusat')ME.role='pusat';else if(Array.isArray(x.areas)&&x.areas.length){ME.role='daerah';ME.areas=x.areas}}}catch(e){}
  }
  if(!ME.role){gate('Akun ini tidak punya akses ke fitur ini','Fitur Pemakaian Unit hanya untuk akun Admin, Armada Pusat, dan Armada Daerah. Masuk dengan akun lain.');return}
  if(!mcp){gate('Koneksi ke server tidak tersedia','Muat ulang halaman ini lalu masuk lagi.','Coba lagi');return}
  if(!db){gate('Database tidak tersedia','Persetujuan dan riwayat disimpan di server. Muat ulang halaman ini lalu masuk lagi.','Coba lagi');return}
  if(!canCreate())S.tab='proc';
  let shown=false;
  const assets=loadPrivateAssets();
  try{await loadData(()=>{
    if(canCreate()&&!TRIPS.length&&!REC.size&&PROBLEMS.length){gate('Data belum bisa dibaca',PROBLEMS.join(' '),'Coba lagi');return}
    shown=true;render();
  })}catch(e){gate('Data belum bisa dibaca',errText(e),'Coba lagi');return}
  await assets;if(shown)render();/* tanda tangan dan template checklist tiba terakhir */
}
boot();
})();
