
/* ---------- Tampilan interaktif: angka berjalan, cincin, grafik, detail trip, latar jaringan ---------- */
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
const fmtN=n=>Number(n).toLocaleString('id-ID');
function anim(el,to,fmt){const from=el._v==null?0:el._v;el._v=to;cancelAnimationFrame(el._r);
  if(RM||from===to){el.textContent=fmt(to);return}
  const t0=performance.now(),D=650;
  const step=t=>{const k=Math.min(1,(t-t0)/D),e=1-Math.pow(1-k,3);el.textContent=fmt(Math.round(from+(to-from)*e));if(k<1)el._r=requestAnimationFrame(step)};
  el._r=requestAnimationFrame(step)}
const dtf=s=>s?tglf(s.slice(0,10))+' '+jamf(s):'–';
function togStatus(s){st.status=st.status===s?'ALL':s;st.page=0;render()}
const C=2*Math.PI*54;
const SEG=[['e','JAM EXPRESS','Tembus jam express','--exp'],['n','NORMAL','Normal','--nor'],['l','TERLAMBAT','Terlambat','--late']];
function renderRing(base){
  const n=base.length,c={e:0,n:0,l:0};
  base.forEach(x=>{x.status==='JAM EXPRESS'?c.e++:x.status==='NORMAL'?c.n++:c.l++});
  let cum=0;
  SEG.forEach(([k,s])=>{const len=n?c[k]/n*C:0,gap=len>6?2:0,el=$('ring-'+k);
    el.style.strokeDasharray=`${Math.max(0,len-gap)} ${C}`;el.style.strokeDashoffset=-cum;
    el.style.opacity=st.status==='ALL'||st.status===s?1:.22;cum+=len});
  anim($('ringPct'),n?Math.round((c.e+c.n)/n*100):0,v=>v+'%');
  $('legend').innerHTML=SEG.map(([k,s,l,v])=>`<button class="lg" type="button" data-s="${s}" aria-pressed="${st.status===s}"><i style="background:var(${v})"></i><span>${l}</span><b class="num">${fmtN(c[k])}</b><span class="pc num">${n?Math.round(c[k]/n*100):0}%</span></button>`).join('');
}
function renderDaily(){
  const a=rows(false,'tgl'),m={};
  a.forEach(x=>{const o=m[x.tgl]||(m[x.tgl]={e:0,n:0,l:0});x.status==='JAM EXPRESS'?o.e++:x.status==='NORMAL'?o.n++:o.l++});
  const days=Object.keys(m).sort(),mx=Math.max(1,...days.map(d=>m[d].e+m[d].n+m[d].l)),sel=$('tgl').value;
  if(!days.length){$('daily').innerHTML='<div class="empty">Tidak ada data untuk grafik ini.</div>';return}
  $('daily').innerHTML=`<div class="bars" role="group" aria-label="Trip per tanggal">${days.map(d=>{const o=m[d],t=o.e+o.n+o.l;
    return `<button class="col${d===sel?' sel':sel?' dim':''}" type="button" data-d="${d}" aria-pressed="${d===sel}" aria-label="${tglf(d)}: ${t} trip" data-tip="${tglf(d)}|${t} trip|Jam Express ${o.e}|Normal ${o.n}|Terlambat ${o.l}"><span class="stack" style="--h:${t/mx}"><i class="s-l" style="flex:${o.l}"></i><i class="s-n" style="flex:${o.n}"></i><i class="s-e" style="flex:${o.e}"></i></span><span class="dl num">${d.slice(8)}</span></button>`}).join('')}</div>`;
}
function renderRoutes(){
  const a=rows(false,'asal'),m={};
  a.forEach(x=>{const o=m[x.asal]||(m[x.asal]={k:x.asal,e:0,n:0,l:0});x.status==='JAM EXPRESS'?o.e++:x.status==='NORMAL'?o.n++:o.l++});
  const all=Object.values(m).map(o=>({...o,t:o.e+o.n+o.l})).sort((x,y)=>y.t-x.t),sel=$('asal').value;
  let list=all.slice(0,8);if(sel&&!list.some(o=>o.k===sel)){const o=all.find(o=>o.k===sel);if(o)list.push(o)}
  if(!list.length){$('routes').innerHTML='<div class="empty">Tidak ada data untuk grafik ini.</div>';return}
  const mx=list[0].t||1;
  $('routes').innerHTML=list.map(o=>`<button class="rt${o.k===sel?' sel':''}" type="button" data-a="${esc(o.k)}" aria-pressed="${o.k===sel}" data-tip="${esc(o.k)}|${o.t} trip|Jam Express ${o.e}|Normal ${o.n}|Terlambat ${o.l}"><span class="rn">${esc(o.k)}</span><span class="rbar"><span class="rfill" style="width:${o.t/mx*100}%"><i class="s-e" style="flex:${o.e}"></i><i class="s-n" style="flex:${o.n}"></i><i class="s-l" style="flex:${o.l}"></i></span></span><span class="rv num">${o.t}</span></button>`).join('')
   +(all.length>list.length?`<div class="count">+${all.length-list.length} asal lainnya, gunakan filter lanjutan</div>`:'');
}

/* tooltip dan cahaya panel */
const tip=$('tip');
function hideTip(){tip.classList.remove('on')}
function placeTip(e){const w=tip.offsetWidth,h=tip.offsetHeight;let x=e.clientX+14,y=e.clientY-h-12;if(x+w>innerWidth-8)x=e.clientX-w-14;if(y<8)y=e.clientY+18;tip.style.left=Math.max(8,x)+'px';tip.style.top=y+'px'}
document.addEventListener('pointerover',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');if(!t){hideTip();return}
  const [h,...l]=t.dataset.tip.split('|');tip.innerHTML=`<b>${esc(h)}</b>`+l.map(esc).join('<br>');tip.classList.add('on');placeTip(e)});
document.addEventListener('pointermove',e=>{if(tip.classList.contains('on'))placeTip(e);
  const p=e.target.closest&&e.target.closest('.panel');if(p){const r=p.getBoundingClientRect();p.style.setProperty('--mx',(e.clientX-r.left)+'px');p.style.setProperty('--my',(e.clientY-r.top)+'px')}});
document.addEventListener('pointerleave',hideTip);

/* detail trip */
let lastF=null,curTrip=-1;
const ymd=s=>{const p=s.slice(0,10).split('-');return Date.UTC(+p[0],+p[1]-1,+p[2])};
function renderTL(x){
  const days=x.datang&&x.bongkar?Math.round((ymd(x.bongkar)-ymd(x.datang))/864e5):null;
  const N=[['Berangkat',x.berangkat?dtf(x.berangkat):'','Tempuh '+hms(x.tempuh)],
    ['Tiba',x.datang?dtf(x.datang):'',days==null?'':days===0?'Bongkar hari yang sama':days>0?`Bongkar H+${days}`:`Bongkar ${-days} hari sebelum tiba`],
    ['Bongkar',x.bongkar?tglf(x.bongkar):'',x.langsir?'Langsir '+x.langsir:'']];
  $('tl').innerHTML=N.map(([l,v,s])=>`<div class="tn${v?'':' empty'}"><b>${l}</b><span class="v">${v?esc(v):'belum diisi'}</span><small>${esc(s)}</small></div>`).join('');
}
const persistMAN=()=>{try{localStorage.setItem('akurasi-manual',JSON.stringify(MAN))}catch(e){}};
function saveTrip(){const x=DATA[curTrip];if(!x||ROLE!=='admin')return;
  const v={berangkat:$('fBer').value,datang:$('fTiba').value,bongkar:$('fBong').value,langsir:$('fLang').value.trim()};
  Object.assign(x,v);if(S.mode==='none'){MAN[keyOf(x)]=Object.assign(MAN[keyOf(x)]||{},v);persistMAN()}else storeUpdateRow(x);renderTL(x);$('dLang').textContent=x.langsir||'–';render();$('fMsg').textContent='Tersimpan di browser ini.'}
function resetTrip(){const x=DATA[curTrip];if(!x||ROLE!=='admin')return;
  Object.assign(x,x._o);if(MAN[keyOf(x)]){for(const k of ['berangkat','datang','bongkar','langsir'])delete MAN[keyOf(x)][k]}persistMAN();if(S.mode!=='none')storeUpdateRow(x);
  $('fBer').value=x.berangkat;$('fTiba').value=x.datang;$('fBong').value=x.bongkar;$('fLang').value=x.langsir;renderTL(x);$('dLang').textContent=x.langsir||'–';render();$('fMsg').textContent='Dikembalikan ke data asli.'}
const JL=j=>j==='TITIKAN'?'Titikan':j==='LANGSUNG'?'Langsung':'–';
function jenisHTML(x){
  if(x.jenis!=='TITIKAN'&&x.jenis!=='LANGSUNG')return '';
  const to=x.jenis==='TITIKAN'?'LANGSUNG':'TITIKAN';
  return `<div class="cekmeta" style="margin-top:12px"><b>Jenis trip:</b> ${JL(x.jenis)}${x.jenisO?` · diubah ${esc(stampC(x.jenisAt))}${x.jenisBy?' oleh <b>'+esc(x.jenisBy)+'</b>':''} (data asli: ${JL(x.jenis0)})`:''}</div><div class="act"><button class="btn alt" id="jToggle" type="button">Ubah menjadi ${JL(to)}</button><span id="jMsg" class="fmsg" role="status"></span></div>`;
}
function recalcDenda(x){x.bn=isT(x)?0:x.bonus;x.dl=isT(x)?0:x.denda;x.dtk=isT(x)?x.denda:0}
let LOGM;
/* Log perubahan ke spreadsheet khusus; server yang menulis (akun layanan), bukan browser. */
async function logSheet(x,aksi,o){
  o=o||{};
  try{
    if(LOGM===undefined)LOGM=(window.claude&&claude.use?await claude.use('mcp'):null)||null;
    if(!LOGM)return false;
    const st2=x.fokus?(x.cek?'CLEAR':'PERLU KOREKSI'):'';
    await LOGM.callTool('Google Sheets','append_values',{spreadsheetId:'1d39r0zquQEgUA45ZxEbXx0uFjAmobUW4Qkimzb7qaBY',range:"'LOG PERUBAHAN'!A1",values:[[new Date().toLocaleString('id-ID'),aksi,x.struk||'',x.tgl||'',x.sopir||'',x.nopol||'',(x.asal||'')+' → '+(x.tujuan||''),LABEL[x.status]||x.status||'',o.from?JL(o.from):JL(x.jenis),o.to?JL(o.to):JL(x.jenis),st2,x.catatan||'',x.cekOleh||ACTOR||USER||'']]},{cache:false});
    return true;
  }catch(e){return false}
}
async function saveJenis(x){
  const from=x.jenis==='TITIKAN'?'TITIKAN':'LANGSUNG',to=from==='TITIKAN'?'LANGSUNG':'TITIKAN';
  $('jToggle').disabled=true;$('jMsg').textContent='Menyimpan …';
  let r;
  try{r=await window.__api.post('/api/cek',{key:keyOf(x),act:'jenis',jenis:to,note:JL(from)+' → '+JL(to)})}
  catch(err){$('jToggle').disabled=false;$('jMsg').textContent=(err&&err.message?err.message:'Gagal menyimpan')+' Tidak ada yang diubah.';return}
  CEK[r.k]={k:r.k,cek:r.cek,catatan:r.catatan,oleh:r.oleh,at:r.at,hist:r.hist,jenis:r.jenis,jenisBy:r.jenisBy,jenisAt:r.jenisAt};
  x.jenis=r.jenis||to;x.jenisO=r.jenis;x.jenisBy=r.jenisBy;x.jenisAt=r.jenisAt;x.cekOleh=r.oleh;x.cekAt=r.at;x.cekHist=r.hist;recalcDenda(x);
  const okLog=await logSheet(x,'UBAH JENIS TRIP',{from,to});
  bindCek(x);render();$('jMsg').textContent='Jenis trip diubah menjadi '+JL(to)+'.'+(okLog?'':' Log ke spreadsheet belum tercatat.');
}
function cekHTML(x){
  const admin=true,open=x.fokus&&!x.cek;
  const head=x.fokus?(x.cek?'<span class="pill p-ok">Clear</span>':'<span class="pill p-warn">Perlu koreksi</span>'):'<span class="pill p-na">Tidak ditandai koreksi</span>';
  const AL={note:'menambah/mengubah catatan',clear:'menandai clear',open:'membuka kembali',jenis:'mengubah jenis trip'};
  const meta=(x.cekAt?`<div class="cekmeta">${x.cek?'Di-clear':'Catatan terakhir'} ${esc(stampC(x.cekAt))}${x.cekOleh?' oleh <b>'+esc(x.cekOleh)+'</b>':''}</div>`:'')+((x.cekHist||[]).length?`<details class="cekmeta"><summary>Riwayat perubahan (${x.cekHist.length})</summary>${x.cekHist.slice(0,15).map(h=>`<div>${esc(stampC(h.at))} · <b>${esc(h.by)}</b> ${esc(AL[h.act]||h.act)}${h.note?': '+esc(h.note.length>90?h.note.slice(0,90)+'…':h.note):''}</div>`).join('')}</details>`:'');
  if(!admin)return `<span class="lbl">Koreksi dan catatan</span><div>${head}</div><div>${x.catatan?esc(x.catatan).replace(/\n/g,'<br>'):'<span class="muted">Belum ada catatan.</span>'}</div>${meta}`;
  return `<span class="lbl">Koreksi dan catatan</span><div>${head}</div>
  <label for="fCat" class="cekmeta">Keterangan hasil pengecekan</label><textarea id="fCat" maxlength="1000" placeholder="mis. Jam tiba salah input, sudah dicek ke driver dan diperbaiki">${esc(x.catatan)}</textarea>
  <div class="act"><button class="btn alt" id="cSave" type="button">Simpan catatan</button>${x.fokus?(x.cek?'<button class="btn alt" id="cOpen" type="button">Buka kembali</button>':'<button class="btn" id="cClear" type="button">Tandai clear</button>'):''}<span id="cMsg" class="fmsg" role="status"></span></div>${meta}
  ${open?'<div class="cekmeta">Isi keterangan dulu, lalu tandai clear.</div>':''}${jenisHTML(x)}`;
}
async function saveCek(x,mode){
  const cat=($('fCat').value||'').trim();
  if(mode==='clear'&&!cat){$('cMsg').textContent='Isi keterangan sebelum menandai clear.';$('fCat').focus();return}
  const btns=[...$('cekBox').querySelectorAll('button')];btns.forEach(b=>b.disabled=true);
  $('cMsg').textContent='Menyimpan …';
  let r;
  try{r=await window.__api.post('/api/cek',{key:keyOf(x),act:mode,note:cat})}
  catch(err){btns.forEach(b=>b.disabled=false);$('cMsg').textContent=(err&&err.message?err.message:'Gagal menyimpan')+' Tidak ada yang diubah.';return}
  /* Server yang menentukan nama pelaku dan waktu, dari akun yang sedang login. */
  CEK[r.k]={k:r.k,cek:r.cek,catatan:r.catatan,oleh:r.oleh,at:r.at,hist:r.hist,jenis:r.jenis,jenisBy:r.jenisBy,jenisAt:r.jenisAt};
  x.cek=r.cek;x.catatan=r.catatan;x.cekOleh=r.oleh;x.cekAt=r.at;x.cekHist=r.hist;
  const okLog=await logSheet(x,mode==='clear'?'TANDAI CLEAR':mode==='open'?'BUKA KEMBALI':'SIMPAN KETERANGAN');
  bindCek(x);render();$('cMsg').textContent=(mode==='clear'?'Ditandai clear.':mode==='open'?'Dibuka kembali.':'Catatan tersimpan.')+(okLog?'':' Log ke spreadsheet belum tercatat.');
}
function bindCek(x){
  $('cekBox').innerHTML=cekHTML(x);
  $('cSave').onclick=()=>saveCek(x,'note');
  if($('cClear'))$('cClear').onclick=()=>saveCek(x,'clear');
  if($('cOpen'))$('cOpen').onclick=()=>saveCek(x,'open');
  if($('jToggle'))$('jToggle').onclick=()=>saveJenis(x);
}
function openTrip(i,from){
  const x=DATA[i];if(!x)return;lastF=from;hideTip();
  const t=x.tempuh,sta=x.standar,ex=x.express==null?0:Math.max(0,x.express),nr=Math.min(sta,Math.max(ex,x.normal==null?sta:x.normal)),mx=Math.max(sta*1.3,t*1.08,1);
  const pe=Math.min(100,ex/mx*100),pn=Math.max(0,(nr-ex)/mx*100),ps=Math.max(0,(sta-nr)/mx*100),pl=Math.max(0,100-pe-pn-ps),pm=Math.min(98,Math.max(2,t/mx*100));
  let ver,vc='';
  if(x.status==='TERLAMBAT'){ver=`Terlambat ${hms(Math.max(0,t-sta))} dari batas standar`;vc='late'}
  else if(x.status==='JAM EXPRESS'){ver=x.express!=null?`Lebih cepat ${hms(Math.max(0,x.express-t))} dari batas express`:'Tembus jam express';vc='good'}
  else ver=t<=nr?`Dalam jam normal, sisa ${hms(Math.max(0,nr-t))} sebelum batas normal`:`Lewat jam normal ${hms(t-nr)}, masih dalam jam standar (sisa ${hms(Math.max(0,sta-t))})`;
  const row=(k,v)=>`<dt>${k}</dt><dd>${v}</dd>`;
  $('drT').textContent=x.sopir+(x.sopir2?' & '+x.sopir2:'');
  $('drS').textContent=x.struk||x.nopol;
  curTrip=i;const dis=ROLE==='admin'?'':' disabled';
  $('drB').innerHTML=`<div class="verdict"><span class="pill ${cls(x.status)}">${LABEL[x.status]}</span><div style="margin-top:8px"><b class="${vc}">${esc(ver)}</b></div>${isT(x)?'<div class="tknote">Trip titikan: ketentuan bonus dan potongan tidak berlaku.</div>':''}</div>
  <div><span class="lbl">Jejak waktu</span><div class="tl" id="tl"></div></div>
  <div><span class="lbl">Waktu tempuh terhadap batas</span><div class="zone"><i class="z-e" style="width:${pe}%"></i><i class="z-n" style="width:${pn}%"></i><i class="z-s" style="width:${ps}%"></i><i class="z-l" style="width:${pl}%"></i><span class="mk" style="left:${pm}%"><span>${hms(t)}</span></span></div>
  <div class="key"><span><i class="s-e"></i>Jam express sampai ${x.express==null?'–':hms(x.express)}</span><span><i class="s-n"></i>Jam normal sampai ${x.normal==null?'–':hms(x.normal)}</span><span><i class="s-n" style="opacity:.5"></i>Jam standar sampai ${hms(sta)}</span><span><i class="s-l"></i>Terlambat</span></div></div>
  <div class="cekbox" id="cekBox"></div>
  <form class="frm" id="frm" autocomplete="off"><span class="lbl full">${ROLE==='admin'?'Lengkapi data trip':'Data trip (hanya lihat)'}</span>
  <div class="f"><label for="fBer">Berangkat (tanggal dan jam)</label><input id="fBer" type="datetime-local" value="${esc(x.berangkat)}"${dis}></div>
  <div class="f"><label for="fTiba">Tiba (tanggal dan jam)</label><input id="fTiba" type="datetime-local" value="${esc(x.datang)}"${dis}></div>
  <div class="f"><label for="fBong">Tanggal bongkar</label><input id="fBong" type="date" value="${esc(x.bongkar)}"${dis}></div>
  <div class="f"><label for="fLang">No. surat langsir</label><input id="fLang" type="text" value="${esc(x.langsir)}"${dis} placeholder="mis. SL/10/2026/0123"></div>
  <div class="full act"${ROLE==='admin'?'':' hidden'}><button class="btn" id="fSave" type="submit">Simpan</button><button class="btn alt" id="fReset" type="button">Kembalikan</button><span id="fMsg" class="fmsg" role="status"></span></div></form>
  <dl class="dl2">${row('No. struk',esc(x.struk||'–'))}<dt>No. surat langsir</dt><dd id="dLang">${esc(x.langsir||'–')}</dd>${row('No. Polisi',esc(x.nopol)+(x.armada?' · '+esc(x.armada):''))}${row('Rute',esc(x.asal)+' → '+esc(x.tujuan))}${row('Jarak',x.jarak+' km')}${row('Waktu tempuh',hms(t))}${row('Batas jam express',x.express==null?'–':hms(x.express))}${row('Batas jam normal',x.normal==null?'–':hms(x.normal))}${row('Batas jam standar',hms(sta))}${row('Jenis trip',x.jenis==='TITIKAN'?'Titikan':x.jenis==='LANGSUNG'?'Langsung':'–')}${isT(x)?row('Bonus','Tidak berlaku (titikan)')+row('Denda langsung','Tidak berlaku (titikan)')+row('Denda titikan',(x.denda?`<span class="tk">${rp(x.denda)}</span> `:'')+'<span class="pill p-na">Tidak berlaku</span>'):row('Bonus',rp(x.bonus))+row('Denda langsung',x.denda?`<span class="late">${rp(x.denda)}</span>`:'–')+row('Denda titikan','–')}${row('Keterangan express',esc(x.ketExpress||'–'))}${row('Terlambat, driver ini',nD(x.sopir)+' kali')}${row('Terlambat, armada ini',nP(x.nopol)+' kali')}${x.fokus?row('Catatan','<span class="pill p-warn">Perlu koreksi</span>'):''}</dl>`;
  renderTL(x);bindCek(x);$('frm').onsubmit=ev=>{ev.preventDefault();saveTrip()};$('fReset').onclick=resetTrip;
  $('veil').classList.add('on');$('dr').classList.add('on');$('dr').setAttribute('aria-hidden','false');$('drX').focus();
}
function closeTrip(){if(!$('dr').classList.contains('on'))return;$('veil').classList.remove('on');$('dr').classList.remove('on');$('dr').setAttribute('aria-hidden','true');if(lastF&&document.contains(lastF))lastF.focus()}
$('drX').onclick=closeTrip;$('veil').onclick=closeTrip;
document.addEventListener('keydown',e=>{
  if(e.key==='Escape')closeTrip();
  const tg=e.target;
  if(e.key==='Enter'&&tg.matches&&tg.matches('tr.click')){e.preventDefault();tg.click()}
  if(e.key==='/'&&!/INPUT|SELECT|TEXTAREA/.test(tg.tagName||'')){e.preventDefault();$('q').focus()}
});

/* latar jaringan titik yang bereaksi pada kursor */
(function(){
  const cv=$('bg'),cx=cv.getContext('2d');if(!cx)return;
  let W=0,H=0,P=[],mx=-999,my=-999,rgb='53,214,255',f=0;
  function col(){rgb=getComputedStyle(document.documentElement).getPropertyValue('--net').trim()||rgb}
  function size(){const d=Math.min(2,devicePixelRatio||1);W=innerWidth;H=innerHeight;cv.width=W*d;cv.height=H*d;cx.setTransform(d,0,0,d,0,0);
    const n=Math.round(Math.min(90,W*H/17000));P=Array.from({length:n},()=>({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.28,vy:(Math.random()-.5)*.28}));col()}
  function draw(){
    cx.clearRect(0,0,W,H);
    for(const p of P){if(!RM){p.x+=p.vx;p.y+=p.vy}if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
      const dx=p.x-mx,dy=p.y-my,d=Math.hypot(dx,dy);if(d<150&&d>0){p.x+=dx/d*.7;p.y+=dy/d*.7}}
    for(let i=0;i<P.length;i++){const a=P[i];
      cx.fillStyle=`rgba(${rgb},.55)`;cx.beginPath();cx.arc(a.x,a.y,1.5,0,6.283);cx.fill();
      for(let j=i+1;j<P.length;j++){const b=P[j],d=Math.hypot(a.x-b.x,a.y-b.y);
        if(d<130){cx.strokeStyle=`rgba(${rgb},${(1-d/130)*.22})`;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(b.x,b.y);cx.stroke()}}
      const dm=Math.hypot(a.x-mx,a.y-my);
      if(dm<180){cx.strokeStyle=`rgba(${rgb},${(1-dm/180)*.55})`;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(mx,my);cx.stroke()}}
  }
  function loop(){if(!document.hidden){if(++f%90===0)col();draw()}requestAnimationFrame(loop)}
  addEventListener('resize',()=>{size();if(RM)draw()});
  addEventListener('pointermove',e=>{mx=e.clientX;my=e.clientY});
  size();draw();if(!RM)requestAnimationFrame(loop);
})();


/* ---------- Sambungan Google Sheets, hanya baca: manifest hanya memuat alat get_values ---------- */
const GS='Google Sheets';
function extractRows(p,d=0){
  if(d>5||p==null)return null;
  if(typeof p==='string'){try{return extractRows(JSON.parse(p),d+1)}catch(e){}
    if(typeof XLSX!=='undefined'&&p.includes('\n')){try{const wb=XLSX.read(p,{type:'string'});return XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,raw:true,defval:null})}catch(e){}}return null}
  if(Array.isArray(p)){if(p.length&&p.every(Array.isArray))return p;for(const x of p){const r=extractRows(x,d+1);if(r)return r}return null}
  if(typeof p==='object'){if(p.values){const r=extractRows(p.values,d+1);if(r)return r}for(const k of Object.keys(p)){const r=extractRows(p[k],d+1);if(r)return r}}
  return null}
const gsId=u=>{const m=String(u).match(/\/d\/([A-Za-z0-9_-]{20,})/)||String(u).trim().match(/^([A-Za-z0-9_-]{30,})$/);return m?m[1]:''};
function gsMsg(t,err){const el=$('gsMsg');el.textContent=t;el.classList.toggle('err',!!err)}
async function gsLoad(){
  if(ROLE!=='admin')return;
  const url=$('gsUrl').value.trim(),id=gsId(url),sheet=$('gsSheet').value.trim();
  if(!id){gsMsg('Link tidak dikenali. Tempel link Google Sheets, misalnya docs.google.com/spreadsheets/d/…',1);return}
  try{localStorage.setItem('akurasi-gs',JSON.stringify({url,sheet}))}catch(e){}
  const mcp=window.claude&&claude.use?await claude.use('mcp'):null;
  if(!mcp){gsMsg('Sambungan Google Sheets tidak tersedia. Pakai tombol “Buka file Excel”.',1);return}
  $('gsGo').disabled=true;gsMsg('Mengambil data dari Google Sheets …');
  try{
    let props=[];try{const d=await mcp.describeTool(GS,'get_values');props=Object.keys((d.inputSchema&&d.inputSchema.properties)||{})}catch(e){}
    const find=re=>props.find(k=>re.test(k));
    const kUrl=find(/url/i),kId=find(/spreadsheet.*id|file.*id|^id$/i)||(kUrl?null:'spreadsheetId'),kRange=find(/range/i)||'range';
    const input={};if(kId)input[kId]=id;else input[kUrl]=url;
    const rng=(sheet?`'${sheet.replace(/'/g,"''")}'!`:'')+'A1:AZ20000';input[kRange]=rng;
    const res=await mcp.callTool(GS,'get_values',input,{cache:false});
    const a=extractRows(res.payload!=null?res.payload:(res.content||[]).map(c=>c.text||'').join('\n'));
    const rows=parseRows(a);
    if(!a){gsMsg('Data diterima, tetapi bentuknya belum dikenali.',1);return}
    if(!rows){gsMsg('Baris pertama sheet harus berisi judul kolom seperti Sopir 1, Waktu Tempuh, Jam Express, Jam Standar, Status.',1);return}
    book={[GS]:rows};fileName=GS;
    $('sheetBox').hidden=true;
    await importRows(rows,GS+(sheet?' › '+sheet:''));
    gsMsg('Terakhir dimuat '+new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'})+'. Klik “Ambil data” untuk memuat ulang.');
  }catch(e){
    const c=e&&e.code,m={
      forbidden:'Akun Anda tidak boleh membaca spreadsheet ini.',
      unauthenticated:'Sesi berakhir. Masuk lagi.',
      sheets_denied:'Google menolak akses. Bagikan spreadsheet ini ke akun layanan server (email service account) sebagai Viewer.',
      sheets_not_configured:'Server belum disambungkan ke Google Sheets. Hubungi admin sistem.',
      sheets_auth_failed:'Server gagal masuk ke Google. Periksa kunci service account.',
      sheets_unavailable:'Google Sheets sedang tidak merespons. Coba lagi sebentar lagi.',
      sheets_error:'Google Sheets menolak permintaan: '+(e&&e.message||'cek link dan nama sheet.'),
      bad_request:(e&&e.message)||'Link atau nama sheet tidak valid.',
      network:'Server tidak bisa dihubungi. Periksa koneksi internet Anda.'}[c];
    gsMsg(m||'Gagal mengambil data'+(c?' ('+c+')':'')+'.',1)
  }finally{$('gsGo').disabled=false}
}
$('gsGo').onclick=gsLoad;
$('gsUrl').addEventListener('keydown',e=>{if(e.key==='Enter')gsLoad()});
try{const s=JSON.parse(localStorage.getItem('akurasi-gs')||'null');if(s){$('gsUrl').value=s.url||'';$('gsSheet').value=s.sheet||''}}catch(e){}

