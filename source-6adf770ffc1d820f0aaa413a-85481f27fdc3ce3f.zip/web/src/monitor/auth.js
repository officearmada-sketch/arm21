/* ---------- Login lewat server: sesi cookie HttpOnly, data bawaan diambil setelah masuk ---------- */
let ROLE='viewer',USER='';
const te=new TextEncoder(),b64d=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)),b64e=u=>btoa(String.fromCharCode(...u));
let ACTOR='';
const ROLENAME={admin:'Admin',pusat:'Armada Pusat',daerah:'Armada Daerah',viewer:'Hanya lihat'};
const API=window.__api;
async function enterApp(user,acct,rows,kb,areas,label){
  const role=(acct==='admin'||acct==='pusat')?'admin':'viewer';
  USER=user;ROLE=role;ACTOR=label||user;BUILTIN=rows;
  window.__acct={user,role:acct,areas:areas||[],label:label||user};
  try{await initStore(kb)}catch(e){S.mode='none'}
  document.body.classList.toggle('ro',role!=='admin');
  $('who').textContent=user+' · '+ROLENAME[acct]+(acct==='daerah'&&areas&&areas.length?' '+areas.join(', '):'');
  $('login').hidden=true;$('app').hidden=false;startApp();
  try{window.dispatchEvent(new Event('armada-login'))}catch(e){}
}
async function openSession(s){
  /* s = {user:{username,role,areas,label}, key:base64}. Data bawaan hanya dikirim ke sesi yang sah. */
  const rows=await API.get('/api/builtin');
  await enterApp(s.user.username,s.user.role,rows,b64d(s.key),s.user.areas,s.user.label);
}
function lgMsg(t,err){$('lgMsg').textContent=t;$('lgMsg').classList.toggle('err',!!err)}
$('lgLogo').src=document.querySelector('.brand .logo').src;
$('lgForm').addEventListener('submit',async ev=>{
  ev.preventDefault();
  const u=$('lgUser').value.trim(),p=$('lgPass').value;if(!u||!p)return;
  if(!(window.crypto&&crypto.subtle)){lgMsg('Halaman ini harus dibuka lewat alamat https:// agar login dan penyimpanan terenkripsi bisa jalan.',1);return}
  $('lgGo').disabled=true;lgMsg('Memeriksa …');
  try{
    const s=await API.post('/api/login',{username:u,password:p},{quiet:true});
    $('lgPass').value='';
    await openSession(s);
  }catch(e){
    $('lgPass').value='';
    const c=e&&e.code;
    if(['invalid_credentials','locked','rate_limited','network','bad_request','configuration','service_unavailable','username_used','weak_password'].includes(c))lgMsg(e.message,1);
    else{console.error(e);lgMsg('Login gagal. Muat ulang halaman lalu coba lagi.',1)}
    if(c==='invalid_credentials')$('lgPass').focus();
  }
  finally{$('lgGo').disabled=false}
});
$('lgGoogle').onclick=async()=>{
  $('lgGoogle').disabled=true;lgMsg('Menghubungkan ke Google …');
  try{await window.__googleAuth.start()}catch(e){lgMsg(e.message||'Login Google tidak tersedia.',1);$('lgGoogle').disabled=false}
};
$('logout').onclick=async()=>{await window.__googleAuth?.logout();try{await API.post('/api/logout',{},{quiet:true})}catch(e){}location.reload()};
/* Lanjutkan sesi yang masih berlaku (cookie) tanpa meminta login lagi */
(async()=>{
  if(!(window.crypto&&crypto.subtle))return;
  const google = await window.__googleAuth?.ready;
  if(google?.error)lgMsg(google.error,1);
  if(google?.linked)lgMsg('Google berhasil ditautkan.');
  if(google?.session){try{await openSession(google.session)}catch(e){lgMsg('Sesi Google terbentuk, tetapi data aplikasi gagal dimuat. Coba muat ulang.',1)}return}
  try{const s=await API.get('/api/session',{quiet:true});await openSession(s)}catch(e){/* belum login */}
})();
