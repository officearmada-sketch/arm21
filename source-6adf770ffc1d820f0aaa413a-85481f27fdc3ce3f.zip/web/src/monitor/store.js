
/* ---------- Penyimpanan data harian: gabung dengan data lama, simpan terenkripsi ---------- */
const FIELDS=['struk','sopir','sopir2','nopol','armada','asal','tujuan','tempuh','jarak','express','normal','standar','bonus','denda','ketExpress','jenis','status','fokus','tgl','datang','berangkat','bongkar','langsir','cek','catatan','cekOleh','cekAt'];
const NUMF=['tempuh','jarak','standar','bonus','denda'],NULLN=['express','normal'],KEEPF=['datang','berangkat','bongkar','langsir','cek','catatan','cekOleh','cekAt'];
const S={mode:'none',rows:null,days:{},log:[],db:null,key:null};
const b64s=u=>{let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
function cleanRow(r){const o={};for(const k of FIELDS){const v=r[k];o[k]=NULLN.includes(k)?(v==null?null:v):NUMF.includes(k)?(typeof v==='number'?v:0):(v==null?'':String(v))}return o}
function rkey(r){return r.struk||[r.sopir,r.nopol,r.asal,r.tgl,r.tempuh].join('|')}
const rcmp=(a,b)=>(a.tgl+rkey(a)).localeCompare(b.tgl+rkey(b));
function mergeRows(base,incoming){
  const map=new Map(base.map(r=>[rkey(r),r]));let added=0,updated=0,same=0;const fc={};
  for(const raw of incoming){
    const n=cleanRow(raw),k=rkey(n),ex=map.get(k);
    if(!ex){map.set(k,n);added++;continue}
    const m={...n};for(const f of KEEPF)if(!m[f]&&ex[f])m[f]=ex[f];
    const ch=FIELDS.filter(f=>m[f]!==ex[f]);
    if(ch.length){updated++;ch.forEach(f=>{fc[f]=(fc[f]||0)+1});map.set(k,m)}else same++;
  }
  return {rows:[...map.values()].sort(rcmp),added,updated,same,fc};
}
function groupDays(rows){const g={};rows.forEach(r=>{(g[r.tgl]||(g[r.tgl]=[])).push(r)});const o={};for(const d of Object.keys(g))o[d]=JSON.stringify(g[d]);return o}
async function gz(str){return new Uint8Array(await new Response(new Blob([te.encode(str)]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer())}
async function gunz(u8){return new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).text()}
async function sealStr(str){const iv=crypto.getRandomValues(new Uint8Array(12));const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},S.key,await gz(str)));return {iv:b64s(iv),ct:b64s(ct)}}
async function openStr(o){return gunz(new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:b64d(o.iv)},S.key,b64d(o.ct))))}
const stamp=iso=>new Date(iso||Date.now()).toLocaleString('id-ID',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});

async function loadDb(){
  const snap=await S.db.collection('trips').limit(1000).get(),all=[];
  for(const d of snap.docs){const o=d.data();if(!o||!o.ct)continue;const rows=JSON.parse(await openStr(o));S.days[d.id]=JSON.stringify(rows);all.push(...rows)}
  S.rows=all.length?all.sort(rcmp):null;
  try{const l=await S.db.collection('imports').orderBy('at','desc').limit(8).get();S.log=l.docs.map(x=>x.data())}catch(e){}
}
async function loadCek(){
  /* Catatan koreksi disimpan server (bukan terenkripsi di browser); pelaku dicatat server dari sesi login. */
  try{const r=await window.__api.get('/api/cek');
    for(const v of r.items||[])if(v&&v.k)CEK[v.k]=v}catch(e){}
}
async function loadLocal(){
  try{
    const raw=localStorage.getItem('akurasi-store');S.mode='local';
    if(raw){const rows=JSON.parse(await openStr(JSON.parse(raw)));S.rows=rows.sort(rcmp);S.days=groupDays(S.rows)}
    S.log=JSON.parse(localStorage.getItem('akurasi-imports')||'[]');
  }catch(e){if(S.mode!=='local')S.mode='none'}
}
async function initStore(kb){
  S.key=await crypto.subtle.importKey('raw',kb,'AES-GCM',false,['encrypt','decrypt']);
  let dbh=null;try{dbh=window.claude&&claude.use?await claude.use('db'):null}catch(e){}
  if(dbh){S.db=dbh;S.mode='db';try{await loadDb();await loadCek()}catch(e){S.db=null;S.mode='none';S.rows=null;S.days={};await loadLocal()}}
  else await loadLocal();
}
async function persistAll(rows){
  const nd=groupDays(rows),changed=Object.keys(nd).filter(d=>S.days[d]!==nd[d]),removed=Object.keys(S.days).filter(d=>!(d in nd));
  if(S.mode==='db'){
    let i=0;
    for(const d of changed){msgSave(`Menyimpan ${++i}/${changed.length} hari …`);await S.db.doc('trips/'+d).set({...await sealStr(nd[d]),n:JSON.parse(nd[d]).length,u:new Date().toISOString()});S.days[d]=nd[d]}
    for(const d of removed){await S.db.doc('trips/'+d).delete();delete S.days[d]}
  }else if(S.mode==='local'){
    localStorage.setItem('akurasi-store',JSON.stringify(await sealStr(JSON.stringify(rows))));S.days=nd;
  }
  S.rows=rows;
}
function msgSave(t){const el=$('storeNote');if(el)el.textContent=t}
async function addLog(e){
  S.log.unshift(e);S.log=S.log.slice(0,8);
  if(S.mode==='db')await S.db.collection('imports').add(e);
  else if(S.mode==='local')localStorage.setItem('akurasi-imports',JSON.stringify(S.log));
}
const where=()=>S.mode==='db'?'Tersimpan di server, dipakai bersama oleh semua pengguna.':S.mode==='local'?'Tersimpan di browser ini saja.':'Penyimpanan tidak tersedia, data hanya berlaku selama sesi ini.';
function renderStoreInfo(){
  const n=$('storeNote');if(!n)return;
  n.textContent=where()+(S.rows?'':' Belum ada pembaruan tersimpan, memakai data bawaan.');
  $('hist').innerHTML=S.log.map(l=>`<li><b class="num">${esc(stamp(l.at))}</b><span>${esc(l.source||'')}</span><span class="num">+${l.added} baru · ${l.updated} diperbarui · ${l.same} sama · total ${l.total}</span>${l.fields?`<span class="num">${esc(l.fields)}</span>`:''}</li>`).join('')||'<li>Belum ada riwayat pembaruan.</li>';
}
const storeLabel=()=>'Data tersimpan'+(S.log[0]?' · diperbarui '+stamp(S.log[0].at):'');
async function importRows(incoming,label){
  if(ROLE!=='admin')return;
  const base=S.rows||BUILTIN.map(cleanRow),res=mergeRows(base,incoming);
  const fcs=Object.entries(res.fc).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=>k+' '+v).join(', ');
  let note='';
  try{
    await persistAll(res.rows);
    await addLog({at:new Date().toISOString(),source:label,by:USER,added:res.added,updated:res.updated,same:res.same,total:res.rows.length,fields:fcs?'Kolom berubah: '+fcs:''});
    note=where();
  }catch(e){
    S.rows=res.rows;
    note='Gagal menyimpan ('+(e&&e.code||'error')+'), data hanya tampil di sesi ini.';
  }
  setData(res.rows.map(r=>({...r})),storeLabel());
  msg(`<b>${esc(label)}</b>+${res.added} baru · ${res.updated} diperbarui · ${res.same} tidak berubah · total ${res.rows.length.toLocaleString('id-ID')}. ${esc(note)}`);
  $('builtin').hidden=false;renderStoreInfo();
}
async function storeUpdateRow(x){
  if(S.mode==='none')return;
  const base=S.rows||BUILTIN.map(cleanRow),n=cleanRow(x),k=rkey(n);
  try{await persistAll(base.filter(r=>rkey(r)!==k).concat([n]).sort(rcmp));if($('fMsg'))$('fMsg').textContent=(S.mode==='db'?'Tersimpan di server.':'Tersimpan di browser ini.')}
  catch(e){if($('fMsg'))$('fMsg').textContent='Gagal menyimpan ('+(e&&e.code||'error')+').'}
}
async function clearStore(){
  try{if(S.mode==='db'){for(const d of Object.keys(S.days))await S.db.doc('trips/'+d).delete()}else if(S.mode==='local')localStorage.removeItem('akurasi-store')}catch(e){}
  S.rows=null;S.days={};
}
let rstT=0;
$('builtin').onclick=async()=>{
  if(ROLE!=='admin')return;
  if(!rstT){$('builtin').textContent='Klik lagi untuk menghapus data tersimpan';rstT=setTimeout(()=>{rstT=0;$('builtin').textContent='Pakai data bawaan'},5000);return}
  clearTimeout(rstT);rstT=0;$('builtin').textContent='Pakai data bawaan';
  await clearStore();book=null;$('sheetBox').hidden=true;$('builtin').hidden=true;
  setData(BUILTIN.map(r=>({...r})),BUILTIN_LABEL);
  msg('<b>Data bawaan</b>Data tersimpan sudah dihapus. Unggah file rekap untuk mulai lagi.');renderStoreInfo();
};

async function startApp(){
  const has=!!S.rows;
  setData((S.rows||BUILTIN).map(r=>({...r})),has?storeLabel():BUILTIN_LABEL);
  $('builtin').hidden=!(has&&ROLE==='admin');
  renderStoreInfo();
  msg('<b>'+(has?'Data tersimpan':'Data bawaan')+'</b>'+(ROLE==='admin'?'Unggah file Excel atau ambil dari Google Sheets setiap hari. Trip dengan No. Struk yang sama disesuaikan, yang baru ditambahkan.':'Hanya lihat. Data diperbarui oleh admin.'));
}

