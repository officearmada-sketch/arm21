let DATA=BUILTIN,TODAY='';
const CEK={};let MAN={};try{MAN=JSON.parse(localStorage.getItem('akurasi-manual')||'{}')||{}}catch(e){MAN={}}
const isT=x=>x.jenis==='TITIKAN';
const keyOf=r=>r.struk||[r.sopir,r.nopol,r.datang].join('|');
const $=id=>document.getElementById(id);
const rp=n=>n?'Rp '+n.toLocaleString('id-ID'):'–';
const hms=s=>{if(s==null)return '–';const neg=s<0;s=Math.abs(s);const h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return (neg?'−':'')+String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(x).padStart(2,'0')};
const tglf=t=>{const [y,m,d]=t.split('-');return d+'/'+m+'/'+y};
const jamf=s=>s?s.slice(11,16):'–';
const LABEL={'JAM EXPRESS':'Jam Express','NORMAL':'Normal','TERLAMBAT':'Terlambat'};
const cls=s=>s==='JAM EXPRESS'?'p-JAM':'p-'+s;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
// jumlah terlambat dihitung dari seluruh data, per driver dan per No. Polisi
let lateD={},lateP={};
const nD=n=>lateD[n]||0,nP=n=>lateP[n]||0;
const st={status:'ALL',tab:'driver',sort:{driver:['telat',-1],nopol:['telat',-1],trip:['tgl',-1],catatan:['tgl',-1]},cf:'ALL',page:0,sopir:null,nopol:null};
const uniq=k=>[...new Set(DATA.map(r=>r[k]))].filter(Boolean).sort();
function fill(id,label,vals,fmt){$(id).innerHTML='<option value="">'+label+'</option>'+vals.map(v=>`<option value="${esc(v)}">${esc(fmt?fmt(v):v)}</option>`).join('')}
function setData(rows,label){
  DATA=rows;lateD={};lateP={};DATA.forEach((r,i)=>{r._i=i;{const c0=CEK[keyOf(r)];if(r.jenis0===undefined)r.jenis0=r.jenis;if(c0&&c0.jenis){r.jenis=c0.jenis;r.jenisO=c0.jenis;r.jenisBy=c0.jenisBy||'';r.jenisAt=c0.jenisAt||''}else{r.jenis=r.jenis0;r.jenisO=''}}r.bn=isT(r)?0:r.bonus;r.dl=isT(r)?0:r.denda;r.dtk=isT(r)?r.denda:0;r.berangkat=r.berangkat||'';r.datang=r.datang||'';r.bongkar=r.bongkar||'';r.langsir=r.langsir||'';r.cek=r.cek||'';r.catatan=r.catatan||'';r.cekOleh=r.cekOleh||'';r.cekAt=r.cekAt||'';if(!r._o)r._o={berangkat:r.berangkat,datang:r.datang,bongkar:r.bongkar,langsir:r.langsir};const m=MAN[keyOf(r)];if(m)Object.assign(r,m);const c=CEK[keyOf(r)];if(c){r.cek=c.cek||'';r.catatan=c.catatan||'';r.cekOleh=c.oleh||'';r.cekAt=c.at||'';r.cekHist=c.hist||[]}});
  DATA.forEach(r=>{if(r.status==='TERLAMBAT'){lateD[r.sopir]=(lateD[r.sopir]||0)+1;lateP[r.nopol]=(lateP[r.nopol]||0)+1}});
  fill('armada','Semua armada',uniq('armada'));fill('asal','Semua asal',uniq('asal'));fill('tujuan','Semua tujuan',uniq('tujuan'));fill('jenis','Semua jenis',uniq('jenis'));
  const tg=uniq('tgl');TODAY=tg.slice(-1)[0]||'';
  const real=new Date();const rs=real.getFullYear()+'-'+String(real.getMonth()+1).padStart(2,'0')+'-'+String(real.getDate()).padStart(2,'0');
  fill('tgl','Semua tanggal',tg.slice().reverse(),t=>tglf(t)+(t===rs?' (hari ini)':''));
  $('today').textContent='Tanggal terbaru';
  ['late','lateP','armada','asal','tujuan','jenis','tgl'].forEach(i=>$(i).selectedIndex=0);$('q').value='';$('koreksi').checked=false;$('besar').checked=false;
  st.status='ALL';st.sopir=null;st.nopol=null;st.page=0;
  $('periode').textContent=DATA.length?`${label} · ${DATA.length.toLocaleString('id-ID')} trip · kedatangan ${tglf(tg[0])} sampai ${tglf(TODAY)} · ${new Set(DATA.map(r=>r.sopir)).size} driver · ${new Set(DATA.map(r=>r.nopol)).size} armada`:label;
  render();
}
function ok(v,n){return v==='eq0'?n===0:!(+v)||n>=+v}
function rows(ignoreStatus,skip){
  const q=$('q').value.trim().toUpperCase();
  return DATA.filter(r=>{
    if(st.sopir&&r.sopir!==st.sopir)return false;
    if(st.nopol&&r.nopol!==st.nopol)return false;
    if(q&&!(r.sopir.includes(q)||r.nopol.includes(q)||r.struk.toUpperCase().includes(q)))return false;
    if(!ok($('late').value,nD(r.sopir)))return false;
    if(!ok($('lateP').value,nP(r.nopol)))return false;
    for(const k of ['armada','asal','tujuan','jenis','tgl'])if(k!==skip&&$(k).value&&r[k]!==$(k).value)return false;
    if($('koreksi').checked&&!(r.fokus&&!r.cek))return false;
    if($('besar').checked&&r.dl<=500000)return false;
    if(!ignoreStatus&&st.status!=='ALL'&&r.status!==st.status)return false;
    return true});
}
function sortRows(a,key,dir){return a.sort((x,y)=>{const u=x[key],v=y[key];const c=typeof u==='string'?u.localeCompare(v):(u??-1)-(v??-1);return c*dir||String(x.sopir).localeCompare(String(y.sopir))})}
function render(){
  const base=rows(true),r=rows(false);
  const cnt=s=>base.filter(x=>x.status===s).length;
  $('chips').innerHTML=[['ALL','Semua',base.length],['JAM EXPRESS','Tembus jam express',cnt('JAM EXPRESS')],['NORMAL','Normal',cnt('NORMAL')],['TERLAMBAT','Terlambat',cnt('TERLAMBAT')]]
   .map(([k,l,c])=>`<button class="chip" type="button" data-s="${k}" aria-pressed="${st.status===k}">${l}<span class="c">${c.toLocaleString('id-ID')}</span></button>`).join('');
  const sum=k=>r.reduce((a,x)=>a+x[k],0),n=r.length,cE=r.filter(x=>x.status==='JAM EXPRESS').length,cN=r.filter(x=>x.status==='NORMAL').length,cL=r.filter(x=>x.status==='TERLAMBAT').length;
  const pc=c=>n?Math.round(c/n*100)+'% dari trip':'';
  anim($('v-n'),n,fmtN);anim($('v-e'),cE,fmtN);anim($('v-o'),cN,fmtN);anim($('v-l'),cL,fmtN);anim($('v-b'),sum('bn'),rp);anim($('v-d'),sum('dl'),rp);anim($('v-dt'),sum('dtk'),rp);const cT=r.filter(isT).length;anim($('v-nt'),cT,fmtN);
  $('p-e').textContent=pc(cE);$('p-o').textContent=pc(cN);$('p-l').textContent=pc(cL);
  renderRing(base);renderDaily();renderRoutes();
  const act=['late','lateP','armada','asal','tujuan','jenis'].filter(i=>$(i).selectedIndex>0).length+($('koreksi').checked?1:0)+($('besar').checked?1:0);
  $('advN').hidden=!act;$('advN').textContent=act;
  for(const t of ['driver','nopol','trip','catatan'])$('t-'+t).setAttribute('aria-selected',st.tab===t);
  const nOpen=r.filter(x=>x.fokus&&!x.cek).length;$('t-catatan').innerHTML='Catatan'+(nOpen?` <span class="tcnt">${fmtN(nOpen)}</span>`:'');
  st.tab==='trip'?renderTrip(r):st.tab==='catatan'?renderCatatan(r):renderGroup(r,st.tab);
}
function th(tab,key,label,right){const[s,d]=st.sort[tab];return `<th class="${right?'r':''}" data-k="${key}" aria-sort="${s===key?(d>0?'ascending':'descending'):'none'}">${label}${s===key?(d>0?' ↑':' ↓'):''}</th>`}
const PS=50;
function pager(total){const pages=Math.max(1,Math.ceil(total/PS));st.page=Math.min(st.page,pages-1);
  $('pager').hidden=pages<2;$('pager').innerHTML=`<button id="prev" type="button" ${st.page?'':'disabled'}>Sebelumnya</button><span class="num">Halaman ${st.page+1} / ${pages}</span><button id="next" type="button" ${st.page<pages-1?'':'disabled'}>Berikutnya</button>`;
  return [st.page*PS,st.page*PS+PS]}
function renderGroup(r,tab){
  const key=tab==='driver'?'sopir':'nopol',cn=tab==='driver'?nD:nP;
  const m={};r.forEach(x=>{const o=m[x[key]]||(m[x[key]]={k:x[key],sopir:x[key],trip:0,exp:0,nor:0,telat:0,bonus:0,denda:0,dt:0,info:new Set()});
    o.trip++;o.bonus+=x.bn;o.denda+=x.dl;o.dt+=x.dtk;o.info.add(tab==='driver'?x.nopol:x.sopir);if(x.status==='JAM EXPRESS')o.exp++;else if(x.status==='NORMAL')o.nor++;else o.telat++});
  const a=Object.values(m);a.forEach(o=>o.ok=(o.exp+o.nor)/o.trip);sortRows(a,...st.sort[tab]);
  $('count').textContent=`${a.length.toLocaleString('id-ID')} ${tab==='driver'?'driver':'armada'} · klik baris untuk melihat trip-nya`;
  if(!a.length){$('tbl').innerHTML='<div class="empty">Tidak ada data yang cocok dengan filter ini.</div>';$('pager').hidden=true;return}
  const [s,e]=pager(a.length),v=a.slice(s,e);
  $('tbl').innerHTML=`<table><thead><tr>${th(tab,'sopir',tab==='driver'?'Driver':'No. Polisi')}${th(tab,'trip','Trip',1)}${th(tab,'exp','Jam Express',1)}${th(tab,'nor','Normal',1)}${th(tab,'telat','Terlambat',1)}${th(tab,'bonus','Bonus',1)}${th(tab,'denda','Denda langsung',1)}${th(tab,'dt','Denda titikan',1)}${th(tab,'ok','Tepat waktu',1)}<th>${tab==='driver'?'No. Polisi':'Driver'}</th></tr></thead><tbody>${v.map(o=>{const al=cn(o.k);return `<tr class="click" tabindex="0" data-g="${esc(o.k)}"><td>${esc(o.k)}</td><td class="r num">${o.trip}</td><td class="r num ${o.exp?'good':''}">${o.exp}</td><td class="r num">${o.nor}</td><td class="r num ${o.telat?'late':''}">${o.telat}${al>1?` <span class="pill p-warn" title="Total terlambat di seluruh data">${al}× total</span>`:''}</td><td class="r num">${rp(o.bonus)}</td><td class="r num ${o.denda?'late':''}">${rp(o.denda)}</td><td class="r num ${o.dt?'tk':''}">${rp(o.dt)}${o.dt?' <span class="pill p-na">Tidak berlaku</span>':''}</td><td class="r"><span class="okc num">${Math.round(o.ok*100)}%<span class="okb"><i style="width:${o.ok*100}%"></i></span></span></td><td>${[...o.info].slice(0,2).map(esc).join(', ')}${o.info.size>2?' +'+(o.info.size-2):''}</td></tr>`}).join('')}</tbody></table>`;
}
function renderTrip(r){
  const a=sortRows(r.slice(),...st.sort.trip);
  $('count').textContent=`${a.length.toLocaleString('id-ID')} trip · klik baris untuk detail`+(st.sopir?` · driver ${st.sopir}`:'')+(st.nopol?` · ${st.nopol}`:'');
  if(!a.length){$('tbl').innerHTML='<div class="empty">Tidak ada trip yang cocok dengan filter ini.</div>';$('pager').hidden=true;return}
  const [s,e]=pager(a.length),v=a.slice(s,e);
  $('tbl').innerHTML=`<table style="min-width:1900px"><thead><tr>${th('trip','berangkat','Berangkat')}${th('trip','datang','Tiba')}${th('trip','sopir','Driver')}${th('trip','nopol','No. Polisi')}${th('trip','armada','Armada')}${th('trip','asal','Asal → Tujuan')}${th('trip','jarak','Jarak',1)}${th('trip','tempuh','Waktu tempuh',1)}${th('trip','express','Jam express',1)}${th('trip','normal','Jam normal',1)}${th('trip','standar','Jam standar',1)}${th('trip','status','Status')}${th('trip','bn','Bonus',1)}${th('trip','dl','Denda langsung',1)}${th('trip','dtk','Denda titikan',1)}${th('trip','bongkar','Tgl bongkar')}${th('trip','langsir','No. surat langsir')}<th>Jenis</th><th>Koreksi</th></tr></thead><tbody>${v.map(x=>`<tr class="click" tabindex="0" data-t="${x._i}"><td class="num">${dtf(x.berangkat)}</td><td class="num">${dtf(x.datang)}</td><td>${esc(x.sopir)}${nD(x.sopir)>1?` <span class="pill p-warn">${nD(x.sopir)}× telat</span>`:''}</td><td class="num" title="${nP(x.nopol)} kali terlambat">${esc(x.nopol)}</td><td>${esc(x.armada)}</td><td title="${esc(x.struk)}">${esc(x.asal)} → ${esc(x.tujuan.replace('PORT ',''))}</td><td class="r num">${x.jarak} km</td><td class="r num">${hms(x.tempuh)}</td><td class="r num">${hms(x.express)}</td><td class="r num">${hms(x.normal)}</td><td class="r num">${hms(x.standar)}</td><td><span class="pill ${cls(x.status)}">${LABEL[x.status]}</span></td>${isT(x)?`<td class="r"><span class="pill p-na" title="Titikan: ketentuan bonus tidak berlaku">Tidak berlaku</span></td><td class="r"><span class="pill p-na" title="Titikan: ketentuan potongan tidak berlaku">Tidak berlaku</span></td><td class="r num tk">${rp(x.denda)} <span class="pill p-na">Tidak berlaku</span></td>`:`<td class="r num">${rp(x.bonus)}</td><td class="r num ${x.denda?'late':''}">${rp(x.denda)}</td><td class="r num">–</td>`}<td class="num">${x.bongkar?tglf(x.bongkar):'–'}</td><td class="num">${esc(x.langsir||'–')}</td><td>${x.jenis==='TITIKAN'?'Titikan':x.jenis==='LANGSUNG'?'Langsung':'–'}</td><td>${cekPill(x)}</td></tr>`).join('')}</tbody></table>`;
}
const cekPill=x=>x.fokus?(x.cek?`<span class="pill p-ok" title="${esc(x.catatan)}">Clear</span>`:'<span class="pill p-warn">Perlu koreksi</span>'):(x.catatan?'<span class="pill p-na" title="'+esc(x.catatan)+'">Ada catatan</span>':'');
const stampC=iso=>{if(!iso)return '';const d=new Date(iso);return isNaN(d)?'':d.toLocaleString('id-ID',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'})};
function renderCatatan(r){
  const all=r.filter(x=>x.fokus||x.catatan),nO=all.filter(x=>x.fokus&&!x.cek).length,nC=all.filter(x=>x.fokus&&x.cek).length,nN=all.filter(x=>!x.fokus&&x.catatan).length;
  const f={ALL:all,OPEN:all.filter(x=>x.fokus&&!x.cek),CLEAR:all.filter(x=>x.fokus&&x.cek),NOTE:all.filter(x=>!x.fokus&&x.catatan)}[st.cf]||all;
  $('count').innerHTML=[['ALL','Semua',all.length],['OPEN','Belum clear',nO],['CLEAR','Clear',nC],['NOTE','Catatan saja',nN]].map(([k,l,c])=>`<button class="chip cf" type="button" data-cf="${k}" aria-pressed="${st.cf===k}">${l}<span class="c">${fmtN(c)}</span></button>`).join('')+'<span class="cfhint">klik baris untuk memeriksa dan memberi catatan</span>';
  const a=sortRows(f.slice(),...st.sort.catatan);
  if(!a.length){$('tbl').innerHTML='<div class="empty">'+(all.length?'Tidak ada trip pada kelompok ini.':'Belum ada trip yang perlu koreksi atau diberi catatan pada filter ini.')+'</div>';$('pager').hidden=true;return}
  const [s,e]=pager(a.length),v=a.slice(s,e);
  $('tbl').innerHTML=`<table style="min-width:1300px"><thead><tr>${th('catatan','tgl','Tanggal')}${th('catatan','sopir','Driver')}${th('catatan','nopol','No. Polisi')}${th('catatan','struk','No. Struk')}<th>Rute</th>${th('catatan','status','Status')}<th>Denda</th><th>Jenis</th>${th('catatan','cek','Koreksi')}<th>Catatan</th>${th('catatan','cekAt','Diperiksa')}</tr></thead><tbody>${v.map(x=>`<tr class="click" tabindex="0" data-t="${x._i}"><td class="num">${tglf(x.tgl)}</td><td>${esc(x.sopir)}</td><td class="num">${esc(x.nopol)}</td><td class="num">${esc(x.struk||'–')}</td><td>${esc(x.asal)} → ${esc(x.tujuan.replace('PORT ',''))}</td><td><span class="pill ${cls(x.status)}">${LABEL[x.status]}</span></td><td class="r num ${x.denda?(isT(x)&&x.cek?'tk':'late'):''}">${rp(x.denda)}${isT(x)&&x.cek&&x.denda?' <span class="pill p-na">Tidak berlaku</span>':''}</td><td>${JL(x.jenis)}</td><td>${cekPill(x)||'–'}</td><td class="cat">${x.catatan?esc(x.catatan):'<span class="muted">belum ada catatan</span>'}</td><td class="num">${x.cekAt?esc(stampC(x.cekAt))+(x.cekOleh?'<br><small>'+esc(x.cekOleh)+'</small>':''):'–'}</td></tr>`).join('')}</tbody></table>`;
}
document.addEventListener('click',e=>{
  const cf=e.target.closest('.cf');if(cf){st.cf=cf.dataset.cf;st.page=0;render();return}
  const c=e.target.closest('.chip');if(c){st.status=c.dataset.s;st.page=0;render();return}
  const h=e.target.closest('th[data-k]');if(h){const t=st.tab,[s,d]=st.sort[t];st.sort[t]=[h.dataset.k,s===h.dataset.k?-d:(['sopir','nopol','tgl','armada','asal','status','berangkat','datang','bongkar','langsir','struk','cek'].includes(h.dataset.k)?1:-1)];render();return}
  const rg=e.target.closest('[data-ring]');if(rg){togStatus(rg.dataset.ring);return}
  const lg=e.target.closest('.lg');if(lg){togStatus(lg.dataset.s);return}
  const dc=e.target.closest('.col[data-d]');if(dc){const same=$('tgl').value===dc.dataset.d;$('tgl').value=same?'':dc.dataset.d;st.page=0;hideTip();render();return}
  const rt=e.target.closest('.rt[data-a]');if(rt){const same=$('asal').value===rt.dataset.a;$('asal').value=same?'':rt.dataset.a;st.page=0;hideTip();render();return}
  const tr=e.target.closest('tr[data-t]');if(tr){openTrip(+tr.dataset.t,tr);return}
  const g=e.target.closest('tr[data-g]');if(g){if(st.tab==='driver'){st.sopir=g.dataset.g;st.nopol=null}else{st.nopol=g.dataset.g;st.sopir=null}st.tab='trip';st.page=0;$('q').value='';render();return}
  if(e.target.id==='prev'){st.page--;render()}if(e.target.id==='next'){st.page++;render()}
});
for(const t of ['driver','nopol','trip','catatan'])$('t-'+t).onclick=()=>{st.tab=t;st.page=0;render()};
['q','late','lateP','armada','asal','tujuan','jenis','tgl','koreksi','besar'].forEach(i=>$(i).addEventListener('input',()=>{if(i==='q'){st.sopir=null;st.nopol=null}st.page=0;render()}));
$('today').onclick=()=>{if(TODAY){$('tgl').value=TODAY;st.page=0;render()}};
$('reset').onclick=()=>{$('q').value='';['late','lateP','armada','asal','tujuan','jenis','tgl'].forEach(i=>$(i).selectedIndex=0);$('koreksi').checked=false;$('besar').checked=false;st.status='ALL';st.sopir=null;st.nopol=null;st.page=0;render()};
$('theme').onclick=()=>{const r=document.documentElement,dark=r.dataset.theme==='dark';r.dataset.theme=dark?'light':'dark'};

/* ---------- Unggah file Excel: dibaca di browser, file tidak dikirim ke mana pun ---------- */
const BUILTIN_LABEL='Data bawaan per 12 Oktober 2026';
const H={sopir:'sopir 1',nopol:'no polisi',armada:'jenis armada',asal:'asal',tujuan:'tujuan',tempuh:'waktu tempuh',jarak:'jarak',express:'jam express',normal:'jam normal',standar:'jam standar',bonus:'jumlah bonus',denda:'jumlah denda',ket:'keterangan jam express',struk:'no. struk',jenis:'keterangan',status:'status',fokus:'fokus',ked:'kedatangan',tdatang:'tanggal kedatangan',berangkat:['berangkat','tanggal berangkat','waktu berangkat','tanggal keberangkatan','waktu keberangkatan','keberangkatan'],bongkar:['tanggal bongkar','tgl bongkar','waktu bongkar','bongkar'],langsir:['no surat langsir','no. surat langsir','nomor surat langsir','no langsir','no. langsir','surat langsir']};
const pad=n=>String(n).padStart(2,'0');
function toSec(v){if(v==null||v==='')return null;if(typeof v==='number')return Math.round(v*86400);
  const m=String(v).trim().match(/^(-)?(\d+):(\d{2})(?::(\d{2}))?$/);return m?(m[1]?-1:1)*(+m[2]*3600+ +m[3]*60+(+m[4]||0)):null}
function toDt(v){if(v==null||v==='')return null;
  if(typeof v==='number')return new Date(Math.round((v-25569)*86400000));
  const m=String(v).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/);if(!m)return null;const sw=+m[1]>12;return new Date(Date.UTC(+m[3],(sw?+m[2]:+m[1])-1,sw?+m[1]:+m[2],+(m[4]||0),+(m[5]||0)))}
const iso=d=>d.getUTCFullYear()+'-'+pad(d.getUTCMonth()+1)+'-'+pad(d.getUTCDate());
const fdt=d=>d?iso(d)+'T'+pad(d.getUTCHours())+':'+pad(d.getUTCMinutes()):'';
const num=v=>{if(typeof v==='number')return v;let s=String(v||'').replace(/[^0-9.,-]/g,'');if(/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s))s=s.replace(/\./g,'').replace(',','.');else if(/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s))s=s.replace(/,/g,'');else s=s.replace(/,/g,'.');return parseFloat(s)||0};
const nm=s=>String(s==null?'':s).replace(/\s+/g,' ').trim().toUpperCase();
function parseSheet(ws){return parseRows(XLSX.utils.sheet_to_json(ws,{header:1,raw:true,defval:null}))}
function parseRows(a){
  if(!a||!a.length)return null;
  const idx={};a[0].forEach((h,i)=>{const k=String(h==null?'':h).trim().toLowerCase();if(k&&!(k in idx))idx[k]=i});
  if(!(H.sopir in idx&&H.tempuh in idx&&H.standar in idx))return null;
  const g=(r,k)=>{for(const n of [].concat(H[k]))if(n in idx)return r[idx[n]];return null};
  const out=[];
  for(let n=1;n<a.length;n++){const r=a[n];
    const tempuh=toSec(g(r,'tempuh')),exp=toSec(g(r,'express')),nor=toSec(g(r,'normal')),sta=toSec(g(r,'standar'));
    if(tempuh==null||sta==null)continue;
    let status=nm(g(r,'status'));
    if(!LABEL[status])status=tempuh>sta?'TERLAMBAT':(exp!=null&&tempuh<exp)?'JAM EXPRESS':'NORMAL';
    let fokus=g(r,'fokus');fokus=fokus?'PERLU KOREKSI':(H.fokus in idx?'':((exp!=null&&tempuh<exp-3600)||tempuh>sta+7200?'PERLU KOREKSI':''));
    const struk=String(g(r,'struk')||'');const sm=struk.match(/\/([A-Z0-9]+)\/(\d{2})(\d{2})(\d{4})\d+$/);
    const sd=sm?sm[4]+'-'+sm[3]+'-'+sm[2]:'';
    const dt=toDt(g(r,'tdatang'));let kd=toDt(g(r,'ked'))||dt;let tgl=kd?iso(kd):sd;
    if(sd&&tgl&&Math.abs(Date.parse(tgl)-Date.parse(sd))>7*864e5)tgl=sd;
    if(!tgl)continue;
    const asalRaw=nm(g(r,'asal')).replace(/^PORT /,'');
    out.push({sopir:nm(g(r,'sopir'))||'TANPA NAMA',nopol:nm(g(r,'nopol'))||'—',armada:nm(g(r,'armada')),asal:asalRaw||(sm?sm[1]:'—'),tujuan:nm(g(r,'tujuan'))||'—',
      tempuh,jarak:num(g(r,'jarak')),express:exp,normal:nor,standar:sta,bonus:num(g(r,'bonus')),denda:num(g(r,'denda')),ketExpress:nm(g(r,'ket')),struk,jenis:nm(g(r,'jenis')),
      status,fokus,tgl,datang:fdt(dt),berangkat:fdt(toDt(g(r,'berangkat'))),bongkar:(d=>d?iso(d):'')(toDt(g(r,'bongkar'))),langsir:String(g(r,'langsir')==null?'':g(r,'langsir')).trim()});
  }
  return out.length?out:null;
}
let book=null,fileName='';
function msg(html,err){$('src').innerHTML=html;$('src').classList.toggle('err',!!err)}
async function useSheet(name){importRows(book[name],`${fileName} › ${name}`)}
async function loadFile(f){
  if(!f||ROLE!=='admin')return;
  if(typeof XLSX==='undefined'){msg('Pembaca Excel belum termuat. Periksa koneksi internet lalu muat ulang halaman.',1);return}
  msg('Membaca '+esc(f.name)+' ...');
  try{
    const wb=XLSX.read(await f.arrayBuffer(),{type:'array'});
    book={};fileName=f.name;
    for(const n of wb.SheetNames){const r=parseSheet(wb.Sheets[n]);if(r)book[n]=r}
    const names=Object.keys(book);
    if(!names.length){book=null;msg('Kolom rekap tidak ditemukan. Baris pertama sheet harus berisi kolom seperti Sopir 1, Waktu Tempuh, Jam Express, Jam Standar, Status.',1);return}
    const lastDate=n=>book[n].reduce((m,r)=>r.tgl>m?r.tgl:m,'');
    names.sort((x,y)=>lastDate(y).localeCompare(lastDate(x))||book[y].length-book[x].length);
    $('sheet').innerHTML=names.map(n=>`<option value="${esc(n)}">${esc(n)} (${book[n].length})</option>`).join('');
    $('sheetBox').hidden=names.length<2;$('builtin').hidden=false;
    useSheet(names[0]);
  }catch(e){msg('File tidak bisa dibaca. Pastikan formatnya .xlsx atau .csv dari rekap akurasi.',1)}
}
$('pick').onclick=()=>$('file').click();
$('file').onchange=e=>{loadFile(e.target.files[0]);e.target.value=''};
$('sheet').onchange=e=>useSheet(e.target.value);
const drop=$('drop');
['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('drag')}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('drag')}));
drop.addEventListener('drop',e=>loadFile(e.dataTransfer.files[0]));
