# Armada Pusat (Baraka Express)

Tiga fitur dengan satu login:

- **Monitor Ketepatan Armada**: ketepatan trip, bonus/denda, koreksi dan clear, ubah jenis Titikan/Langsung, log perubahan ke spreadsheet.
- **Peminjaman Unit Operasional**: Google Form -> DATA -> spreadsheet per area -> ACC PUSAT. ACC Area, ACC Armada Pusat, ACC Manager Armada, form fisik F4 (2 halaman), pengembalian unit (form pemeriksaan, keterangan, foto unit pulang ke Drive).

- **Pemakaian Unit**: SPPD perjalanan dinas bertipe MOBIL INVENTARIS (sheet LIST PERJALANAN DINAS NEW) + mobil grup OPERASIONAL (sheet MASTER) menjadi form pemakaian dan checklist pemeriksaan (PDF). ACC area, ACC Armada Pusat, ACC Manager Armada, unggah form keberangkatan dan kepulangan ke Drive, tombol Berangkat, serta riwayat/arsip. Data pengajuan disimpan di database server (koleksi `pakai`), bukan di spreadsheet. Kolom sheet SPPD dicari dari judulnya, jadi penambahan kolom tidak merusak pembacaan agenda.

Peran: `admin`, `pusat` (termasuk manager), `daerah` (satu akun per area), `viewer`.

## Arsitektur singkat

- Server Node 22 (`node:sqlite`, tanpa dependensi npm saat berjalan). Sesi cookie `HttpOnly`, password scrypt, kunci akun setelah gagal berulang, CSRF header + cek Origin, CSP ketat.
- Google Sheets/Drive diakses SERVER lewat akun layanan (service account). Browser tidak pernah memegang kredensial Google. Tulisan dibatasi allowlist: centang ACC (R, Y), kolom pengembalian (U, X, W), baris log, dan foto JPEG ke satu folder.
- Daftar area dan ID spreadsheet dibaca langsung dari sheet **MASTER** di ACC PUSAT. Kode area dan nama lengkap area dicocokkan (JMB = JMBR).
- Data Monitor disegel di browser dengan `DATA_KEY` sebelum disimpan di database.
- Caddy untuk HTTPS otomatis, cadangan harian, CI/CD GitHub Actions.

## Mulai cepat (lokal)

```bash
node --version            # perlu >= 22.5
npm install               # hanya untuk membangun tampilan (font, xlsx, html2canvas, jspdf)
npm run build             # hasil: public/ dan private/
npm test                  # tes server
cp .env.example .env      # lalu isi; lihat docs/GOOGLE.md untuk akun layanan
npm run user -- add admin admin
node --env-file=.env --disable-warning=ExperimentalWarning server/index.js   # http://127.0.0.1:3000
```

Impor akun dari CSV (`Username,Password,Peran`): `npm run seed -- --accounts akun_baru.csv`. Setelah itu minta tiap orang mengganti password dari menu akun, dan hapus CSV-nya.

## Dokumen

- `docs/GOOGLE.md`: membuat akun layanan dan membagikan spreadsheet/folder.
- `docs/DEPLOY.md`: memasang di VPS (Docker + Caddy), DNS, CI/CD, pembaruan.
- `docs/OPERASI.md`: cadangan, pemulihan, akun, pemantauan, masalah umum.
- `docs/KEAMANAN.md`: apa yang dijaga server, batasan, daftar periksa.

## Hal yang perlu Anda kerjakan sekali (tidak bisa saya lakukan dari sini)

1. Jalankan `npm install` agar `package-lock.json` terbentuk, lalu commit berkas itu (build `--strict` di CI membutuhkannya).
2. Buat akun layanan Google dan bagikan file/folder (docs/GOOGLE.md).
3. Sewa VPS dan arahkan domain (docs/DEPLOY.md).
4. Area **SURABAYA VIA LAUT** ada di script pembuat file Anda tetapi belum ada di sheet MASTER. Tambahkan barisnya di MASTER bila memang area ke-23.
