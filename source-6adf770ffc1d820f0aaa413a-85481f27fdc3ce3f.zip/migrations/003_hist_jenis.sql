-- Riwayat koreksi boleh mencatat aksi 'jenis' (penggantian titikan/langsung). SQLite tidak bisa mengubah CHECK, jadi tabel dibangun ulang.
CREATE TABLE cek_hist_new (
  id       INTEGER PRIMARY KEY,
  key      TEXT    NOT NULL REFERENCES cek(key) ON DELETE CASCADE,
  at       INTEGER NOT NULL,
  oleh     TEXT    NOT NULL,
  oleh_user TEXT   NOT NULL,
  act      TEXT    NOT NULL CHECK (act IN ('note','clear','open','jenis')),
  note     TEXT    NOT NULL DEFAULT ''
);
INSERT INTO cek_hist_new (id, key, at, oleh, oleh_user, act, note) SELECT id, key, at, oleh, oleh_user, act, note FROM cek_hist;
DROP TABLE cek_hist;
ALTER TABLE cek_hist_new RENAME TO cek_hist;
CREATE INDEX cek_hist_key ON cek_hist(key, at DESC);
