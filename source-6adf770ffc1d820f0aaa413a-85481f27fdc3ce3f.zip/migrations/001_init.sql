-- Skema awal. Aturan penting dijaga oleh database (CHECK / UNIQUE / FK), bukan hanya oleh kode aplikasi.
CREATE TABLE users (
  id            INTEGER PRIMARY KEY,
  username      TEXT    NOT NULL UNIQUE COLLATE NOCASE CHECK (length(username) BETWEEN 3 AND 64 AND username NOT GLOB '*[^A-Za-z0-9._-]*'),
  password_hash TEXT    NOT NULL,
  role          TEXT    NOT NULL CHECK (role IN ('admin','pusat','daerah','viewer')),
  areas         TEXT    NOT NULL DEFAULT '[]' CHECK (json_valid(areas) AND json_type(areas) = 'array'),
  label         TEXT    NOT NULL DEFAULT '' CHECK (length(label) <= 80),
  disabled      INTEGER NOT NULL DEFAULT 0 CHECK (disabled IN (0,1)),
  failed_count  INTEGER NOT NULL DEFAULT 0 CHECK (failed_count >= 0),
  locked_until  INTEGER NOT NULL DEFAULT 0,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL,
  last_login_at INTEGER,
  CHECK (role <> 'daerah' OR json_array_length(areas) > 0)
);

CREATE TABLE sessions (
  id_hash      TEXT    PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at   INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL,
  expires_at   INTEGER NOT NULL,
  ip           TEXT,
  ua           TEXT
);
CREATE INDEX sessions_user ON sessions(user_id);
CREATE INDEX sessions_exp  ON sessions(expires_at);

-- Penyimpanan dokumen (pengganti database artefak): path = koleksi/id
CREATE TABLE docs (
  path       TEXT    PRIMARY KEY,
  collection TEXT    NOT NULL CHECK (length(collection) BETWEEN 1 AND 64),
  id         TEXT    NOT NULL CHECK (length(id) BETWEEN 1 AND 200),
  data       TEXT    NOT NULL CHECK (json_valid(data)),
  version    INTEGER NOT NULL DEFAULT 1,
  updated_at INTEGER NOT NULL,
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  CHECK (path = collection || '/' || id)
);
CREATE INDEX docs_collection ON docs(collection);

-- Catatan koreksi/clear Monitor. Pelaku dicatat oleh SERVER dari sesi login, bukan dari kiriman browser.
CREATE TABLE cek (
  key        TEXT    PRIMARY KEY CHECK (length(key) BETWEEN 1 AND 300),
  cek        TEXT    NOT NULL DEFAULT '' CHECK (cek IN ('','CLEAR')),
  catatan    TEXT    NOT NULL DEFAULT '' CHECK (length(catatan) <= 1000),
  oleh       TEXT    NOT NULL DEFAULT '',
  oleh_user  TEXT    NOT NULL DEFAULT '',
  at         INTEGER NOT NULL
);
CREATE TABLE cek_hist (
  id       INTEGER PRIMARY KEY,
  key      TEXT    NOT NULL REFERENCES cek(key) ON DELETE CASCADE,
  at       INTEGER NOT NULL,
  oleh     TEXT    NOT NULL,
  oleh_user TEXT   NOT NULL,
  act      TEXT    NOT NULL CHECK (act IN ('note','clear','open')),
  note     TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX cek_hist_key ON cek_hist(key, at DESC);

-- Jejak audit untuk semua perubahan penting (login, ACC, ubah pengguna, impor).
CREATE TABLE audit (
  id       INTEGER PRIMARY KEY,
  at       INTEGER NOT NULL,
  user_id  INTEGER,
  username TEXT,
  action   TEXT    NOT NULL,
  target   TEXT,
  detail   TEXT,
  ip       TEXT
);
CREATE INDEX audit_at ON audit(at DESC);

-- Nilai kecil: data bawaan Monitor (gzip+base64), dll.
CREATE TABLE kv (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
