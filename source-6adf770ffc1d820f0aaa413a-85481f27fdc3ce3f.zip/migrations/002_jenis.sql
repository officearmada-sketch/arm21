-- Penggantian jenis trip (TITIKAN <-> LANGSUNG) per trip, dicatat bersama pelaku dan waktu.
ALTER TABLE cek ADD COLUMN jenis TEXT NOT NULL DEFAULT '' CHECK (jenis IN ('','TITIKAN','LANGSUNG'));
ALTER TABLE cek ADD COLUMN jenis_by TEXT NOT NULL DEFAULT '';
ALTER TABLE cek ADD COLUMN jenis_at INTEGER NOT NULL DEFAULT 0;
