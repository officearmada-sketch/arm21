'use strict';
// Memindahkan data awal ke server baru (sekali jalan, aman diulang):
//   npm run seed -- --accounts seed/accounts.json   (atau akun_baru.csv: Username,Password,Peran) --builtin seed/builtin.json --olddb seed/olddb
// accounts.json: [{ "username", "password", "role", "areas": [..] }]  -> password di-hash, file jangan disimpan.
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { openDb, args } = require('./_common');
const { hashPassword } = require('../server/auth');

const { flags } = args(process.argv.slice(2));
(async () => {
  const { db } = openDb();
  const now = Date.now();
  if (flags.accounts) {
    let list;
    if (/\.csv$/i.test(flags.accounts)) {
      // CSV "Username,Password,Peran": Armada Pusat / Manager Armada -> pusat; "Armada Daerah X" -> daerah dengan kode area dari akhiran username (armada.cpy -> CPY)
      const AREA_ALIAS = { jmbr: 'JMBR' };
      list = fs.readFileSync(flags.accounts, 'utf8').split(/\r?\n/).slice(1).filter((l) => l.trim()).map((l) => {
        const [username, password, peran = ''] = l.split(',').map((x) => x.trim());
        const daerah = /^armada daerah/i.test(peran);
        const code = (username.split('.').pop() || '').toLowerCase();
        return { username, password, role: daerah ? 'daerah' : /^admin/i.test(peran) ? 'admin' : 'pusat', areas: daerah ? [AREA_ALIAS[code] || code.toUpperCase()] : [], label: peran };
      });
    } else list = JSON.parse(fs.readFileSync(flags.accounts, 'utf8'));
    const ins = db.prepare('INSERT INTO users (username, password_hash, role, areas, label, created_at, updated_at) VALUES (?,?,?,?,?,?,?) ON CONFLICT(username) DO UPDATE SET role = excluded.role, areas = excluded.areas, label = excluded.label, updated_at = excluded.updated_at' + (flags['reset-passwords'] ? ', password_hash = excluded.password_hash, failed_count = 0, locked_until = 0' : ''));
    let n = 0;
    for (const a of list) { ins.run(a.username, await hashPassword(a.password), a.role, JSON.stringify(a.areas || []), a.label || '', now, now); n++; }
    console.log(`Akun: ${n} diproses`);
  }
  if (flags.builtin) {
    const rows = JSON.parse(fs.readFileSync(flags.builtin, 'utf8'));
    if (!Array.isArray(rows)) throw new Error('builtin harus berupa array');
    db.prepare("INSERT INTO kv (key, value) VALUES ('builtin_gz', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value").run(zlib.gzipSync(Buffer.from(JSON.stringify(rows))).toString('base64'));
    console.log(`Data bawaan Monitor: ${rows.length} baris`);
  }
  if (flags.olddb) {
    const up = db.prepare("INSERT INTO docs (path, collection, id, data, version, updated_at) VALUES (?,?,?,?,1,?) ON CONFLICT(path) DO UPDATE SET data = excluded.data, version = docs.version + 1, updated_at = excluded.updated_at");
    let n = 0;
    for (const coll of fs.readdirSync(flags.olddb)) {
      const dir = path.join(flags.olddb, coll);
      if (!fs.statSync(dir).isDirectory()) continue;
      for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.json'))) {
        const id = f.slice(0, -5);
        up.run(`${coll}/${id}`, coll, id, fs.readFileSync(path.join(dir, f), 'utf8'), now);
        n++;
      }
    }
    console.log(`Dokumen database lama: ${n} dokumen`);
  }
})().catch((e) => { console.error(e.message); process.exit(1); });
