'use strict';
const { load } = require('../server/config');
const { open } = require('../server/db');
function openDb() {
  const cfg = load();
  return { cfg, db: open(cfg.dbFile) };
}
function args(argv) {
  const pos = [], flags = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--')) { const [k, v] = a.slice(2).split('='); flags[k] = v === undefined ? (argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[++i] : true) : v; }
    else pos.push(a);
  }
  return { pos, flags };
}
module.exports = { openDb, args };
