'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
let bad = 0;
const walk = (d) => { for (const f of fs.readdirSync(d, { withFileTypes: true })) { if (f.name === 'node_modules' || f.name.startsWith('.')) continue; const p = path.join(d, f.name); if (f.isDirectory()) walk(p); else if (p.endsWith('.js')) { const r = spawnSync(process.execPath, ['--check', p]); if (r.status) { bad++; console.error(p + '\n' + r.stderr); } } } };
for (const d of ['server', 'scripts', 'test', 'web']) if (fs.existsSync(d)) walk(d);
if (bad) process.exit(1);
console.log('sintaks OK');
