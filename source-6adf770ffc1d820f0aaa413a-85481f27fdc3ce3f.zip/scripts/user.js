'use strict';
// Kelola akun dari terminal server:
//   npm run user -- list
//   npm run user -- add <username> <admin|pusat|daerah|viewer> [--areas LPG,PKB] [--password ...]
//   npm run user -- passwd <username> [--password ...]
//   npm run user -- disable|enable <username>
const crypto = require('node:crypto');
const { openDb, args } = require('./_common');
const { hashPassword, parseAreas } = require('../server/auth');

const { pos, flags } = args(process.argv.slice(2));
const [cmd, name, role] = pos;
const AL = 'abcdefghjkmnpqrstuvwxyzACDEFGHJKLMNPQRTUVWXYZ2346789';
const gen = () => Array.from(crypto.randomBytes(14), (x) => AL[x % AL.length]).join('');
const die = (m) => { console.error(m); process.exit(1); };

(async () => {
  const { db } = openDb();
  const now = Date.now();
  const get = (u) => db.prepare('SELECT * FROM users WHERE username = ?').get(u);
  if (cmd === 'list') {
    for (const u of db.prepare('SELECT * FROM users ORDER BY username').all()) console.log([u.username.padEnd(20), u.role.padEnd(7), parseAreas(u).join(',').padEnd(8), u.disabled ? 'NONAKTIF' : 'aktif', u.last_login_at ? new Date(u.last_login_at).toISOString() : 'belum pernah login'].join('  '));
  } else if (cmd === 'add') {
    if (!name || !['admin', 'pusat', 'daerah', 'viewer'].includes(role)) die('Pemakaian: user add <username> <admin|pusat|daerah|viewer> [--areas LPG] [--password ...]');
    const areas = role === 'daerah' ? String(flags.areas || '').split(',').map((s) => s.trim().toUpperCase()).filter(Boolean) : [];
    if (role === 'daerah' && !areas.length) die('Akun daerah butuh --areas (mis. --areas LPG)');
    const pw = typeof flags.password === 'string' ? flags.password : gen();
    db.prepare('INSERT INTO users (username, password_hash, role, areas, label, created_at, updated_at) VALUES (?,?,?,?,?,?,?)').run(name, await hashPassword(pw), role, JSON.stringify(areas), '', now, now);
    console.log(`Akun dibuat: ${name} (${role}${areas.length ? ' ' + areas.join(',') : ''})` + (flags.password ? '' : `\nPassword awal: ${pw}   (catat sekarang, tidak ditampilkan lagi)`));
  } else if (cmd === 'passwd') {
    const u = name && get(name); if (!u) die('Pengguna tidak ditemukan.');
    const pw = typeof flags.password === 'string' ? flags.password : gen();
    db.prepare('UPDATE users SET password_hash = ?, failed_count = 0, locked_until = 0, updated_at = ? WHERE id = ?').run(await hashPassword(pw), now, u.id);
    db.prepare('DELETE FROM sessions WHERE user_id = ?').run(u.id);
    console.log('Password diganti.' + (flags.password ? '' : `\nPassword baru: ${pw}`));
  } else if (cmd === 'disable' || cmd === 'enable') {
    const u = name && get(name); if (!u) die('Pengguna tidak ditemukan.');
    if (cmd === 'disable' && u.role === 'admin' && db.prepare("SELECT COUNT(*) n FROM users WHERE role='admin' AND disabled=0 AND id<>?").get(u.id).n < 1) die('Tidak boleh menonaktifkan admin terakhir.');
    db.prepare('UPDATE users SET disabled = ?, updated_at = ? WHERE id = ?').run(cmd === 'disable' ? 1 : 0, now, u.id);
    if (cmd === 'disable') db.prepare('DELETE FROM sessions WHERE user_id = ?').run(u.id);
    console.log(`${name}: ${cmd === 'disable' ? 'dinonaktifkan' : 'diaktifkan'}`);
  } else die('Perintah: list | add | passwd | disable | enable');
})().catch((e) => die(e.message));
