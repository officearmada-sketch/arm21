'use strict';
// Pulihkan dari cadangan. HENTIKAN server dulu (docker compose stop app).
//   npm run restore -- /data/backups/armada-2026-10-18-02-00-00.db.gz
const fs = require('node:fs');
const zlib = require('node:zlib');
const { DatabaseSync } = require('node:sqlite');
const { load } = require('../server/config');

const src = process.argv[2];
if (!src || !fs.existsSync(src)) { console.error('Pemakaian: restore <berkas .db.gz>'); process.exit(1); }
const cfg = load();
const tmp = cfg.dbFile + '.restore';
fs.writeFileSync(tmp, zlib.gunzipSync(fs.readFileSync(src)));
let ok = 'gagal dibuka', n = 0;
try {
  const chk = new DatabaseSync(tmp, { readOnly: true });
  ok = chk.prepare('PRAGMA integrity_check').get().integrity_check;
  n = chk.prepare('SELECT COUNT(*) n FROM users').get().n;
  chk.close();
} catch (e) { ok = e.message; }
if (ok !== 'ok' || n < 1) { fs.rmSync(tmp, { force: true }); console.error('Cadangan rusak atau kosong, dibatalkan (' + ok + ').'); process.exit(1); }
if (fs.existsSync(cfg.dbFile)) fs.copyFileSync(cfg.dbFile, cfg.dbFile + '.sebelum-restore-' + Date.now());
for (const ext of ['-wal', '-shm']) fs.rmSync(cfg.dbFile + ext, { force: true });
fs.renameSync(tmp, cfg.dbFile);
console.log(`Pulih dari ${src} (${n} akun). Salinan database lama disimpan di samping berkas.`);
