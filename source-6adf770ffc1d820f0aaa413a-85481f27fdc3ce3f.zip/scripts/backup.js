'use strict';
// Cadangan konsisten (online, tanpa menghentikan server) memakai VACUUM INTO, lalu di-gzip dan dirotasi.
//   npm run backup                 -> sekali jalan
//   npm run backup -- --loop 24    -> ulang tiap 24 jam (dipakai container "backup")
// Variabel: DATA_DIR, BACKUP_DIR (default DATA_DIR/backups), BACKUP_KEEP (default 14 harian)
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { DatabaseSync } = require('node:sqlite');
const { load } = require('../server/config');
const { args } = require('./_common');

const cfg = load();
const dir = process.env.BACKUP_DIR || path.join(cfg.dataDir, 'backups');
const keep = Number(process.env.BACKUP_KEEP || 14);

function once() {
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
  const tmp = path.join(dir, `.tmp-${stamp}.db`), out = path.join(dir, `armada-${stamp}.db.gz`);
  const db = new DatabaseSync(cfg.dbFile, { readOnly: true });
  try { db.exec(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`); } finally { db.close(); }
  // verifikasi hasil cadangan sebelum dipercaya
  const chk = new DatabaseSync(tmp, { readOnly: true });
  const ok = chk.prepare('PRAGMA integrity_check').get().integrity_check;
  const users = chk.prepare('SELECT COUNT(*) n FROM users').get().n;
  chk.close();
  if (ok !== 'ok') { fs.rmSync(tmp, { force: true }); throw new Error('integrity_check gagal: ' + ok); }
  fs.writeFileSync(out, zlib.gzipSync(fs.readFileSync(tmp)));
  fs.rmSync(tmp, { force: true });
  const all = fs.readdirSync(dir).filter((f) => /^armada-.*\.db\.gz$/.test(f)).sort();
  for (const f of all.slice(0, Math.max(0, all.length - keep))) fs.rmSync(path.join(dir, f));
  console.log(JSON.stringify({ t: new Date().toISOString(), msg: 'backup_ok', file: out, bytes: fs.statSync(out).size, users }));
}

const { flags } = args(process.argv.slice(2));
const hours = Number(flags.loop || 0);
try { once(); } catch (e) { console.error(JSON.stringify({ t: new Date().toISOString(), level: 'error', msg: 'backup_gagal', error: e.message })); if (!hours) process.exit(1); }
if (hours) setInterval(() => { try { once(); } catch (e) { console.error(JSON.stringify({ t: new Date().toISOString(), level: 'error', msg: 'backup_gagal', error: e.message })); } }, hours * 3600 * 1000);
