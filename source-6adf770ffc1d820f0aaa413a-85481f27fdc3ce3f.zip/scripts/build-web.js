'use strict';
/* Merakit situs statis dari web/src menjadi public/ (yang disajikan server) dan private/ (aset yang hanya untuk akun login).
   Tanpa dependensi runtime. Pustaka pihak ketiga (xlsx, html2canvas, jspdf, font) diambil dari node_modules (devDependencies),
   jadi `npm ci` harus dijalankan lebih dulu. Pakai --strict (otomatis di CI/Docker) agar build gagal bila ada yang kurang. */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.resolve(__dirname, '..');
const SRC = path.join(ROOT, 'web', 'src');
const OUT = path.join(ROOT, 'public');
const PRIV = path.join(ROOT, 'private');
const NM = path.join(ROOT, 'node_modules');
const STRICT = process.argv.includes('--strict') || process.env.CI === 'true' || process.env.BUILD_STRICT === '1';

const warnings = [];
const warn = (m) => { warnings.push(m); console.warn('  ! ' + m); };
const rd = (...p) => fs.readFileSync(path.join(SRC, ...p), 'utf8');
const hash = (s) => crypto.createHash('sha256').update(s).digest('hex').slice(0, 10);
const write = (rel, data) => { const f = path.join(OUT, rel); fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, data); return f; };

/* ---------- modul (Monitor, Peminjaman, Pemakaian, Admin), dijalankan di dalam shadow DOM oleh hub.js ---------- */
function splitStyle(html) {
  const m = /<style>([\s\S]*?)<\/style>/.exec(html);
  if (!m) throw new Error('head.html tidak punya blok <style>');
  return { css: m[1], rest: html.slice(0, m.index) + html.slice(m.index + m[0].length) };
}
function fixCss(c) {
  c = c.split(':root:not([data-theme="light"])').join(':host(:not([data-theme="light"]))');
  c = c.split(':root[data-theme="dark"]').join(':host([data-theme="dark"])');
  c = c.replace(/:root\s*\{/g, ':host{');
  c = c.replace(/(^|\n)body::before/g, '$1.mbody::before');
  c = c.replace(/(^|\n)body\{/g, '$1.mbody{');
  if (c.includes(':root')) throw new Error('CSS modul masih memuat :root yang tak terkonversi');
  return c + '\n.mbody{min-height:100%;isolation:isolate}[hidden]{display:none!important}\n#dr,.dr,#veil,.veil,#login{top:calc(var(--navh) + env(safe-area-inset-top,0px))!important}';
}
const lit = (s) => JSON.stringify(s).replace(/<\//g, '<\\/');

function buildModules() {
  const mon = splitStyle(rd('monitor', 'head.html'));
  const monJs = ['let BUILTIN=[];', rd('monitor', 'base.js'), rd('monitor', 'extras.js'), rd('monitor', 'auth.js'), rd('monitor', 'store.js')].join('\n');
  const pu = splitStyle(rd('peminjaman', 'head.html'));
  const puHtml = (pu.rest + '\n' + rd('peminjaman', 'body.html')).trim();
  const puJs = rd('peminjaman', 'app.js');
  const pk = splitStyle(rd('pemakaian', 'head.html'));
  const pkHtml = (pk.rest + '\n' + rd('pemakaian', 'body.html')).trim();
  const pkJs = rd('pemakaian', 'app.js');
  const ad = splitStyle(rd('admin', 'head.html'));
  const adHtml = ad.rest.trim();
  const adJs = rd('admin', 'app.js');
  for (const [n, s] of [['monitor', mon.rest + monJs], ['peminjaman', puHtml + puJs], ['pemakaian', pkHtml + pkJs], ['admin', adHtml + adJs]]) {
    if (/\{\{[A-Z0-9]+\}\}/.test(s)) throw new Error(`Penanda {{...}} tersisa di modul ${n}`);
  }
  return 'const MODS={'
    + `monitor:{css:${lit(fixCss(mon.css))},html:${lit(mon.rest.trim())},run:function(document){\n${monJs}\n}},`
    + `peminjaman:{css:${lit(fixCss(pu.css))},html:${lit(puHtml)},run:function(document){\n${puJs}\n}},`
    + `pemakaian:{css:${lit(fixCss(pk.css))},html:${lit(pkHtml)},run:function(document){\n${pkJs}\n}},`
    + `admin:{css:${lit(fixCss(ad.css))},html:${lit(adHtml)},run:function(document){\n${adJs}\n}}`
    + '};\n';
}

/* ---------- pustaka dan font dari node_modules ---------- */
const VENDOR = [
  ['xlsx', 'xlsx/dist/xlsx.full.min.js', 'vendor/xlsx.full.min.js'],
  ['html2canvas', 'html2canvas/dist/html2canvas.min.js', 'vendor/html2canvas.min.js'],
  ['jspdf', 'jspdf/dist/jspdf.umd.min.js', 'vendor/jspdf.umd.min.js'],
];
const FONTS = [
  ['chakra-petch', 'Chakra Petch', [500, 600, 700]],
  ['manrope', 'Manrope', [400, 500, 600, 700]],
  ['jetbrains-mono', 'JetBrains Mono', [400, 500]],
];
function copyVendor() {
  const tags = [];
  for (const [name, from, to] of VENDOR) {
    const f = path.join(NM, from);
    if (!fs.existsSync(f)) { warn(`Pustaka ${name} tidak ditemukan di node_modules (jalankan "npm ci"). Fitur terkait dinonaktifkan.`); continue; }
    write(to, fs.readFileSync(f));
    tags.push(`<script defer src="/assets/${to}"></script>`);
  }
  let css = '';
  for (const [dir, family, weights] of FONTS) {
    for (const w of weights) {
      const file = `${dir}-latin-${w}-normal.woff2`, f = path.join(NM, '@fontsource', dir, 'files', file);
      if (!fs.existsSync(f)) { warn(`Font ${family} ${w} tidak ditemukan; memakai font sistem sebagai gantinya.`); continue; }
      write('assets/fonts/' + file, fs.readFileSync(f));
      css += `@font-face{font-family:'${family}';font-style:normal;font-display:swap;font-weight:${w};src:url(/assets/fonts/${file}) format('woff2')}\n`;
    }
  }
  return { tags, css };
}

/* ---------- rakit ---------- */
function main() {
  console.log('Membangun situs ke', path.relative(ROOT, OUT) + '/', STRICT ? '(strict)' : '');
  fs.rmSync(OUT, { recursive: true, force: true });
  fs.rmSync(PRIV, { recursive: true, force: true });
  fs.mkdirSync(OUT, { recursive: true });
  fs.mkdirSync(PRIV, { recursive: true });

  // aset publik (logo, ikon) dan privat (tanda tangan, stempel, template checklist)
  for (const f of fs.readdirSync(path.join(SRC, 'assets'))) write('assets/' + f, fs.readFileSync(path.join(SRC, 'assets', f)));
  for (const f of fs.readdirSync(path.join(SRC, 'private'))) fs.copyFileSync(path.join(SRC, 'private', f), path.join(PRIV, f));

  const identityBundle = require('esbuild').buildSync({
    entryPoints: [path.join(SRC, 'identity/client.js')], bundle: true,
    format: 'iife', platform: 'browser', target: 'es2020', write: false, minify: true,
  }).outputFiles[0].text;
  const identityUrl = '/assets/identity.' + hash(identityBundle) + '.js';
  write(identityUrl.slice(1), identityBundle);
  const vendor = copyVendor();
  if (vendor.css) write('assets/fonts.css', vendor.css);

  const files = {
    shim: ['shim', 'js', rd('shim.js')],
    modules: ['modules', 'js', buildModules()],
    hub: ['hub', 'js', rd('shell', 'hub.js').replace(/^\/\*MODS\*\/\s*/, '')],
    css: ['hub', 'css', rd('shell', 'hub.css')],
  };
  const url = {};
  for (const [k, [name, ext, body]] of Object.entries(files)) {
    const rel = `assets/${name}.${hash(body)}.${ext}`;
    write(rel, body);
    url[k] = '/' + rel;
  }

  const commit = process.env.GIT_SHA || process.env.GITHUB_SHA || 'dev';
  const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  const index = `<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#1a4bd8">
<meta name="robots" content="noindex,nofollow">
<title>Armada Pusat · Baraka Express</title>
<link rel="icon" type="image/png" href="/assets/favicon.png">
<link rel="apple-touch-icon" href="/assets/icon-192.png">
<link rel="manifest" href="/manifest.webmanifest">
${vendor.css ? '<link rel="stylesheet" href="/assets/fonts.css">\n' : ''}<link rel="stylesheet" href="${url.css}">
</head>
<body>
${rd('shell', 'nav.html').trim()}
<div id="expired" role="alertdialog" aria-labelledby="expT" hidden>
  <div class="box"><b id="expT">Sesi Anda berakhir</b><span>Masuk lagi untuk melanjutkan. Pekerjaan yang belum tersimpan perlu diulang.</span><button type="button" id="expGo">Masuk lagi</button></div>
</div>
<noscript><p style="padding:24px;font-family:sans-serif">Halaman ini membutuhkan JavaScript.</p></noscript>
<script defer src="${url.shim}"></script>
<script defer src="${identityUrl}"></script>
${vendor.tags.join('\n')}
<script defer src="${url.modules}"></script>
<script defer src="${url.hub}"></script>
</body>
</html>
`;
  write('index.html', index);
  write('manifest.webmanifest', JSON.stringify({
    name: 'Armada Pusat · Baraka Express', short_name: 'Armada', start_url: '/', scope: '/', display: 'standalone',
    background_color: '#ffffff', theme_color: '#1a4bd8', lang: 'id',
    icons: [{ src: '/assets/icon-192.png', sizes: '192x192', type: 'image/png' }, { src: '/assets/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any' }],
  }));
  write('robots.txt', 'User-agent: *\nDisallow: /\n');
  write('version.json', JSON.stringify({ name: pkg.name, version: pkg.version, commit, builtAt: new Date().toISOString() }));

  // pemeriksaan akhir: CSP hanya mengizinkan sumber dari server sendiri
  const bad = [];
  for (const m of index.matchAll(/(?:src|href)="(https?:)?\/\/[^"]+"/g)) bad.push(m[0]);
  if (/<script(?![^>]*\bsrc=)[^>]*>/.test(index)) bad.push('skrip inline di index.html');
  if (bad.length) throw new Error('Sumber eksternal/inline tidak diizinkan oleh CSP: ' + bad.join(', '));

  let total = 0;
  (function walk(d) { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); e.isDirectory() ? walk(p) : (total += fs.statSync(p).size); } })(OUT);
  console.log(`Selesai: ${(total / 1024).toFixed(0)} KB di public/, ${fs.readdirSync(PRIV).length} aset privat.`);
  if (warnings.length) {
    if (STRICT) { console.error(`\nBuild strict gagal: ${warnings.length} peringatan (lihat di atas).`); process.exit(1); }
    console.warn(`\n${warnings.length} peringatan. Untuk produksi jalankan "npm ci" lalu "npm run build -- --strict".`);
  }
}

try { main(); } catch (e) { console.error('Build gagal:', e.message); process.exit(1); }
