#!/usr/bin/env bash
# Dijalankan DI SERVER (atau lewat CI/CD via SSH) dari /opt/armada/deploy:  ./deploy.sh [IMAGE_TAG]
# Menarik image baru, menjalankan ulang, menunggu sehat. Bila gagal, kembali ke tag sebelumnya.
set -euo pipefail
cd "$(dirname "$0")"
TAG="${1:-latest}"
PREV="$(grep -E '^IMAGE_TAG=' .env | cut -d= -f2- || true)"

set_tag() { if grep -q '^IMAGE_TAG=' .env; then sed -i "s|^IMAGE_TAG=.*|IMAGE_TAG=$1|" .env; else echo "IMAGE_TAG=$1" >> .env; fi; }

echo ">> backup sebelum deploy"
docker compose exec -T backup node --disable-warning=ExperimentalWarning scripts/backup.js || echo "(backup gagal; lanjut hati-hati)"

echo ">> tarik image $TAG"
set_tag "$TAG"
docker compose pull app backup
docker compose up -d --remove-orphans

echo ">> menunggu app sehat"
for i in $(seq 1 30); do
  st="$(docker inspect --format '{{.State.Health.Status}}' "$(docker compose ps -q app)" 2>/dev/null || echo none)"
  [ "$st" = "healthy" ] && { echo "OK: $TAG berjalan."; docker image prune -f >/dev/null; exit 0; }
  sleep 4
done

echo "GAGAL: app tidak sehat. Kembali ke ${PREV:-sebelumnya}." >&2
docker compose logs --tail 80 app >&2 || true
if [ -n "$PREV" ]; then set_tag "$PREV"; docker compose up -d app; fi
exit 1
