const MODS={monitor:{css:"\n\n/* Layout: kokpit terang sebagai tema utama. Palet merah, biru, putih: biru = aksen dan status Normal/Standar, navy = jam express, merah = terlambat.\n   Latar jaringan titik bergerak, panel putih dengan cahaya mengikuti kursor, cincin + ubin angka, grafik harian dan rute, lalu tabel. Mode gelap lewat tombol tema. */\n:host{\n  --bg:#f6f8ff;--bg2:#e9efff;--surface:#ffffff;--surface2:#eff3ff;--fg:#0a1640;--muted:#52618f;--line:#d3ddf5;\n  --accent:#1a4bd8;--accent-fg:#ffffff;--accent-soft:rgba(26,75,216,.09);\n  --exp:#0a1f66;--exp-bg:rgba(10,31,102,.09);--nor:#3d7bf5;--nor-bg:rgba(61,123,245,.12);--late:#d6182f;--late-bg:rgba(214,24,47,.08);--warn:#8f1a2a;--warn-bg:rgba(143,26,42,.09);\n  --glass:rgba(255,255,255,.86);--glow:rgba(26,75,216,.22);--net:26,75,216;--shadow:0 20px 50px rgba(30,60,110,.14);\n  --display:'Chakra Petch','Segoe UI',system-ui,sans-serif;--sans:'Manrope',system-ui,-apple-system,'Segoe UI',sans-serif;--mono:'JetBrains Mono',ui-monospace,Menlo,monospace;\n  color-scheme:light;\n}\n:host([data-theme=\"dark\"]){\n  --bg:#040817;--bg2:#08112b;--surface:#0a1330;--surface2:#101c42;--fg:#f4f7ff;--muted:#8d9bc4;--line:#1c2b5e;\n  --accent:#5b8dff;--accent-fg:#03103a;--accent-soft:rgba(91,141,255,.16);\n  --exp:#f4f8ff;--exp-bg:rgba(244,248,255,.12);--nor:#3f78ff;--nor-bg:rgba(63,120,255,.18);--late:#ff3d55;--late-bg:rgba(255,61,85,.16);--warn:#ffb3bd;--warn-bg:rgba(255,179,189,.12);\n  --glass:rgba(10,19,48,.74);--glow:rgba(91,141,255,.42);--net:91,141,255;--shadow:0 20px 60px rgba(0,0,0,.45);color-scheme:dark}\n\n*{box-sizing:border-box}\n.mbody{background:var(--bg);color:var(--fg);font-family:var(--sans);font-size:14px;line-height:1.5;padding-inline:16px;padding-block:22px 56px;position:relative;min-height:100vh;overflow-x:hidden}\n.mbody::before{content:\"\";position:fixed;inset:0;z-index:-2;background:radial-gradient(1000px 520px at 85% -8%,var(--accent-soft),transparent 70%),radial-gradient(800px 500px at -5% 105%,var(--late-bg),transparent 70%),var(--bg)}\n#bg{position:fixed;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none}\n.wrap{max-width:1280px;margin-inline:auto;display:flex;flex-direction:column;gap:16px;position:relative}\nh1{font-family:var(--display);font-size:clamp(24px,4vw,34px);font-weight:700;letter-spacing:.01em;margin:0;text-wrap:balance;line-height:1.1}\n.sub{color:var(--muted);margin:6px 0 0;min-width:0}\n.num{font-family:var(--mono);font-variant-numeric:tabular-nums}\n.lbl,.f label{font-family:var(--display);font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);font-weight:500}\n\n/* panel kaca dengan cahaya yang mengikuti kursor */\n.panel{background:var(--glass);border:1px solid var(--line);border-radius:14px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);position:relative;min-width:0}\n.panel::before{content:\"\";position:absolute;inset:-1px;border-radius:inherit;padding:1px;pointer-events:none;opacity:0;transition:opacity .25s;\n  background:radial-gradient(260px circle at var(--mx,50%) var(--my,50%),var(--accent),transparent 65%);\n  -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0)}\n.panel:hover::before{opacity:.9}\n.ptitle{display:flex;justify-content:space-between;align-items:baseline;gap:8px 12px;flex-wrap:wrap;margin:0 0 12px}\n.ptitle h2{margin:0;font-family:var(--display);font-size:15px;font-weight:600;letter-spacing:.04em}\n.ptitle span{color:var(--muted);font-size:12px}\n\ninput,select,button{font:inherit;color:var(--fg)}\ninput[type=search],input[type=password],input[type=text],input[type=date],input[type=datetime-local],select{background:var(--surface2);border:1px solid var(--line);border-radius:10px;padding:9px 12px;width:100%;min-width:0;transition:border-color .2s,box-shadow .2s}\ninput[type=search]:focus,input[type=password]:focus,input[type=text]:focus,input[type=date]:focus,input[type=datetime-local]:focus,select:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft);outline:none}\n:focus-visible{outline:2px solid var(--accent);outline-offset:2px}\n.f{display:flex;flex-direction:column;gap:5px;min-width:0}\n.chips{display:flex;flex-wrap:wrap;gap:6px}\n.chip{border:1px solid var(--line);background:var(--surface2);border-radius:999px;padding:7px 13px;cursor:pointer;display:inline-flex;gap:8px;align-items:center;transition:transform .15s,border-color .2s,background .2s,box-shadow .2s}\n.chip:hover{border-color:var(--accent);transform:translateY(-1px)}\n.chip[aria-pressed=true]{background:var(--accent);color:var(--accent-fg);border-color:var(--accent);box-shadow:0 0 18px var(--glow)}\n.chip .c{font-family:var(--mono);font-size:12px;opacity:.8}\n.check{display:flex;gap:7px;align-items:center;cursor:pointer}\n.check input{accent-color:var(--accent);width:16px;height:16px}\n.link{background:none;border:0;color:var(--accent);cursor:pointer;padding:6px 0;font-weight:600}\n.link:hover{text-decoration:underline}\n\n.top{display:flex;justify-content:space-between;gap:12px 16px;flex-wrap:wrap;align-items:flex-start}\n.top>div{min-width:0}\n.brand{display:flex;flex-direction:column;align-items:flex-start;gap:14px}\n.lockup{display:flex;flex-wrap:wrap;align-items:center;gap:14px 20px;max-width:100%}\n.unit{border-left:4px solid var(--late);padding-left:16px;display:flex;flex-direction:column;line-height:1;font-family:var(--display);text-transform:uppercase}\n.unit span{font-size:13px;letter-spacing:.32em;color:var(--muted);font-weight:500}\n.unit b{font-size:clamp(30px,5vw,46px);letter-spacing:.06em;color:var(--exp);font-weight:700;margin-top:6px}\n.logo{display:block;width:clamp(230px,46vw,540px);height:auto;max-width:100%;background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 20px;box-shadow:0 8px 30px rgba(0,0,0,.14)}\n.theme{background:var(--glass);border:1px solid var(--line);border-radius:999px;padding:8px 16px;cursor:pointer;font-family:var(--display);letter-spacing:.06em;transition:border-color .2s,box-shadow .2s}\n.theme:hover{border-color:var(--accent);box-shadow:0 0 16px var(--glow)}\n\n/* unggah */\n.upload{padding:14px 16px;display:flex;flex-wrap:wrap;gap:12px 16px;align-items:center;border-style:dashed;overflow:hidden}\n.upload.drag{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft),0 0 40px var(--glow)}\n.upload.drag::after{content:\"\";position:absolute;left:0;right:0;height:2px;background:var(--accent);box-shadow:0 0 14px var(--accent);animation:scan 1.1s linear infinite}\n@keyframes scan{from{top:0}to{top:100%}}\n.upload .msg{flex:1 1 260px;min-width:0}\n.upload .msg b{display:block;font-family:var(--display);letter-spacing:.03em}\n.upload select{width:auto;max-width:100%}\n.btn{background:var(--accent);color:var(--accent-fg);border:0;border-radius:10px;padding:10px 18px;cursor:pointer;font-family:var(--display);font-weight:600;letter-spacing:.05em;transition:transform .15s,box-shadow .2s}\n.btn:hover{transform:translateY(-1px);box-shadow:0 0 22px var(--glow)}\n.btn.alt{background:var(--surface2);color:var(--fg);border:1px solid var(--line)}\n.err{color:var(--late)}\n[hidden]{display:none!important}\n#login{position:fixed;inset:0;z-index:30;display:grid;place-items:center;padding:16px;overflow-y:auto}\n.lgcard{width:min(440px,100%);padding:28px;display:flex;flex-direction:column;gap:16px;box-shadow:var(--shadow)}\n.lgcard .logo{width:100%;max-width:300px}\n.lgcard .unit b{font-size:30px}\n.lgcard h2{margin:4px 0 0;font-family:var(--display);font-size:20px;line-height:1.2}\n.acct{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:flex-end}\n.who{color:var(--muted);font-size:12px}\n.ro #drop{display:none}\n.hist{padding:12px 16px}\n.hist summary{cursor:pointer;font-family:var(--display);letter-spacing:.04em;font-weight:600}\n.histl{margin:10px 0 0;padding:0;list-style:none;display:flex;flex-direction:column;gap:8px;font-size:13px}\n.histl li{display:flex;flex-wrap:wrap;gap:2px 14px;border-top:1px dashed var(--line);padding-top:8px}\n.histl .num{color:var(--muted)}\n.gs{flex:1 1 100%;display:flex;flex-wrap:wrap;gap:10px 12px;align-items:end;border-top:1px dashed var(--line);padding-top:14px}\n.gsu{flex:2 1 280px}.gss{flex:1 1 180px}\n.stbox{flex:1 1 100%;display:flex;flex-wrap:wrap;gap:8px 16px;align-items:center;border-top:1px dashed var(--line);padding-top:14px}\n.stbox .gsnote{flex:1 1 260px}\n.stbtn{display:flex;gap:16px;flex-wrap:wrap}\n.stlog{flex:1 1 100%;display:flex;flex-direction:column;gap:6px;max-height:320px;overflow:auto}\n.lgi{background:var(--surface2);border:1px solid var(--line);border-radius:10px;padding:8px 12px}\n.lgi summary{cursor:pointer}\n.lgi ul{margin:8px 0 0;padding-left:18px;color:var(--muted);font-size:12px}\n.gsnote{flex:1 1 100%;margin:0;color:var(--muted);font-size:12px}\n.gsnote.err{color:var(--late)}\n.btn:disabled{opacity:.55;cursor:wait;transform:none;box-shadow:none}\n\n/* filter */\n.cmd{padding:16px;display:flex;flex-direction:column;gap:14px}\n.cmdrow{display:grid;grid-template-columns:minmax(220px,1.4fr) minmax(170px,.7fr) auto;gap:14px;align-items:end}\n.adv summary{cursor:pointer;color:var(--accent);font-family:var(--display);letter-spacing:.06em;font-weight:600;list-style:none;display:inline-flex;gap:8px;align-items:center;padding:4px 0}\n.adv summary::-webkit-details-marker{display:none}\n.adv summary::before{content:\"+\";display:inline-grid;place-items:center;width:20px;height:20px;border:1px solid var(--accent);border-radius:6px;transition:transform .2s}\n.adv[open] summary::before{content:\"−\"}\n.badge{background:var(--accent);color:var(--accent-fg);border-radius:999px;padding:0 8px;font-family:var(--mono);font-size:12px;line-height:20px}\n.advgrid{display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));align-items:end;margin-top:12px}\n.advact{grid-column:1/-1;display:flex;flex-wrap:wrap;gap:6px 20px;align-items:center}\n\n/* kokpit atas: cincin + ubin */\n.hud{display:grid;grid-template-columns:minmax(280px,380px) 1fr;gap:16px}\n.ring{padding:18px;display:flex;flex-direction:column;gap:14px;align-items:center}\n.gauge{position:relative;width:min(240px,100%);aspect-ratio:1}\n.gauge svg{width:100%;height:100%;transform:rotate(-90deg);overflow:visible}\n.gauge circle{fill:none;stroke-width:11;stroke-linecap:butt}\n.gauge .trk{stroke:var(--line);opacity:.7}\n.gauge .seg{cursor:pointer;transition:stroke-dasharray .8s cubic-bezier(.2,.8,.2,1),stroke-dashoffset .8s cubic-bezier(.2,.8,.2,1),opacity .25s,stroke-width .2s;filter:drop-shadow(0 0 5px currentColor)}\n.gauge .seg:hover{stroke-width:14}\n.seg.e{stroke:var(--exp);color:var(--exp)}.seg.n{stroke:var(--nor);color:var(--nor)}.seg.l{stroke:var(--late);color:var(--late)}\n.gauge .mid{position:absolute;inset:0;display:grid;place-content:center;text-align:center;pointer-events:none}\n.gauge .mid b{font-family:var(--display);font-size:clamp(36px,9vw,50px);font-weight:700;line-height:1;}\n.gauge .mid span{color:var(--muted);font-family:var(--display);letter-spacing:.14em;text-transform:uppercase;font-size:11px;margin-top:4px}\n.legend{display:flex;flex-direction:column;gap:6px;width:100%}\n.lg{display:grid;grid-template-columns:12px 1fr auto auto;gap:10px;align-items:center;background:var(--surface2);border:1px solid var(--line);border-radius:10px;padding:8px 12px;cursor:pointer;text-align:left;transition:border-color .2s,transform .15s}\n.lg:hover{border-color:var(--accent);transform:translateX(2px)}\n.lg[aria-pressed=true]{border-color:var(--accent);box-shadow:0 0 16px var(--glow)}\n.lg i{width:10px;height:10px;border-radius:3px;display:block}\n.lg .pc{color:var(--muted);font-size:12px;min-width:3.2em;text-align:right}\n\n.tiles{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}\n.tile{padding:16px 18px;display:flex;flex-direction:column;gap:4px;min-width:0;justify-content:space-between;overflow:hidden}\n.tile b{font-family:var(--display);font-size:clamp(20px,2.3vw,29px);font-weight:600;line-height:1.1;overflow-wrap:anywhere}\n.tile .sub{margin:0;font-size:11px;font-family:var(--mono);overflow-wrap:anywhere}\n.tile.exp b{color:var(--exp)}.tile.late b{color:var(--late)}.tile.nor b{color:var(--nor)}\n.tile::after{content:\"\";position:absolute;left:18px;right:18px;bottom:0;height:2px;border-radius:2px;background:var(--line)}\n.tile.tkt b{color:var(--accent)}.tile.tkt::after{background:var(--accent)}\n.tile.exp::after{background:var(--exp)}.tile.late::after{background:var(--late)}.tile.nor::after{background:var(--nor)}\n\n/* grafik */\n.charts{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(0,1fr);gap:16px}\n.card{padding:18px}\n.bars{display:flex;gap:6px;align-items:flex-end;height:190px;position:relative;padding-top:14px;overflow-x:auto;overflow-y:hidden;\n  background:linear-gradient(to top,var(--line) 1px,transparent 1px) 0 calc(100% - 24px)/100% 1px no-repeat}\n.col{flex:1 0 24px;max-width:56px;height:100%;display:flex;flex-direction:column;justify-content:flex-end;gap:6px;background:none;border:0;padding:0;cursor:pointer;position:relative;min-width:24px}\n.col .stack{display:flex;flex-direction:column;border-radius:5px 5px 0 0;overflow:hidden;min-height:2px;transition:filter .2s,transform .2s,height .5s cubic-bezier(.2,.8,.2,1);transform-origin:bottom;max-height:calc(100% - 22px)}\n.col .stack i{display:block;min-height:0}\n.col .stack{height:calc((100% - 22px)*var(--h,0))}\n.s-e{background:var(--exp)}.s-n{background:var(--nor)}.s-l{background:var(--late)}\n.col:hover .stack{filter:brightness(1.25) drop-shadow(0 0 8px var(--glow));transform:scaleY(1.03)}\n.col.sel .stack{filter:drop-shadow(0 0 10px var(--accent))}\n.col.dim .stack{opacity:.35}\n.col .dl{font-size:11px;color:var(--muted);text-align:center;height:16px}\n.col.sel .dl{color:var(--accent);font-weight:600}\n.key{display:flex;gap:14px;flex-wrap:wrap;color:var(--muted);font-size:12px;margin-top:10px}\n.key span{display:inline-flex;gap:6px;align-items:center}.key i{width:10px;height:10px;border-radius:3px;display:block}\n.routes{display:flex;flex-direction:column;gap:6px}\n.rt{display:grid;grid-template-columns:minmax(84px,.9fr) 2fr auto;gap:10px;align-items:center;background:none;border:1px solid transparent;border-radius:10px;padding:6px 8px;cursor:pointer;text-align:left;transition:background .2s,border-color .2s}\n.rt:hover{background:var(--surface2)}\n.rt.sel{border-color:var(--accent);background:var(--accent-soft)}\n.rt .rn{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px}\n.rbar{display:block;height:10px;background:var(--line);border-radius:6px;overflow:hidden}\n.rfill{display:flex;height:100%;border-radius:6px;overflow:hidden;transition:width .6s cubic-bezier(.2,.8,.2,1)}\n.rfill i{display:block}\n.rv{font-size:12px;color:var(--muted);min-width:2.4em;text-align:right}\n\n/* tab dan tabel */\n.tabs{display:flex;gap:4px;border-bottom:1px solid var(--line);position:relative;overflow-x:auto}\n.tab{background:none;border:0;padding:12px 18px;cursor:pointer;color:var(--muted);font-family:var(--display);font-weight:600;letter-spacing:.06em;text-transform:uppercase;font-size:13px;white-space:nowrap;transition:color .2s}\n.tab:hover{color:var(--fg)}\n.tab[aria-selected=true]{color:var(--accent);text-shadow:0 0 14px var(--glow);box-shadow:inset 0 -2px 0 var(--accent)}\n.count{padding:10px 4px;color:var(--muted)}\n.tblwrap{overflow:hidden}\n.tbl{overflow-x:auto}\ntable{border-collapse:collapse;width:100%;min-width:820px}\nth,td{text-align:left;padding:11px 14px;border-bottom:1px solid var(--line);white-space:nowrap}\nth{font-family:var(--display);font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:500;background:var(--surface);position:sticky;top:0;cursor:pointer;user-select:none;transition:color .2s}\nth:hover{color:var(--accent)}\nth.r,td.r{text-align:right}\ntbody tr{transition:background .15s,box-shadow .15s}\ntbody tr:hover{background:var(--accent-soft)}\ntr.click{cursor:pointer}\ntr.click:hover{box-shadow:inset 3px 0 0 var(--accent)}\ntr.click:focus-visible{outline-offset:-2px}\n.pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:600;border:1px solid transparent}\n.p-JAM{background:var(--exp-bg);color:var(--exp);border-color:var(--exp)}.p-NORMAL{background:var(--nor-bg);color:var(--nor);border-color:var(--nor)}.p-TERLAMBAT{background:var(--late-bg);color:var(--late);border-color:var(--late)}\n.p-ok{background:var(--accent-soft);color:var(--accent);border-color:var(--accent)}\n.tcnt{display:inline-block;min-width:18px;padding:0 6px;margin-left:4px;border-radius:999px;background:var(--late);color:#fff;font-size:11px;line-height:18px;text-align:center}\n.cfhint{color:var(--muted);font-size:12px;margin-left:8px}\n.count .cf{margin-right:6px}\ntd.cat{white-space:normal;min-width:260px;max-width:420px}\n.cekbox{border:1px solid var(--line);border-radius:12px;padding:14px;background:var(--surface2);display:flex;flex-direction:column;gap:10px}\n.cekbox textarea{width:100%;min-height:84px;resize:vertical;font:inherit;padding:10px 12px;border-radius:10px;border:1px solid var(--line);background:var(--surface);color:var(--fg)}\n.cekbox textarea:focus-visible{outline:2px solid var(--accent);outline-offset:1px}\n.cekbox .act{display:flex;gap:8px;flex-wrap:wrap;align-items:center}\n.cekmeta{color:var(--muted);font-size:12px}\n.p-warn{background:var(--warn-bg);color:var(--warn);border-color:var(--warn)}\n.late{color:var(--late)}.good{color:var(--exp)}\n.tk{color:var(--accent);font-weight:600}\n.p-na{background:var(--surface2);color:var(--muted);border-color:var(--line);font-weight:500}\n.tknote{margin-top:10px;padding:8px 10px;border-radius:8px;background:var(--accent-soft);color:var(--accent);font-size:12px;font-weight:600}\n.okc{display:inline-flex;gap:8px;align-items:center;justify-content:flex-end}\n.okb{width:64px;height:6px;border-radius:4px;background:var(--late-bg);overflow:hidden;display:block}\n.okb i{display:block;height:100%;background:var(--exp);box-shadow:0 0 8px var(--exp)}\n.empty{padding:36px;text-align:center;color:var(--muted)}\n.pager{display:flex;gap:10px;align-items:center;justify-content:space-between;padding:12px 14px}\n.pager button{background:var(--surface2);border:1px solid var(--line);border-radius:10px;padding:7px 14px;cursor:pointer;transition:border-color .2s}\n.pager button:hover:not(:disabled){border-color:var(--accent)}\n.pager button:disabled{opacity:.4;cursor:default}\n\n/* tooltip */\n#tip{position:fixed;z-index:60;pointer-events:none;background:var(--surface);border:1px solid var(--accent);border-radius:10px;padding:8px 11px;font-size:12px;line-height:1.5;box-shadow:0 0 24px var(--glow);opacity:0;transform:translateY(4px);transition:opacity .12s,transform .12s;max-width:240px}\n#tip.on{opacity:1;transform:none}\n#tip b{font-family:var(--display);letter-spacing:.04em;display:block}\n\n/* panel detail trip */\n#veil{position:fixed;inset:0;z-index:40;background:rgba(2,6,14,.55);backdrop-filter:blur(3px);opacity:0;pointer-events:none;transition:opacity .25s}\n#veil.on{opacity:1;pointer-events:auto}\n#dr{position:fixed;top:0;right:0;bottom:0;z-index:50;width:min(440px,100%);background:var(--surface);border-left:1px solid var(--accent);box-shadow:-20px 0 60px rgba(0,0,0,.35),0 0 40px var(--glow);transform:translateX(104%);transition:transform .35s cubic-bezier(.2,.8,.2,1);display:flex;flex-direction:column;visibility:hidden;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}\n#dr.on{transform:none;visibility:visible}\n.dh{padding:18px 20px;display:flex;justify-content:space-between;gap:12px;align-items:flex-start;border-bottom:1px solid var(--line)}\n.dh h3{margin:0;font-family:var(--display);font-size:20px;line-height:1.2;overflow-wrap:anywhere}\n.dh p{margin:4px 0 0;color:var(--muted)}\n.dx{background:var(--surface2);border:1px solid var(--line);border-radius:10px;width:36px;height:36px;cursor:pointer;flex:none;font-size:18px;line-height:1}\n.dx:hover{border-color:var(--accent)}\n.db{padding:20px;display:flex;flex-direction:column;gap:20px;overflow-y:auto}\n.zone{position:relative;height:16px;border-radius:8px;display:flex;overflow:visible;margin-top:30px}\n.zone i{display:block;height:100%;flex:none}\n.zone i:first-child{border-radius:8px 0 0 8px}.zone i:last-child{border-radius:0 8px 8px 0}\n.zone .z-e{background:var(--exp)}.zone .z-n{background:var(--nor)}.zone .z-s{background:var(--nor);opacity:.45}.zone .z-l{background:var(--late)}\n.mk{position:absolute;top:-8px;bottom:-8px;width:3px;background:var(--fg);border-radius:2px;box-shadow:0 0 12px var(--fg);transform:translateX(-50%)}\n.mk span{position:absolute;bottom:100%;left:50%;transform:translateX(-50%);margin-bottom:6px;background:var(--fg);color:var(--bg);font-family:var(--mono);font-size:12px;padding:2px 8px;border-radius:6px;white-space:nowrap}\n.dl2{display:grid;grid-template-columns:1fr auto;gap:8px 16px;margin:0}\n.dl2 dt{color:var(--muted)}.dl2 dd{margin:0;text-align:right;overflow-wrap:anywhere}\n.verdict{border:1px solid var(--line);border-radius:12px;padding:12px 14px;background:var(--surface2)}\n.verdict b{font-family:var(--display);font-size:16px}\n\n.tl{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));margin-top:12px}\n.tn{position:relative;padding-top:22px;padding-right:8px;min-width:0}\n.tn::before{content:\"\";position:absolute;top:5px;left:6px;right:0;height:2px;background:var(--accent)}\n.tn:last-child::before{display:none}\n.tn::after{content:\"\";position:absolute;top:0;left:0;width:12px;height:12px;border-radius:50%;background:var(--accent);box-shadow:0 0 12px var(--glow)}\n.tn.empty::before{background:var(--line)}\n.tn.empty::after{background:var(--surface2);border:2px solid var(--line);box-shadow:none}\n.tn b{display:block;font-family:var(--display);font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:500}\n.tn .v{display:block;font-family:var(--mono);font-size:12px;overflow-wrap:anywhere;margin-top:2px}\n.tn.empty .v{color:var(--muted);font-family:var(--sans)}\n.tn small{display:block;color:var(--muted);font-size:11px;margin-top:2px;overflow-wrap:anywhere}\n.frm{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px;border:1px solid var(--line);border-radius:12px;padding:14px;background:var(--surface2)}\n.frm .full{grid-column:1/-1}\n.frm .act{display:flex;flex-wrap:wrap;gap:10px;align-items:center}\n.fmsg{color:var(--accent);font-size:12px}\n@media (max-width:1000px){.hud{grid-template-columns:1fr}.charts{grid-template-columns:1fr}.ring{flex-direction:row;flex-wrap:wrap;justify-content:center}.legend{flex:1 1 240px}}\n@media (max-width:720px){.cmdrow{grid-template-columns:1fr}.tiles{grid-template-columns:repeat(2,minmax(0,1fr))}.ring{flex-direction:column}}\n@media (prefers-reduced-motion:reduce){*,*::before,*::after{transition-duration:.01ms!important;animation-duration:.01ms!important}}\n\n\n.mbody{min-height:100%;isolation:isolate}[hidden]{display:none!important}\n#dr,.dr,#veil,.veil,#login{top:calc(var(--navh) + env(safe-area-inset-top,0px))!important}",html:"<canvas id=\"bg\" aria-hidden=\"true\"><\/canvas>\n<section id=\"login\" aria-label=\"Masuk\">\n  <form class=\"panel lgcard\" id=\"lgForm\" autocomplete=\"on\">\n    <img class=\"logo\" id=\"lgLogo\" alt=\"Baraka Express\">\n    <div class=\"unit\"><span>Armada<\/span><b>Pusat<\/b><\/div>\n    <h2>Masuk ke Monitor Ketepatan Armada<\/h2>\n    <div class=\"f\"><label for=\"lgUser\">Username<\/label><input id=\"lgUser\" name=\"username\" type=\"text\" autocomplete=\"username\" autocapitalize=\"none\" spellcheck=\"false\" required><\/div>\n    <div class=\"f\"><label for=\"lgPass\">Password<\/label><input id=\"lgPass\" name=\"password\" type=\"password\" autocomplete=\"current-password\" required><\/div>\n    <button class=\"btn\" id=\"lgGo\" type=\"submit\">Masuk<\/button>\n    <p class=\"gsnote\" id=\"lgMsg\" role=\"status\">Akses dibatasi. Hubungi admin untuk mendapatkan akun.<\/p>\n  <\/form>\n<\/section>\n<div class=\"wrap\" id=\"app\" hidden>\n  <div class=\"top\">\n    <div class=\"brand\"><div class=\"lockup\"><img class=\"logo\" alt=\"Baraka Express\" src=\"/assets/logo.png\"><div class=\"unit\"><span>Armada<\/span><b>Pusat<\/b><\/div><\/div><div><h1>Monitor Ketepatan Armada<\/h1>\n    <p class=\"sub\" id=\"periode\"><\/p><\/div><\/div>\n    <div class=\"acct\"><span class=\"who num\" id=\"who\"><\/span><button class=\"theme\" id=\"logout\" type=\"button\">Keluar<\/button><button class=\"theme\" id=\"theme\" type=\"button\">Ganti tema<\/button><\/div>\n  <\/div>\n\n  <section class=\"panel upload\" id=\"drop\" aria-label=\"Unggah file rekap\">\n    <input id=\"file\" type=\"file\" accept=\".xlsx,.xls,.csv\" hidden>\n    <button class=\"btn\" id=\"pick\" type=\"button\">Buka file Excel<\/button>\n    <div class=\"msg\" id=\"src\" role=\"status\"><\/div>\n    <div class=\"f\" id=\"sheetBox\" hidden><label for=\"sheet\">Sheet<\/label><select id=\"sheet\"><\/select><\/div>\n    <button class=\"btn alt\" id=\"builtin\" type=\"button\" hidden>Tampilkan data tersimpan<\/button>\n    <div class=\"gs\">\n      <div class=\"f gsu\"><label for=\"gsUrl\">Link Google Sheets<\/label><input id=\"gsUrl\" type=\"text\" inputmode=\"url\" placeholder=\"https://docs.google.com/spreadsheets/d/…\"><\/div>\n      <div class=\"f gss\"><label for=\"gsSheet\">Nama sheet (opsional)<\/label><input id=\"gsSheet\" type=\"text\" placeholder=\"mis. Oktober 2026\"><\/div>\n      <button class=\"btn\" id=\"gsGo\" type=\"button\">Ambil data<\/button>\n      <p class=\"gsnote\" id=\"gsMsg\" role=\"status\">Hanya baca. Spreadsheet harus dibagikan ke akun layanan server (Viewer) lebih dulu.<\/p>\n    <\/div>\n<\/section>\n\n  <details class=\"panel hist\" id=\"histBox\"><summary>Penyimpanan data dan riwayat pembaruan<\/summary><p class=\"gsnote\" id=\"storeNote\"><\/p><ul class=\"histl\" id=\"hist\"><\/ul><\/details>\n\n  <section class=\"panel cmd\" aria-label=\"Filter\">\n    <div class=\"cmdrow\">\n      <div class=\"f\"><label for=\"q\">Cari driver / No. Polisi / No. struk<\/label><input id=\"q\" type=\"search\" placeholder=\"mis. IMAM, B 9020 KXV, STUT/PST   (tekan / untuk mencari)\"><\/div>\n      <div class=\"f\"><label for=\"tgl\">Tanggal kedatangan<\/label><select id=\"tgl\"><\/select><\/div>\n      <div class=\"f\"><span class=\"lbl\">Status<\/span><div class=\"chips\" id=\"chips\"><\/div><\/div>\n    <\/div>\n    <details class=\"adv\" id=\"adv\">\n      <summary>Filter lanjutan <span class=\"badge num\" id=\"advN\" hidden><\/span><\/summary>\n      <div class=\"advgrid\">\n        <div class=\"f\"><label for=\"late\">Terlambat per driver<\/label>\n          <select id=\"late\"><option value=\"0\">Semua driver<\/option><option value=\"1\">Pernah terlambat (≥ 1 kali)<\/option><option value=\"2\">Terlambat ≥ 2 kali<\/option><option value=\"3\">Terlambat ≥ 3 kali<\/option><option value=\"4\">Terlambat ≥ 4 kali<\/option><option value=\"eq0\">Tidak pernah terlambat<\/option><\/select><\/div>\n        <div class=\"f\"><label for=\"lateP\">Terlambat per No. Polisi<\/label>\n          <select id=\"lateP\"><option value=\"0\">Semua armada<\/option><option value=\"1\">Pernah terlambat (≥ 1 kali)<\/option><option value=\"2\">Terlambat ≥ 2 kali<\/option><option value=\"3\">Terlambat ≥ 3 kali<\/option><option value=\"4\">Terlambat ≥ 4 kali<\/option><option value=\"eq0\">Tidak pernah terlambat<\/option><\/select><\/div>\n        <div class=\"f\"><label for=\"asal\">Asal<\/label><select id=\"asal\"><\/select><\/div>\n        <div class=\"f\"><label for=\"tujuan\">Tujuan<\/label><select id=\"tujuan\"><\/select><\/div>\n        <div class=\"f\"><label for=\"armada\">Jenis armada<\/label><select id=\"armada\"><\/select><\/div>\n        <div class=\"f\"><label for=\"jenis\">Jenis trip<\/label><select id=\"jenis\"><\/select><\/div>\n        <div class=\"advact\">\n          <label class=\"check\"><input type=\"checkbox\" id=\"koreksi\"> Perlu koreksi (belum clear)<\/label>\n          <label class=\"check\"><input type=\"checkbox\" id=\"besar\"> Denda di atas Rp 500.000<\/label>\n          <button class=\"link\" id=\"today\" type=\"button\">Hari ini<\/button>\n          <button class=\"link\" id=\"reset\" type=\"button\">Reset filter<\/button>\n        <\/div>\n      <\/div>\n    <\/details>\n  <\/section>\n\n  <section class=\"hud\" aria-label=\"Ringkasan\">\n    <div class=\"panel ring\">\n      <div class=\"gauge\">\n        <svg viewBox=\"0 0 140 140\" role=\"img\" aria-label=\"Komposisi status trip\">\n          <circle class=\"trk\" cx=\"70\" cy=\"70\" r=\"54\"/>\n          <circle class=\"seg e\" id=\"ring-e\" data-ring=\"JAM EXPRESS\" cx=\"70\" cy=\"70\" r=\"54\" stroke-dasharray=\"0 400\"/>\n          <circle class=\"seg n\" id=\"ring-n\" data-ring=\"NORMAL\" cx=\"70\" cy=\"70\" r=\"54\" stroke-dasharray=\"0 400\"/>\n          <circle class=\"seg l\" id=\"ring-l\" data-ring=\"TERLAMBAT\" cx=\"70\" cy=\"70\" r=\"54\" stroke-dasharray=\"0 400\"/>\n        <\/svg>\n        <div class=\"mid\"><b class=\"num\" id=\"ringPct\">0%<\/b><span>tepat waktu<\/span><\/div>\n      <\/div>\n      <div class=\"legend\" id=\"legend\"><\/div>\n    <\/div>\n    <div class=\"tiles\" id=\"tiles\">\n      <div class=\"panel tile\"><span class=\"lbl\">Total trip<\/span><b class=\"num\" id=\"v-n\">0<\/b><span class=\"sub\">sesuai filter aktif<\/span><\/div>\n      <div class=\"panel tile exp\"><span class=\"lbl\">Jam Express<\/span><b class=\"num\" id=\"v-e\">0<\/b><span class=\"sub num\" id=\"p-e\"><\/span><\/div>\n      <div class=\"panel tile nor\"><span class=\"lbl\">Normal<\/span><b class=\"num\" id=\"v-o\">0<\/b><span class=\"sub num\" id=\"p-o\"><\/span><\/div>\n      <div class=\"panel tile late\"><span class=\"lbl\">Terlambat<\/span><b class=\"num\" id=\"v-l\">0<\/b><span class=\"sub num\" id=\"p-l\"><\/span><\/div>\n      <div class=\"panel tile exp\"><span class=\"lbl\">Total bonus<\/span><b class=\"num\" id=\"v-b\">–<\/b><span class=\"sub\">trip langsung<\/span><\/div>\n      <div class=\"panel tile late\"><span class=\"lbl\">Denda langsung<\/span><b class=\"num\" id=\"v-d\">–<\/b><span class=\"sub\">potongan trip langsung<\/span><\/div>\n      <div class=\"panel tile tkt\"><span class=\"lbl\">Denda titikan<\/span><b class=\"num\" id=\"v-dt\">–<\/b><span class=\"sub\">Tidak berlaku, terpisah dari potongan<\/span><\/div>\n      <div class=\"panel tile tkt\"><span class=\"lbl\">Trip titikan<\/span><b class=\"num\" id=\"v-nt\">0<\/b><span class=\"sub\">bonus dan potongan tidak berlaku<\/span><\/div>\n    <\/div>\n  <\/section>\n\n  <section class=\"charts\" aria-label=\"Grafik\">\n    <div class=\"panel card\">\n      <div class=\"ptitle\"><h2>Trip per tanggal kedatangan<\/h2><span>klik batang untuk memfilter tanggal<\/span><\/div>\n      <div id=\"daily\"><\/div>\n      <div class=\"key\"><span><i class=\"s-e\"><\/i>Jam Express<\/span><span><i class=\"s-n\"><\/i>Normal<\/span><span><i class=\"s-l\"><\/i>Terlambat<\/span><\/div>\n    <\/div>\n    <div class=\"panel card\">\n      <div class=\"ptitle\"><h2>Rute asal<\/h2><span>klik untuk memfilter asal<\/span><\/div>\n      <div class=\"routes\" id=\"routes\"><\/div>\n    <\/div>\n  <\/section>\n\n  <div>\n    <div class=\"tabs\" role=\"tablist\">\n      <button class=\"tab\" role=\"tab\" id=\"t-driver\" aria-selected=\"true\">Per driver<\/button>\n      <button class=\"tab\" role=\"tab\" id=\"t-nopol\" aria-selected=\"false\">Per No. Polisi<\/button>\n      <button class=\"tab\" role=\"tab\" id=\"t-trip\" aria-selected=\"false\">Detail trip<\/button>\n      <button class=\"tab\" role=\"tab\" id=\"t-catatan\" aria-selected=\"false\">Catatan<\/button>\n    <\/div>\n    <div class=\"count\" id=\"count\"><\/div>\n    <div class=\"panel tblwrap\"><div class=\"tbl\" id=\"tbl\"><\/div><div class=\"pager\" id=\"pager\" hidden><\/div><\/div>\n  <\/div>\n<\/div>\n\n<div id=\"tip\" role=\"tooltip\"><\/div>\n<div id=\"veil\"><\/div>\n<aside id=\"dr\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"drT\" aria-hidden=\"true\">\n  <div class=\"dh\"><div><h3 id=\"drT\"><\/h3><p id=\"drS\" class=\"num\"><\/p><\/div><button class=\"dx\" id=\"drX\" type=\"button\" aria-label=\"Tutup detail\">×<\/button><\/div>\n  <div class=\"db\" id=\"drB\"><\/div>\n<\/aside>",run:function(document){
let BUILTIN=[];
let DATA=BUILTIN,TODAY='';
const CEK={};let MAN={};try{MAN=JSON.parse(localStorage.getItem('akurasi-manual')||'{}')||{}}catch(e){MAN={}}
const isT=x=>x.jenis==='TITIKAN';
const keyOf=r=>r.struk||[r.sopir,r.nopol,r.datang].join('|');
const $=id=>document.getElementById(id);
const rp=n=>n?'Rp '+n.toLocaleString('id-ID'):'–';
const hms=s=>{if(s==null)return '–';const neg=s<0;s=Math.abs(s);const h=Math.floor(s/3600),m=Math.floor(s%3600/60),x=s%60;return (neg?'−':'')+String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')+':'+String(x).padStart(2,'0')};
const tglf=t=>{const [y,m,d]=t.split('-');return d+'/'+m+'/'+y};
const jamf=s=>s?s.slice(11,16):'–';
const LABEL={'JAM EXPRESS':'Jam Express','NORMAL':'Normal','TERLAMBAT':'Terlambat'};
const cls=s=>s==='JAM EXPRESS'?'p-JAM':'p-'+s;
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
// jumlah terlambat dihitung dari seluruh data, per driver dan per No. Polisi
let lateD={},lateP={};
const nD=n=>lateD[n]||0,nP=n=>lateP[n]||0;
const st={status:'ALL',tab:'driver',sort:{driver:['telat',-1],nopol:['telat',-1],trip:['tgl',-1],catatan:['tgl',-1]},cf:'ALL',page:0,sopir:null,nopol:null};
const uniq=k=>[...new Set(DATA.map(r=>r[k]))].filter(Boolean).sort();
function fill(id,label,vals,fmt){$(id).innerHTML='<option value="">'+label+'</option>'+vals.map(v=>`<option value="${esc(v)}">${esc(fmt?fmt(v):v)}</option>`).join('')}
function setData(rows,label){
  DATA=rows;lateD={};lateP={};DATA.forEach((r,i)=>{r._i=i;{const c0=CEK[keyOf(r)];if(r.jenis0===undefined)r.jenis0=r.jenis;if(c0&&c0.jenis){r.jenis=c0.jenis;r.jenisO=c0.jenis;r.jenisBy=c0.jenisBy||'';r.jenisAt=c0.jenisAt||''}else{r.jenis=r.jenis0;r.jenisO=''}}r.bn=isT(r)?0:r.bonus;r.dl=isT(r)?0:r.denda;r.dtk=isT(r)?r.denda:0;r.berangkat=r.berangkat||'';r.datang=r.datang||'';r.bongkar=r.bongkar||'';r.langsir=r.langsir||'';r.cek=r.cek||'';r.catatan=r.catatan||'';r.cekOleh=r.cekOleh||'';r.cekAt=r.cekAt||'';if(!r._o)r._o={berangkat:r.berangkat,datang:r.datang,bongkar:r.bongkar,langsir:r.langsir};const m=MAN[keyOf(r)];if(m)Object.assign(r,m);const c=CEK[keyOf(r)];if(c){r.cek=c.cek||'';r.catatan=c.catatan||'';r.cekOleh=c.oleh||'';r.cekAt=c.at||'';r.cekHist=c.hist||[]}});
  DATA.forEach(r=>{if(r.status==='TERLAMBAT'){lateD[r.sopir]=(lateD[r.sopir]||0)+1;lateP[r.nopol]=(lateP[r.nopol]||0)+1}});
  fill('armada','Semua armada',uniq('armada'));fill('asal','Semua asal',uniq('asal'));fill('tujuan','Semua tujuan',uniq('tujuan'));fill('jenis','Semua jenis',uniq('jenis'));
  const tg=uniq('tgl');TODAY=tg.slice(-1)[0]||'';
  const real=new Date();const rs=real.getFullYear()+'-'+String(real.getMonth()+1).padStart(2,'0')+'-'+String(real.getDate()).padStart(2,'0');
  fill('tgl','Semua tanggal',tg.slice().reverse(),t=>tglf(t)+(t===rs?' (hari ini)':''));
  $('today').textContent='Tanggal terbaru';
  ['late','lateP','armada','asal','tujuan','jenis','tgl'].forEach(i=>$(i).selectedIndex=0);$('q').value='';$('koreksi').checked=false;$('besar').checked=false;
  st.status='ALL';st.sopir=null;st.nopol=null;st.page=0;
  $('periode').textContent=DATA.length?`${label} · ${DATA.length.toLocaleString('id-ID')} trip · kedatangan ${tglf(tg[0])} sampai ${tglf(TODAY)} · ${new Set(DATA.map(r=>r.sopir)).size} driver · ${new Set(DATA.map(r=>r.nopol)).size} armada`:label;
  render();
}
function ok(v,n){return v==='eq0'?n===0:!(+v)||n>=+v}
function rows(ignoreStatus,skip){
  const q=$('q').value.trim().toUpperCase();
  return DATA.filter(r=>{
    if(st.sopir&&r.sopir!==st.sopir)return false;
    if(st.nopol&&r.nopol!==st.nopol)return false;
    if(q&&!(r.sopir.includes(q)||r.nopol.includes(q)||r.struk.toUpperCase().includes(q)))return false;
    if(!ok($('late').value,nD(r.sopir)))return false;
    if(!ok($('lateP').value,nP(r.nopol)))return false;
    for(const k of ['armada','asal','tujuan','jenis','tgl'])if(k!==skip&&$(k).value&&r[k]!==$(k).value)return false;
    if($('koreksi').checked&&!(r.fokus&&!r.cek))return false;
    if($('besar').checked&&r.dl<=500000)return false;
    if(!ignoreStatus&&st.status!=='ALL'&&r.status!==st.status)return false;
    return true});
}
function sortRows(a,key,dir){return a.sort((x,y)=>{const u=x[key],v=y[key];const c=typeof u==='string'?u.localeCompare(v):(u??-1)-(v??-1);return c*dir||String(x.sopir).localeCompare(String(y.sopir))})}
function render(){
  const base=rows(true),r=rows(false);
  const cnt=s=>base.filter(x=>x.status===s).length;
  $('chips').innerHTML=[['ALL','Semua',base.length],['JAM EXPRESS','Tembus jam express',cnt('JAM EXPRESS')],['NORMAL','Normal',cnt('NORMAL')],['TERLAMBAT','Terlambat',cnt('TERLAMBAT')]]
   .map(([k,l,c])=>`<button class="chip" type="button" data-s="${k}" aria-pressed="${st.status===k}">${l}<span class="c">${c.toLocaleString('id-ID')}</span></button>`).join('');
  const sum=k=>r.reduce((a,x)=>a+x[k],0),n=r.length,cE=r.filter(x=>x.status==='JAM EXPRESS').length,cN=r.filter(x=>x.status==='NORMAL').length,cL=r.filter(x=>x.status==='TERLAMBAT').length;
  const pc=c=>n?Math.round(c/n*100)+'% dari trip':'';
  anim($('v-n'),n,fmtN);anim($('v-e'),cE,fmtN);anim($('v-o'),cN,fmtN);anim($('v-l'),cL,fmtN);anim($('v-b'),sum('bn'),rp);anim($('v-d'),sum('dl'),rp);anim($('v-dt'),sum('dtk'),rp);const cT=r.filter(isT).length;anim($('v-nt'),cT,fmtN);
  $('p-e').textContent=pc(cE);$('p-o').textContent=pc(cN);$('p-l').textContent=pc(cL);
  renderRing(base);renderDaily();renderRoutes();
  const act=['late','lateP','armada','asal','tujuan','jenis'].filter(i=>$(i).selectedIndex>0).length+($('koreksi').checked?1:0)+($('besar').checked?1:0);
  $('advN').hidden=!act;$('advN').textContent=act;
  for(const t of ['driver','nopol','trip','catatan'])$('t-'+t).setAttribute('aria-selected',st.tab===t);
  const nOpen=r.filter(x=>x.fokus&&!x.cek).length;$('t-catatan').innerHTML='Catatan'+(nOpen?` <span class="tcnt">${fmtN(nOpen)}</span>`:'');
  st.tab==='trip'?renderTrip(r):st.tab==='catatan'?renderCatatan(r):renderGroup(r,st.tab);
}
function th(tab,key,label,right){const[s,d]=st.sort[tab];return `<th class="${right?'r':''}" data-k="${key}" aria-sort="${s===key?(d>0?'ascending':'descending'):'none'}">${label}${s===key?(d>0?' ↑':' ↓'):''}</th>`}
const PS=50;
function pager(total){const pages=Math.max(1,Math.ceil(total/PS));st.page=Math.min(st.page,pages-1);
  $('pager').hidden=pages<2;$('pager').innerHTML=`<button id="prev" type="button" ${st.page?'':'disabled'}>Sebelumnya</button><span class="num">Halaman ${st.page+1} / ${pages}</span><button id="next" type="button" ${st.page<pages-1?'':'disabled'}>Berikutnya</button>`;
  return [st.page*PS,st.page*PS+PS]}
function renderGroup(r,tab){
  const key=tab==='driver'?'sopir':'nopol',cn=tab==='driver'?nD:nP;
  const m={};r.forEach(x=>{const o=m[x[key]]||(m[x[key]]={k:x[key],sopir:x[key],trip:0,exp:0,nor:0,telat:0,bonus:0,denda:0,dt:0,info:new Set()});
    o.trip++;o.bonus+=x.bn;o.denda+=x.dl;o.dt+=x.dtk;o.info.add(tab==='driver'?x.nopol:x.sopir);if(x.status==='JAM EXPRESS')o.exp++;else if(x.status==='NORMAL')o.nor++;else o.telat++});
  const a=Object.values(m);a.forEach(o=>o.ok=(o.exp+o.nor)/o.trip);sortRows(a,...st.sort[tab]);
  $('count').textContent=`${a.length.toLocaleString('id-ID')} ${tab==='driver'?'driver':'armada'} · klik baris untuk melihat trip-nya`;
  if(!a.length){$('tbl').innerHTML='<div class="empty">Tidak ada data yang cocok dengan filter ini.</div>';$('pager').hidden=true;return}
  const [s,e]=pager(a.length),v=a.slice(s,e);
  $('tbl').innerHTML=`<table><thead><tr>${th(tab,'sopir',tab==='driver'?'Driver':'No. Polisi')}${th(tab,'trip','Trip',1)}${th(tab,'exp','Jam Express',1)}${th(tab,'nor','Normal',1)}${th(tab,'telat','Terlambat',1)}${th(tab,'bonus','Bonus',1)}${th(tab,'denda','Denda langsung',1)}${th(tab,'dt','Denda titikan',1)}${th(tab,'ok','Tepat waktu',1)}<th>${tab==='driver'?'No. Polisi':'Driver'}</th></tr></thead><tbody>${v.map(o=>{const al=cn(o.k);return `<tr class="click" tabindex="0" data-g="${esc(o.k)}"><td>${esc(o.k)}</td><td class="r num">${o.trip}</td><td class="r num ${o.exp?'good':''}">${o.exp}</td><td class="r num">${o.nor}</td><td class="r num ${o.telat?'late':''}">${o.telat}${al>1?` <span class="pill p-warn" title="Total terlambat di seluruh data">${al}× total</span>`:''}</td><td class="r num">${rp(o.bonus)}</td><td class="r num ${o.denda?'late':''}">${rp(o.denda)}</td><td class="r num ${o.dt?'tk':''}">${rp(o.dt)}${o.dt?' <span class="pill p-na">Tidak berlaku</span>':''}</td><td class="r"><span class="okc num">${Math.round(o.ok*100)}%<span class="okb"><i style="width:${o.ok*100}%"></i></span></span></td><td>${[...o.info].slice(0,2).map(esc).join(', ')}${o.info.size>2?' +'+(o.info.size-2):''}</td></tr>`}).join('')}</tbody></table>`;
}
function renderTrip(r){
  const a=sortRows(r.slice(),...st.sort.trip);
  $('count').textContent=`${a.length.toLocaleString('id-ID')} trip · klik baris untuk detail`+(st.sopir?` · driver ${st.sopir}`:'')+(st.nopol?` · ${st.nopol}`:'');
  if(!a.length){$('tbl').innerHTML='<div class="empty">Tidak ada trip yang cocok dengan filter ini.</div>';$('pager').hidden=true;return}
  const [s,e]=pager(a.length),v=a.slice(s,e);
  $('tbl').innerHTML=`<table style="min-width:1900px"><thead><tr>${th('trip','berangkat','Berangkat')}${th('trip','datang','Tiba')}${th('trip','sopir','Driver')}${th('trip','nopol','No. Polisi')}${th('trip','armada','Armada')}${th('trip','asal','Asal → Tujuan')}${th('trip','jarak','Jarak',1)}${th('trip','tempuh','Waktu tempuh',1)}${th('trip','express','Jam express',1)}${th('trip','normal','Jam normal',1)}${th('trip','standar','Jam standar',1)}${th('trip','status','Status')}${th('trip','bn','Bonus',1)}${th('trip','dl','Denda langsung',1)}${th('trip','dtk','Denda titikan',1)}${th('trip','bongkar','Tgl bongkar')}${th('trip','langsir','No. surat langsir')}<th>Jenis</th><th>Koreksi</th></tr></thead><tbody>${v.map(x=>`<tr class="click" tabindex="0" data-t="${x._i}"><td class="num">${dtf(x.berangkat)}</td><td class="num">${dtf(x.datang)}</td><td>${esc(x.sopir)}${nD(x.sopir)>1?` <span class="pill p-warn">${nD(x.sopir)}× telat</span>`:''}</td><td class="num" title="${nP(x.nopol)} kali terlambat">${esc(x.nopol)}</td><td>${esc(x.armada)}</td><td title="${esc(x.struk)}">${esc(x.asal)} → ${esc(x.tujuan.replace('PORT ',''))}</td><td class="r num">${x.jarak} km</td><td class="r num">${hms(x.tempuh)}</td><td class="r num">${hms(x.express)}</td><td class="r num">${hms(x.normal)}</td><td class="r num">${hms(x.standar)}</td><td><span class="pill ${cls(x.status)}">${LABEL[x.status]}</span></td>${isT(x)?`<td class="r"><span class="pill p-na" title="Titikan: ketentuan bonus tidak berlaku">Tidak berlaku</span></td><td class="r"><span class="pill p-na" title="Titikan: ketentuan potongan tidak berlaku">Tidak berlaku</span></td><td class="r num tk">${rp(x.denda)} <span class="pill p-na">Tidak berlaku</span></td>`:`<td class="r num">${rp(x.bonus)}</td><td class="r num ${x.denda?'late':''}">${rp(x.denda)}</td><td class="r num">–</td>`}<td class="num">${x.bongkar?tglf(x.bongkar):'–'}</td><td class="num">${esc(x.langsir||'–')}</td><td>${x.jenis==='TITIKAN'?'Titikan':x.jenis==='LANGSUNG'?'Langsung':'–'}</td><td>${cekPill(x)}</td></tr>`).join('')}</tbody></table>`;
}
const cekPill=x=>x.fokus?(x.cek?`<span class="pill p-ok" title="${esc(x.catatan)}">Clear</span>`:'<span class="pill p-warn">Perlu koreksi</span>'):(x.catatan?'<span class="pill p-na" title="'+esc(x.catatan)+'">Ada catatan</span>':'');
const stampC=iso=>{if(!iso)return '';const d=new Date(iso);return isNaN(d)?'':d.toLocaleString('id-ID',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'})};
function renderCatatan(r){
  const all=r.filter(x=>x.fokus||x.catatan),nO=all.filter(x=>x.fokus&&!x.cek).length,nC=all.filter(x=>x.fokus&&x.cek).length,nN=all.filter(x=>!x.fokus&&x.catatan).length;
  const f={ALL:all,OPEN:all.filter(x=>x.fokus&&!x.cek),CLEAR:all.filter(x=>x.fokus&&x.cek),NOTE:all.filter(x=>!x.fokus&&x.catatan)}[st.cf]||all;
  $('count').innerHTML=[['ALL','Semua',all.length],['OPEN','Belum clear',nO],['CLEAR','Clear',nC],['NOTE','Catatan saja',nN]].map(([k,l,c])=>`<button class="chip cf" type="button" data-cf="${k}" aria-pressed="${st.cf===k}">${l}<span class="c">${fmtN(c)}</span></button>`).join('')+'<span class="cfhint">klik baris untuk memeriksa dan memberi catatan</span>';
  const a=sortRows(f.slice(),...st.sort.catatan);
  if(!a.length){$('tbl').innerHTML='<div class="empty">'+(all.length?'Tidak ada trip pada kelompok ini.':'Belum ada trip yang perlu koreksi atau diberi catatan pada filter ini.')+'</div>';$('pager').hidden=true;return}
  const [s,e]=pager(a.length),v=a.slice(s,e);
  $('tbl').innerHTML=`<table style="min-width:1300px"><thead><tr>${th('catatan','tgl','Tanggal')}${th('catatan','sopir','Driver')}${th('catatan','nopol','No. Polisi')}${th('catatan','struk','No. Struk')}<th>Rute</th>${th('catatan','status','Status')}<th>Denda</th><th>Jenis</th>${th('catatan','cek','Koreksi')}<th>Catatan</th>${th('catatan','cekAt','Diperiksa')}</tr></thead><tbody>${v.map(x=>`<tr class="click" tabindex="0" data-t="${x._i}"><td class="num">${tglf(x.tgl)}</td><td>${esc(x.sopir)}</td><td class="num">${esc(x.nopol)}</td><td class="num">${esc(x.struk||'–')}</td><td>${esc(x.asal)} → ${esc(x.tujuan.replace('PORT ',''))}</td><td><span class="pill ${cls(x.status)}">${LABEL[x.status]}</span></td><td class="r num ${x.denda?(isT(x)&&x.cek?'tk':'late'):''}">${rp(x.denda)}${isT(x)&&x.cek&&x.denda?' <span class="pill p-na">Tidak berlaku</span>':''}</td><td>${JL(x.jenis)}</td><td>${cekPill(x)||'–'}</td><td class="cat">${x.catatan?esc(x.catatan):'<span class="muted">belum ada catatan</span>'}</td><td class="num">${x.cekAt?esc(stampC(x.cekAt))+(x.cekOleh?'<br><small>'+esc(x.cekOleh)+'</small>':''):'–'}</td></tr>`).join('')}</tbody></table>`;
}
document.addEventListener('click',e=>{
  const cf=e.target.closest('.cf');if(cf){st.cf=cf.dataset.cf;st.page=0;render();return}
  const c=e.target.closest('.chip');if(c){st.status=c.dataset.s;st.page=0;render();return}
  const h=e.target.closest('th[data-k]');if(h){const t=st.tab,[s,d]=st.sort[t];st.sort[t]=[h.dataset.k,s===h.dataset.k?-d:(['sopir','nopol','tgl','armada','asal','status','berangkat','datang','bongkar','langsir','struk','cek'].includes(h.dataset.k)?1:-1)];render();return}
  const rg=e.target.closest('[data-ring]');if(rg){togStatus(rg.dataset.ring);return}
  const lg=e.target.closest('.lg');if(lg){togStatus(lg.dataset.s);return}
  const dc=e.target.closest('.col[data-d]');if(dc){const same=$('tgl').value===dc.dataset.d;$('tgl').value=same?'':dc.dataset.d;st.page=0;hideTip();render();return}
  const rt=e.target.closest('.rt[data-a]');if(rt){const same=$('asal').value===rt.dataset.a;$('asal').value=same?'':rt.dataset.a;st.page=0;hideTip();render();return}
  const tr=e.target.closest('tr[data-t]');if(tr){openTrip(+tr.dataset.t,tr);return}
  const g=e.target.closest('tr[data-g]');if(g){if(st.tab==='driver'){st.sopir=g.dataset.g;st.nopol=null}else{st.nopol=g.dataset.g;st.sopir=null}st.tab='trip';st.page=0;$('q').value='';render();return}
  if(e.target.id==='prev'){st.page--;render()}if(e.target.id==='next'){st.page++;render()}
});
for(const t of ['driver','nopol','trip','catatan'])$('t-'+t).onclick=()=>{st.tab=t;st.page=0;render()};
['q','late','lateP','armada','asal','tujuan','jenis','tgl','koreksi','besar'].forEach(i=>$(i).addEventListener('input',()=>{if(i==='q'){st.sopir=null;st.nopol=null}st.page=0;render()}));
$('today').onclick=()=>{if(TODAY){$('tgl').value=TODAY;st.page=0;render()}};
$('reset').onclick=()=>{$('q').value='';['late','lateP','armada','asal','tujuan','jenis','tgl'].forEach(i=>$(i).selectedIndex=0);$('koreksi').checked=false;$('besar').checked=false;st.status='ALL';st.sopir=null;st.nopol=null;st.page=0;render()};
$('theme').onclick=()=>{const r=document.documentElement,dark=r.dataset.theme==='dark';r.dataset.theme=dark?'light':'dark'};

/* ---------- Unggah file Excel: dibaca di browser, file tidak dikirim ke mana pun ---------- */
const BUILTIN_LABEL='Data bawaan per 12 Oktober 2026';
const H={sopir:'sopir 1',nopol:'no polisi',armada:'jenis armada',asal:'asal',tujuan:'tujuan',tempuh:'waktu tempuh',jarak:'jarak',express:'jam express',normal:'jam normal',standar:'jam standar',bonus:'jumlah bonus',denda:'jumlah denda',ket:'keterangan jam express',struk:'no. struk',jenis:'keterangan',status:'status',fokus:'fokus',ked:'kedatangan',tdatang:'tanggal kedatangan',berangkat:['berangkat','tanggal berangkat','waktu berangkat','tanggal keberangkatan','waktu keberangkatan','keberangkatan'],bongkar:['tanggal bongkar','tgl bongkar','waktu bongkar','bongkar'],langsir:['no surat langsir','no. surat langsir','nomor surat langsir','no langsir','no. langsir','surat langsir']};
const pad=n=>String(n).padStart(2,'0');
function toSec(v){if(v==null||v==='')return null;if(typeof v==='number')return Math.round(v*86400);
  const m=String(v).trim().match(/^(-)?(\d+):(\d{2})(?::(\d{2}))?$/);return m?(m[1]?-1:1)*(+m[2]*3600+ +m[3]*60+(+m[4]||0)):null}
function toDt(v){if(v==null||v==='')return null;
  if(typeof v==='number')return new Date(Math.round((v-25569)*86400000));
  const m=String(v).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/);if(!m)return null;const sw=+m[1]>12;return new Date(Date.UTC(+m[3],(sw?+m[2]:+m[1])-1,sw?+m[1]:+m[2],+(m[4]||0),+(m[5]||0)))}
const iso=d=>d.getUTCFullYear()+'-'+pad(d.getUTCMonth()+1)+'-'+pad(d.getUTCDate());
const fdt=d=>d?iso(d)+'T'+pad(d.getUTCHours())+':'+pad(d.getUTCMinutes()):'';
const num=v=>{if(typeof v==='number')return v;let s=String(v||'').replace(/[^0-9.,-]/g,'');if(/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s))s=s.replace(/\./g,'').replace(',','.');else if(/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s))s=s.replace(/,/g,'');else s=s.replace(/,/g,'.');return parseFloat(s)||0};
const nm=s=>String(s==null?'':s).replace(/\s+/g,' ').trim().toUpperCase();
function parseSheet(ws){return parseRows(XLSX.utils.sheet_to_json(ws,{header:1,raw:true,defval:null}))}
function parseRows(a){
  if(!a||!a.length)return null;
  const idx={};a[0].forEach((h,i)=>{const k=String(h==null?'':h).trim().toLowerCase();if(k&&!(k in idx))idx[k]=i});
  if(!(H.sopir in idx&&H.tempuh in idx&&H.standar in idx))return null;
  const g=(r,k)=>{for(const n of [].concat(H[k]))if(n in idx)return r[idx[n]];return null};
  const out=[];
  for(let n=1;n<a.length;n++){const r=a[n];
    const tempuh=toSec(g(r,'tempuh')),exp=toSec(g(r,'express')),nor=toSec(g(r,'normal')),sta=toSec(g(r,'standar'));
    if(tempuh==null||sta==null)continue;
    let status=nm(g(r,'status'));
    if(!LABEL[status])status=tempuh>sta?'TERLAMBAT':(exp!=null&&tempuh<exp)?'JAM EXPRESS':'NORMAL';
    let fokus=g(r,'fokus');fokus=fokus?'PERLU KOREKSI':(H.fokus in idx?'':((exp!=null&&tempuh<exp-3600)||tempuh>sta+7200?'PERLU KOREKSI':''));
    const struk=String(g(r,'struk')||'');const sm=struk.match(/\/([A-Z0-9]+)\/(\d{2})(\d{2})(\d{4})\d+$/);
    const sd=sm?sm[4]+'-'+sm[3]+'-'+sm[2]:'';
    const dt=toDt(g(r,'tdatang'));let kd=toDt(g(r,'ked'))||dt;let tgl=kd?iso(kd):sd;
    if(sd&&tgl&&Math.abs(Date.parse(tgl)-Date.parse(sd))>7*864e5)tgl=sd;
    if(!tgl)continue;
    const asalRaw=nm(g(r,'asal')).replace(/^PORT /,'');
    out.push({sopir:nm(g(r,'sopir'))||'TANPA NAMA',nopol:nm(g(r,'nopol'))||'—',armada:nm(g(r,'armada')),asal:asalRaw||(sm?sm[1]:'—'),tujuan:nm(g(r,'tujuan'))||'—',
      tempuh,jarak:num(g(r,'jarak')),express:exp,normal:nor,standar:sta,bonus:num(g(r,'bonus')),denda:num(g(r,'denda')),ketExpress:nm(g(r,'ket')),struk,jenis:nm(g(r,'jenis')),
      status,fokus,tgl,datang:fdt(dt),berangkat:fdt(toDt(g(r,'berangkat'))),bongkar:(d=>d?iso(d):'')(toDt(g(r,'bongkar'))),langsir:String(g(r,'langsir')==null?'':g(r,'langsir')).trim()});
  }
  return out.length?out:null;
}
let book=null,fileName='';
function msg(html,err){$('src').innerHTML=html;$('src').classList.toggle('err',!!err)}
async function useSheet(name){importRows(book[name],`${fileName} › ${name}`)}
async function loadFile(f){
  if(!f||ROLE!=='admin')return;
  if(typeof XLSX==='undefined'){msg('Pembaca Excel belum termuat. Periksa koneksi internet lalu muat ulang halaman.',1);return}
  msg('Membaca '+esc(f.name)+' ...');
  try{
    const wb=XLSX.read(await f.arrayBuffer(),{type:'array'});
    book={};fileName=f.name;
    for(const n of wb.SheetNames){const r=parseSheet(wb.Sheets[n]);if(r)book[n]=r}
    const names=Object.keys(book);
    if(!names.length){book=null;msg('Kolom rekap tidak ditemukan. Baris pertama sheet harus berisi kolom seperti Sopir 1, Waktu Tempuh, Jam Express, Jam Standar, Status.',1);return}
    const lastDate=n=>book[n].reduce((m,r)=>r.tgl>m?r.tgl:m,'');
    names.sort((x,y)=>lastDate(y).localeCompare(lastDate(x))||book[y].length-book[x].length);
    $('sheet').innerHTML=names.map(n=>`<option value="${esc(n)}">${esc(n)} (${book[n].length})</option>`).join('');
    $('sheetBox').hidden=names.length<2;$('builtin').hidden=false;
    useSheet(names[0]);
  }catch(e){msg('File tidak bisa dibaca. Pastikan formatnya .xlsx atau .csv dari rekap akurasi.',1)}
}
$('pick').onclick=()=>$('file').click();
$('file').onchange=e=>{loadFile(e.target.files[0]);e.target.value=''};
$('sheet').onchange=e=>useSheet(e.target.value);
const drop=$('drop');
['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('drag')}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('drag')}));
drop.addEventListener('drop',e=>loadFile(e.dataTransfer.files[0]));


/* ---------- Tampilan interaktif: angka berjalan, cincin, grafik, detail trip, latar jaringan ---------- */
const RM=matchMedia('(prefers-reduced-motion:reduce)').matches;
const fmtN=n=>Number(n).toLocaleString('id-ID');
function anim(el,to,fmt){const from=el._v==null?0:el._v;el._v=to;cancelAnimationFrame(el._r);
  if(RM||from===to){el.textContent=fmt(to);return}
  const t0=performance.now(),D=650;
  const step=t=>{const k=Math.min(1,(t-t0)/D),e=1-Math.pow(1-k,3);el.textContent=fmt(Math.round(from+(to-from)*e));if(k<1)el._r=requestAnimationFrame(step)};
  el._r=requestAnimationFrame(step)}
const dtf=s=>s?tglf(s.slice(0,10))+' '+jamf(s):'–';
function togStatus(s){st.status=st.status===s?'ALL':s;st.page=0;render()}
const C=2*Math.PI*54;
const SEG=[['e','JAM EXPRESS','Tembus jam express','--exp'],['n','NORMAL','Normal','--nor'],['l','TERLAMBAT','Terlambat','--late']];
function renderRing(base){
  const n=base.length,c={e:0,n:0,l:0};
  base.forEach(x=>{x.status==='JAM EXPRESS'?c.e++:x.status==='NORMAL'?c.n++:c.l++});
  let cum=0;
  SEG.forEach(([k,s])=>{const len=n?c[k]/n*C:0,gap=len>6?2:0,el=$('ring-'+k);
    el.style.strokeDasharray=`${Math.max(0,len-gap)} ${C}`;el.style.strokeDashoffset=-cum;
    el.style.opacity=st.status==='ALL'||st.status===s?1:.22;cum+=len});
  anim($('ringPct'),n?Math.round((c.e+c.n)/n*100):0,v=>v+'%');
  $('legend').innerHTML=SEG.map(([k,s,l,v])=>`<button class="lg" type="button" data-s="${s}" aria-pressed="${st.status===s}"><i style="background:var(${v})"></i><span>${l}</span><b class="num">${fmtN(c[k])}</b><span class="pc num">${n?Math.round(c[k]/n*100):0}%</span></button>`).join('');
}
function renderDaily(){
  const a=rows(false,'tgl'),m={};
  a.forEach(x=>{const o=m[x.tgl]||(m[x.tgl]={e:0,n:0,l:0});x.status==='JAM EXPRESS'?o.e++:x.status==='NORMAL'?o.n++:o.l++});
  const days=Object.keys(m).sort(),mx=Math.max(1,...days.map(d=>m[d].e+m[d].n+m[d].l)),sel=$('tgl').value;
  if(!days.length){$('daily').innerHTML='<div class="empty">Tidak ada data untuk grafik ini.</div>';return}
  $('daily').innerHTML=`<div class="bars" role="group" aria-label="Trip per tanggal">${days.map(d=>{const o=m[d],t=o.e+o.n+o.l;
    return `<button class="col${d===sel?' sel':sel?' dim':''}" type="button" data-d="${d}" aria-pressed="${d===sel}" aria-label="${tglf(d)}: ${t} trip" data-tip="${tglf(d)}|${t} trip|Jam Express ${o.e}|Normal ${o.n}|Terlambat ${o.l}"><span class="stack" style="--h:${t/mx}"><i class="s-l" style="flex:${o.l}"></i><i class="s-n" style="flex:${o.n}"></i><i class="s-e" style="flex:${o.e}"></i></span><span class="dl num">${d.slice(8)}</span></button>`}).join('')}</div>`;
}
function renderRoutes(){
  const a=rows(false,'asal'),m={};
  a.forEach(x=>{const o=m[x.asal]||(m[x.asal]={k:x.asal,e:0,n:0,l:0});x.status==='JAM EXPRESS'?o.e++:x.status==='NORMAL'?o.n++:o.l++});
  const all=Object.values(m).map(o=>({...o,t:o.e+o.n+o.l})).sort((x,y)=>y.t-x.t),sel=$('asal').value;
  let list=all.slice(0,8);if(sel&&!list.some(o=>o.k===sel)){const o=all.find(o=>o.k===sel);if(o)list.push(o)}
  if(!list.length){$('routes').innerHTML='<div class="empty">Tidak ada data untuk grafik ini.</div>';return}
  const mx=list[0].t||1;
  $('routes').innerHTML=list.map(o=>`<button class="rt${o.k===sel?' sel':''}" type="button" data-a="${esc(o.k)}" aria-pressed="${o.k===sel}" data-tip="${esc(o.k)}|${o.t} trip|Jam Express ${o.e}|Normal ${o.n}|Terlambat ${o.l}"><span class="rn">${esc(o.k)}</span><span class="rbar"><span class="rfill" style="width:${o.t/mx*100}%"><i class="s-e" style="flex:${o.e}"></i><i class="s-n" style="flex:${o.n}"></i><i class="s-l" style="flex:${o.l}"></i></span></span><span class="rv num">${o.t}</span></button>`).join('')
   +(all.length>list.length?`<div class="count">+${all.length-list.length} asal lainnya, gunakan filter lanjutan</div>`:'');
}

/* tooltip dan cahaya panel */
const tip=$('tip');
function hideTip(){tip.classList.remove('on')}
function placeTip(e){const w=tip.offsetWidth,h=tip.offsetHeight;let x=e.clientX+14,y=e.clientY-h-12;if(x+w>innerWidth-8)x=e.clientX-w-14;if(y<8)y=e.clientY+18;tip.style.left=Math.max(8,x)+'px';tip.style.top=y+'px'}
document.addEventListener('pointerover',e=>{const t=e.target.closest&&e.target.closest('[data-tip]');if(!t){hideTip();return}
  const [h,...l]=t.dataset.tip.split('|');tip.innerHTML=`<b>${esc(h)}</b>`+l.map(esc).join('<br>');tip.classList.add('on');placeTip(e)});
document.addEventListener('pointermove',e=>{if(tip.classList.contains('on'))placeTip(e);
  const p=e.target.closest&&e.target.closest('.panel');if(p){const r=p.getBoundingClientRect();p.style.setProperty('--mx',(e.clientX-r.left)+'px');p.style.setProperty('--my',(e.clientY-r.top)+'px')}});
document.addEventListener('pointerleave',hideTip);

/* detail trip */
let lastF=null,curTrip=-1;
const ymd=s=>{const p=s.slice(0,10).split('-');return Date.UTC(+p[0],+p[1]-1,+p[2])};
function renderTL(x){
  const days=x.datang&&x.bongkar?Math.round((ymd(x.bongkar)-ymd(x.datang))/864e5):null;
  const N=[['Berangkat',x.berangkat?dtf(x.berangkat):'','Tempuh '+hms(x.tempuh)],
    ['Tiba',x.datang?dtf(x.datang):'',days==null?'':days===0?'Bongkar hari yang sama':days>0?`Bongkar H+${days}`:`Bongkar ${-days} hari sebelum tiba`],
    ['Bongkar',x.bongkar?tglf(x.bongkar):'',x.langsir?'Langsir '+x.langsir:'']];
  $('tl').innerHTML=N.map(([l,v,s])=>`<div class="tn${v?'':' empty'}"><b>${l}</b><span class="v">${v?esc(v):'belum diisi'}</span><small>${esc(s)}</small></div>`).join('');
}
const persistMAN=()=>{try{localStorage.setItem('akurasi-manual',JSON.stringify(MAN))}catch(e){}};
function saveTrip(){const x=DATA[curTrip];if(!x||ROLE!=='admin')return;
  const v={berangkat:$('fBer').value,datang:$('fTiba').value,bongkar:$('fBong').value,langsir:$('fLang').value.trim()};
  Object.assign(x,v);if(S.mode==='none'){MAN[keyOf(x)]=Object.assign(MAN[keyOf(x)]||{},v);persistMAN()}else storeUpdateRow(x);renderTL(x);$('dLang').textContent=x.langsir||'–';render();$('fMsg').textContent='Tersimpan di browser ini.'}
function resetTrip(){const x=DATA[curTrip];if(!x||ROLE!=='admin')return;
  Object.assign(x,x._o);if(MAN[keyOf(x)]){for(const k of ['berangkat','datang','bongkar','langsir'])delete MAN[keyOf(x)][k]}persistMAN();if(S.mode!=='none')storeUpdateRow(x);
  $('fBer').value=x.berangkat;$('fTiba').value=x.datang;$('fBong').value=x.bongkar;$('fLang').value=x.langsir;renderTL(x);$('dLang').textContent=x.langsir||'–';render();$('fMsg').textContent='Dikembalikan ke data asli.'}
const JL=j=>j==='TITIKAN'?'Titikan':j==='LANGSUNG'?'Langsung':'–';
function jenisHTML(x){
  if(x.jenis!=='TITIKAN'&&x.jenis!=='LANGSUNG')return '';
  const to=x.jenis==='TITIKAN'?'LANGSUNG':'TITIKAN';
  return `<div class="cekmeta" style="margin-top:12px"><b>Jenis trip:</b> ${JL(x.jenis)}${x.jenisO?` · diubah ${esc(stampC(x.jenisAt))}${x.jenisBy?' oleh <b>'+esc(x.jenisBy)+'</b>':''} (data asli: ${JL(x.jenis0)})`:''}</div><div class="act"><button class="btn alt" id="jToggle" type="button">Ubah menjadi ${JL(to)}</button><span id="jMsg" class="fmsg" role="status"></span></div>`;
}
function recalcDenda(x){x.bn=isT(x)?0:x.bonus;x.dl=isT(x)?0:x.denda;x.dtk=isT(x)?x.denda:0}
let LOGM;
/* Log perubahan ke spreadsheet khusus; server yang menulis (akun layanan), bukan browser. */
async function logSheet(x,aksi,o){
  o=o||{};
  try{
    if(LOGM===undefined)LOGM=(window.claude&&claude.use?await claude.use('mcp'):null)||null;
    if(!LOGM)return false;
    const st2=x.fokus?(x.cek?'CLEAR':'PERLU KOREKSI'):'';
    await LOGM.callTool('Google Sheets','append_values',{spreadsheetId:'1d39r0zquQEgUA45ZxEbXx0uFjAmobUW4Qkimzb7qaBY',range:"'LOG PERUBAHAN'!A1",values:[[new Date().toLocaleString('id-ID'),aksi,x.struk||'',x.tgl||'',x.sopir||'',x.nopol||'',(x.asal||'')+' → '+(x.tujuan||''),LABEL[x.status]||x.status||'',o.from?JL(o.from):JL(x.jenis),o.to?JL(o.to):JL(x.jenis),st2,x.catatan||'',x.cekOleh||ACTOR||USER||'']]},{cache:false});
    return true;
  }catch(e){return false}
}
async function saveJenis(x){
  const from=x.jenis==='TITIKAN'?'TITIKAN':'LANGSUNG',to=from==='TITIKAN'?'LANGSUNG':'TITIKAN';
  $('jToggle').disabled=true;$('jMsg').textContent='Menyimpan …';
  let r;
  try{r=await window.__api.post('/api/cek',{key:keyOf(x),act:'jenis',jenis:to,note:JL(from)+' → '+JL(to)})}
  catch(err){$('jToggle').disabled=false;$('jMsg').textContent=(err&&err.message?err.message:'Gagal menyimpan')+' Tidak ada yang diubah.';return}
  CEK[r.k]={k:r.k,cek:r.cek,catatan:r.catatan,oleh:r.oleh,at:r.at,hist:r.hist,jenis:r.jenis,jenisBy:r.jenisBy,jenisAt:r.jenisAt};
  x.jenis=r.jenis||to;x.jenisO=r.jenis;x.jenisBy=r.jenisBy;x.jenisAt=r.jenisAt;x.cekOleh=r.oleh;x.cekAt=r.at;x.cekHist=r.hist;recalcDenda(x);
  const okLog=await logSheet(x,'UBAH JENIS TRIP',{from,to});
  bindCek(x);render();$('jMsg').textContent='Jenis trip diubah menjadi '+JL(to)+'.'+(okLog?'':' Log ke spreadsheet belum tercatat.');
}
function cekHTML(x){
  const admin=true,open=x.fokus&&!x.cek;
  const head=x.fokus?(x.cek?'<span class="pill p-ok">Clear</span>':'<span class="pill p-warn">Perlu koreksi</span>'):'<span class="pill p-na">Tidak ditandai koreksi</span>';
  const AL={note:'menambah/mengubah catatan',clear:'menandai clear',open:'membuka kembali',jenis:'mengubah jenis trip'};
  const meta=(x.cekAt?`<div class="cekmeta">${x.cek?'Di-clear':'Catatan terakhir'} ${esc(stampC(x.cekAt))}${x.cekOleh?' oleh <b>'+esc(x.cekOleh)+'</b>':''}</div>`:'')+((x.cekHist||[]).length?`<details class="cekmeta"><summary>Riwayat perubahan (${x.cekHist.length})</summary>${x.cekHist.slice(0,15).map(h=>`<div>${esc(stampC(h.at))} · <b>${esc(h.by)}</b> ${esc(AL[h.act]||h.act)}${h.note?': '+esc(h.note.length>90?h.note.slice(0,90)+'…':h.note):''}</div>`).join('')}</details>`:'');
  if(!admin)return `<span class="lbl">Koreksi dan catatan</span><div>${head}</div><div>${x.catatan?esc(x.catatan).replace(/\n/g,'<br>'):'<span class="muted">Belum ada catatan.</span>'}</div>${meta}`;
  return `<span class="lbl">Koreksi dan catatan</span><div>${head}</div>
  <label for="fCat" class="cekmeta">Keterangan hasil pengecekan</label><textarea id="fCat" maxlength="1000" placeholder="mis. Jam tiba salah input, sudah dicek ke driver dan diperbaiki">${esc(x.catatan)}</textarea>
  <div class="act"><button class="btn alt" id="cSave" type="button">Simpan catatan</button>${x.fokus?(x.cek?'<button class="btn alt" id="cOpen" type="button">Buka kembali</button>':'<button class="btn" id="cClear" type="button">Tandai clear</button>'):''}<span id="cMsg" class="fmsg" role="status"></span></div>${meta}
  ${open?'<div class="cekmeta">Isi keterangan dulu, lalu tandai clear.</div>':''}${jenisHTML(x)}`;
}
async function saveCek(x,mode){
  const cat=($('fCat').value||'').trim();
  if(mode==='clear'&&!cat){$('cMsg').textContent='Isi keterangan sebelum menandai clear.';$('fCat').focus();return}
  const btns=[...$('cekBox').querySelectorAll('button')];btns.forEach(b=>b.disabled=true);
  $('cMsg').textContent='Menyimpan …';
  let r;
  try{r=await window.__api.post('/api/cek',{key:keyOf(x),act:mode,note:cat})}
  catch(err){btns.forEach(b=>b.disabled=false);$('cMsg').textContent=(err&&err.message?err.message:'Gagal menyimpan')+' Tidak ada yang diubah.';return}
  /* Server yang menentukan nama pelaku dan waktu, dari akun yang sedang login. */
  CEK[r.k]={k:r.k,cek:r.cek,catatan:r.catatan,oleh:r.oleh,at:r.at,hist:r.hist,jenis:r.jenis,jenisBy:r.jenisBy,jenisAt:r.jenisAt};
  x.cek=r.cek;x.catatan=r.catatan;x.cekOleh=r.oleh;x.cekAt=r.at;x.cekHist=r.hist;
  const okLog=await logSheet(x,mode==='clear'?'TANDAI CLEAR':mode==='open'?'BUKA KEMBALI':'SIMPAN KETERANGAN');
  bindCek(x);render();$('cMsg').textContent=(mode==='clear'?'Ditandai clear.':mode==='open'?'Dibuka kembali.':'Catatan tersimpan.')+(okLog?'':' Log ke spreadsheet belum tercatat.');
}
function bindCek(x){
  $('cekBox').innerHTML=cekHTML(x);
  $('cSave').onclick=()=>saveCek(x,'note');
  if($('cClear'))$('cClear').onclick=()=>saveCek(x,'clear');
  if($('cOpen'))$('cOpen').onclick=()=>saveCek(x,'open');
  if($('jToggle'))$('jToggle').onclick=()=>saveJenis(x);
}
function openTrip(i,from){
  const x=DATA[i];if(!x)return;lastF=from;hideTip();
  const t=x.tempuh,sta=x.standar,ex=x.express==null?0:Math.max(0,x.express),nr=Math.min(sta,Math.max(ex,x.normal==null?sta:x.normal)),mx=Math.max(sta*1.3,t*1.08,1);
  const pe=Math.min(100,ex/mx*100),pn=Math.max(0,(nr-ex)/mx*100),ps=Math.max(0,(sta-nr)/mx*100),pl=Math.max(0,100-pe-pn-ps),pm=Math.min(98,Math.max(2,t/mx*100));
  let ver,vc='';
  if(x.status==='TERLAMBAT'){ver=`Terlambat ${hms(Math.max(0,t-sta))} dari batas standar`;vc='late'}
  else if(x.status==='JAM EXPRESS'){ver=x.express!=null?`Lebih cepat ${hms(Math.max(0,x.express-t))} dari batas express`:'Tembus jam express';vc='good'}
  else ver=t<=nr?`Dalam jam normal, sisa ${hms(Math.max(0,nr-t))} sebelum batas normal`:`Lewat jam normal ${hms(t-nr)}, masih dalam jam standar (sisa ${hms(Math.max(0,sta-t))})`;
  const row=(k,v)=>`<dt>${k}</dt><dd>${v}</dd>`;
  $('drT').textContent=x.sopir+(x.sopir2?' & '+x.sopir2:'');
  $('drS').textContent=x.struk||x.nopol;
  curTrip=i;const dis=ROLE==='admin'?'':' disabled';
  $('drB').innerHTML=`<div class="verdict"><span class="pill ${cls(x.status)}">${LABEL[x.status]}</span><div style="margin-top:8px"><b class="${vc}">${esc(ver)}</b></div>${isT(x)?'<div class="tknote">Trip titikan: ketentuan bonus dan potongan tidak berlaku.</div>':''}</div>
  <div><span class="lbl">Jejak waktu</span><div class="tl" id="tl"></div></div>
  <div><span class="lbl">Waktu tempuh terhadap batas</span><div class="zone"><i class="z-e" style="width:${pe}%"></i><i class="z-n" style="width:${pn}%"></i><i class="z-s" style="width:${ps}%"></i><i class="z-l" style="width:${pl}%"></i><span class="mk" style="left:${pm}%"><span>${hms(t)}</span></span></div>
  <div class="key"><span><i class="s-e"></i>Jam express sampai ${x.express==null?'–':hms(x.express)}</span><span><i class="s-n"></i>Jam normal sampai ${x.normal==null?'–':hms(x.normal)}</span><span><i class="s-n" style="opacity:.5"></i>Jam standar sampai ${hms(sta)}</span><span><i class="s-l"></i>Terlambat</span></div></div>
  <div class="cekbox" id="cekBox"></div>
  <form class="frm" id="frm" autocomplete="off"><span class="lbl full">${ROLE==='admin'?'Lengkapi data trip':'Data trip (hanya lihat)'}</span>
  <div class="f"><label for="fBer">Berangkat (tanggal dan jam)</label><input id="fBer" type="datetime-local" value="${esc(x.berangkat)}"${dis}></div>
  <div class="f"><label for="fTiba">Tiba (tanggal dan jam)</label><input id="fTiba" type="datetime-local" value="${esc(x.datang)}"${dis}></div>
  <div class="f"><label for="fBong">Tanggal bongkar</label><input id="fBong" type="date" value="${esc(x.bongkar)}"${dis}></div>
  <div class="f"><label for="fLang">No. surat langsir</label><input id="fLang" type="text" value="${esc(x.langsir)}"${dis} placeholder="mis. SL/10/2026/0123"></div>
  <div class="full act"${ROLE==='admin'?'':' hidden'}><button class="btn" id="fSave" type="submit">Simpan</button><button class="btn alt" id="fReset" type="button">Kembalikan</button><span id="fMsg" class="fmsg" role="status"></span></div></form>
  <dl class="dl2">${row('No. struk',esc(x.struk||'–'))}<dt>No. surat langsir</dt><dd id="dLang">${esc(x.langsir||'–')}</dd>${row('No. Polisi',esc(x.nopol)+(x.armada?' · '+esc(x.armada):''))}${row('Rute',esc(x.asal)+' → '+esc(x.tujuan))}${row('Jarak',x.jarak+' km')}${row('Waktu tempuh',hms(t))}${row('Batas jam express',x.express==null?'–':hms(x.express))}${row('Batas jam normal',x.normal==null?'–':hms(x.normal))}${row('Batas jam standar',hms(sta))}${row('Jenis trip',x.jenis==='TITIKAN'?'Titikan':x.jenis==='LANGSUNG'?'Langsung':'–')}${isT(x)?row('Bonus','Tidak berlaku (titikan)')+row('Denda langsung','Tidak berlaku (titikan)')+row('Denda titikan',(x.denda?`<span class="tk">${rp(x.denda)}</span> `:'')+'<span class="pill p-na">Tidak berlaku</span>'):row('Bonus',rp(x.bonus))+row('Denda langsung',x.denda?`<span class="late">${rp(x.denda)}</span>`:'–')+row('Denda titikan','–')}${row('Keterangan express',esc(x.ketExpress||'–'))}${row('Terlambat, driver ini',nD(x.sopir)+' kali')}${row('Terlambat, armada ini',nP(x.nopol)+' kali')}${x.fokus?row('Catatan','<span class="pill p-warn">Perlu koreksi</span>'):''}</dl>`;
  renderTL(x);bindCek(x);$('frm').onsubmit=ev=>{ev.preventDefault();saveTrip()};$('fReset').onclick=resetTrip;
  $('veil').classList.add('on');$('dr').classList.add('on');$('dr').setAttribute('aria-hidden','false');$('drX').focus();
}
function closeTrip(){if(!$('dr').classList.contains('on'))return;$('veil').classList.remove('on');$('dr').classList.remove('on');$('dr').setAttribute('aria-hidden','true');if(lastF&&document.contains(lastF))lastF.focus()}
$('drX').onclick=closeTrip;$('veil').onclick=closeTrip;
document.addEventListener('keydown',e=>{
  if(e.key==='Escape')closeTrip();
  const tg=e.target;
  if(e.key==='Enter'&&tg.matches&&tg.matches('tr.click')){e.preventDefault();tg.click()}
  if(e.key==='/'&&!/INPUT|SELECT|TEXTAREA/.test(tg.tagName||'')){e.preventDefault();$('q').focus()}
});

/* latar jaringan titik yang bereaksi pada kursor */
(function(){
  const cv=$('bg'),cx=cv.getContext('2d');if(!cx)return;
  let W=0,H=0,P=[],mx=-999,my=-999,rgb='53,214,255',f=0;
  function col(){rgb=getComputedStyle(document.documentElement).getPropertyValue('--net').trim()||rgb}
  function size(){const d=Math.min(2,devicePixelRatio||1);W=innerWidth;H=innerHeight;cv.width=W*d;cv.height=H*d;cx.setTransform(d,0,0,d,0,0);
    const n=Math.round(Math.min(90,W*H/17000));P=Array.from({length:n},()=>({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.28,vy:(Math.random()-.5)*.28}));col()}
  function draw(){
    cx.clearRect(0,0,W,H);
    for(const p of P){if(!RM){p.x+=p.vx;p.y+=p.vy}if(p.x<0||p.x>W)p.vx*=-1;if(p.y<0||p.y>H)p.vy*=-1;
      const dx=p.x-mx,dy=p.y-my,d=Math.hypot(dx,dy);if(d<150&&d>0){p.x+=dx/d*.7;p.y+=dy/d*.7}}
    for(let i=0;i<P.length;i++){const a=P[i];
      cx.fillStyle=`rgba(${rgb},.55)`;cx.beginPath();cx.arc(a.x,a.y,1.5,0,6.283);cx.fill();
      for(let j=i+1;j<P.length;j++){const b=P[j],d=Math.hypot(a.x-b.x,a.y-b.y);
        if(d<130){cx.strokeStyle=`rgba(${rgb},${(1-d/130)*.22})`;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(b.x,b.y);cx.stroke()}}
      const dm=Math.hypot(a.x-mx,a.y-my);
      if(dm<180){cx.strokeStyle=`rgba(${rgb},${(1-dm/180)*.55})`;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(mx,my);cx.stroke()}}
  }
  function loop(){if(!document.hidden){if(++f%90===0)col();draw()}requestAnimationFrame(loop)}
  addEventListener('resize',()=>{size();if(RM)draw()});
  addEventListener('pointermove',e=>{mx=e.clientX;my=e.clientY});
  size();draw();if(!RM)requestAnimationFrame(loop);
})();


/* ---------- Sambungan Google Sheets, hanya baca: manifest hanya memuat alat get_values ---------- */
const GS='Google Sheets';
function extractRows(p,d=0){
  if(d>5||p==null)return null;
  if(typeof p==='string'){try{return extractRows(JSON.parse(p),d+1)}catch(e){}
    if(typeof XLSX!=='undefined'&&p.includes('\n')){try{const wb=XLSX.read(p,{type:'string'});return XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,raw:true,defval:null})}catch(e){}}return null}
  if(Array.isArray(p)){if(p.length&&p.every(Array.isArray))return p;for(const x of p){const r=extractRows(x,d+1);if(r)return r}return null}
  if(typeof p==='object'){if(p.values){const r=extractRows(p.values,d+1);if(r)return r}for(const k of Object.keys(p)){const r=extractRows(p[k],d+1);if(r)return r}}
  return null}
const gsId=u=>{const m=String(u).match(/\/d\/([A-Za-z0-9_-]{20,})/)||String(u).trim().match(/^([A-Za-z0-9_-]{30,})$/);return m?m[1]:''};
function gsMsg(t,err){const el=$('gsMsg');el.textContent=t;el.classList.toggle('err',!!err)}
async function gsLoad(){
  if(ROLE!=='admin')return;
  const url=$('gsUrl').value.trim(),id=gsId(url),sheet=$('gsSheet').value.trim();
  if(!id){gsMsg('Link tidak dikenali. Tempel link Google Sheets, misalnya docs.google.com/spreadsheets/d/…',1);return}
  try{localStorage.setItem('akurasi-gs',JSON.stringify({url,sheet}))}catch(e){}
  const mcp=window.claude&&claude.use?await claude.use('mcp'):null;
  if(!mcp){gsMsg('Sambungan Google Sheets tidak tersedia. Pakai tombol “Buka file Excel”.',1);return}
  $('gsGo').disabled=true;gsMsg('Mengambil data dari Google Sheets …');
  try{
    let props=[];try{const d=await mcp.describeTool(GS,'get_values');props=Object.keys((d.inputSchema&&d.inputSchema.properties)||{})}catch(e){}
    const find=re=>props.find(k=>re.test(k));
    const kUrl=find(/url/i),kId=find(/spreadsheet.*id|file.*id|^id$/i)||(kUrl?null:'spreadsheetId'),kRange=find(/range/i)||'range';
    const input={};if(kId)input[kId]=id;else input[kUrl]=url;
    const rng=(sheet?`'${sheet.replace(/'/g,"''")}'!`:'')+'A1:AZ20000';input[kRange]=rng;
    const res=await mcp.callTool(GS,'get_values',input,{cache:false});
    const a=extractRows(res.payload!=null?res.payload:(res.content||[]).map(c=>c.text||'').join('\n'));
    const rows=parseRows(a);
    if(!a){gsMsg('Data diterima, tetapi bentuknya belum dikenali.',1);return}
    if(!rows){gsMsg('Baris pertama sheet harus berisi judul kolom seperti Sopir 1, Waktu Tempuh, Jam Express, Jam Standar, Status.',1);return}
    book={[GS]:rows};fileName=GS;
    $('sheetBox').hidden=true;
    await importRows(rows,GS+(sheet?' › '+sheet:''));
    gsMsg('Terakhir dimuat '+new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'})+'. Klik “Ambil data” untuk memuat ulang.');
  }catch(e){
    const c=e&&e.code,m={
      forbidden:'Akun Anda tidak boleh membaca spreadsheet ini.',
      unauthenticated:'Sesi berakhir. Masuk lagi.',
      sheets_denied:'Google menolak akses. Bagikan spreadsheet ini ke akun layanan server (email service account) sebagai Viewer.',
      sheets_not_configured:'Server belum disambungkan ke Google Sheets. Hubungi admin sistem.',
      sheets_auth_failed:'Server gagal masuk ke Google. Periksa kunci service account.',
      sheets_unavailable:'Google Sheets sedang tidak merespons. Coba lagi sebentar lagi.',
      sheets_error:'Google Sheets menolak permintaan: '+(e&&e.message||'cek link dan nama sheet.'),
      bad_request:(e&&e.message)||'Link atau nama sheet tidak valid.',
      network:'Server tidak bisa dihubungi. Periksa koneksi internet Anda.'}[c];
    gsMsg(m||'Gagal mengambil data'+(c?' ('+c+')':'')+'.',1)
  }finally{$('gsGo').disabled=false}
}
$('gsGo').onclick=gsLoad;
$('gsUrl').addEventListener('keydown',e=>{if(e.key==='Enter')gsLoad()});
try{const s=JSON.parse(localStorage.getItem('akurasi-gs')||'null');if(s){$('gsUrl').value=s.url||'';$('gsSheet').value=s.sheet||''}}catch(e){}


/* ---------- Login lewat server: sesi cookie HttpOnly, data bawaan diambil setelah masuk ---------- */
let ROLE='viewer',USER='';
const te=new TextEncoder(),b64d=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0)),b64e=u=>btoa(String.fromCharCode(...u));
let ACTOR='';
const ROLENAME={admin:'Admin',pusat:'Armada Pusat',daerah:'Armada Daerah',viewer:'Hanya lihat'};
const API=window.__api;
async function enterApp(user,acct,rows,kb,areas,label){
  const role=(acct==='admin'||acct==='pusat')?'admin':'viewer';
  USER=user;ROLE=role;ACTOR=label||user;BUILTIN=rows;
  window.__acct={user,role:acct,areas:areas||[],label:label||user};
  try{await initStore(kb)}catch(e){S.mode='none'}
  document.body.classList.toggle('ro',role!=='admin');
  $('who').textContent=user+' · '+ROLENAME[acct]+(acct==='daerah'&&areas&&areas.length?' '+areas.join(', '):'');
  $('login').hidden=true;$('app').hidden=false;startApp();
  try{window.dispatchEvent(new Event('armada-login'))}catch(e){}
}
async function openSession(s){
  /* s = {user:{username,role,areas,label}, key:base64}. Data bawaan hanya dikirim ke sesi yang sah. */
  const rows=await API.get('/api/builtin');
  await enterApp(s.user.username,s.user.role,rows,b64d(s.key),s.user.areas,s.user.label);
}
function lgMsg(t,err){$('lgMsg').textContent=t;$('lgMsg').classList.toggle('err',!!err)}
$('lgLogo').src=document.querySelector('.brand .logo').src;
$('lgForm').addEventListener('submit',async ev=>{
  ev.preventDefault();
  const u=$('lgUser').value.trim(),p=$('lgPass').value;if(!u||!p)return;
  if(!(window.crypto&&crypto.subtle)){lgMsg('Halaman ini harus dibuka lewat alamat https:// agar login dan penyimpanan terenkripsi bisa jalan.',1);return}
  $('lgGo').disabled=true;lgMsg('Memeriksa …');
  try{
    const s=await API.post('/api/login',{username:u,password:p},{quiet:true});
    $('lgPass').value='';
    await openSession(s);
  }catch(e){
    $('lgPass').value='';
    const c=e&&e.code;
    if(c==='invalid_credentials'||c==='locked'||c==='rate_limited'||c==='network'||c==='bad_request')lgMsg(e.message,1);
    else{console.error(e);lgMsg('Login gagal. Muat ulang halaman lalu coba lagi.',1)}
    if(c==='invalid_credentials')$('lgPass').focus();
  }
  finally{$('lgGo').disabled=false}
});
$('logout').onclick=async()=>{try{await API.post('/api/logout',{},{quiet:true})}catch(e){}location.reload()};
/* Lanjutkan sesi yang masih berlaku (cookie) tanpa meminta login lagi */
(async()=>{
  if(!(window.crypto&&crypto.subtle))return;
  try{const s=await API.get('/api/session',{quiet:true});await openSession(s)}catch(e){/* belum login */}
})();


/* ---------- Penyimpanan data harian: gabung dengan data lama, simpan terenkripsi ---------- */
const FIELDS=['struk','sopir','sopir2','nopol','armada','asal','tujuan','tempuh','jarak','express','normal','standar','bonus','denda','ketExpress','jenis','status','fokus','tgl','datang','berangkat','bongkar','langsir','cek','catatan','cekOleh','cekAt'];
const NUMF=['tempuh','jarak','standar','bonus','denda'],NULLN=['express','normal'],KEEPF=['datang','berangkat','bongkar','langsir','cek','catatan','cekOleh','cekAt'];
const S={mode:'none',rows:null,days:{},log:[],db:null,key:null};
const b64s=u=>{let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
function cleanRow(r){const o={};for(const k of FIELDS){const v=r[k];o[k]=NULLN.includes(k)?(v==null?null:v):NUMF.includes(k)?(typeof v==='number'?v:0):(v==null?'':String(v))}return o}
function rkey(r){return r.struk||[r.sopir,r.nopol,r.asal,r.tgl,r.tempuh].join('|')}
const rcmp=(a,b)=>(a.tgl+rkey(a)).localeCompare(b.tgl+rkey(b));
function mergeRows(base,incoming){
  const map=new Map(base.map(r=>[rkey(r),r]));let added=0,updated=0,same=0;const fc={};
  for(const raw of incoming){
    const n=cleanRow(raw),k=rkey(n),ex=map.get(k);
    if(!ex){map.set(k,n);added++;continue}
    const m={...n};for(const f of KEEPF)if(!m[f]&&ex[f])m[f]=ex[f];
    const ch=FIELDS.filter(f=>m[f]!==ex[f]);
    if(ch.length){updated++;ch.forEach(f=>{fc[f]=(fc[f]||0)+1});map.set(k,m)}else same++;
  }
  return {rows:[...map.values()].sort(rcmp),added,updated,same,fc};
}
function groupDays(rows){const g={};rows.forEach(r=>{(g[r.tgl]||(g[r.tgl]=[])).push(r)});const o={};for(const d of Object.keys(g))o[d]=JSON.stringify(g[d]);return o}
async function gz(str){return new Uint8Array(await new Response(new Blob([te.encode(str)]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer())}
async function gunz(u8){return new Response(new Blob([u8]).stream().pipeThrough(new DecompressionStream('gzip'))).text()}
async function sealStr(str){const iv=crypto.getRandomValues(new Uint8Array(12));const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv},S.key,await gz(str)));return {iv:b64s(iv),ct:b64s(ct)}}
async function openStr(o){return gunz(new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:b64d(o.iv)},S.key,b64d(o.ct))))}
const stamp=iso=>new Date(iso||Date.now()).toLocaleString('id-ID',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});

async function loadDb(){
  const snap=await S.db.collection('trips').limit(1000).get(),all=[];
  for(const d of snap.docs){const o=d.data();if(!o||!o.ct)continue;const rows=JSON.parse(await openStr(o));S.days[d.id]=JSON.stringify(rows);all.push(...rows)}
  S.rows=all.length?all.sort(rcmp):null;
  try{const l=await S.db.collection('imports').orderBy('at','desc').limit(8).get();S.log=l.docs.map(x=>x.data())}catch(e){}
}
async function loadCek(){
  /* Catatan koreksi disimpan server (bukan terenkripsi di browser); pelaku dicatat server dari sesi login. */
  try{const r=await window.__api.get('/api/cek');
    for(const v of r.items||[])if(v&&v.k)CEK[v.k]=v}catch(e){}
}
async function loadLocal(){
  try{
    const raw=localStorage.getItem('akurasi-store');S.mode='local';
    if(raw){const rows=JSON.parse(await openStr(JSON.parse(raw)));S.rows=rows.sort(rcmp);S.days=groupDays(S.rows)}
    S.log=JSON.parse(localStorage.getItem('akurasi-imports')||'[]');
  }catch(e){if(S.mode!=='local')S.mode='none'}
}
async function initStore(kb){
  S.key=await crypto.subtle.importKey('raw',kb,'AES-GCM',false,['encrypt','decrypt']);
  let dbh=null;try{dbh=window.claude&&claude.use?await claude.use('db'):null}catch(e){}
  if(dbh){S.db=dbh;S.mode='db';try{await loadDb();await loadCek()}catch(e){S.db=null;S.mode='none';S.rows=null;S.days={};await loadLocal()}}
  else await loadLocal();
}
async function persistAll(rows){
  const nd=groupDays(rows),changed=Object.keys(nd).filter(d=>S.days[d]!==nd[d]),removed=Object.keys(S.days).filter(d=>!(d in nd));
  if(S.mode==='db'){
    let i=0;
    for(const d of changed){msgSave(`Menyimpan ${++i}/${changed.length} hari …`);await S.db.doc('trips/'+d).set({...await sealStr(nd[d]),n:JSON.parse(nd[d]).length,u:new Date().toISOString()});S.days[d]=nd[d]}
    for(const d of removed){await S.db.doc('trips/'+d).delete();delete S.days[d]}
  }else if(S.mode==='local'){
    localStorage.setItem('akurasi-store',JSON.stringify(await sealStr(JSON.stringify(rows))));S.days=nd;
  }
  S.rows=rows;
}
function msgSave(t){const el=$('storeNote');if(el)el.textContent=t}
async function addLog(e){
  S.log.unshift(e);S.log=S.log.slice(0,8);
  if(S.mode==='db')await S.db.collection('imports').add(e);
  else if(S.mode==='local')localStorage.setItem('akurasi-imports',JSON.stringify(S.log));
}
const where=()=>S.mode==='db'?'Tersimpan di server, dipakai bersama oleh semua pengguna.':S.mode==='local'?'Tersimpan di browser ini saja.':'Penyimpanan tidak tersedia, data hanya berlaku selama sesi ini.';
function renderStoreInfo(){
  const n=$('storeNote');if(!n)return;
  n.textContent=where()+(S.rows?'':' Belum ada pembaruan tersimpan, memakai data bawaan.');
  $('hist').innerHTML=S.log.map(l=>`<li><b class="num">${esc(stamp(l.at))}</b><span>${esc(l.source||'')}</span><span class="num">+${l.added} baru · ${l.updated} diperbarui · ${l.same} sama · total ${l.total}</span>${l.fields?`<span class="num">${esc(l.fields)}</span>`:''}</li>`).join('')||'<li>Belum ada riwayat pembaruan.</li>';
}
const storeLabel=()=>'Data tersimpan'+(S.log[0]?' · diperbarui '+stamp(S.log[0].at):'');
async function importRows(incoming,label){
  if(ROLE!=='admin')return;
  const base=S.rows||BUILTIN.map(cleanRow),res=mergeRows(base,incoming);
  const fcs=Object.entries(res.fc).sort((a,b)=>b[1]-a[1]).slice(0,6).map(([k,v])=>k+' '+v).join(', ');
  let note='';
  try{
    await persistAll(res.rows);
    await addLog({at:new Date().toISOString(),source:label,by:USER,added:res.added,updated:res.updated,same:res.same,total:res.rows.length,fields:fcs?'Kolom berubah: '+fcs:''});
    note=where();
  }catch(e){
    S.rows=res.rows;
    note='Gagal menyimpan ('+(e&&e.code||'error')+'), data hanya tampil di sesi ini.';
  }
  setData(res.rows.map(r=>({...r})),storeLabel());
  msg(`<b>${esc(label)}</b>+${res.added} baru · ${res.updated} diperbarui · ${res.same} tidak berubah · total ${res.rows.length.toLocaleString('id-ID')}. ${esc(note)}`);
  $('builtin').hidden=false;renderStoreInfo();
}
async function storeUpdateRow(x){
  if(S.mode==='none')return;
  const base=S.rows||BUILTIN.map(cleanRow),n=cleanRow(x),k=rkey(n);
  try{await persistAll(base.filter(r=>rkey(r)!==k).concat([n]).sort(rcmp));if($('fMsg'))$('fMsg').textContent=(S.mode==='db'?'Tersimpan di server.':'Tersimpan di browser ini.')}
  catch(e){if($('fMsg'))$('fMsg').textContent='Gagal menyimpan ('+(e&&e.code||'error')+').'}
}
async function clearStore(){
  try{if(S.mode==='db'){for(const d of Object.keys(S.days))await S.db.doc('trips/'+d).delete()}else if(S.mode==='local')localStorage.removeItem('akurasi-store')}catch(e){}
  S.rows=null;S.days={};
}
let rstT=0;
$('builtin').onclick=async()=>{
  if(ROLE!=='admin')return;
  if(!rstT){$('builtin').textContent='Klik lagi untuk menghapus data tersimpan';rstT=setTimeout(()=>{rstT=0;$('builtin').textContent='Pakai data bawaan'},5000);return}
  clearTimeout(rstT);rstT=0;$('builtin').textContent='Pakai data bawaan';
  await clearStore();book=null;$('sheetBox').hidden=true;$('builtin').hidden=true;
  setData(BUILTIN.map(r=>({...r})),BUILTIN_LABEL);
  msg('<b>Data bawaan</b>Data tersimpan sudah dihapus. Unggah file rekap untuk mulai lagi.');renderStoreInfo();
};

async function startApp(){
  const has=!!S.rows;
  setData((S.rows||BUILTIN).map(r=>({...r})),has?storeLabel():BUILTIN_LABEL);
  $('builtin').hidden=!(has&&ROLE==='admin');
  renderStoreInfo();
  msg('<b>'+(has?'Data tersimpan':'Data bawaan')+'</b>'+(ROLE==='admin'?'Unggah file Excel atau ambil dari Google Sheets setiap hari. Trip dengan No. Struk yang sama disesuaikan, yang baru ditambahkan.':'Hanya lihat. Data diperbarui oleh admin.'));
}


}},peminjaman:{css:"\n\n/* Papan kerja armada: panel putih, biru dan merah Baraka. Daftar pengajuan di kiri, form fisik muncul di laci kanan. */\n:host{\n  --bg:#f6f8ff;--surface:#ffffff;--surface2:#eff3ff;--fg:#0a1640;--muted:#52618f;--line:#d3ddf5;\n  --accent:#1a4bd8;--accent-fg:#ffffff;--accent-soft:rgba(26,75,216,.09);\n  --navy:#0a1f66;--navy-bg:rgba(10,31,102,.09);--late:#d6182f;--late-bg:rgba(214,24,47,.08);\n  --shadow:0 20px 50px rgba(30,60,110,.14);\n  --display:'Chakra Petch','Segoe UI',system-ui,sans-serif;--sans:'Manrope',system-ui,-apple-system,'Segoe UI',sans-serif;--mono:'JetBrains Mono',ui-monospace,Menlo,monospace;\n  --paper:#ffffff;--ink:#0b0b0b;--veil:rgba(8,16,48,.45);\n  color-scheme:light;\n}\n:host([data-theme=\"dark\"]){\n  --bg:#060b1f;--surface:#0d1530;--surface2:#121c3d;--fg:#eaf0ff;--muted:#9aaad6;--line:#24305e;\n  --accent:#5b8cff;--accent-fg:#06102e;--accent-soft:rgba(91,140,255,.14);\n  --navy:#dfe8ff;--navy-bg:rgba(223,232,255,.1);--late:#ff5a70;--late-bg:rgba(255,90,112,.14);\n  --shadow:0 20px 50px rgba(0,0,0,.5);--veil:rgba(0,0,0,.6);color-scheme:dark}\n*{box-sizing:border-box}\n[hidden]{display:none!important}\n.mbody{margin:0;background:var(--bg);color:var(--fg);font-family:var(--sans);font-size:14px;line-height:1.5;\n  padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:20px 48px}\n.wrap{max-width:1280px;margin:0 auto;display:flex;flex-direction:column;gap:18px}\n.num{font-family:var(--mono);font-variant-numeric:tabular-nums}\nbutton{font:inherit;color:inherit}\n:focus-visible{outline:2px solid var(--accent);outline-offset:2px}\n.top{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:center;justify-content:space-between}\n.brand{display:flex;flex-wrap:wrap;align-items:center;gap:14px 20px;min-width:0;max-width:100%}\n.logo{display:block;width:clamp(230px,46vw,540px);height:auto;max-width:100%;background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 20px;box-shadow:0 8px 30px rgba(0,0,0,.14)}\n.unit{display:flex;flex-direction:column;border-left:4px solid var(--late);padding-left:16px;min-width:0;line-height:1;font-family:var(--display);text-transform:uppercase}\n.unit b{font-size:clamp(30px,5vw,46px);letter-spacing:.06em;color:var(--navy);font-weight:700;margin-top:6px;text-wrap:balance}\n.unit span{font-size:13px;letter-spacing:.32em;color:var(--muted);font-weight:500}\n.acct{display:flex;align-items:center;gap:10px;flex-wrap:wrap}\n.role{font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:5px 12px;border-radius:999px;background:var(--accent-soft);color:var(--accent);border:1px solid var(--accent)}\n.themebtn{background:var(--surface);border:1px solid var(--line);border-radius:999px;padding:8px 16px;cursor:pointer;font-family:var(--display);letter-spacing:.06em;transition:border-color .2s}\n.themebtn:hover{border-color:var(--accent)}\n.stamp{color:var(--muted);font-size:12px}\n.btn{border:1px solid var(--accent);background:var(--accent);color:var(--accent-fg);border-radius:10px;padding:8px 16px;font-weight:600;cursor:pointer;transition:transform .15s,box-shadow .15s}\n.btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 16px var(--accent-soft)}\n.btn:disabled{opacity:.5;cursor:not-allowed}\n.btn.alt{background:transparent;color:var(--accent)}\n.btn.warn{background:var(--late);border-color:var(--late);color:#fff}\n.btn.sm{padding:4px 12px;font-size:12px}\n.link{background:none;border:0;color:var(--accent);cursor:pointer;padding:2px 0;font-weight:600}\n.panel{background:var(--surface);border:1px solid var(--line);border-radius:14px}\n.gate{padding:36px 24px;text-align:center;display:flex;flex-direction:column;gap:10px;align-items:center}\n.gate h2{font-family:var(--display);margin:0;font-size:20px}\n.gate p{margin:0;max-width:56ch;color:var(--muted)}\n.banner{border:1px solid var(--late);background:var(--late-bg);color:var(--fg);border-radius:12px;padding:10px 14px;font-size:13px}\n.banner.info{border-color:var(--accent);background:var(--accent-soft)}\n.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}\n.tile{padding:14px 16px;display:flex;flex-direction:column;gap:2px;border-top:3px solid var(--line)}\n.tile .k{font-size:12px;color:var(--muted);letter-spacing:.06em;text-transform:uppercase}\n.tile .v{font-family:var(--display);font-size:34px;font-weight:700;line-height:1.1}\n.tile .s{font-size:12px;color:var(--muted)}\n.tile.t-wait{border-top-color:var(--late)}.tile.t-park{border-top-color:var(--accent)}.tile.t-go{border-top-color:var(--navy)}\n.bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center}\n.chips{display:flex;gap:6px;flex-wrap:wrap;flex:1 1 320px;min-width:0}\n.chip{border:1px solid var(--line);background:var(--surface);border-radius:999px;padding:5px 12px;cursor:pointer;font-weight:600;font-size:13px;display:inline-flex;gap:8px;align-items:center}\n.chip .c{font-family:var(--mono);font-size:12px;color:var(--muted)}\n.chip[aria-pressed=\"true\"]{background:var(--accent);border-color:var(--accent);color:var(--accent-fg)}\n.chip[aria-pressed=\"true\"] .c{color:inherit}\ninput[type=search],input[type=text],select,textarea{font:inherit;color:var(--fg);background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:8px 12px;min-width:0}\n.tabs{display:flex;gap:4px;border-bottom:1px solid var(--line);overflow-x:auto}\n.tab{background:none;border:0;padding:12px 18px;cursor:pointer;color:var(--muted);font-family:var(--display);font-weight:600;letter-spacing:.06em;text-transform:uppercase;font-size:13px;white-space:nowrap}\n.tab:hover{color:var(--fg)}\n.tab[aria-selected=\"true\"]{color:var(--accent);box-shadow:inset 0 -2px 0 var(--accent)}\n.count{color:var(--muted);font-size:12px;padding:2px 0}\n.tbl{overflow-x:auto}\ntable{border-collapse:collapse;width:100%;min-width:980px}\nth{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);text-align:left;padding:10px 12px;border-bottom:1px solid var(--line);white-space:nowrap}\ntd{padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}\ntbody tr{cursor:pointer}\ntbody tr:hover{background:var(--accent-soft)}\ntd small{display:block;color:var(--muted);font-size:12px}\n.pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid transparent;white-space:nowrap}\n.p-go{background:var(--navy);color:var(--bg);border-color:var(--navy)}\n.p-back{background:#e6f4ee;color:#0b6b46;border-color:#0b6b46}\n.p-park{background:var(--accent-soft);color:var(--accent);border-color:var(--accent)}\n.p-wait{background:var(--late-bg);color:var(--late);border-color:var(--late)}\n.p-first{background:transparent;color:var(--late);border-color:var(--late);border-style:dashed}\n.p-na{background:var(--surface2);color:var(--muted);border-color:var(--line);font-weight:500}\n.empty{padding:36px;text-align:center;color:var(--muted)}\n/* laci detail */\n.veil{position:fixed;inset:0;background:var(--veil);opacity:0;pointer-events:none;transition:opacity .2s;z-index:30}\n.veil.on{opacity:1;pointer-events:auto}\n.dr{position:fixed;top:0;right:0;bottom:0;width:min(820px,100vw);background:var(--bg);border-left:2px solid var(--accent);z-index:31;transform:translateX(102%);transition:transform .25s;display:flex;flex-direction:column;box-shadow:var(--shadow);padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}\n.dr.on{transform:none}\n.dh{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding:16px max(16px,env(safe-area-inset-right,0px)) 12px 20px;border-bottom:1px solid var(--line);background:var(--surface)}\n.dh h3{margin:0;font-family:var(--display);font-size:20px}\n.dh p{margin:2px 0 0;color:var(--muted);font-size:12px}\n.dx{border:1px solid var(--line);background:var(--surface);border-radius:10px;width:36px;height:36px;font-size:20px;cursor:pointer}\n.db{overflow:auto;padding:16px max(16px,env(safe-area-inset-right,0px)) 32px 20px;display:flex;flex-direction:column;gap:18px}\n.lbl{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:700}\n.steps{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}\n.step{border:1px solid var(--line);border-radius:12px;padding:10px 12px;background:var(--surface);display:flex;flex-direction:column;gap:2px}\n.step b{font-size:13px}.step small{color:var(--muted)}\n.step.done{border-color:var(--accent);background:var(--accent-soft)}\n.act{display:flex;flex-wrap:wrap;gap:10px;align-items:center}\n.hint{font-size:12px;color:var(--muted)}\n.msg{font-size:13px}.msg.err{color:var(--late)}\n/* form fisik */\n.sheetwrap{overflow:auto;border:1px solid var(--line);border-radius:12px;background:#d9e0f2;padding:12px}\n.paper{background:var(--paper);color:var(--ink);width:813px;min-height:1247px;box-sizing:border-box;max-width:none;margin:0 auto;padding:44px 56px 40px;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.35}\n.paper .hd{display:flex;align-items:center;gap:20px;border-bottom:2px solid #0a1f66;padding-bottom:12px;margin-bottom:22px}\n.paper .hd img{height:44px;width:auto}\n.paper .hd h1{margin:0;flex:1;text-align:center;font-size:17px;letter-spacing:.02em}\n.paper dl{display:grid;grid-template-columns:200px 14px 1fr;row-gap:3px;margin:0 0 14px}\n.paper dt{font-weight:700}.paper dd{margin:0;grid-column:3}\n.paper dl span.c{grid-column:2}\n.paper .gap{grid-column:1/-1;height:8px}\n.paper h2{font-size:13px;margin:16px 0 6px}\n.paper ol{margin:0 0 12px;padding-left:18px}.paper li{margin-bottom:6px}\n.paper .sig{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;text-align:center;margin-top:26px}\n.paper .sig .h{font-weight:700;margin-bottom:6px}\n.paper .box{height:104px;position:relative;display:flex;align-items:center;justify-content:center}\n.paper .box img{max-height:100%;max-width:100%;object-fit:contain}\n.paper.ck{padding:0;height:1247px;position:relative;overflow:hidden}\n.paper.ck .in{position:relative;width:100%;aspect-ratio:612/792}\n.paper.ck img.bg{position:absolute;inset:0;width:100%;height:100%}\n.paper.ck .v{position:absolute;font-size:12px;line-height:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:700;margin-top:-1px}\n.paper+.paper{break-before:page}\n.paper .nm{font-weight:700;border-top:1px solid var(--ink);padding-top:3px;min-height:20px}\n.paper .mgr{position:relative;height:92px;margin-top:2px}\n.paper .mgr img{position:absolute;left:50%;top:-14px;height:112px;transform:translateX(-50%)}\n.paper .mgr span{position:absolute;left:0;right:0;bottom:0;font-weight:700}\n/* pengguna */\n.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}\n.card{padding:16px;display:flex;flex-direction:column;gap:10px}\n.card h3{margin:0;font-family:var(--display);font-size:16px}\n.urow{display:flex;gap:10px;align-items:center;flex-wrap:wrap;border-bottom:1px solid var(--line);padding:8px 0}\n.urow img{width:28px;height:28px;border-radius:50%}\n.urow .who{flex:1 1 140px;min-width:0;font-weight:600}\n.areas{display:flex;flex-wrap:wrap;gap:6px}\n.areas label{border:1px solid var(--line);border-radius:999px;padding:2px 10px;font-size:12px;cursor:pointer;display:inline-flex;gap:6px;align-items:center}\nul.plain{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}\nul.plain li{display:flex;gap:10px;flex-wrap:wrap;font-size:13px;border-bottom:1px solid var(--line);padding:5px 0}\n@media (max-width:640px){.steps{grid-template-columns:1fr}.tile .v{font-size:28px}}\n@media (prefers-reduced-motion:reduce){*{transition:none!important}}\n\n\n.mbody{min-height:100%;isolation:isolate}[hidden]{display:none!important}\n#dr,.dr,#veil,.veil,#login{top:calc(var(--navh) + env(safe-area-inset-top,0px))!important}",html:"<div class=\"wrap\">\n  <header class=\"top\">\n    <div class=\"brand\">\n      <img class=\"logo\" src=\"/assets/logo.png\" alt=\"Baraka Express\">\n      <div class=\"unit\"><span>Peminjaman Unit Operasional<\/span><b id=\"unitName\">ARMADA PUSAT<\/b><\/div>\n    <\/div>\n    <div class=\"acct\">\n      <span id=\"simBox\" hidden><select id=\"simSel\" aria-label=\"Uji peran\"><\/select><\/span>\n      <span class=\"role\" id=\"roleTag\" hidden><\/span>\n      <span class=\"stamp num\" id=\"stamp\"><\/span>\n      <button class=\"themebtn\" id=\"themeBtn\" type=\"button\">Ganti tema<\/button>\n      <button class=\"btn alt\" id=\"reload\" type=\"button\" hidden>Muat ulang<\/button>\n    <\/div>\n  <\/header>\n\n  <section class=\"panel gate\" id=\"gate\" aria-live=\"polite\"><h2>Memuat data peminjaman<\/h2><p>Menyiapkan akses dan membaca spreadsheet.<\/p><\/section>\n\n  <div id=\"app\" hidden style=\"display:flex;flex-direction:column;gap:18px\">\n    <div id=\"banner\" class=\"banner\" hidden role=\"alert\"><\/div>\n    <section class=\"tiles\" id=\"tiles\" aria-label=\"Ringkasan\"><\/section>\n    <div>\n      <div class=\"tabs\" role=\"tablist\">\n        <button class=\"tab\" role=\"tab\" id=\"tab-list\" aria-selected=\"true\" type=\"button\">Pengajuan<\/button>\n        <button class=\"tab\" role=\"tab\" id=\"tab-db\" aria-selected=\"false\" type=\"button\" hidden>Database utama<\/button>\n        <button class=\"tab\" role=\"tab\" id=\"tab-users\" aria-selected=\"false\" type=\"button\" hidden>Pengguna dan riwayat<\/button>\n      <\/div>\n    <\/div>\n    <section id=\"listView\" style=\"display:flex;flex-direction:column;gap:12px\">\n      <div class=\"bar\">\n        <div class=\"chips\" id=\"areaChips\" role=\"group\" aria-label=\"Filter area\"><\/div>\n        <input type=\"search\" id=\"q\" placeholder=\"Cari no. form, nama, nopol, tujuan\" aria-label=\"Cari pengajuan\" style=\"flex:1 1 220px;max-width:340px\">\n        <select id=\"stSel\" aria-label=\"Filter status\">\n          <option value=\"ALL\">Semua status<\/option>\n          <option value=\"WAIT\">Menunggu ACC Armada Pusat<\/option>\n          <option value=\"PARK\">Diparkir, menunggu ACC Manager Armada<\/option>\n          <option value=\"GO\">Berangkat<\/option>\n        <\/select>\n      <\/div>\n      <div class=\"count\" id=\"count\"><\/div>\n      <div class=\"panel tbl\" id=\"tbl\"><\/div>\n    <\/section>\n    <section id=\"dbView\" hidden style=\"display:flex;flex-direction:column;gap:12px\">\n      <div class=\"tiles\" id=\"dbTiles\"><\/div>\n      <div class=\"bar\">\n        <select id=\"dbArea\" aria-label=\"Filter area\"><\/select>\n        <select id=\"dbRange\" aria-label=\"Rentang waktu\"><option value=\"\">Semua waktu<\/option><option value=\"today\">Hari ini<\/option><option value=\"7\">7 hari terakhir<\/option><\/select>\n        <input type=\"search\" id=\"dbQ\" placeholder=\"Cari no. form, nama, nopol, tujuan\" aria-label=\"Cari isian formulir\" style=\"flex:1 1 220px;max-width:340px\">\n        <button class=\"btn alt sm\" id=\"dbCsv\" type=\"button\">Unduh CSV<\/button>\n      <\/div>\n      <div class=\"count\" id=\"dbInfo\" role=\"status\"><\/div>\n      <div class=\"count\" id=\"dbCount\"><\/div>\n      <div class=\"panel tbl\" id=\"dbTbl\"><\/div>\n    <\/section>\n    <section id=\"usersView\" hidden style=\"display:flex;flex-direction:column;gap:14px\"><\/section>\n  <\/div>\n<\/div>\n<div class=\"veil\" id=\"veil\"><\/div>\n<aside class=\"dr\" id=\"dr\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"drT\" aria-hidden=\"true\">\n  <div class=\"dh\"><div><h3 id=\"drT\"><\/h3><p class=\"num\" id=\"drS\"><\/p><\/div><button class=\"dx\" id=\"drX\" type=\"button\" aria-label=\"Tutup detail\">×<\/button><\/div>\n  <div class=\"db\" id=\"drB\"><\/div>\n<\/aside>",run:function(document){

(()=>{
const SERVER='Google Sheets';
const ACC_ID='1uwenWPo9NR9rkTfZpHuJaXQFEGnspVjg0Ty6K4xpSDI';
const FORM_ID='1V18f6If7Emm_bgpfuMUnLiJDCzA-4w1bAnM7D5EhJjw';
let TTD_STAF='',TTD_MGR='',CHK='';/* tanda tangan dan template: diambil dari server setelah login, tidak ada di berkas publik */
const NAMA_PUSAT='IZAKI ARVIO MUTTAQIN';
const NAMA_MGR='ABDURRAHMAN';
const SEED=[['PST','PUSAT'],['CPY','CIPAYUNG'],['MRD','MARUNDA'],['BDG','BANDUNG'],['CKR','CIKARANG'],['KLW','KALIWUNGU'],['BGR','BOGOR'],['LGD','LEGUNDI'],['MDN','MADIUN'],['TGR','TANGERANG'],['BJM','BANJARMASIN'],['PRB','PROBOLINGGO'],['MKS','MAKASSAR'],['DLS','DELISERDANG'],['LPG','LAMPUNG']];
const BULAN=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtN=n=>Number(n).toLocaleString('id-ID');
const pad=n=>String(n).padStart(2,'0');
const tglL=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()]} ${d.getFullYear()}`:'';
const tglS=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()].slice(0,3)} ${d.getFullYear()}`:'–';
const jam=d=>d?`${pad(d.getHours())}:${pad(d.getMinutes())}`:'';
let mcp=null,db=null,user=null;
const ME={id:null,role:null,areas:[]};
const REAL={role:null,areas:[]};
let DBROWS=[],DBSEEN=null,DBUNSUB=null,DBAT=0,DBERR='',DBNEW=new Set();
let SIM=null,SIMO={};/* mode uji peran: tidak pernah menulis ke spreadsheet */
let AREAS={},ROWS=[],LOADED=0,PROBLEMS=[],SYNC=[];
const OVR={};/* hasil tulis yang belum sampai ke sheet gabungan (IMPORTRANGE butuh beberapa detik) */
const S={area:'ALL',q:'',st:'ALL',tab:'list',cur:null,busy:false,confirm:null};

async function loadPrivateAssets(){
  const get=async n=>{try{const r=await fetch('/api/asset/'+n,{credentials:'same-origin'});if(!r.ok)return '';const b=await r.blob();
    return await new Promise(res=>{const f=new FileReader();f.onload=()=>res(String(f.result));f.onerror=()=>res('');f.readAsDataURL(b)})}catch(e){return ''}};
  [TTD_STAF,TTD_MGR,CHK]=await Promise.all([get('ttd_staf.png'),get('ttd_mgr.png'),get('chk.jpg')]);
}

/* ---------- sumber data: Google Sheets lewat server ---------- */
async function getVals(id,range){
  const r=await mcp.callTool(SERVER,'get_values',{spreadsheetId:id,range},{cache:false});
  let v=r&&r.payload&&r.payload.values;
  if(!v){try{v=JSON.parse(r.content[0].text).values}catch(e){v=null}}
  return v||[];
}
const putVals=(id,range,values)=>mcp.callTool(SERVER,'update_values',{spreadsheetId:id,range,values},{cache:false});
function errText(e,ctx){
  const c=e&&e.code,m=(e&&e.message)||'',w=ctx||'Spreadsheet';
  if(c==='unauthenticated')return 'Sesi berakhir. Muat ulang halaman lalu masuk lagi.';
  if(c==='forbidden')return m||'Akun Anda tidak berwenang untuk data ini.';
  if(c==='sheets_denied')return w+': Google menolak akses. Bagikan spreadsheet ini ke akun layanan server (email service account) sebagai Editor, lalu klik Muat ulang.';
  if(c==='sheets_not_configured')return 'Server belum disambungkan ke Google Sheets. Hubungi admin sistem.';
  if(c==='sheets_auth_failed')return 'Server gagal masuk ke Google. Periksa kunci service account.';
  if(c==='sheets_unavailable')return 'Google Sheets sedang tidak merespons. Coba muat ulang sebentar lagi.';
  if(c==='sheets_error')return w+': '+m.slice(0,160);
  if(c==='rate_limited')return 'Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.';
  if(c==='network')return 'Server tidak bisa dihubungi. Periksa koneksi internet Anda.';
  if(c==='bad_request')return m||'Permintaan tidak valid.';
  return 'Gagal mengakses Google Sheets ('+(c||'error')+').';
}

/* ---------- tanggal ---------- */
function parseDT(s,order){
  const m=String(s||'').trim().match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if(!m)return null;
  const a=+m[1],b=+m[2],d=order==='dmy'?a:b,mo=order==='dmy'?b:a;
  const t=new Date(+m[3],mo-1,d,+(m[4]||0),+(m[5]||0),+(m[6]||0));
  return isNaN(t)||t.getMonth()!==mo-1?null:t;
}
function detectOrder(vals){
  let dmy=0,mdy=0;
  for(const r of vals){
    for(const i of [0,15,16,18]){
      const m=String(r[i]||'').match(/^(\d{1,2})\/(\d{1,2})\//);if(!m)continue;
      if(+m[1]>12)dmy+=3;else if(+m[2]>12)mdy+=3;
    }
    const n=String(r[1]||'').match(/^[A-Z]{3}(\d{2})(\d{2})(\d{2})\d{3}$/),t=String(r[0]||'').match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
    if(n&&t){
      const y=2000+ +n[1],mo=+n[2],d=+n[3];
      if(+t[3]===y&&+t[1]===d&&+t[2]===mo)dmy++;
      if(+t[3]===y&&+t[2]===d&&+t[1]===mo)mdy++;
    }
  }
  return mdy>dmy?'mdy':'dmy';
}
const B=v=>v===true||String(v).toUpperCase()==='TRUE';
/* Cocokkan area: kode persis, lalu nama lengkap area (kolom ASAL), lalu awalan kode (JMB = JMBR). */
const nz=x=>String(x||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
function areaCode(nomor,asal){
  const L=((String(nomor||'').toUpperCase().match(/^[A-Z]+/)||[''])[0])||String(nomor||'').slice(0,3).toUpperCase();
  const ks=Object.keys(AREAS);
  if(AREAS[L])return L;
  const na=nz(asal);
  if(na){
    const hit=ks.filter(c=>nz(AREAS[c].name)===na);
    if(hit.length)return hit.find(c=>AREAS[c].sheetId)||hit[0];
    const hit2=ks.filter(c=>nz(AREAS[c].name).length>=4&&(na.includes(nz(AREAS[c].name))||nz(AREAS[c].name).includes(na)&&na.length>=4));
    if(hit2.length===1)return hit2[0];
  }
  if(L.length>=2){const p=ks.filter(c=>c.startsWith(L)||L.startsWith(c));if(p.length)return p.find(c=>AREAS[c].sheetId)||p[0]}
  return L.slice(0,3)||L;
}
/* Samakan kode area yang berbeda penulisan (JMB/JMBR) agar semuanya menunjuk ke spreadsheet yang terdaftar. */
function reconcileAreas(){
  let ks=Object.keys(AREAS);
  for(const c of ks){
    const a=AREAS[c];if(a.sheetId)continue;
    const alt=ks.find(k=>k!==c&&AREAS[k].sheetId&&(nz(AREAS[k].name)===nz(a.name)||k.startsWith(c)||c.startsWith(k)));
    if(alt)delete AREAS[c];/* alias tanpa spreadsheet: gabung ke area terdaftar */
  }
  ks=Object.keys(AREAS);
  const canon=c=>{
    if(AREAS[c]&&AREAS[c].sheetId)return c;
    const k=ks.find(k=>AREAS[k].sheetId&&(nz(AREAS[k].name)===nz(c)||k.startsWith(c)||c.startsWith(k)));
    return k||c;
  };
  const f=l=>[...new Set((l||[]).map(canon))];
  ME.areas=f(ME.areas);REAL.areas=f(REAL.areas);
}
function mkRow(r,order,src){
  const g=i=>String(r[i]==null?'':r[i]).trim(),nomor=g(1);
  if(!nomor)return null;
  return {nomor,code:areaCode(nomor,g(9)),ts:parseDT(g(0),order),nama:g(2),ktp:g(3),sim:g(4),wa:g(5),telp:g(6),sp:g(7),nopol:g(8),asal:g(9),tujLok:g(10),tuj:g(11),jenis:g(12),merk:g(13),grup:g(14),pinjam:parseDT(g(15),order),kembali:parseDT(g(16),order),ar:B(r[17]),tglAcc:parseDT(g(18),order),pu:src==='ACC'&&r.length>24&&String(r[24]).trim()!==''?B(r[24]):B(r[19]),ac:src!=='ACC'&&src!=='FORM'?B(r[24]):false,back:/DIKEMBALIKAN/i.test(g(20)),src};
}
const areaName=r=>(AREAS[r.code]&&AREAS[r.code].name)||r.asal||r.code;
function stat(r){
  if(r.back)return {k:'back',t:'Telah dikembalikan',d:'Unit sudah dikembalikan dan form pemeriksaan sudah diunggah'};
  if(r.ar&&r.pu)return {k:'go',t:'Berangkat',d:'Disetujui Armada Pusat dan Manager'};
  if(r.ar)return {k:'park',t:'Diparkir',d:'ACC Armada Pusat selesai, menunggu ACC Manager Armada'};
  if(r.pu)return {k:'first',t:'ACC Armada Pusat dulu',d:'ACC Manager Armada sudah, ACC Armada Pusat belum dicentang'};
  if(r.ac)return {k:'wait',t:'ACC area',d:'Sudah di-ACC area, menunggu ACC Armada Pusat'};
  return {k:'wait',t:'Menunggu ACC',d:'Belum ada persetujuan'};
}
const isAdminLike=()=>ME.role==='admin'||ME.role==='pusat';
const canAR=r=>isAdminLike();
const canAC=r=>isAdminLike()||(ME.role==='daerah'&&ME.areas.includes(r.code));
const canPU=()=>isAdminLike();
const NAMES={PST:'PUSAT',CPY:'CIPAYUNG',MRD:'MARUNDA',BDG:'BANDUNG',CKR:'CIKARANG',KLW:'KALIWUNGU',BGR:'BOGOR',LGD:'LEGUNDI',MDN:'MADIUN',TGR:'TANGERANG',BJM:'BANJARMASIN',PRB:'PROBOLINGGO',MKS:'MAKASSAR',DLS:'DELISERDANG',LPG:'LAMPUNG',PJG:'PEJAGAN',PKB:'PEKANBARU',SLK:'SOLOK',PLB:'PALEMBANG',JMBR:'JEMBRANA',BPN:'BALIKPAPAN',PNK:'PONTIANAK'};
const unitTitle=()=>ME.role==='daerah'&&ME.areas.length?('ARMADA '+ME.areas.map(c=>((AREAS[c]&&AREAS[c].name)||NAMES[c]||c).toUpperCase()).join(', ')):'ARMADA PUSAT';
const roleLabel=()=>ME.role==='admin'?'Admin':ME.role==='pusat'?'Armada Pusat':'Armada Daerah'+(ME.areas.length?' · '+ME.areas.map(c=>(AREAS[c]&&AREAS[c].name)||c).join(', '):'');

/* ---------- area dan data ---------- */
async function loadAreas(){
  AREAS={};SEED.forEach(([c,n])=>AREAS[c]={name:n,sheetId:''});
  try{
    const r=await window.__api.get('/api/areas');
    for(const [c,a] of Object.entries(r.areas||{}))AREAS[c]={name:a.name||(AREAS[c]&&AREAS[c].name)||c,sheetId:a.sheetId||''};
    if(r.error)PROBLEMS.push('Daftar area dari sheet MASTER belum terbaca: '+String(r.error).slice(0,120));
  }catch(e){PROBLEMS.push(errText(e,'Daftar area'))}
  reconcileAreas();
}
async function fillAc(rows){
  const codes=[...new Set(rows.map(r=>r.code))].filter(c=>AREAS[c]&&AREAS[c].sheetId);
  await Promise.all(codes.map(async c=>{
    try{
      const v=await getVals(AREAS[c].sheetId,"'DATA PEMINJAM'!B5:Y3000"),m=new Map();
      v.forEach(x=>{const n=String((x&&x[0])||'').trim();if(n)m.set(n,B(x[23]))});
      rows.forEach(r=>{if(r.code===c)r.ac=!!m.get(r.nomor)});
    }catch(e){}
  }));
}
/* Pengajuan yang sudah ada di database formulir tetapi belum ditarik ke ACC PUSAT (biasanya izin IMPORTRANGE area belum diberikan) */
async function checkSync(rows){
  SYNC=[];
  if(!isAdminLike()||SIM)return;
  try{
    const v=await getVals(FORM_ID,"'DATA'!A2:Q5000"),o=detectOrder(v),have=new Set(rows.map(r=>r.nomor));
    SYNC=v.map(r=>mkRow(r,o,'FORM')).filter(Boolean).filter(r=>!have.has(r.nomor)&&r.ts&&Date.now()-r.ts>10*60000);
  }catch(e){}
}
async function loadData(){
  PROBLEMS=PROBLEMS.slice(0,0);
  let rows=[];
  if(isAdminLike()||SIM){
    try{
      let v=await getVals(ACC_ID,"'ACC PUSAT'!A2:Y5000"),o=detectOrder(v);
      rows=v.map(r=>mkRow(r,o,'ACC')).filter(Boolean);
      /* IMPORTRANGE kadang sesaat mengosongkan satu area saat menyegarkan: bila ada form lama yang belum tampak, baca ulang sekali */
      if(isAdminLike()&&!SIM){
        try{
          const f=await getVals(FORM_ID,"'DATA'!A2:Q5000"),fo=detectOrder(f);
          const miss=()=>{const have=new Set(rows.map(r=>r.nomor));return f.map(r=>mkRow(r,fo,'FORM')).filter(Boolean).some(r=>!have.has(r.nomor)&&r.ts&&Date.now()-r.ts>10*60000)};
          if(Date.now()-(window.__syncRetry||0)>60000&&miss()){window.__syncRetry=Date.now();await new Promise(z=>setTimeout(z,2500));v=await getVals(ACC_ID,"'ACC PUSAT'!A2:Y5000");o=detectOrder(v);rows=v.map(r=>mkRow(r,o,'ACC')).filter(Boolean)}
        }catch(e){}
      }
      if(ME.role==='daerah')rows=rows.filter(r=>ME.areas.includes(r.code));
      await fillAc(rows);
    }catch(e){PROBLEMS.push(errText(e,'ACC ARMADA PUSAT'))}
  }else{
    for(const c of ME.areas){
      const a=AREAS[c];
      if(!a||!a.sheetId){PROBLEMS.push('Spreadsheet area '+((a&&a.name)||c)+' belum didaftarkan. Minta admin menyinkronkannya.');continue}
      try{
        const v=await getVals(a.sheetId,"'DATA PEMINJAM'!A5:Y3000"),o=detectOrder(v);
        rows.push(...v.map(r=>mkRow(r,o,c)).filter(Boolean).map(r=>(r.code=c,r)));
      }catch(e){PROBLEMS.push(errText(e,'Area '+a.name))}
    }
  }
  if(db&&!SIM){try{const sn=await db.collection('kstat').get(),m=new Map();sn.docs.forEach(d=>m.set(d.id,d.data()));rows.forEach(r=>{const x=m.get(r.nomor);if(x){r.kst=x;if(x.returned)r.back=true}})}catch(e){}}
  const now=Date.now();
  for(const r of rows){const o=OVR[r.nomor];if(!o)continue;if(now-o.t>180000){delete OVR[r.nomor];continue}for(const k of ['ar','pu','ac']){if(k in o){if(r[k]===o[k])delete o[k];else{r[k]=o[k];if(k==='ar'&&o.ar&&!r.tglAcc)r.tglAcc=new Date(o.t)}}}if(!('ar' in o)&&!('pu' in o)&&!('ac' in o))delete OVR[r.nomor]}
  if(SIM)for(const r of rows){const o=SIMO[r.nomor];if(!o)continue;if('ar' in o){r.ar=o.ar;if(o.ar&&!r.tglAcc)r.tglAcc=new Date(o.t)}if('pu' in o)r.pu=o.pu;if('ac' in o)r.ac=o.ac}
  const seen=new Map();rows.forEach(r=>seen.set(r.nomor,r));
  ROWS=[...seen.values()].sort((a,b)=>((b.ts?+b.ts:0)-(a.ts?+a.ts:0))||b.nomor.localeCompare(a.nomor));
  await checkSync(ROWS);
  LOADED=Date.now();
}

/* ---------- tampilan ---------- */
function gate(h,p,btn){
  $('gate').hidden=false;$('app').hidden=true;
  $('gate').innerHTML=`<h2>${esc(h)}</h2><p>${esc(p)}</p>`+(btn?`<button class="btn" id="gateBtn" type="button">${esc(btn)}</button>`:'');
  if(btn)$('gateBtn').onclick=boot;
}
function visibleRows(base){
  const q=S.q.trim().toLowerCase();
  return ROWS.filter(r=>{
    if(base)return true;
    if(S.area!=='ALL'&&r.code!==S.area)return false;
    if(q&&!(r.nomor+' '+r.nama+' '+r.nopol+' '+r.tuj+' '+r.tujLok).toLowerCase().includes(q))return false;
    const s=stat(r).k;
    if(S.st==='WAIT'&&r.ar)return false;
    if(S.st==='PARK'&&s!=='park')return false;
    if(S.st==='GO'&&s!=='go')return false;
    return true;
  });
}
function render(){
  $('gate').hidden=true;$('app').hidden=false;
  {const u=$('unitName');if(u)u.textContent=unitTitle()}
  $('roleTag').hidden=false;$('roleTag').textContent=roleLabel();
  $('reload').hidden=false;
  $('stamp').textContent=LOADED?'Dibaca '+pad(new Date(LOADED).getHours())+':'+pad(new Date(LOADED).getMinutes()):'';
  const b=$('banner');const syncMsg=SYNC.length?[SYNC.length+' pengajuan sudah ada di database formulir tetapi belum masuk ke ACC PUSAT: '+SYNC.slice(0,5).map(r=>r.nomor+' ('+areaName(r)+')').join(', ')+(SYNC.length>5?' dan '+(SYNC.length-5)+' lainnya':'')+'. Biasanya izin akses (Allow access) untuk area itu belum diberikan. Buka sheet ACC PUSAT, tab IZIN AKSES.']:[];
  const msgs=(SIM?['Mode uji peran aktif: Anda melihat halaman sebagai '+roleLabel()+'. Tidak ada perubahan yang dikirim ke spreadsheet.']:[]).concat(PROBLEMS,syncMsg);b.hidden=!msgs.length;b.innerHTML=msgs.map(esc).join('<br>');b.classList.toggle('info',!!SIM&&!PROBLEMS.length&&!syncMsg.length);
  $('tab-users').hidden=REAL.role!=='admin'||!!SIM||!!window.__acct;
  $('tab-db').hidden=!isAdminLike();
  if($('tab-db').hidden&&S.tab==='db')tab('list');
  const area=ROWS.filter(r=>S.area==='ALL'||r.code===S.area);
  const nW=area.filter(r=>!r.ar).length,nP=area.filter(r=>r.ar&&!r.pu).length,nG=area.filter(r=>r.ar&&r.pu).length;
  $('tiles').innerHTML=`<div class="panel tile"><span class="k">Total pengajuan</span><span class="v num">${fmtN(area.length)}</span><span class="s">${S.area==='ALL'?'semua area':esc((AREAS[S.area]||{}).name||S.area)}</span></div>
  <div class="panel tile t-wait"><span class="k">Menunggu ACC Armada Pusat</span><span class="v num">${fmtN(nW)}</span><span class="s">${fmtN(area.filter(r=>!r.ar&&r.ac).length)} sudah di-ACC area</span></div>
  <div class="panel tile t-park"><span class="k">Diparkir</span><span class="v num">${fmtN(nP)}</span><span class="s">menunggu ACC Manager Armada</span></div>
  <div class="panel tile t-go"><span class="k">Berangkat</span><span class="v num">${fmtN(nG)}</span><span class="s">sudah disetujui lengkap</span></div>`;
  // chip area
  const cnt={};ROWS.forEach(r=>cnt[r.code]=(cnt[r.code]||0)+1);
  const codes=isAdminLike()?Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]):ME.areas.slice();
  let ch=codes.length>1?`<button class="chip" type="button" data-a="ALL" aria-pressed="${S.area==='ALL'}">Semua area<span class="c">${fmtN(ROWS.length)}</span></button>`:'';
  ch+=codes.map(c=>`<button class="chip" type="button" data-a="${esc(c)}" aria-pressed="${S.area===c}">${esc((AREAS[c]||{}).name||c)}<span class="c">${fmtN(cnt[c]||0)}</span></button>`).join('');
  $('areaChips').innerHTML=ch;
  const rows=visibleRows();
  $('count').textContent=`${fmtN(rows.length)} pengajuan · klik baris untuk melihat form fisik dan menyetujui`;
  if(!rows.length){$('tbl').innerHTML=`<div class="empty">${ROWS.length?'Tidak ada pengajuan yang cocok dengan filter ini.':'Belum ada data pengajuan yang bisa dibaca untuk akun ini.'}</div>`;return}
  $('tbl').innerHTML=`<table><thead><tr><th>No. form</th><th>Peminjam</th><th>Area</th><th>Tujuan</th><th>Pinjam sampai kembali</th><th>ACC area</th><th>ACC Armada Pusat</th><th>ACC Manager Armada</th><th>Status</th></tr></thead><tbody>${rows.slice(0,300).map(r=>{const s=stat(r);return `<tr tabindex="0" data-n="${esc(r.nomor)}"><td class="num">${esc(r.nomor)}</td><td>${esc(r.nama)}<small class="num">${esc(r.nopol)}${r.jenis?' · '+esc(r.jenis):''}</small></td><td>${esc(areaName(r))}</td><td>${esc(r.tujLok)}<small>${esc(r.tuj)}</small></td><td class="num">${tglS(r.pinjam)}<small>sampai ${tglS(r.kembali)}</small></td><td>${r.ac?'<span class="pill p-park">Sudah</span>':'<span class="pill p-na">Belum</span>'}</td><td>${r.ar?`<span class="pill p-park">Sudah</span><small class="num">${tglS(r.tglAcc)} ${jam(r.tglAcc)}</small>`:'<span class="pill p-na">Belum</span>'}</td><td>${r.pu?'<span class="pill p-go">Sudah</span>':'<span class="pill p-na">Belum</span>'}</td><td><span class="pill p-${s.k}">${s.t}</span></td></tr>`}).join('')}</tbody></table>`+(rows.length>300?`<div class="empty">Menampilkan 300 pengajuan terbaru. Persempit dengan pencarian atau filter area.</div>`:'');
}

/* ---------- form fisik ---------- */
function checklistHTML(r){
  const v=(l,t,w,s)=>`<div class="v" style="left:${l}%;top:${t}%;max-width:${w}%">${esc(s||'')}</div>`;
  return `<div class="paper ck" id="paperck"><div class="in"><img class="bg" src="${CHK}" alt="">
  ${v(20.3,20.9,16.8,r.asal)}${v(20.3,23.5,16.8,[r.jenis,r.merk].filter(Boolean).join(' '))}${v(20.3,26.5,16.8,r.nama)}
  ${v(51.9,20.9,18,tglL(r.pinjam))}${v(51.9,23.5,18,r.nopol)}</div></div>`;
}
function formHTML(r){
  const a=r.ar,p=r.pu,nmArea=areaName(r);
  const f=(k,v)=>`<dt>${k}</dt><span class="c">:</span><dd>${esc(v||'')}</dd>`;
  return `<div class="paper" id="paper">
  <div class="hd"><img src="${document.querySelector('.logo').src}" alt=""><h1>FORMULIR PEMINJAMAN UNIT OPERASIONAL MANAGEMEN</h1></div>
  <dl>${f('NO. FORM PEMINJAMAN',r.nomor)}${f('NAMA',r.nama)}${f('NO. KTP',r.ktp)}${f('NO SIM',r.sim)}${f('ALAMAT TUJUAN',r.tujLok)}${f('NO WHATSAPP',r.wa)}${f('NO TELFON AKTIF',r.telp)}<div class="gap"></div>${f('STATUS PEMINJAM',r.sp)}${f('NOPOL UNIT ARMADA',r.nopol)}${f('JENIS UNIT ARMADA',r.jenis)}${f('MERK UNIT ARMADA',r.merk)}${f('LOKASI TERAKHIR UNIT',r.asal)}${f('GROUP UNIT',r.grup)}${f('TANGGAL PINJAM',tglL(r.pinjam))}${f('PELAPORAN TANGGAL KEMBALI',tglL(r.kembali))}</dl>
  <h2>Aturan Peminjaman Unit Armada Baraka Express</h2>
  <ol><li>Setiap peminjaman unit kendaraan menjadi tanggung jawab penuh peminjam, termasuk segala akibat, risiko, dan kerusakan yang terjadi selama masa penggunaan.</li><li>Peminjam wajib menjaga dan menggunakan kendaraan dengan baik; segala bentuk kerusakan, kehilangan, atau konsekuensi hukum yang timbul selama peminjaman sepenuhnya menjadi tanggung jawab peminjam.</li><li>Unit kendaraan yang dipinjam harus dikembalikan dalam kondisi semula. Apabila terjadi kerusakan atau kehilangan, seluruh biaya perbaikan dan/atau penggantian ditanggung oleh peminjam.</li><li>Peminjaman kendaraan bersifat tanggung jawab pribadi; segala akibat yang timbul selama penggunaan, baik kerusakan ringan maupun berat, menjadi beban peminjam.</li></ol>
  <p>Dengan ini menyatakan dengan kondisi sadar bahwa saya meminjam kendaraan milik perusahaan PT Baraka Sarana Tama sesuai dengan data diatas dan menyetujui Aturan Peminjaman Unit Armada Baraka Express secara jelas.</p>
  <div class="sig">
    <div><div class="h">PEMINJAM</div><div class="box"></div><div class="nm">${esc(r.nama)}</div></div>
    <div><div class="h">STAF ARMADA</div><div class="box"></div><div class="nm">ARMADA ${esc(nmArea)}</div></div>
    <div><div class="h">ARMADA PUSAT</div><div class="box" data-ttd="staf" data-on="${a?1:0}">${a?`<img src="${TTD_STAF}" alt="Tanda tangan Armada Pusat">`:''}</div><div class="nm">${NAMA_PUSAT}</div></div>
    <div style="grid-column:2;margin-top:14px"><div class="h">MANAGER ARMADA</div><div class="box" data-ttd="mgr" data-on="${p?1:0}">${p?`<img src="${TTD_MGR}" alt="Tanda tangan dan stempel Manager Armada">`:''}</div><div class="nm">${NAMA_MGR}</div></div>
  </div></div>`;
}
async function savePdf(r,btn){
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){$('pdfMsg').textContent='Penyimpanan file tidak tersedia di tampilan ini.';return}
  if(!window.html2canvas||!window.jspdf){$('pdfMsg').textContent='Pustaka PDF belum termuat. Pakai tombol Cetak form.';return}
  btn.disabled=true;$('pdfMsg').textContent='Menyiapkan PDF …';
  const host=document.createElement('div');host.style.cssText='position:fixed;left:-9999px;top:0;width:813px;background:#fff';
  const pcss='.paper{--paper:#fff;--ink:#0b0b0b}\n'+document.querySelector('style').textContent.split('\n').filter(l=>l.startsWith('.paper')).join('\n');
  host.innerHTML='<style>'+pcss+'</style>'+formHTML(r)+checklistHTML(r);(window.__realDoc||document).body.appendChild(host);
  try{
    await Promise.all([...host.querySelectorAll('img')].map(i=>i.decode?i.decode().catch(()=>{}):0));
    const {jsPDF}=window.jspdf,doc=new jsPDF({unit:'pt',format:[609.45,935.43]});
    const pw=doc.internal.pageSize.getWidth(),ph=doc.internal.pageSize.getHeight();
    let first=true;
    for(const el of host.children){
      if(!el.classList.contains('paper'))continue;
      const cv=await html2canvas(el,{scale:2,backgroundColor:'#ffffff'});
      let w=pw,h=cv.height*w/cv.width;if(h>ph){h=ph;w=cv.width*h/cv.height}
      if(!first)doc.addPage();first=false;
      doc.addImage(cv.toDataURL('image/jpeg',.92),'JPEG',(pw-w)/2,0,w,h);
    }
    await dl.save({filename:`Form Peminjaman ${r.nomor}.pdf`,data:doc.output('blob')});
    $('pdfMsg').textContent='PDF siap disimpan.';
  }catch(e){$('pdfMsg').textContent=(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'PDF gagal dibuat ('+((e&&e.code)||'error')+').'}
  finally{host.remove();btn.disabled=false}
}

async function saveHtml(r){
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){$('pdfMsg').textContent='Penyimpanan file tidak tersedia di tampilan ini.';return}
  const css=document.querySelector('style').textContent.split('\n').filter(l=>l.startsWith('.paper')).join('\n');
  const html='<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Form Peminjaman '+esc(r.nomor)+'</title><style>@page{size:215mm 330mm;margin:0}body{margin:0;background:#fff;--paper:#fff;--ink:#0b0b0b}'+css+'.paper{margin:0 auto}.paper.ck{height:1247px}</style></head><body>'+formHTML(r)+checklistHTML(r)+'<script>addEventListener("load",function(){setTimeout(function(){print()},500)})<\/script></body></html>';
  try{await dl.save({filename:'Form Peminjaman '+r.nomor+'.html',data:new Blob([html],{type:'text/html'})});$('pdfMsg').textContent='File siap disimpan. Buka file itu dan dialog cetak akan muncul sendiri.'}
  catch(e){$('pdfMsg').textContent=(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'Gagal menyiapkan file ('+((e&&e.code)||'error')+').'}
}

/* ---------- laci detail dan persetujuan ---------- */
function openRow(n,from){
  const r=ROWS.find(x=>x.nomor===n)||DBROWS.find(x=>x.nomor===n);if(!r)return;S.cur=n;S.confirm=null;S.from=from;
  $('drT').textContent=r.nama;$('drS').textContent=r.nomor;
  drawDetail(r);
  $('veil').classList.add('on');$('dr').classList.add('on');$('dr').setAttribute('aria-hidden','false');$('drX').focus();
}
function closeRow(){
  if(!$('dr').classList.contains('on'))return;
  $('veil').classList.remove('on');$('dr').classList.remove('on');$('dr').setAttribute('aria-hidden','true');S.cur=null;
  if(S.from&&document.contains(S.from))S.from.focus();
}
function drawDetail(r){
  const s=stat(r),nf=r.src==='FORM';
  const mk=(k,lbl,ok,hint)=>nf?`<button class="btn alt" disabled type="button">${lbl}</button>`:!ok?`<button class="btn alt" disabled type="button">${lbl}</button><span class="hint">${hint}</span>`
    :`<button class="btn ${r[k]?'warn':''}" id="b${k.toUpperCase()}" type="button" data-k="${k}" ${S.busy?'disabled':''}>${S.confirm===k?'Klik lagi untuk memastikan':r[k]?'Batalkan '+lbl:lbl}</button>`;
  const acBtn=mk('ac','ACC area',canAC(r),'Area ini bukan wewenang akun Anda.');
  const arBtn=mk('ar','ACC Armada Pusat',canAR(r),'Hanya Armada Pusat dan Admin.');
  const puBtn=nf?`<button class="btn alt" disabled type="button">ACC Manager Armada</button><span class="hint">Pengajuan ini belum masuk ke sheet ACC pusat, jadi belum bisa disetujui. Biasanya area belum terdaftar atau data belum tersinkron.</span>`:!canPU()?`<button class="btn alt" disabled type="button">ACC Manager Armada</button><span class="hint">Hanya Armada Pusat dan Admin.</span>`

    :`<button class="btn ${r.pu?'warn':''}" id="bPU" type="button" data-k="pu" ${S.busy?'disabled':''}>${S.confirm==='pu'?'Klik lagi untuk memastikan':r.pu?'Batalkan ACC Manager Armada':'ACC Manager Armada'}</button>`;
  $('drB').innerHTML=`<div><span class="lbl">Persetujuan</span>
    <div class="steps" style="margin-top:8px">
      <div class="step done"><b>1. Diajukan</b><small>${tglS(r.ts)} ${jam(r.ts)}</small></div>
      <div class="step ${r.ac?'done':''}"><b>2. ACC area</b><small>${r.ac?'sudah':'belum'}</small></div>
      <div class="step ${r.ar?'done':''}"><b>3. ACC Armada Pusat</b><small>${r.ar?tglS(r.tglAcc)+' '+jam(r.tglAcc):'belum'}</small></div>
      <div class="step ${r.pu?'done':''}"><b>4. ACC Manager Armada</b><small>${r.pu?'sudah':'belum'}</small></div>
    </div></div>
    <div><span class="pill p-${s.k}">${s.t}</span> <span class="hint">${esc(s.d)}</span></div>
    <div class="act"><div class="act">${acBtn}</div><div class="act">${arBtn}</div><div class="act">${puBtn}</div></div>
    <div class="msg" id="actMsg" role="status"></div>
    <div id="berSec"></div>
    <div id="kemSec"></div>
    <div><span class="lbl">Form fisik</span>
      <div class="act" style="margin:8px 0"><button class="btn alt sm" id="pdfBtn" type="button">Unduh PDF</button><button class="btn alt sm" id="htmlBtn" type="button">Cetak form</button><span class="hint" id="pdfMsg"></span></div>
      <div class="sheetwrap">${formHTML(r)}<div style="height:12px"></div>${checklistHTML(r)}</div>
      <p class="hint">ACC area hanya centang, tanpa tanda tangan. Halaman 2 adalah checklist pemeriksaan kendaraan, terisi otomatis dari data pengajuan. Unduh PDF dan cetak memuat kedua halaman. Tanda tangan Armada Pusat muncul setelah ACC Armada Pusat dicentang. Tanda tangan dan stempel Manager Armada muncul setelah ACC Manager Armada dicentang.</p></div>`;
  $('pdfBtn').onclick=()=>savePdf(r,$('pdfBtn'));$('htmlBtn').onclick=()=>saveHtml(r);
  drawBerangkat(r);drawKembali(r);
  for(const id of ['bAC','bAR','bPU']){const b=$(id);if(b)b.onclick=()=>toggleAcc(r,b.dataset.k)}
}
/* ---------- pengembalian unit: kondisi, keterangan, dan foto form pemeriksaan setelah kembali ---------- */
const KEM_MAX=170000,FOTO_MAX=900000,DRIVE='Google Drive',FOLDER_KEM='1ogPsvCHhhVcY17J2bfwdISmThzg9J3VH'; /* ukuran foto tersimpan (karakter base64), dokumen database maksimal 256 KB */
function shrinkImg(file,max){
  max=max||KEM_MAX;
  return new Promise((res,rej)=>{
    const u=URL.createObjectURL(file),im=new Image();
    im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('Berkas ini bukan gambar yang bisa dibaca.'))};
    im.onload=()=>{
      URL.revokeObjectURL(u);
      let side=1500,q=.82;
      for(let i=0;i<10;i++){
        const k=Math.min(1,side/Math.max(im.width,im.height)),c=document.createElement('canvas');
        c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));
        const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(im,0,0,c.width,c.height);
        const d=c.toDataURL('image/jpeg',q);
        if(d.length<=max)return res(d);
        if(q>.5)q-=.1;else side=Math.round(side*.8);
      }
      rej(new Error('Foto terlalu besar. Coba foto dengan resolusi lebih kecil.'));
    };
    im.src=u;
  });
}
async function rowIn(r){
  const a=AREAS[r.code];if(!a||!a.sheetId)throw {code:'local',message:'Spreadsheet area '+areaName(r)+' belum didaftarkan.'};
  const keys=await getVals(a.sheetId,"'DATA PEMINJAM'!B5:B5000");
  const i=keys.findIndex(x=>String((x&&x[0])||'').trim()===r.nomor);
  if(i<0)throw {code:'local',message:'No. form tidak ditemukan di spreadsheet area. Muat ulang lalu coba lagi.'};
  return {sid:a.sheetId,row:5+i};
}
const b64=d=>d.slice(d.indexOf(',')+1);
const payOf=x=>{let v=x&&x.payload;if(!v){try{v=JSON.parse(x.content[0].text)}catch(e){}}return v||{}};
const stamp=()=>{const d=new Date();return pad(d.getDate())+pad(d.getMonth()+1)+String(d.getFullYear()).slice(2)+pad(d.getHours())+pad(d.getMinutes())+pad(d.getSeconds())};
async function putW(r,url,title){
  const w=await rowIn(r),cell=`'DATA PEMINJAM'!W${w.row}`;
  for(const sep of [';',',']){
    await mcp.callTool(SERVER,'update_formulas',{spreadsheetId:w.sid,range:cell,formulas:[[`=HYPERLINK("${url}"${sep}"${title}")`]]},{cache:false});
    const b=await getVals(w.sid,cell);
    if(String((b[0]&&b[0][0])||'')===title)return true;
  }
  return false;
}
const toPdfData=async d=>({dataUrl:d,ext:'pdf',mime:'application/pdf'}); /* server membungkus JPEG menjadi PDF */
async function driveUp(r,jenis,p,old){
  if(typeof p==='string')p={dataUrl:p};
  const up=payOf(await mcp.callTool(DRIVE,'create_file',{code:r.code,jenis,base64Content:b64(p.dataUrl),oldId:old&&old.id||''},{cache:false}));
  if(!up.id)throw {code:'local',message:'Google Drive tidak mengembalikan ID file.'};
  return {id:up.id,url:up.viewUrl||`https://drive.google.com/file/d/${up.id}/view?usp=drivesdk`,title:up.title,folder:up.folder};
}
function crc32(u){let t=crc32.t;if(!t){t=crc32.t=[];for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}}let r=-1;for(let i=0;i<u.length;i++)r=t[(r^u[i])&255]^(r>>>8);return(r^-1)>>>0}
function zipStore(files){
  const parts=[],cen=[],enc=new TextEncoder(),d=new Date();let off=0;
  const dt=((d.getFullYear()-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate(),tm=(d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1);
  for(const f of files){
    const nm=enc.encode(f.name),crc=crc32(f.data),n=f.data.length;
    const h=new DataView(new ArrayBuffer(30));h.setUint32(0,0x04034b50,true);h.setUint16(4,20,true);h.setUint16(6,0x0800,true);h.setUint16(10,tm,true);h.setUint16(12,dt,true);h.setUint32(14,crc,true);h.setUint32(18,n,true);h.setUint32(22,n,true);h.setUint16(26,nm.length,true);
    parts.push(new Uint8Array(h.buffer),nm,f.data);
    const c=new DataView(new ArrayBuffer(46));c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x0800,true);c.setUint16(12,tm,true);c.setUint16(14,dt,true);c.setUint32(16,crc,true);c.setUint32(20,n,true);c.setUint32(24,n,true);c.setUint16(28,nm.length,true);c.setUint32(42,off,true);
    cen.push(new Uint8Array(c.buffer),nm);off+=30+nm.length+n;
  }
  const cs=cen.reduce((a,x)=>a+x.length,0),e=new DataView(new ArrayBuffer(22));
  e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,cs,true);e.setUint32(16,off,true);
  return new Blob([...parts,...cen,new Uint8Array(e.buffer)],{type:'application/zip'});
}
const u8Of=d=>{const s=atob(d.slice(d.indexOf(',')+1)),u=new Uint8Array(s.length);for(let i=0;i<s.length;i++)u[i]=s.charCodeAt(i);return u};
const FOTO_BANYAK=10,FOTO_ZIP_MAX=300000;
/* satu foto tetap JPEG; beberapa foto digabung menjadi satu ZIP (tanpa kompresi ulang, JPEG sudah terkompresi) */
async function packPhotos(files,prefix){
  const n=files.length,max=n>1?FOTO_ZIP_MAX:FOTO_MAX,list=[];
  for(const f of files)list.push(await shrinkImg(f,max));
  if(n===1)return {dataUrl:list[0],ext:'jpeg',mime:'image/jpeg',n};
  const blob=zipStore(list.map((d,i)=>({name:prefix+'_'+String(i+1).padStart(2,'0')+'.jpg',data:u8Of(d)})));
  const dataUrl=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('ZIP gagal dibuat.'));fr.readAsDataURL(blob)});
  return {dataUrl,ext:'zip',mime:'application/zip',n};
}

const actor=()=>(window.__acct&&window.__acct.label)||ME.id||'';
/* v2 */
/* ---------- checklist keberangkatan: pemeriksaan dan kelengkapan kendaraan inventaris, diunggah setelah ACC Manager Armada (JPG atau PDF) ---------- */
async function drawBerangkat(r){
  const box=$('berSec');if(!box)return;
  if(!(r.ar&&r.pu)||r.src==='FORM'){box.innerHTML='';return}
  let ks=r.kst||null;
  if(db){try{const sn=await db.doc('kstat/'+r.nomor).get();if(sn.exists)ks=sn.data()||null}catch(e){}}
  if(S.cur!==r.nomor||!$('berSec'))return;
  const can=(canAC(r)||canAR(r))&&!SIM&&!!db;
  const has=!!(ks&&ks.berUrl);
  const fmt=t=>t?tglS(new Date(t))+' '+jam(new Date(t)):'';
  const head=`<span class="lbl">Checklist keberangkatan</span><div style="margin:6px 0">${has?'<span class="pill p-go">Sudah diunggah</span>':'<span class="pill p-na">Belum diunggah</span>'}${has&&ks.berAt?` <span class="hint">${esc(fmt(ks.berAt))}${ks.berBy?' oleh '+esc(ks.berBy):''}</span>`:''}</div>`;
  const ln=has?`<div class="hint" style="margin:6px 0">Berkas di Drive: <a href="${esc(ks.berUrl)}" target="_blank" rel="noopener">${esc(ks.berName||'buka di Drive')}</a></div>`:'';
  if(!can){
    box.innerHTML=`<div>${head}${ln}${has?'':'<p class="hint">Checklist pemeriksaan dan kelengkapan kendaraan inventaris yang sudah dicek sebelum berangkat belum diunggah.</p>'}</div>`;
    return;
  }
  box.innerHTML=`<div>${head}${ln}
    <p class="hint">Unggah checklist pemeriksaan dan kelengkapan kendaraan inventaris yang sudah dicek untuk keberangkatan. Format JPG atau PDF (PDF maksimal 4 MB).</p>
    <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${has?'Ganti checklist':'Pilih file JPG atau PDF'}<input id="berFile" type="file" accept=".jpg,.jpeg,image/jpeg,.pdf,application/pdf" hidden></label><button class="btn" id="berSave" type="button" disabled>${has?'Simpan checklist baru':'Unggah checklist'}</button></div>
    <div class="msg" id="berMsg" role="status"></div></div>`;
  const say=(t,err)=>{const m=$('berMsg');if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
  let pack=null;
  $('berFile').onchange=async ev=>{
    const f=ev.target.files&&ev.target.files[0];pack=null;$('berSave').disabled=true;if(!f)return;
    const isPdf=f.type==='application/pdf'||/\.pdf$/i.test(f.name),isJpg=f.type==='image/jpeg'||/\.jpe?g$/i.test(f.name);
    if(!isPdf&&!isJpg){say('Format harus JPG atau PDF.',true);ev.target.value='';return}
    say('Memproses berkas …');
    try{
      if(isPdf){
        if(f.size>4*1024*1024)throw new Error('PDF terlalu besar (maksimal 4 MB).');
        const d=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('PDF tidak terbaca.'));fr.readAsDataURL(f)});
        if(atob(d.slice(d.indexOf(',')+1,d.indexOf(',')+9)).slice(0,4)!=='%PDF')throw new Error('Berkas ini bukan PDF yang valid.');
        pack={dataUrl:d,ext:'pdf',mime:'application/pdf'};
      }else{
        pack={dataUrl:await shrinkImg(f,FOTO_MAX),ext:'jpg',mime:'image/jpeg'};
      }
      $('berSave').disabled=false;say((isPdf?'PDF':'Foto')+' siap: '+f.name+'. Tekan tombol di sebelahnya untuk menyimpan.');
    }catch(e){pack=null;say(e.message||'Berkas gagal diproses.',true)}
  };
  $('berSave').onclick=async()=>{
    if(!pack)return;
    $('berSave').disabled=true;say('Mengunggah ke Google Drive …');
    try{
      const d0=await driveUp(r,'CHECKLIST_BERANGKAT',pack,ks&&ks.berId?{id:ks.berId,folder:ks.berFolder}:null);
      const now=new Date().toISOString();
      await db.doc('kstat/'+r.nomor).set(Object.assign({nomor:r.nomor},ks||{},{berId:d0.id,berFolder:d0.folder,berUrl:d0.url,berName:d0.title,berAt:now,berBy:actor()}));
      try{if(db&&ME.id)db.collection('log').add({nomor:r.nomor,aksi:'berangkat_checklist',by:ME.id,at:now})}catch(e){}
      r.kst=Object.assign({nomor:r.nomor},ks||{},{berUrl:d0.url});
      say('Checklist keberangkatan tersimpan di Google Drive.');
      try{await mcp.invalidate()}catch(e){}
      await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
    }catch(e){say(e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':e&&e.code==='local'?e.message:errText(e,'Google Drive')+' Tidak ada yang diubah.',true);$('berSave').disabled=false}
  };
}
async function drawKembali(r){
  const box=$('kemSec');if(!box)return;
  if(!(r.ar&&r.pu)||r.src==='FORM'){box.innerHTML='';return}
  let k=null,ks=r.kst||null;
  if(db){
    try{const sn=await db.doc('kembali/'+r.nomor).get();if(sn.exists)k=sn.data()||null}catch(e){}
    try{const sn=await db.doc('kstat/'+r.nomor).get();if(sn.exists)ks=sn.data()||null}catch(e){}
  }
  if(S.cur!==r.nomor||!$('kemSec'))return;
  const can=canAC(r)&&!SIM&&!!db;
  const back=!!(r.back||(ks&&ks.returned));
  const fmt=t=>t?tglS(new Date(t))+' '+jam(new Date(t)):'';
  const img=k&&k.foto?`<div style="margin:8px 0"><img id="kemImg" src="${esc(k.foto)}" alt="Foto form pemeriksaan setelah kembali" style="max-width:100%;max-height:320px;border:1px solid var(--line,#c9d3ee);border-radius:8px;cursor:zoom-in"></div>`:'';
  const formLn=ks&&ks.formUrl?`<div class="hint" style="margin:6px 0">Form di Drive: <a href="${esc(ks.formUrl)}" target="_blank" rel="noopener">${esc(ks.formName||'buka di Drive')}</a></div>`:'';
  const unit=ks&&ks.unitUrl?`<div class="hint" style="margin:6px 0">Foto unit pulang: <a href="${esc(ks.unitUrl)}" target="_blank" rel="noopener">${esc(ks.unitName||'buka di Drive')}</a>${ks.unitAt?' · '+esc(fmt(ks.unitAt)):''}</div>`:'';
  const ketPill=ks&&typeof ks.rusak==='boolean'?`<div style="margin:6px 0"><span class="pill p-${ks.rusak?'park':'go'}">${ks.rusak?'Ada kerusakan':'Normal'}</span>${ks.ket?`<p style="white-space:pre-wrap;margin:8px 0">${esc(ks.ket)}</p>`:''}${ks.dmgUrl?`<div class="hint">Foto kerusakan: <a href="${esc(ks.dmgUrl)}" target="_blank" rel="noopener">${esc(ks.dmgName||'buka di Drive')}</a></div>`:''}</div>`:'';
  const head=`<span class="lbl">Pengembalian unit</span><div style="margin:6px 0">${back?'<span class="pill p-back">Telah dikembalikan</span>':'<span class="pill p-na">Belum dikembalikan</span>'}${k&&k.at?` <span class="hint">form diunggah ${esc(fmt(k.at))}${k.by?' oleh '+esc(k.by):''}</span>`:''}</div>`;
  if(!can){
    box.innerHTML=`<div>${head}${ketPill}${unit}${img}${formLn}</div>`;
  }else{
    const rus=ks&&ks.rusak===true;
    box.innerHTML=`<div>${head}
      <div class="lbl" style="margin-top:8px">1. Upload form pemeriksaan setelah kembali</div>
      ${img}${formLn}
      <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${k&&k.foto?'Ganti foto form':'Pilih foto atau PDF form'}<input id="kemFile" type="file" accept="image/*,application/pdf,.pdf" hidden></label><button class="btn" id="kemSave" type="button" disabled>${back?'Simpan foto form':'Unggah dan tandai dikembalikan'}</button></div>
      <div class="msg" id="kemMsg" role="status"></div>
      ${back?`<div class="lbl" style="margin-top:8px">2. Keterangan unit</div>
      <div class="act" style="margin:6px 0"><label><input type="radio" name="kemR" value="0" ${rus?'':'checked'}> Normal</label> <label><input type="radio" name="kemR" value="1" ${rus?'checked':''}> Ada kerusakan</label></div>
      <textarea id="kemKet" rows="3" maxlength="1500" placeholder="Jelaskan kerusakan (wajib bila ada kerusakan)" style="width:100%;box-sizing:border-box">${esc(ks&&ks.ket||'')}</textarea>
      <div id="dmgBox" class="act" style="margin:6px 0" ${rus?'':'hidden'}><label class="btn alt sm" style="cursor:pointer">${ks&&ks.dmgUrl?'Ganti foto kerusakan':'Foto kerusakan'} (boleh beberapa)<input id="dmgFile" type="file" accept="image/*" multiple hidden></label><span class="hint" id="dmgInfo">Opsional. Beberapa foto disimpan sebagai satu ZIP di Google Drive.</span></div>
      <div class="act" style="margin:6px 0"><button class="btn" id="ketSave" type="button">Simpan keterangan</button></div>
      <div class="msg" id="ketMsg" role="status"></div>
      <div class="lbl" style="margin-top:8px">3. Foto unit pulang</div>${unit}
      <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${ks&&ks.unitUrl?'Ganti foto unit':'Pilih foto unit (boleh beberapa)'}<input id="unitFile" type="file" accept="image/*" multiple hidden></label><span class="hint" id="unitInfo">Boleh pilih beberapa foto; di Google Drive jadi satu file ZIP.</span><button class="btn" id="unitSave" type="button" disabled>Unggah ke Google Drive</button></div>
      <div class="msg" id="unitMsg" role="status"></div>`:'<p class="hint">Setelah form diunggah, status berubah menjadi Telah dikembalikan dan isian keterangan serta foto unit pulang muncul di sini.</p>'}
    </div>`;
    const say=(id,t,err)=>{const m=$(id);if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
    const base=()=>Object.assign({nomor:r.nomor},ks||{});
    const logIt=a=>{try{if(db&&ME.id)db.collection('log').add({nomor:r.nomor,aksi:a,by:ME.id,at:new Date().toISOString()})}catch(e){}};
    let foto='',fotoBig='',fotoPdf=null,unitFiles=[],dmgFiles=[];
    $('kemFile').onchange=async ev=>{
      const f=ev.target.files&&ev.target.files[0];if(!f)return;
      say('kemMsg','Memproses foto …');
      try{
        fotoPdf=null;foto='';fotoBig='';
        if(f.type==='application/pdf'||/\.pdf$/i.test(f.name)){
          if(f.size>4*1024*1024)throw new Error('PDF terlalu besar (maksimal 4 MB).');
          const d=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('PDF tidak terbaca.'));fr.readAsDataURL(f)});
          if(atob(d.slice(d.indexOf(',')+1,d.indexOf(',')+9)).slice(0,4)!=='%PDF')throw new Error('Berkas ini bukan PDF yang valid.');
          fotoPdf={dataUrl:d,ext:'pdf',mime:'application/pdf'};
        }else{foto=await shrinkImg(f);fotoBig=await shrinkImg(f,FOTO_MAX)}
        $('kemSave').disabled=false;say('kemMsg',(fotoPdf?'PDF siap.':'Foto siap.')+' Tekan tombol di sebelahnya untuk menyimpan.')}catch(e){say('kemMsg',e.message||'Foto gagal diproses.',true)}
    };
    $('kemSave').onclick=async()=>{
      if(!foto&&!fotoPdf)return;
      $('kemSave').disabled=true;say('kemMsg','Menyimpan …');
      const now=new Date().toISOString();
      try{
        let warn='',fd=null;
        try{fd=await driveUp(r,'FORM_PULANG',(fotoPdf||await toPdfData(fotoBig)),ks&&ks.formId?{id:ks.formId,folder:ks.formFolder}:null)}catch(e){warn=' Foto form belum masuk Google Drive ('+((e&&e.message)||'cek akses')+').'}
        await db.doc('kembali/'+r.nomor).set({nomor:r.nomor,foto,by:actor(),at:now});
        await db.doc('kstat/'+r.nomor).set(Object.assign(base(),{returned:true,at:now,by:actor()},fd?{formId:fd.id,formUrl:fd.url,formName:fd.title}:{}));
        try{const w=await rowIn(r);await putVals(w.sid,`'DATA PEMINJAM'!U${w.row}`,[['TELAH DIKEMBALIKAN']])}catch(e){warn+=' Status di spreadsheet area belum bisa diubah ('+((e&&e.message)||'cek akses')+').'}
        if(fd){try{if(!(await putW(r,fd.url,fd.title)))warn+=' Link form belum tampil benar di kolom UPLOAD PENGEMBALIAN.'}catch(e){warn+=' Kolom UPLOAD PENGEMBALIAN belum bisa diisi ('+((e&&e.message)||'cek akses')+').'}}
        logIt('kembali_form');
        r.back=true;r.kst=Object.assign(base(),{returned:true},fd?{formUrl:fd.url}:{});
        say('kemMsg','Tersimpan. Status: Telah dikembalikan.'+warn,!!warn);
        await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
      }catch(e){say('kemMsg',e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':'Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);$('kemSave').disabled=false}
    };
    if(back){
      document.querySelectorAll('input[name="kemR"]').forEach(x=>x.onchange=()=>{const on=(document.querySelector('input[name="kemR"]:checked')||{}).value==='1';$('dmgBox').hidden=!on});
      $('dmgFile').onchange=ev=>{dmgFiles=[...(ev.target.files||[])].slice(0,FOTO_BANYAK);$('dmgInfo').textContent=dmgFiles.length?dmgFiles.length+' foto dipilih. Tekan Simpan keterangan.':'Opsional.'};
      $('ketSave').onclick=async()=>{
        const rusak=!!(document.querySelector('input[name="kemR"]:checked')||{}).value&&document.querySelector('input[name="kemR"]:checked').value==='1';
        const ket=$('kemKet').value.trim().slice(0,1500);
        if(rusak&&!ket){say('ketMsg','Isi keterangan kerusakan terlebih dulu.',true);return}
        $('ketSave').disabled=true;say('ketMsg','Menyimpan …');
        try{
          let warn='',dm=null;
          if(rusak&&dmgFiles.length){
            say('ketMsg','Mengunggah foto kerusakan ke Google Drive …');
            try{const pk=await packPhotos(dmgFiles,String(areaName(r)||r.code).trim()+'_KERUSAKAN');const d0=await driveUp(r,'KERUSAKAN',pk,ks&&ks.dmgId?{id:ks.dmgId,folder:ks.dmgFolder}:null);dm={dmgId:d0.id,dmgFolder:d0.folder,dmgUrl:d0.url,dmgName:d0.title,dmgAt:new Date().toISOString()}}
            catch(e){warn=' Foto kerusakan belum masuk Google Drive ('+((e&&e.message)||'cek akses')+').'}
          }
          await db.doc('kstat/'+r.nomor).set(Object.assign(base(),{returned:true,rusak,ket,ketBy:actor(),ketAt:new Date().toISOString()},dm||{}));
          try{const w=await rowIn(r);await putVals(w.sid,`'DATA PEMINJAM'!X${w.row}`,[[rusak?'ADA KERUSAKAN':'NORMAL']])}catch(e){warn+=' Kolom KETERANGAN di spreadsheet area belum bisa diisi ('+((e&&e.message)||'cek akses')+').'}
          logIt('kembali_ket');
          say('ketMsg','Keterangan tersimpan.'+warn,!!warn);
          await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
        }catch(e){say('ketMsg','Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);$('ketSave').disabled=false}
      };
      $('unitFile').onchange=ev=>{
        unitFiles=[...(ev.target.files||[])].slice(0,FOTO_BANYAK);
        $('unitSave').disabled=!unitFiles.length;
        say('unitMsg',unitFiles.length?unitFiles.length+' foto dipilih'+(unitFiles.length>1?' (akan digabung menjadi satu ZIP).':'.'):'');
      };
      $('unitSave').onclick=async()=>{
        if(!unitFiles.length)return;
        $('unitSave').disabled=true;say('unitMsg','Memproses foto …');
        try{
          const pack=await packPhotos(unitFiles,String(areaName(r)||r.code).trim()+'_PULANG');
          say('unitMsg','Mengunggah ke Google Drive …');
          const dr=await driveUp(r,'PULANG',pack,ks&&ks.unitId?{id:ks.unitId,folder:ks.unitFolder}:null);
          const url=dr.url,title=dr.title,up={id:dr.id};
          let warn='';
          try{
            const okc=await putW(r,url,title);
            if(!okc)warn=' Link belum tampil benar di kolom UPLOAD PENGEMBALIAN.';
          }catch(e){warn=' Kolom UPLOAD PENGEMBALIAN di spreadsheet belum bisa diisi ('+((e&&e.message)||'cek akses')+').'}
          await db.doc('kstat/'+r.nomor).set(Object.assign(base(),{returned:true,unitId:up.id,unitFolder:up.folder,unitUrl:url,unitName:title,unitAt:new Date().toISOString(),unitBy:actor()}));
          logIt('kembali_foto');
          say('unitMsg','Foto unit tersimpan di Google Drive.'+warn,!!warn);
          try{await mcp.invalidate()}catch(e){}
          await loadData();render();const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
        }catch(e){say('unitMsg',e&&e.code==='local'?e.message:errText(e,'Google Drive')+' Tidak ada yang diubah.',true);$('unitSave').disabled=false}
      };
    }
  }
  const im=$('kemImg');if(im)im.onclick=()=>{const w=window.open();if(w&&k){w.document.write('<img src="'+k.foto+'" style="max-width:100%">');w.document.close()}};
}
let confT=0;
async function toggleAcc(r,k){
  if(S.busy)return;
  if(S.confirm!==k){S.confirm=k;drawDetail(r);clearTimeout(confT);confT=setTimeout(()=>{if(S.confirm===k){S.confirm=null;const x=ROWS.find(z=>z.nomor===S.cur);if(x)drawDetail(x)}},4000);return}
  clearTimeout(confT);S.confirm=null;S.busy=true;drawDetail(r);
  const val=!r[k];
  const say=(t,err)=>{const m=$('actMsg');if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
  if(SIM){
    if(k==='ar'&&!canAR(r)){S.busy=false;say('Akun uji ini tidak bisa ACC Armada Pusat.',true);drawDetail(r);return}
    if(k==='ac'&&!canAC(r)){S.busy=false;say('Akun uji ini tidak berwenang untuk area ini.',true);drawDetail(r);return}
    if(k==='pu'&&!canPU()){S.busy=false;say('Akun uji ini tidak bisa ACC Manager Armada.',true);drawDetail(r);return}
    SIMO[r.nomor]=Object.assign(SIMO[r.nomor]||{t:Date.now()},{[k]:val});
    await loadData();render();S.busy=false;const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
    say('Simulasi: perubahan hanya tampil di sini dan tidak dikirim ke spreadsheet.');return;
  }
  say('Menyimpan ke spreadsheet …');
  try{
    if(k==='ar'&&!canAR(r))throw {code:'local',message:'Hanya Armada Pusat dan Admin yang bisa ACC Armada Pusat.'};
    if(k==='ac'&&!canAC(r))throw {code:'local',message:'Akun Anda tidak berwenang untuk area ini.'};
    if(k==='pu'&&!canPU())throw {code:'local',message:'Hanya Armada Pusat dan Admin yang bisa ACC Manager Armada.'};

    let sid,col,first,sheet;
    if(k==='ar'||k==='ac'){
      const a=AREAS[r.code];if(!a||!a.sheetId)throw {code:'local',message:'Spreadsheet area '+areaName(r)+' belum didaftarkan.'};
      sid=a.sheetId;sheet="'DATA PEMINJAM'";col=k==='ar'?'R':'Y';first=5;
    }else{sid=ACC_ID;sheet="'ACC PUSAT'";col='Y';first=2}
    const keys=await getVals(sid,`${sheet}!B${first}:B5000`);
    const i=keys.findIndex(x=>String((x&&x[0])||'').trim()===r.nomor);
    if(i<0)throw {code:'local',message:'No. form tidak ditemukan di spreadsheet. Muat ulang lalu coba lagi.'};
    const row=first+i;
    await putVals(sid,`${sheet}!${col}${row}`,[[val]]);
    const back=await getVals(sid,`${sheet}!${col}${row}`);
    const ok=B(back[0]&&back[0][0])===val;
    if(ok){OVR[r.nomor]=Object.assign(OVR[r.nomor]||{t:Date.now()},{[k]:val})}
    try{await mcp.invalidate()}catch(e){}
    try{if(db&&ME.id)await db.collection('log').add({nomor:r.nomor,aksi:(val?'acc':'batal')+'_'+(k==='ar'?'armada_pusat':k==='ac'?'area':'manager'),by:ME.id,at:new Date().toISOString()})}catch(e){}
    await loadData();render();
    S.busy=false;const nr=ROWS.find(z=>z.nomor===r.nomor);if(nr)drawDetail(nr);
    say(ok?(val?'Tersimpan. Persetujuan tercatat di spreadsheet.':'Persetujuan dibatalkan di spreadsheet.'):'Perintah terkirim, tetapi nilai di spreadsheet belum berubah. Periksa hak edit Anda.',!ok);
  }catch(e){
    S.busy=false;const nr=ROWS.find(z=>z.nomor===r.nomor)||r;drawDetail(nr);
    say(e&&e.code==='local'?e.message:errText(e,k==='pu'?'ACC ARMADA PUSAT':'Spreadsheet area')+' Tidak ada yang diubah.',true);
  }
}

/* ---------- pengguna, area, riwayat (admin) ---------- */
let draft=null;
async function renderUsers(){
  const v=$('usersView');v.innerHTML='<div class="panel empty">Memuat …</div>';
  let roles=[],logs=[];
  try{if(db){roles=(await db.collection('roles').get()).docs.map(d=>({id:d.id,...d.data()}))}}catch(e){}
  try{if(db){logs=(await db.collection('log').orderBy('at','desc').limit(20).get()).docs.map(d=>d.data())}}catch(e){}
  const ids=[...new Set([...roles.map(x=>x.id),...logs.map(x=>x.by).filter(Boolean)])];
  let prof={};try{prof=await user.profiles(ids)}catch(e){}
  const nm=id=>(prof[id]&&prof[id].name)||'Pengguna';
  const codes=Object.keys(AREAS);
  const rowHTML=x=>`<div class="urow" data-id="${esc(x.id)}"><img src="${esc((prof[x.id]||{}).avatarUrl||'')}" alt=""><span class="who">${esc(nm(x.id))}</span><span class="pill p-na">${x.role==='pusat'?'Armada Pusat':'Armada Daerah'}</span><span class="hint">${x.role==='daerah'?esc((x.areas||[]).map(c=>(AREAS[c]||{}).name||c).join(', ')||'tanpa area'):'semua area'}</span><button class="link" data-del="${esc(x.id)}" type="button">Hapus</button></div>`;
  v.innerHTML=`<div class="grid2">
   <div class="panel card"><h3>Akses pengguna</h3>
     <p class="hint">Pemilik dan editor halaman otomatis menjadi Admin. Armada Pusat bisa ACC area, ACC Armada Pusat dan ACC Manager Armada untuk semua area. Armada Daerah hanya bisa mencentang ACC area di areanya, tanpa tanda tangan, dan tidak bisa ACC Armada Pusat maupun ACC Manager Armada.</p>
     <div id="ulist">${roles.map(rowHTML).join('')||'<div class="hint">Belum ada pengguna yang ditambahkan.</div>'}</div>
     <div class="lbl">Tambah pengguna</div>
     <input type="text" id="usrQ" placeholder="Cari nama rekan" aria-label="Cari pengguna" autocomplete="off">
     <div id="usrHits"></div><div id="usrDraft"></div>
   </div>
   <div class="panel card"><h3>Spreadsheet per area</h3>
     <p class="hint">Dibaca otomatis dari sheet MASTER di ACC ARMADA PUSAT. Area tanpa spreadsheet belum bisa di-ACC dari halaman ini.</p>
     <ul class="plain">${codes.map(c=>`<li><b class="num">${esc(c)}</b><span>${esc(AREAS[c].name)}</span><span class="pill ${AREAS[c].sheetId?'p-park':'p-na'}">${AREAS[c].sheetId?'terdaftar':'belum ada'}</span></li>`).join('')}</ul>
   </div>
   <div class="panel card"><h3>Riwayat persetujuan</h3>
     <ul class="plain">${logs.map(l=>`<li><span class="num">${esc(String(l.at||'').slice(0,16).replace('T',' '))}</span><b>${esc(String(l.aksi||'').replace('_',' '))}</b><span class="num">${esc(l.nomor)}</span><span class="hint">${esc(nm(l.by))}</span></li>`).join('')||'<li class="hint">Belum ada riwayat.</li>'}</ul>
   </div></div>`;
  v.querySelectorAll('[data-del]').forEach(b=>b.onclick=async()=>{try{await db.doc('roles/'+b.dataset.del).delete()}catch(e){}renderUsers()});
  const q=$('usrQ');
  q.oninput=async()=>{
    const hits=q.value.trim()?await user.search(q.value.trim()):[];
    $('usrHits').innerHTML=hits.map(h=>`<button class="link" type="button" data-pick="${esc(h.id)}" style="display:block">${esc(h.name)}</button>`).join('');
    $('usrHits').querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>{draft={id:b.dataset.pick,name:b.textContent,role:'daerah',areas:[]};drawDraft(codes)});
  };
  if(draft)drawDraft(codes);
}
function drawDraft(codes){
  const d=draft,el=$('usrDraft');if(!el)return;
  el.innerHTML=`<div class="card" style="padding:10px 0"><b></b>
    <select id="dRole" aria-label="Peran"><option value="daerah" ${d.role==='daerah'?'selected':''}>Armada Daerah</option><option value="pusat" ${d.role==='pusat'?'selected':''}>Armada Pusat</option></select>
    <div class="areas" id="dAreas" ${d.role==='pusat'?'hidden':''}>${codes.map(c=>`<label><input type="checkbox" value="${esc(c)}" ${d.areas.includes(c)?'checked':''}>${esc(AREAS[c].name)}</label>`).join('')}</div>
    <div class="act"><button class="btn sm" id="dSave" type="button">Simpan</button><button class="btn alt sm" id="dCancel" type="button">Batal</button><span class="hint" id="dMsg"></span></div></div>`;
  el.querySelector('b').textContent=d.name;
  $('dRole').onchange=e=>{d.role=e.target.value;drawDraft(codes)};
  $('dAreas').onchange=()=>{d.areas=[...$('dAreas').querySelectorAll('input:checked')].map(i=>i.value)};
  $('dCancel').onclick=()=>{draft=null;el.innerHTML=''};
  $('dSave').onclick=async()=>{
    if(d.role==='daerah'&&!d.areas.length){$('dMsg').textContent='Pilih minimal satu area.';return}
    try{await db.doc('roles/'+d.id).set({role:d.role,areas:d.role==='daerah'?d.areas:[]});draft=null;renderUsers()}
    catch(e){$('dMsg').textContent='Gagal menyimpan ('+((e&&e.code)||'error')+').'}
  };
}

/* ---------- database utama: isian Google Form, terbaca otomatis ---------- */
function dbIngest(vals){
  const o=detectOrder(vals);
  DBROWS=vals.map(r=>mkRow(r,o,'FORM')).filter(Boolean).sort((x,y)=>((y.ts?+y.ts:0)-(x.ts?+x.ts:0))||y.nomor.localeCompare(x.nomor));
  const now=new Set(DBROWS.map(r=>r.nomor));
  let fresh=0;
  if(DBSEEN){for(const n of now)if(!DBSEEN.has(n)){DBNEW.add(n);fresh++}}
  DBSEEN=now;DBAT=Date.now();DBERR='';
  if(fresh&&isAdminLike()){loadData().then(()=>{render();renderDb()}).catch(()=>{})}
  renderDb(fresh);
}
async function pollDb(manual){
  try{const v=await getVals(FORM_ID,"'DATA'!A2:Q5000");dbIngest(v||[])}
  catch(e){DBERR=errText(e,'Spreadsheet formulir');renderDb()}
}
function startDb(){
  if(DBUNSUB||!mcp)return;
  $('dbInfo').textContent='Membaca data formulir …';
  pollDb();const t=setInterval(pollDb,60000);DBUNSUB=()=>clearInterval(t);
}
function stopDb(){if(DBUNSUB){try{DBUNSUB()}catch(e){}DBUNSUB=null}}
const dbFiltered=()=>{
  const q=$('dbQ').value.trim().toLowerCase(),ar=$('dbArea').value,rg=$('dbRange').value,start=new Date();start.setHours(0,0,0,0);
  const from=rg==='today'?+start:rg==='7'?+start-6*864e5:0;
  return DBROWS.filter(r=>(!ar||r.code===ar)&&(!from||(r.ts&&+r.ts>=from))&&(!q||(r.nomor+' '+r.nama+' '+r.nopol+' '+r.tujLok+' '+r.tuj).toLowerCase().includes(q)));
};
function renderDb(fresh){
  if(S.tab!=='db')return;
  const sel=$('dbArea'),keep=sel.value,cnt={};DBROWS.forEach(r=>cnt[r.code]=(cnt[r.code]||0)+1);
  sel.innerHTML='<option value="">Semua area</option>'+Object.keys(cnt).sort().map(c=>`<option value="${esc(c)}">${esc((AREAS[c]||{}).name||c)} (${cnt[c]})</option>`).join('');sel.value=cnt[keep]?keep:'';
  const inAcc=new Set(ROWS.map(r=>r.nomor)),today=new Date();today.setHours(0,0,0,0);
  const nToday=DBROWS.filter(r=>r.ts&&+r.ts>=+today).length,nGap=DBROWS.filter(r=>!inAcc.has(r.nomor)).length;
  $('dbTiles').innerHTML=`<div class="panel tile"><span class="k">Total isian formulir</span><span class="v num">${fmtN(DBROWS.length)}</span><span class="s">sejak formulir dibuka</span></div>
   <div class="panel tile t-park"><span class="k">Masuk hari ini</span><span class="v num">${fmtN(nToday)}</span><span class="s">${DBNEW.size?fmtN(DBNEW.size)+' baru sejak halaman dibuka':'otomatis dari Google Form'}</span></div>
   <div class="panel tile ${nGap?'t-wait':'t-go'}"><span class="k">Belum masuk ACC pusat</span><span class="v num">${fmtN(nGap)}</span><span class="s">${nGap?'cek area yang belum terdaftar':'semua sudah tersinkron'}</span></div>`;
  const d=DBAT?new Date(DBAT):null;
  $('dbInfo').innerHTML=(DBERR?`<span class="msg err">${esc(DBERR)}</span> `:'')+(d?`Diperbarui otomatis tiap 1 menit · terakhir ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`:'')+(fresh?` · <b>${fresh} isian baru masuk</b>`:'');
  const rows=dbFiltered();
  $('dbCount').textContent=`${fmtN(rows.length)} dari ${fmtN(DBROWS.length)} isian`;
  if(!rows.length){$('dbTbl').innerHTML='<div class="empty">'+(DBROWS.length?'Tidak ada isian yang cocok dengan filter.':(DBERR?'Data formulir belum bisa dibaca.':'Belum ada isian formulir.'))+'</div>';return}
  $('dbTbl').innerHTML=`<table><thead><tr><th>Waktu isi</th><th>No. form</th><th>Peminjam</th><th>Unit</th><th>Area</th><th>Tujuan</th><th>Pinjam sampai kembali</th><th>Posisi</th></tr></thead><tbody>${rows.slice(0,300).map(r=>`<tr tabindex="0" data-n="${esc(r.nomor)}"><td class="num">${tglS(r.ts)}<small>${jam(r.ts)}</small></td><td class="num">${esc(r.nomor)}${DBNEW.has(r.nomor)?' <span class="pill p-park">Baru</span>':''}</td><td>${esc(r.nama)}<small>${esc(r.sp)}</small></td><td class="num">${esc(r.nopol)}<small>${esc(r.jenis)} ${esc(r.merk)}</small></td><td>${esc(areaName(r))}</td><td>${esc(r.tujLok)}<small>${esc(r.tuj)}</small></td><td class="num">${tglS(r.pinjam)}<small>sampai ${tglS(r.kembali)}</small></td><td>${inAcc.has(r.nomor)?'<span class="pill p-park">Di ACC Manager Armada</span>':'<span class="pill p-first">Belum di ACC Manager Armada</span>'}</td></tr>`).join('')}</tbody></table>`+(rows.length>300?'<div class="empty">Menampilkan 300 isian terbaru. Persempit dengan filter. CSV memuat semua yang tersaring.</div>':'');
}
async function dbCsv(){
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){$('dbInfo').textContent='Penyimpanan file tidak tersedia di tampilan ini.';return}
  const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"';
  const head=['Waktu isi','No. form','Nama','No. KTP','No. SIM','No. WhatsApp','No. telepon aktif','Status peminjam','Nopol','Lokasi terakhir unit','Lokasi tujuan','Tujuan peminjaman','Jenis armada','Merk','Grup unit','Tanggal pinjam','Tanggal kembali'];
  const f=d=>d?`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`:'';
  const ft=d=>d?f(d)+' '+jam(d):'';
  const lines=[head.map(q).join(',')].concat(dbFiltered().map(r=>[ft(r.ts),r.nomor,r.nama,r.ktp,r.sim,r.wa,r.telp,r.sp,r.nopol,r.asal,r.tujLok,r.tuj,r.jenis,r.merk,r.grup,f(r.pinjam),f(r.kembali)].map(q).join(',')));
  try{await dl.save({filename:'Database Peminjaman Unit.csv',data:new Blob(['\ufeff'+lines.join('\r\n')],{type:'text/csv'})})}
  catch(e){$('dbInfo').textContent=(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'Gagal menyiapkan CSV ('+((e&&e.code)||'error')+').'}
}
$('dbQ').oninput=()=>renderDb();$('dbArea').onchange=()=>renderDb();$('dbRange').onchange=()=>renderDb();$('dbCsv').onclick=dbCsv;
$('dbTbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)});
$('dbTbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)}});

/* ---------- boot ---------- */
async function boot(){
  gate('Memuat data peminjaman','Membaca spreadsheet area dan formulir.');
  const cl=window.claude;
  if(!cl||!cl.use){gate('Halaman belum siap','Penghubung ke server tidak termuat. Muat ulang halaman.');return}
  [mcp,db,user]=await Promise.all([cl.use('mcp').catch(()=>null),cl.use('db').catch(()=>null),cl.use('user').catch(()=>null)]);
  let me={id:null,isOwner:false,canEdit:false};
  try{if(user)me=await user.me()}catch(e){}
  ME.id=me.id;ME.role=null;ME.areas=[];
  const AC=window.__acct;
  if(AC){ME.id=AC.user;if(AC.role==='admin')ME.role='admin';else if(AC.role==='pusat')ME.role='pusat';else if(AC.role==='daerah'){ME.role='daerah';ME.areas=(AC.areas||[]).slice()}}
  else if(me.isOwner||me.canEdit)ME.role='admin';
  else if(db&&me.id){
    try{const s=await db.doc('roles/'+me.id).get();if(s.exists){const x=s.data()||{};ME.role=x.role==='pusat'?'pusat':'daerah';ME.areas=Array.isArray(x.areas)?x.areas:[]}}catch(e){}
  }
  REAL.role=ME.role;REAL.areas=ME.areas.slice();
  {const u=$('unitName');if(u)u.textContent=unitTitle()}
  if(!ME.role){gate(AC?'Akun ini tidak punya akses ke fitur ini':'Akun Anda belum punya akses',AC?'Fitur Peminjaman Unit hanya untuk akun Admin, Armada Pusat, dan Armada Daerah. Masuk dengan akun lain.':'Minta admin menambahkan akun Anda dan menentukan areanya.');return}
  if(!mcp){gate('Google Sheets tidak tersedia','Sambungan ke Google Sheets lewat server tidak tersedia.','Coba lagi');return}
  try{await Promise.all([loadAreas().then(loadData),loadPrivateAssets()])}catch(e){gate('Data belum bisa dibaca',errText(e),'Coba lagi');return}
  buildSim();
  if(ME.role==='daerah'&&ME.areas.length&&S.area==='ALL')S.area=ME.areas.length===1?ME.areas[0]:'ALL';
  if(!ROWS.length&&PROBLEMS.length){gate('Data belum bisa dibaca',PROBLEMS.join(' '),'Coba lagi');return}
  render();
}
$('reload').onclick=async()=>{$('reload').disabled=true;try{await mcp.invalidate()}catch(e){}await loadData();render();if(S.cur){const r=ROWS.find(x=>x.nomor===S.cur);if(r)drawDetail(r)}$('reload').disabled=false};
$('areaChips').onclick=e=>{const b=e.target.closest('[data-a]');if(b){S.area=b.dataset.a;render()}};
$('q').oninput=e=>{S.q=e.target.value;render()};
$('stSel').onchange=e=>{S.st=e.target.value;render()};
$('tbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)});
$('tbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-n]');if(tr)openRow(tr.dataset.n,tr)}});
$('drX').onclick=closeRow;$('veil').onclick=closeRow;
document.addEventListener('keydown',e=>{if(e.key==='Escape')closeRow()});
function tab(t){
  S.tab=t;for(const k of ['list','users','db'])$('tab-'+k).setAttribute('aria-selected',t===k);
  $('listView').hidden=t!=='list';$('usersView').hidden=t!=='users';$('dbView').hidden=t!=='db';
  if(t==='users')renderUsers();
  if(t==='db')startDb();else stopDb();
}
$('tab-list').onclick=()=>tab('list');$('tab-users').onclick=()=>tab('users');$('tab-db').onclick=()=>tab('db');
function buildSim(){
  const box=$('simBox');box.hidden=REAL.role!=='admin';
  if(box.hidden)return;
  const sel=$('simSel');
  const codes=Object.keys(AREAS);
  sel.innerHTML='<option value="">Uji peran: akun saya (Admin)</option><option value="pusat">Uji sebagai Manager / Armada Pusat</option>'+codes.map(c=>`<option value="d:${esc(c)}">Uji sebagai Armada Daerah ${esc(AREAS[c].name)}</option>`).join('');
  sel.value=SIM?(SIM.role==='pusat'?'pusat':'d:'+SIM.areas[0]):'';
}
$('simSel').onchange=async e=>{
  const v=e.target.value;SIMO={};closeRow();
  if(!v){SIM=null;ME.role=REAL.role;ME.areas=REAL.areas.slice()}
  else if(v==='pusat'){SIM={role:'pusat',areas:[]};ME.role='pusat';ME.areas=[]}
  else{const c=v.slice(2);SIM={role:'daerah',areas:[c]};ME.role='daerah';ME.areas=[c]}
  S.area=SIM&&SIM.role==='daerah'?SIM.areas[0]:'ALL';
  if(S.tab==='users')tab('list');
  await loadData();render();
};
;(function(){const t=$('themeBtn');if(t)t.onclick=()=>{const r=document.documentElement;r.dataset.theme=r.dataset.theme==='dark'?'light':'dark'}})();
boot();
})();



}},pemakaian:{css:"\n\n/* Papan kerja armada: panel putih, biru dan merah Baraka. Daftar pengajuan di kiri, form fisik muncul di laci kanan. */\n:host{\n  --bg:#f6f8ff;--surface:#ffffff;--surface2:#eff3ff;--fg:#0a1640;--muted:#52618f;--line:#d3ddf5;\n  --accent:#1a4bd8;--accent-fg:#ffffff;--accent-soft:rgba(26,75,216,.09);\n  --navy:#0a1f66;--navy-bg:rgba(10,31,102,.09);--late:#d6182f;--late-bg:rgba(214,24,47,.08);\n  --shadow:0 20px 50px rgba(30,60,110,.14);\n  --display:'Chakra Petch','Segoe UI',system-ui,sans-serif;--sans:'Manrope',system-ui,-apple-system,'Segoe UI',sans-serif;--mono:'JetBrains Mono',ui-monospace,Menlo,monospace;\n  --paper:#ffffff;--ink:#0b0b0b;--veil:rgba(8,16,48,.45);\n  color-scheme:light;\n}\n:host([data-theme=\"dark\"]){\n  --bg:#060b1f;--surface:#0d1530;--surface2:#121c3d;--fg:#eaf0ff;--muted:#9aaad6;--line:#24305e;\n  --accent:#5b8cff;--accent-fg:#06102e;--accent-soft:rgba(91,140,255,.14);\n  --navy:#dfe8ff;--navy-bg:rgba(223,232,255,.1);--late:#ff5a70;--late-bg:rgba(255,90,112,.14);\n  --shadow:0 20px 50px rgba(0,0,0,.5);--veil:rgba(0,0,0,.6);color-scheme:dark}\n*{box-sizing:border-box}\n[hidden]{display:none!important}\n.mbody{margin:0;background:var(--bg);color:var(--fg);font-family:var(--sans);font-size:14px;line-height:1.5;\n  padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px));padding-block:20px 48px}\n.wrap{max-width:1280px;margin:0 auto;display:flex;flex-direction:column;gap:18px}\n.num{font-family:var(--mono);font-variant-numeric:tabular-nums}\nbutton{font:inherit;color:inherit}\n:focus-visible{outline:2px solid var(--accent);outline-offset:2px}\n.top{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:center;justify-content:space-between}\n.brand{display:flex;flex-wrap:wrap;align-items:center;gap:14px 20px;min-width:0;max-width:100%}\n.logo{display:block;width:clamp(230px,46vw,540px);height:auto;max-width:100%;background:#fff;border:1px solid var(--line);border-radius:14px;padding:12px 20px;box-shadow:0 8px 30px rgba(0,0,0,.14)}\n.unit{display:flex;flex-direction:column;border-left:4px solid var(--late);padding-left:16px;min-width:0;line-height:1;font-family:var(--display);text-transform:uppercase}\n.unit b{font-size:clamp(30px,5vw,46px);letter-spacing:.06em;color:var(--navy);font-weight:700;margin-top:6px;text-wrap:balance}\n.unit span{font-size:13px;letter-spacing:.32em;color:var(--muted);font-weight:500}\n.acct{display:flex;align-items:center;gap:10px;flex-wrap:wrap}\n.role{font-size:12px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:5px 12px;border-radius:999px;background:var(--accent-soft);color:var(--accent);border:1px solid var(--accent)}\n.themebtn{background:var(--surface);border:1px solid var(--line);border-radius:999px;padding:8px 16px;cursor:pointer;font-family:var(--display);letter-spacing:.06em;transition:border-color .2s}\n.themebtn:hover{border-color:var(--accent)}\n.stamp{color:var(--muted);font-size:12px}\n.btn{border:1px solid var(--accent);background:var(--accent);color:var(--accent-fg);border-radius:10px;padding:8px 16px;font-weight:600;cursor:pointer;transition:transform .15s,box-shadow .15s}\n.btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 6px 16px var(--accent-soft)}\n.btn:disabled{opacity:.5;cursor:not-allowed}\n.btn.alt{background:transparent;color:var(--accent)}\n.btn.warn{background:var(--late);border-color:var(--late);color:#fff}\n.btn.sm{padding:4px 12px;font-size:12px}\n.link{background:none;border:0;color:var(--accent);cursor:pointer;padding:2px 0;font-weight:600}\n.panel{background:var(--surface);border:1px solid var(--line);border-radius:14px}\n.gate{padding:36px 24px;text-align:center;display:flex;flex-direction:column;gap:10px;align-items:center}\n.gate h2{font-family:var(--display);margin:0;font-size:20px}\n.gate p{margin:0;max-width:56ch;color:var(--muted)}\n.banner{border:1px solid var(--late);background:var(--late-bg);color:var(--fg);border-radius:12px;padding:10px 14px;font-size:13px}\n.banner.info{border-color:var(--accent);background:var(--accent-soft)}\n.tiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px}\n.tile{padding:14px 16px;display:flex;flex-direction:column;gap:2px;border-top:3px solid var(--line)}\n.tile .k{font-size:12px;color:var(--muted);letter-spacing:.06em;text-transform:uppercase}\n.tile .v{font-family:var(--display);font-size:34px;font-weight:700;line-height:1.1}\n.tile .s{font-size:12px;color:var(--muted)}\n.tile.t-wait{border-top-color:var(--late)}.tile.t-park{border-top-color:var(--accent)}.tile.t-go{border-top-color:var(--navy)}\n.bar{display:flex;flex-wrap:wrap;gap:10px;align-items:center}\n.chips{display:flex;gap:6px;flex-wrap:wrap;flex:1 1 320px;min-width:0}\n.chip{border:1px solid var(--line);background:var(--surface);border-radius:999px;padding:5px 12px;cursor:pointer;font-weight:600;font-size:13px;display:inline-flex;gap:8px;align-items:center}\n.chip .c{font-family:var(--mono);font-size:12px;color:var(--muted)}\n.chip[aria-pressed=\"true\"]{background:var(--accent);border-color:var(--accent);color:var(--accent-fg)}\n.chip[aria-pressed=\"true\"] .c{color:inherit}\ninput[type=search],input[type=text],select,textarea{font:inherit;color:var(--fg);background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:8px 12px;min-width:0}\n.tabs{display:flex;gap:4px;border-bottom:1px solid var(--line);overflow-x:auto}\n.tab{background:none;border:0;padding:12px 18px;cursor:pointer;color:var(--muted);font-family:var(--display);font-weight:600;letter-spacing:.06em;text-transform:uppercase;font-size:13px;white-space:nowrap}\n.tab:hover{color:var(--fg)}\n.tab[aria-selected=\"true\"]{color:var(--accent);box-shadow:inset 0 -2px 0 var(--accent)}\n.count{color:var(--muted);font-size:12px;padding:2px 0}\n.tbl{overflow-x:auto}\ntable{border-collapse:collapse;width:100%;min-width:980px}\nth{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);text-align:left;padding:10px 12px;border-bottom:1px solid var(--line);white-space:nowrap}\ntd{padding:10px 12px;border-bottom:1px solid var(--line);vertical-align:top}\ntbody tr{cursor:pointer}\ntbody tr:hover{background:var(--accent-soft)}\ntd small{display:block;color:var(--muted);font-size:12px}\n.pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid transparent;white-space:nowrap}\n.p-go{background:var(--navy);color:var(--bg);border-color:var(--navy)}\n.p-back{background:#e6f4ee;color:#0b6b46;border-color:#0b6b46}\n.p-park{background:var(--accent-soft);color:var(--accent);border-color:var(--accent)}\n.p-wait{background:var(--late-bg);color:var(--late);border-color:var(--late)}\n.p-first{background:transparent;color:var(--late);border-color:var(--late);border-style:dashed}\n.p-na{background:var(--surface2);color:var(--muted);border-color:var(--line);font-weight:500}\n.empty{padding:36px;text-align:center;color:var(--muted)}\n/* laci detail */\n.veil{position:fixed;inset:0;background:var(--veil);opacity:0;pointer-events:none;transition:opacity .2s;z-index:30}\n.veil.on{opacity:1;pointer-events:auto}\n.dr{position:fixed;top:0;right:0;bottom:0;width:min(820px,100vw);background:var(--bg);border-left:2px solid var(--accent);z-index:31;transform:translateX(102%);transition:transform .25s;display:flex;flex-direction:column;box-shadow:var(--shadow);padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}\n.dr.on{transform:none}\n.dh{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;padding:16px max(16px,env(safe-area-inset-right,0px)) 12px 20px;border-bottom:1px solid var(--line);background:var(--surface)}\n.dh h3{margin:0;font-family:var(--display);font-size:20px}\n.dh p{margin:2px 0 0;color:var(--muted);font-size:12px}\n.dx{border:1px solid var(--line);background:var(--surface);border-radius:10px;width:36px;height:36px;font-size:20px;cursor:pointer}\n.db{overflow:auto;padding:16px max(16px,env(safe-area-inset-right,0px)) 32px 20px;display:flex;flex-direction:column;gap:18px}\n.lbl{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);font-weight:700}\n.steps{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}\n.step{border:1px solid var(--line);border-radius:12px;padding:10px 12px;background:var(--surface);display:flex;flex-direction:column;gap:2px}\n.step b{font-size:13px}.step small{color:var(--muted)}\n.step.done{border-color:var(--accent);background:var(--accent-soft)}\n.act{display:flex;flex-wrap:wrap;gap:10px;align-items:center}\n.hint{font-size:12px;color:var(--muted)}\n.msg{font-size:13px}.msg.err{color:var(--late)}\n/* form fisik */\n.sheetwrap{overflow:auto;border:1px solid var(--line);border-radius:12px;background:#d9e0f2;padding:12px}\n.paper{background:var(--paper);color:var(--ink);width:813px;min-height:1247px;box-sizing:border-box;max-width:none;margin:0 auto;padding:44px 56px 40px;font-family:Arial,Helvetica,sans-serif;font-size:13px;line-height:1.35}\n.paper .hd{display:flex;align-items:center;gap:20px;border-bottom:2px solid #0a1f66;padding-bottom:12px;margin-bottom:22px}\n.paper .hd img{height:44px;width:auto}\n.paper .hd h1{margin:0;flex:1;text-align:center;font-size:17px;letter-spacing:.02em}\n.paper dl{display:grid;grid-template-columns:200px 14px 1fr;row-gap:3px;margin:0 0 14px}\n.paper dt{font-weight:700}.paper dd{margin:0;grid-column:3}\n.paper dl span.c{grid-column:2}\n.paper .gap{grid-column:1/-1;height:8px}\n.paper h2{font-size:13px;margin:16px 0 6px}\n.paper ol{margin:0 0 12px;padding-left:18px}.paper li{margin-bottom:6px}\n.paper .sig{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;text-align:center;margin-top:26px}\n.paper .sig .h{font-weight:700;margin-bottom:6px}\n.paper .box{height:104px;position:relative;display:flex;align-items:center;justify-content:center}\n.paper .box img{max-height:100%;max-width:100%;object-fit:contain}\n.paper.ck{padding:0;height:1247px;position:relative;overflow:hidden}\n.paper.ck .in{position:relative;width:100%;aspect-ratio:612/792}\n.paper.ck img.bg{position:absolute;inset:0;width:100%;height:100%}\n.paper.ck .v{position:absolute;font-size:12px;line-height:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:700;margin-top:-1px}\n.paper+.paper{break-before:page}\n.paper .nm{font-weight:700;border-top:1px solid var(--ink);padding-top:3px;min-height:20px}\n.paper .mgr{position:relative;height:92px;margin-top:2px}\n.paper .mgr img{position:absolute;left:50%;top:-14px;height:112px;transform:translateX(-50%)}\n.paper .mgr span{position:absolute;left:0;right:0;bottom:0;font-weight:700}\n/* pengguna */\n.grid2{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px}\n.card{padding:16px;display:flex;flex-direction:column;gap:10px}\n.card h3{margin:0;font-family:var(--display);font-size:16px}\n.urow{display:flex;gap:10px;align-items:center;flex-wrap:wrap;border-bottom:1px solid var(--line);padding:8px 0}\n.urow img{width:28px;height:28px;border-radius:50%}\n.urow .who{flex:1 1 140px;min-width:0;font-weight:600}\n.areas{display:flex;flex-wrap:wrap;gap:6px}\n.areas label{border:1px solid var(--line);border-radius:999px;padding:2px 10px;font-size:12px;cursor:pointer;display:inline-flex;gap:6px;align-items:center}\nul.plain{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}\nul.plain li{display:flex;gap:10px;flex-wrap:wrap;font-size:13px;border-bottom:1px solid var(--line);padding:5px 0}\n@media (max-width:640px){.steps{grid-template-columns:1fr}.tile .v{font-size:28px}}\n@media (prefers-reduced-motion:reduce){*{transition:none!important}}\n/* ---------- Pemakaian Unit ---------- */\n.spwrap{position:relative}\n.spbtn{width:100%;display:flex;gap:12px;align-items:center;justify-content:space-between;text-align:left;background:var(--surface);border:1px solid var(--line);border-radius:12px;padding:10px 14px;cursor:pointer}\n.spbtn:hover,.spbtn[aria-expanded=\"true\"]{border-color:var(--accent)}\n.spbtn .ph{color:var(--muted)}\n.spbtn .sel{display:flex;flex-wrap:wrap;gap:2px 14px;align-items:baseline;min-width:0;flex:1}\n.spbtn .sel small{flex:1 1 100%;color:var(--muted);font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.spbtn .car{color:var(--muted)}\n.sppanel{position:absolute;z-index:20;left:0;right:0;top:calc(100% + 6px);background:var(--surface);border:1px solid var(--accent);border-radius:12px;box-shadow:var(--shadow);display:flex;flex-direction:column;max-height:min(520px,70vh)}\n.sppanel .sh{padding:10px;border-bottom:1px solid var(--line);display:flex;flex-direction:column;gap:6px}\n.sppanel .sh input{width:100%}\n.splist{overflow:auto;display:flex;flex-direction:column}\n.spi{display:flex;flex-direction:column;gap:3px;text-align:left;background:none;border:0;border-bottom:1px solid var(--line);padding:10px 14px;cursor:pointer;width:100%}\n.spi:hover,.spi.on{background:var(--accent-soft)}\n.spi .spt{display:flex;flex-wrap:wrap;gap:2px 14px;align-items:baseline}\n.spi .spd{color:var(--muted);font-size:12px}\n.spi .spn{display:flex;flex-wrap:wrap;gap:6px}\n.spi .spn i{font-style:normal;font-size:12px;border:1px solid var(--line);background:var(--surface2);border-radius:999px;padding:0 8px}\n.spi .spn em{font-size:12px;color:var(--muted)}\n.spi small{color:var(--muted);font-size:12px;line-height:1.35;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}\n.sum{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px}\n.sum>div{display:flex;flex-direction:column;gap:2px;min-width:0}\n.sum .wide{grid-column:1/-1}\n.sum .k{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}\n.paper.ck .v.wr{white-space:normal;line-height:12px;font-size:10.5px;overflow:visible;text-overflow:clip}\n.paper .nm div{font-weight:700}\n.tcnt{font-family:var(--mono);font-size:11px;background:var(--accent);color:var(--accent-fg);border-radius:999px;padding:1px 7px;margin-left:4px}\ntd a{color:var(--accent);font-weight:600}\n\n.mbody{min-height:100%;isolation:isolate}[hidden]{display:none!important}\n#dr,.dr,#veil,.veil,#login{top:calc(var(--navh) + env(safe-area-inset-top,0px))!important}",html:"<div class=\"wrap\">\n  <header class=\"top\">\n    <div class=\"brand\">\n      <img class=\"logo\" id=\"logoImg\" src=\"/assets/logo.png\" alt=\"Baraka Express\">\n      <div class=\"unit\"><span>Pemakaian Unit Operasional<\/span><b id=\"unitName\">ARMADA PUSAT<\/b><\/div>\n    <\/div>\n    <div class=\"acct\">\n      <span class=\"role\" id=\"roleTag\" hidden><\/span>\n      <span class=\"stamp num\" id=\"stamp\"><\/span>\n      <button class=\"themebtn\" id=\"themeBtn\" type=\"button\">Ganti tema<\/button>\n      <button class=\"btn alt\" id=\"reload\" type=\"button\" hidden>Muat ulang<\/button>\n    <\/div>\n  <\/header>\n\n  <section class=\"panel gate\" id=\"gate\" aria-live=\"polite\"><h2>Memuat data pemakaian<\/h2><p>Menyiapkan akses dan membaca spreadsheet.<\/p><\/section>\n\n  <div id=\"app\" hidden style=\"display:flex;flex-direction:column;gap:18px\">\n    <div id=\"banner\" class=\"banner\" hidden role=\"alert\"><\/div>\n    <section class=\"tiles\" id=\"tiles\" aria-label=\"Ringkasan\"><\/section>\n    <div>\n      <div class=\"tabs\" role=\"tablist\">\n        <button class=\"tab\" role=\"tab\" id=\"tab-pick\" aria-selected=\"true\" type=\"button\">Pemakaian<\/button>\n        <button class=\"tab\" role=\"tab\" id=\"tab-proc\" aria-selected=\"false\" type=\"button\">Dalam proses<\/button>\n        <button class=\"tab\" role=\"tab\" id=\"tab-hist\" aria-selected=\"false\" type=\"button\">Riwayat<\/button>\n      <\/div>\n    <\/div>\n    <section id=\"vPick\" style=\"display:flex;flex-direction:column;gap:14px\">\n    <section class=\"panel card\" id=\"pickCard\">\n      <div class=\"lbl\">1. Pilih SPPD perjalanan dinas (hanya mobil inventaris)<\/div>\n      <div class=\"spwrap\">\n        <button type=\"button\" class=\"spbtn\" id=\"spBtn\" aria-haspopup=\"listbox\" aria-expanded=\"false\"><\/button>\n        <div class=\"sppanel\" id=\"spPanel\" hidden>\n          <div class=\"sh\"><input type=\"search\" id=\"spQ\" placeholder=\"Cari no. SPPD, NIB, nama, agenda\" aria-label=\"Cari SPPD\" autocomplete=\"off\"><span class=\"count\" id=\"spCount\"><\/span><\/div>\n          <div class=\"splist\" id=\"spList\" role=\"listbox\" aria-label=\"Daftar SPPD\"><\/div>\n        <\/div>\n      <\/div>\n      <div class=\"lbl\" style=\"margin-top:6px\">2. Pilih mobil<\/div>\n      <select id=\"carSel\" aria-label=\"Pilih mobil operasional\"><\/select>\n      <span class=\"hint\" id=\"carHint\"><\/span>\n      <button class=\"btn alt sm\" id=\"delTop\" type=\"button\" hidden><\/button>\n    <\/section>\n    <section id=\"result\" style=\"display:flex;flex-direction:column;gap:14px\"><\/section>\n    <\/section>\n    <section id=\"vProc\" hidden style=\"display:flex;flex-direction:column;gap:12px\">\n      <div class=\"bar\"><input type=\"search\" id=\"pQ\" placeholder=\"Cari no. SPPD, nama, nopol, agenda\" aria-label=\"Cari pemakaian\" style=\"flex:1 1 220px;max-width:340px\"><\/div>\n      <div class=\"count\" id=\"pCount\"><\/div>\n      <div class=\"panel tbl\" id=\"pTbl\"><\/div>\n    <\/section>\n    <section id=\"vHist\" hidden style=\"display:flex;flex-direction:column;gap:12px\">\n      <div class=\"bar\">\n        <input type=\"search\" id=\"hQ\" placeholder=\"Cari no. SPPD, nama, nopol, agenda\" aria-label=\"Cari riwayat\" style=\"flex:1 1 220px;max-width:340px\">\n        <select id=\"hSt\" aria-label=\"Filter status\"><option value=\"ALL\">Semua status<\/option><option value=\"GO\">Berangkat (belum kembali)<\/option><option value=\"BACK\">Telah kembali<\/option><\/select>\n      <\/div>\n      <div class=\"count\" id=\"hCount\"><\/div>\n      <div class=\"panel tbl\" id=\"hTbl\"><\/div>\n    <\/section>\n  <\/div>\n<\/div>",run:function(document){
(()=>{
/* Pemakaian Unit: SPPD perjalanan dinas (MOBIL INVENTARIS) + mobil grup OPERASIONAL menjadi form pemakaian dan checklist,
   lengkap dengan ACC area, ACC Armada Pusat, ACC Manager Armada, konfirmasi berangkat, upload form berangkat dan pulang, serta riwayat. */
const SERVER='Google Sheets',DRIVE='Google Drive';
const SPPD_ID='19BQ1RVmu04zoehzE_SNJYuurRAH9hgysJU2z_370Q5M';
const SPPD_SHEET="'LIST PERJALANAN DINAS NEW'";
const MASTER_ID='1V18f6If7Emm_bgpfuMUnLiJDCzA-4w1bAnM7D5EhJjw';
const EMP_ID='1h5jyC0dui20lPWCQLaKguzMuVvcHtjjIVPMkd4jrzNA';
const EMP_SHEETS=['STAFF','NON-STAFF','SOPIR','TKBM'];
const TIPE_OK='MOBIL INVENTARIS';
const GRUP_OK='OPERASIONAL';
const NAMA_PUSAT='IZAKI ARVIO MUTTAQIN';
const NAMA_MGR='ABDURRAHMAN';
const FOTO_MAX=900000,PDF_MAX=4*1024*1024;/* foto: karakter base64; PDF: byte (server menerima maksimal sekitar 4,4 MB per berkas) */
let TTD_STAF='',TTD_MGR='',CHK='';/* tanda tangan dan template: diambil dari server setelah login, tidak ada di berkas publik */
const BULAN=['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad=n=>String(n).padStart(2,'0');
const fmtN=n=>Number(n).toLocaleString('id-ID');
const tglL=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()]} ${d.getFullYear()}`:'';
const tglS=d=>d?`${pad(d.getDate())} ${BULAN[d.getMonth()].slice(0,3)} ${d.getFullYear()}`:'';
const jam=d=>d?`${pad(d.getHours())}:${pad(d.getMinutes())}`:'';
let mcp=null,db=null,user=null;
const ME={id:null,role:null,areas:[]};
let TRIPS=[],CARS=[],EMP=new Map(),REC=new Map(),LOADED=0,PROBLEMS=[];
const S={tab:'pick',q:'',sppd:null,car:'',open:false,busy:false,confirm:null,pq:'',hq:'',hst:'ALL'};
const isAdminLike=()=>ME.role==='admin'||ME.role==='pusat';
const canCreate=()=>isAdminLike();
const canAC=r=>isAdminLike()||(ME.role==='daerah'&&ME.areas.includes(r.kode));
const actor=()=>(window.__acct&&window.__acct.label)||ME.id||'';

async function loadPrivateAssets(){
  const get=async n=>{try{const r=await fetch('/api/asset/'+n,{credentials:'same-origin'});if(!r.ok)return '';const b=await r.blob();
    return await new Promise(res=>{const f=new FileReader();f.onload=()=>res(String(f.result));f.onerror=()=>res('');f.readAsDataURL(b)})}catch(e){return ''}};
  [TTD_STAF,TTD_MGR,CHK]=await Promise.all([get('ttd_staf.png'),get('ttd_mgr.png'),get('chk.jpg')]);
}

/* ---------- konektor ---------- */
const openEnd=rg=>String(rg).replace(/([A-Z]+\d+):([A-Z]+)\d+$/,'$1:$2');
async function getVals(id,range){
  const run=async rg=>{
    const r=await mcp.callTool(SERVER,'get_values',{spreadsheetId:id,range:rg},{cache:false});
    let v=r&&r.payload&&r.payload.values;
    if(!v){try{v=JSON.parse(r.content[0].text).values}catch(e){v=null}}
    return v||[];
  };
  /* panggilan konektor kadang menggantung: batasi 25 detik, ulangi sekali */
  const tm=(p,ms)=>new Promise((ok,no)=>{const t=setTimeout(()=>no({code:'timeout',message:'Spreadsheet terlalu lama merespons'}),ms);p.then(v=>{clearTimeout(t);ok(v)},e=>{clearTimeout(t);no(e)})});
  try{
    try{return await tm(run(range),25000)}
    catch(e){if(e&&e.code==='timeout')return await tm(run(range),25000);throw e}
  }
  catch(e){
    /* bad_request biasanya karena batas baris melewati ukuran grid sheet: coba lagi tanpa batas baris bawah */
    if(e&&e.code==='bad_request'){const alt=openEnd(range);if(alt!==range)return await run(alt)}
    throw e;
  }
}
function errText(e,ctx){
  const c=e&&e.code,m=(e&&e.message)||'',w=ctx||'Spreadsheet';
  if(c==='unauthenticated')return 'Sesi berakhir. Muat ulang halaman lalu masuk lagi.';
  if(c==='forbidden')return m||'Akun Anda tidak berwenang untuk data ini.';
  if(c==='sheets_denied')return w+': Google menolak akses. Bagikan spreadsheet ini ke akun layanan server (email service account) sebagai Editor, lalu klik Muat ulang.';
  if(c==='sheets_not_configured')return 'Server belum disambungkan ke Google Sheets. Hubungi admin sistem.';
  if(c==='sheets_auth_failed')return 'Server gagal masuk ke Google. Periksa kunci service account.';
  if(c==='sheets_unavailable')return 'Google Sheets sedang tidak merespons. Coba muat ulang sebentar lagi.';
  if(c==='sheets_error')return w+': '+m.slice(0,160);
  if(c==='drive_error'||c==='drive_unavailable')return m||'Google Drive tidak merespons.';
  if(c==='timeout')return 'Spreadsheet terlalu lama merespons. Coba muat ulang.';
  if(c==='rate_limited')return 'Terlalu banyak permintaan. Tunggu sebentar lalu coba lagi.';
  if(c==='network')return 'Server tidak bisa dihubungi. Periksa koneksi internet Anda.';
  if(c==='bad_request')return m||'Permintaan tidak valid.';
  return 'Gagal mengakses Google Sheets ('+(c||'error')+').';
}

/* ---------- tanggal ---------- */
const BLN_IDX={};BULAN.forEach((b,i)=>{BLN_IDX[b.toLowerCase()]=i;BLN_IDX[b.slice(0,3).toLowerCase()]=i});
BLN_IDX['agu']=7;BLN_IDX['agt']=7;BLN_IDX['okt']=9;BLN_IDX['des']=11;BLN_IDX['mei']=4;BLN_IDX['nop']=10;BLN_IDX['nov']=10;
/* sel tanggal SPPD berbentuk teks "Kamis, 20 Agustus 2026"; terima juga 20/08/2026 */
function parseTgl(s){
  const t=String(s||'').trim();if(!t)return null;
  let m=t.match(/(\d{1,2})\s+([A-Za-z]+)\.?\s+(\d{4})/);
  if(m){const mo=BLN_IDX[m[2].toLowerCase()];if(mo!=null){const d=new Date(+m[3],mo,+m[1]);return d.getMonth()===mo?d:null}}
  m=t.match(/(\d{1,2})[\/-](\d{1,2})[\/-](\d{4})/);
  if(m){const d=new Date(+m[3],+m[2]-1,+m[1]);return d.getMonth()===+m[2]-1?d:null}
  return null;
}
const dStr=d=>d?`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`:'';
const dPar=s=>{const m=String(s||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);return m?new Date(+m[1],+m[2]-1,+m[3]):null};
const isoD=s=>{const d=s?new Date(s):null;return d&&!isNaN(d)?d:null};

/* ---------- data ---------- */
const g=(r,i)=>String(r&&r[i]!=null?r[i]:'').trim();
/* kolom dicari dari judul di baris 1-3 sheet, karena sheet SPPD pernah menambah kolom (mis. JARAK PERJALANAN) dan menggeser agenda */
function tripCols(h){
  const up=(r,i)=>String((h[r]&&h[r][i])||'').trim().toUpperCase();
  const width=Math.max(...h.map(r=>r.length),14);
  const find=(rows,re)=>{for(const r of rows)for(let i=0;i<width;i++)if(re.test(up(r,i)))return i;return -1};
  const cSppd=find([1,0],/^NO\.?\s*SPPD/),cB=find([1,0],/^TANGGAL BERANGKAT/),cP=find([1,0],/^TANGGAL PULANG/);
  const cTipe=find([2,1],/^TIPE KENDARAAN/),cAg=find([1,2],/^AGENDA/),cKar=find([1,0],/^KARYAWAN/);
  const col={sppd:cSppd>=0?cSppd:1,b:cB>=0?cB:3,p:cP>=0?cP:4,tipe:cTipe>=0?cTipe:11,agenda:cAg>=0?cAg:14};
  const lo=cKar>=0?cKar:5,nib=[];
  for(let i=lo;i<col.tipe;i++)if(/^[1-6]$/.test(up(2,i)))nib.push(i);
  col.nib=nib.length?nib:[5,6,7,8,9,10];
  return col;
}
async function loadTrips(){
  const [head,v]=await Promise.all([getVals(SPPD_ID,SPPD_SHEET+'!A1:Z3'),getVals(SPPD_ID,SPPD_SHEET+'!A4:Z')]);
  const C=tripCols(head);
  const out=[];
  v.forEach((r,i)=>{
    const sppd=g(r,C.sppd);if(!sppd)return;
    if(g(r,C.tipe).toUpperCase()!==TIPE_OK)return;
    const nib=C.nib.map(k=>g(r,k)).filter(x=>x&&x!=='0');
    out.push({sppd,bTxt:g(r,C.b),pTxt:g(r,C.p),berangkat:parseTgl(g(r,C.b)),pulang:parseTgl(g(r,C.p)),nib,agenda:g(r,C.agenda),idx:i});
  });
  out.sort((a,b)=>((b.berangkat?+b.berangkat:0)-(a.berangkat?+a.berangkat:0))||b.idx-a.idx);
  return out;
}
async function loadCars(){
  const v=await getVals(MASTER_ID,"'MASTER'!A1:Q3000");
  const seen=new Set(),out=[];
  for(const r of v){
    const nopol=g(r,0);if(!nopol)continue;
    if(g(r,11).toUpperCase()!==GRUP_OK)continue;
    const k=nopol.toUpperCase().replace(/\s+/g,' ');if(seen.has(k))continue;seen.add(k);
    out.push({nopol,jenis:g(r,1),merk:g(r,5),tipe:g(r,6),lokasi:g(r,12)||g(r,10)||g(r,16),grup:g(r,11),kode:g(r,15),area:g(r,16)||g(r,12)||g(r,10)});
  }
  out.sort((a,b)=>a.nopol.localeCompare(b.nopol));
  return out;
}
async function loadEmp(){
  const map=new Map(),bad=[];
  await Promise.all(EMP_SHEETS.map(async sh=>{
    try{
      const v=await getVals(EMP_ID,`'${sh}'!A2:B`);
      v.forEach(r=>{const n=g(r,0),nm=g(r,1);if(n&&nm&&!map.has(n))map.set(n,nm)});
    }catch(e){bad.push(sh+': '+errText(e,'Database karyawan'))}
  }));
  if(bad.length)PROBLEMS.push('Sebagian database karyawan belum terbaca ('+bad.join(' | ')+'). Nama yang belum ditemukan tampil sebagai NIB.');
  return map;
}
async function loadRecs(){
  const sn=await db.collection('pakai').get(),m=new Map();
  sn.docs.forEach(d=>{const x=d.data()||{};if(x.sppd)m.set(d.id,Object.assign({},x,{id:d.id}))});
  return m;
}
let LOADING=false;
/* tahap 1: pengajuan dan daftar SPPD (cukup untuk membuka dropdown); tahap 2: mobil dan nama karyawan di latar belakang */
async function loadData(onFirst){
  PROBLEMS=[];
  const pr=db?loadRecs():Promise.reject({code:'local',message:'Database halaman tidak tersedia.'});
  const pt=canCreate()?loadTrips():null,pc=canCreate()?loadCars():null,pe=canCreate()?loadEmp():null;
  const first=await Promise.allSettled(pt?[pr,pt]:[pr]);
  if(first[0].status==='fulfilled')REC=first[0].value;else{REC=new Map();PROBLEMS.push('Data pemakaian tersimpan belum terbaca: '+((first[0].reason&&first[0].reason.message)||'cek akses')+'.')}
  if(pt){
    const a=first[1];
    if(a.status==='fulfilled')TRIPS=a.value;else{TRIPS=[];PROBLEMS.push(errText(a.reason,'Daftar perjalanan dinas'))}
    CARS=[];EMP=new Map();LOADING=true;
  }
  LOADED=Date.now();
  if(onFirst)onFirst();
  if(pt){
    const [b,c]=await Promise.allSettled([pc,pe]);
    if(b.status==='fulfilled')CARS=b.value;else{CARS=[];PROBLEMS.push(errText(b.reason,'Master armada'))}
    if(c.status==='fulfilled')EMP=c.value;else{EMP=new Map();PROBLEMS.push(errText(c.reason,'Database karyawan'))}
    LOADING=false;LOADED=Date.now();
  }
}
const ridOf=s=>String(s).replace(/[^A-Za-z0-9]+/g,'_').replace(/^_+|_+$/g,'');
const names=t=>t.nama||t.nib.map(n=>({nib:n,name:EMP.get(n)||''}));
/* "KE PORT CIKARANG (DAWUAN) AGENDA ..." dipecah menjadi tujuan dan agenda */
function splitAgenda(s){
  const t=String(s||'').trim();
  const m=t.match(/^(.*?)\s*\bAGENDA\b\s*(.*)$/is);
  if(!m)return {tujuan:t,agenda:t};
  const tuj=m[1].replace(/^KE\s+/i,'').trim();
  return {tujuan:tuj||t,agenda:m[2].trim()||t};
}
const tripOf=r=>({sppd:r.sppd,nib:r.nib||[],nama:r.nama||[],agenda:r.agenda||'',bTxt:r.bTxt||'',pTxt:r.pTxt||'',berangkat:dPar(r.berangkat),pulang:dPar(r.pulang)});
const carOf=r=>({nopol:r.nopol,jenis:r.jenis||'',merk:r.merk||'',tipe:r.tipe||'',lokasi:r.lokasi||'',grup:r.grup||'',kode:r.kode||'',area:r.area||''});
const recOf=()=>S.sppd?REC.get(ridOf(S.sppd))||null:null;
/* pasangan SPPD, mobil, dan data tersimpan yang sedang dilihat */
function view(){
  const rec=recOf();
  if(rec)return {rec,t:tripOf(rec),c:carOf(rec)};
  const t=TRIPS.find(x=>x.sppd===S.sppd)||null,c=CARS.find(x=>x.nopol===S.car)||null;
  return {rec:null,t,c};
}
const safeName=s=>String(s).replace(/[\\/:*?"<>|]+/g,'-').replace(/\s+/g,' ').trim();
function stat(r){
  if(r.returned)return {k:'back',t:'Telah kembali',d:'Form kepulangan sudah diunggah'};
  if(r.dep)return {k:'go',t:'Berangkat',d:'Unit sudah diberangkatkan, menunggu form kepulangan'};
  if(r.ar&&r.pu)return {k:'park',t:'Siap berangkat',d:'Semua ACC lengkap, tekan Berangkat saat unit jalan'};
  if(r.ar)return {k:'park',t:'Menunggu ACC Manager',d:'ACC Armada Pusat selesai, menunggu ACC Manager Armada'};
  if(r.ac)return {k:'wait',t:'ACC area',d:'Sudah di-ACC area, menunggu ACC Armada Pusat'};
  return {k:'wait',t:'Menunggu ACC',d:'Belum ada persetujuan'};
}
const inScope=r=>isAdminLike()||(ME.role==='daerah'&&ME.areas.includes(r.kode));

/* ---------- simpan ke database ---------- */
async function patch(rec,ch,aksi){
  let cur=rec;
  try{const sn=await db.doc('pakai/'+rec.id).get();if(sn.exists)cur=Object.assign({},sn.data(),{id:rec.id})}catch(e){}
  const nx=Object.assign({},cur,ch,{id:rec.id});
  const body=Object.assign({},nx);delete body.id;
  await db.doc('pakai/'+rec.id).set(body);
  REC.set(rec.id,nx);
  try{if(aksi&&ME.id)db.collection('log').add({nomor:rec.sppd,aksi,by:ME.id,at:new Date().toISOString()})}catch(e){}
  return nx;
}

/* ---------- tampilan: umum ---------- */
function gate(h,p,btn){
  $('gate').hidden=false;$('app').hidden=true;
  $('gate').innerHTML=`<h2>${esc(h)}</h2><p>${esc(p)}</p>`+(btn?`<button class="btn" id="gateBtn" type="button">${esc(btn)}</button>`:'');
  if(btn)$('gateBtn').onclick=boot;
}
const roleLabel=()=>ME.role==='admin'?'Admin':ME.role==='pusat'?'Armada Pusat':'Armada Daerah'+(ME.areas.length?' · '+ME.areas.join(', '):'');
const recs=()=>[...REC.values()].filter(inScope);
function tripLabel(t){
  const b=t.berangkat?tglS(t.berangkat):(t.bTxt||'-'),p=t.pulang?tglS(t.pulang):(t.pTxt||'-');
  return b+(p&&p!==b?' sampai '+p:'');
}
function tripItem(t,on){
  const rc=REC.get(ridOf(t.sppd)),st=rc?stat(rc):null;
  return `<button type="button" class="spi${on?' on':''}" role="option" aria-selected="${on}" data-s="${esc(t.sppd)}">
    <span class="spt"><b class="num">${esc(t.sppd)}</b><span class="spd">${esc(tripLabel(t))}</span>${st?`<span class="pill p-${st.k}">${esc(st.t)}</span>`:''}</span>
    <span class="spn">${t.nib.map(n=>`<i class="num">${esc(n)}</i>`).join('')||'<em>tanpa NIB</em>'}</span>
    <small>${esc(t.agenda||'-')}</small></button>`;
}
function filteredTrips(){
  const q=S.q.trim().toLowerCase();
  if(!q)return TRIPS;
  return TRIPS.filter(t=>(t.sppd+' '+t.nib.join(' ')+' '+t.agenda+' '+t.bTxt+' '+t.pTxt+' '+names(t).map(n=>n.name).join(' ')).toLowerCase().includes(q));
}
function drawList(){
  const rows=filteredTrips();
  $('spCount').textContent=rows.length===TRIPS.length?fmtN(TRIPS.length)+' SPPD mobil inventaris':fmtN(rows.length)+' dari '+fmtN(TRIPS.length)+' SPPD';
  $('spList').innerHTML=rows.length?rows.slice(0,150).map(t=>tripItem(t,t.sppd===S.sppd)).join('')+(rows.length>150?`<div class="hint" style="padding:8px 12px">Menampilkan 150 teratas. Persempit dengan kolom cari.</div>`:''):'<div class="empty">Tidak ada SPPD mobil inventaris yang cocok.</div>';
}
function drawTrigger(){
  const {t}=view();
  $('spBtn').setAttribute('aria-expanded',S.open);
  $('spPanel').hidden=!S.open;
  if(!t){$('spBtn').innerHTML='<span class="ph">Pilih SPPD perjalanan dinas</span><span class="car">▾</span>';return}
  $('spBtn').innerHTML=`<span class="sel"><b class="num">${esc(t.sppd)}</b><span>${esc(tripLabel(t))}</span><span class="num">NIB ${esc(t.nib.join(', ')||'-')}</span><small>${esc(t.agenda||'-')}</small></span><span class="car">▾</span>`;
}
function render(){
  $('gate').hidden=true;$('app').hidden=false;
  $('roleTag').hidden=false;$('roleTag').textContent=roleLabel();
  $('reload').hidden=false;
  $('stamp').textContent=LOADED?'Dibaca '+pad(new Date(LOADED).getHours())+':'+pad(new Date(LOADED).getMinutes()):'';
  const b=$('banner');b.hidden=!PROBLEMS.length;b.innerHTML=PROBLEMS.map(esc).join('<br>');
  const all=recs();
  const nW=all.filter(r=>!r.dep&&!r.returned&&!(r.ar&&r.pu)).length,nR=all.filter(r=>!r.dep&&!r.returned&&r.ar&&r.pu).length,nG=all.filter(r=>r.dep&&!r.returned).length,nB=all.filter(r=>r.returned).length;
  $('tiles').innerHTML=`<div class="panel tile t-wait"><span class="k">Menunggu ACC</span><span class="v num">${fmtN(nW)}</span><span class="s">belum lengkap persetujuannya</span></div>
  <div class="panel tile t-park"><span class="k">Siap berangkat</span><span class="v num">${fmtN(nR)}</span><span class="s">ACC lengkap, belum berangkat</span></div>
  <div class="panel tile t-go"><span class="k">Sedang berangkat</span><span class="v num">${fmtN(nG)}</span><span class="s">menunggu form kepulangan</span></div>
  <div class="panel tile"><span class="k">Telah kembali</span><span class="v num">${fmtN(nB)}</span><span class="s">arsip pemakaian selesai</span></div>`;
  $('tab-proc').innerHTML='Dalam proses'+(all.filter(r=>!r.dep&&!r.returned).length?` <span class="tcnt">${fmtN(all.filter(r=>!r.dep&&!r.returned).length)}</span>`:'');
  $('pickCard').hidden=!canCreate();
  drawTrigger();drawList();
  const rec=recOf(),keep=rec?rec.nopol:S.car;
  $('carSel').innerHTML='<option value="">Pilih mobil operasional</option>'+CARS.map(c=>`<option value="${esc(c.nopol)}">${esc(c.nopol)} · ${esc([c.jenis,c.merk].filter(Boolean).join(' '))}${c.area?' · '+esc(c.area):''}</option>`).join('')+(rec&&!CARS.some(c=>c.nopol===rec.nopol)?`<option value="${esc(rec.nopol)}">${esc(rec.nopol)}</option>`:'');
  $('carSel').value=keep||'';
  $('carSel').disabled=!!rec;
  $('carHint').textContent=rec?'Mobil terkunci sejak pemakaian diajukan. Batalkan pengajuan bila ingin mengganti mobil.':LOADING?'Memuat daftar mobil…':CARS.length?'Hanya mobil grup '+GRUP_OK+' dari sheet MASTER yang bisa dipilih.':'Belum ada mobil grup '+GRUP_OK+' yang terbaca dari sheet MASTER.';
  drawResult();drawTab();
}

/* ---------- form fisik dan checklist ---------- */
const logoSrc=()=>{try{return (window.__realDoc||window.document).querySelector('.brand img').src}catch(e){return ''}};
function namaHTML(t){
  const n=names(t);
  return n.length?n.map((x,i)=>`${n.length>1?(i+1)+'. ':''}${esc(x.name||('NIB '+x.nib))}`).join('<br>'):'';
}
function checklistHTML(t,c){
  const v=(l,tp,w,s,cls)=>`<div class="v${cls?' '+cls:''}" style="left:${l}%;top:${tp}%;max-width:${w}%">${s}</div>`;
  const nm=names(t).map(x=>x.name||('NIB '+x.nib));
  return `<div class="paper ck" id="paperck"><div class="in"><img class="bg" src="${CHK}" alt="">
  ${v(20.3,20.9,16.8,esc(c.lokasi))}${v(20.3,23.5,16.8,esc([c.jenis,c.merk].filter(Boolean).join(' ')))}${v(20.3,26.5,17.6,nm.map(esc).join('<br>'),'wr')}
  ${v(51.9,20.9,18,esc(tglL(t.berangkat)||t.bTxt))}${v(51.9,23.5,18,esc(c.nopol))}</div></div>`;
}
function formHTML(t,c,rec){
  const f=(k,h)=>`<dt>${k}</dt><span class="c">:</span><dd>${h||''}</dd>`;
  const sp=splitAgenda(t.agenda),n=names(t),a=!!(rec&&rec.ar),p=!!(rec&&rec.pu);
  const pemakai=n.map(x=>`<div>${esc(x.name||('NIB '+x.nib))}</div>`).join('');
  return `<div class="paper" id="paper">
  <div class="hd"><img src="${logoSrc()}" alt=""><h1>FORMULIR PEMAKAIAN UNIT OPERASIONAL MANAGEMEN</h1></div>
  <dl>${f('NO. FORM PEMAKAIAN',esc(t.sppd))}${f('NAMA',namaHTML(t))}${f('ALAMAT TUJUAN',esc(sp.tujuan))}<div class="gap"></div>${f('NOPOL UNIT ARMADA',esc(c.nopol))}${f('JENIS UNIT ARMADA',esc(c.jenis))}${f('MERK UNIT ARMADA',esc(c.merk))}${f('LOKASI TERAKHIR UNIT',esc(c.lokasi))}${f('GROUP UNIT',esc(c.grup))}${f('TANGGAL PAKAI',esc(tglL(t.berangkat)||t.bTxt))}${f('PELAPORAN TANGGAL KEMBALI',esc(tglL(t.pulang)||t.pTxt))}</dl>
  <h2>Aturan Pemakaian Unit Armada Baraka Express</h2>
  <ol><li>Setiap pemakaian unit kendaraan menjadi tanggung jawab penuh pemakai, termasuk segala akibat, risiko, dan kerusakan yang terjadi selama masa penggunaan.</li><li>Pemakai wajib menjaga dan menggunakan kendaraan dengan baik; segala bentuk kerusakan, kehilangan, atau konsekuensi hukum yang timbul selama pemakaian sepenuhnya menjadi tanggung jawab pemakai.</li><li>Unit kendaraan yang dipakai harus dikembalikan dalam kondisi semula. Apabila terjadi kerusakan atau kehilangan, seluruh biaya perbaikan dan/atau penggantian ditanggung oleh pemakai.</li><li>Pemakaian kendaraan bersifat tanggung jawab pribadi; segala akibat yang timbul selama penggunaan, baik kerusakan ringan maupun berat, menjadi beban pemakai.</li></ol>
  <p>Dengan ini menyatakan dengan kondisi sadar bahwa saya memakai kendaraan milik perusahaan PT Baraka Sarana Tama sesuai dengan data diatas dan menyetujui Aturan Pemakaian Unit Armada Baraka Express secara jelas.</p>
  <div class="sig">
    <div><div class="h">PEMAKAI</div><div class="box"></div><div class="nm">${pemakai}</div></div>
    <div><div class="h">STAF ARMADA</div><div class="box"></div><div class="nm">ARMADA ${esc(String(c.area||'').toUpperCase())}</div></div>
    <div><div class="h">ARMADA PUSAT</div><div class="box" data-ttd="staf" data-on="${a?1:0}">${a?`<img src="${TTD_STAF}" alt="Tanda tangan Armada Pusat">`:''}</div><div class="nm">${NAMA_PUSAT}</div></div>
    <div style="grid-column:2;margin-top:14px"><div class="h">MANAGER ARMADA</div><div class="box" data-ttd="mgr" data-on="${p?1:0}">${p?`<img src="${TTD_MGR}" alt="Tanda tangan dan stempel Manager Armada">`:''}</div><div class="nm">${NAMA_MGR}</div></div>
  </div></div>`;
}
const say=(id,t,err)=>{const m=$(id);if(m){m.textContent=t;m.classList.toggle('err',!!err)}};
const paperCss=()=>'.paper{--paper:#fff;--ink:#0b0b0b}\n'+document.querySelector('style').textContent.split('\n').filter(l=>l.startsWith('.paper')).join('\n');

/* ---------- detail pemakaian ---------- */
function drawCancel(){
  const b=$('delTop');if(!b)return;
  const rec=recOf(),ok=!!rec&&(isAdminLike()||canAC(rec))&&!rec.dep&&!rec.returned;
  b.hidden=!ok;if(!ok)return;
  b.textContent=S.confirm==='del'?'Klik lagi untuk memastikan':'Batalkan pengajuan';
  b.disabled=!!S.busy;b.onclick=()=>delRec(rec);
}
function drawResult(){drawCancel();drawResult0()}
function drawResult0(){
  const {rec,t,c}=view(),box=$('result');
  if(!t||!c){
    box.innerHTML=`<div class="panel empty">${canCreate()?`${!t?'Pilih SPPD terlebih dulu':'Pilih mobil operasional'}${!t&&!c?', lalu pilih mobil.':'.'} Form pemakaian dan checklist terisi otomatis setelah keduanya dipilih.`:'Pilih satu pemakaian dari tab Dalam proses atau Riwayat untuk melihat detailnya.'}</div>`;
    return;
  }
  const n=names(t),miss=n.filter(x=>!x.name).length;
  let ctrl='';
  if(!rec){
    ctrl=`<div class="act"><button class="btn" id="mk" type="button" ${S.busy?'disabled':''}>Ajukan pemakaian</button><span class="hint">Menyimpan pasangan SPPD dan mobil ini agar bisa di-ACC, diberangkatkan, dan masuk riwayat.</span></div><div class="msg" id="actMsg" role="status"></div>`;
  }else{
    const s=stat(rec);
    const mk=(k,lbl,ok,hint)=>!ok?`<button class="btn alt" disabled type="button">${lbl}</button><span class="hint">${hint}</span>`
      :`<button class="btn ${rec[k]?'warn':''}" data-k="${k}" type="button" ${S.busy?'disabled':''}>${S.confirm===k?'Klik lagi untuk memastikan':rec[k]?'Batalkan '+lbl:lbl}</button>`;
    const fmt=iso=>{const d=isoD(iso);return d?tglS(d)+' '+jam(d):''};
    ctrl=`<div class="steps">
      <div class="step done"><b>1. Diajukan</b><small>${fmt(rec.createdAt)}</small></div>
      <div class="step ${rec.ac?'done':''}"><b>2. ACC area</b><small>${rec.ac?fmt(rec.acAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.ar?'done':''}"><b>3. ACC Armada Pusat</b><small>${rec.ar?fmt(rec.arAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.pu?'done':''}"><b>4. ACC Manager Armada</b><small>${rec.pu?fmt(rec.puAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.dep?'done':''}"><b>5. Berangkat</b><small>${rec.dep?fmt(rec.depAt)||'sudah':'belum'}</small></div>
      <div class="step ${rec.returned?'done':''}"><b>6. Kembali</b><small>${rec.returned?fmt(rec.retAt)||'sudah':'belum'}</small></div>
    </div>
    <div><span class="pill p-${s.k}">${esc(s.t)}</span> <span class="hint">${esc(s.d)}</span></div>
    <div class="act"><div class="act">${mk('ac','ACC area',canAC(rec)&&!rec.dep,rec.dep?'Sudah berangkat.':'Area ini bukan wewenang akun Anda.')}</div><div class="act">${mk('ar','ACC Armada Pusat',isAdminLike()&&!rec.pu&&!rec.dep,rec.pu?'Batalkan ACC Manager Armada dulu.':rec.dep?'Sudah berangkat.':'Hanya Armada Pusat dan Admin.')}</div><div class="act">${mk('pu','ACC Manager Armada',isAdminLike()&&rec.ar&&!rec.dep,!isAdminLike()?'Hanya Armada Pusat dan Admin.':rec.dep?'Sudah berangkat.':'ACC Armada Pusat harus dicentang lebih dulu.')}</div></div>
    <div class="msg" id="actMsg" role="status"></div>
    <div id="berSec"></div>
    <div class="dep"><span class="lbl">Konfirmasi keberangkatan</span>
      <div class="act" style="margin:6px 0">${rec.dep?`<span class="pill p-go">Sudah berangkat</span><span class="hint">${esc(fmt(rec.depAt))}${rec.depBy?' · '+esc(rec.depBy):''}</span>${isAdminLike()&&!rec.returned?`<button class="btn warn sm" data-k="dep" type="button" ${S.busy?'disabled':''}>${S.confirm==='dep'?'Klik lagi untuk memastikan':'Batalkan berangkat'}</button>`:''}`
        :`${isAdminLike()&&rec.ar&&rec.pu?`<button class="btn" data-k="dep" type="button" ${S.busy?'disabled':''}>${S.confirm==='dep'?'Klik lagi untuk memastikan':'Berangkat'}</button><span class="hint">Tekan saat unit benar-benar jalan.</span>`:`<button class="btn alt" disabled type="button">Berangkat</button><span class="hint">${!isAdminLike()?'Hanya Armada Pusat dan Admin.':'Menunggu ACC Armada Pusat dan ACC Manager Armada.'}</span>`}`}</div></div>
    <div id="pulSec"></div>`;
  }
  box.innerHTML=`<div class="panel card">
    <div class="lbl">Ringkasan pemakaian</div>
    <div class="sum">
      <div><span class="k">No. SPPD</span><b class="num">${esc(t.sppd)}</b></div>
      <div><span class="k">Berangkat sampai pulang</span><b>${esc(tglL(t.berangkat)||t.bTxt)}${t.pulang&&t.berangkat&&+t.pulang!==+t.berangkat?' sampai '+esc(tglL(t.pulang)):''}</b></div>
      <div><span class="k">Karyawan</span><b>${n.map(x=>esc(x.name||'(belum ada di database)')+' <span class="num hint">'+esc(x.nib)+'</span>').join('<br>')||'-'}</b></div>
      <div><span class="k">Mobil</span><b>${esc(c.nopol)}</b><span class="hint">${esc([c.jenis,c.merk,c.tipe].filter(Boolean).join(' '))} · ${esc(c.area||c.lokasi)}</span></div>
      <div class="wide"><span class="k">Agenda</span><b>${esc(t.agenda||'-')}</b></div>
    </div>
    ${miss&&!rec?`<div class="msg err">${miss} NIB belum ditemukan di database karyawan, jadi form memakai NIB sebagai pengganti nama.</div>`:''}
    ${ctrl}
  </div>
  <div class="panel card"><span class="lbl">Dokumen</span>
    <div class="act"><button class="btn" id="dlForm" type="button">Unduh form pemakaian (PDF)</button><button class="btn" id="dlCk" type="button">Unduh checklist pemeriksaan (PDF)</button><button class="btn alt" id="prAll" type="button">Cetak keduanya</button></div>
    <div class="msg" id="dlMsg" role="status"></div>
    <p class="hint">Tanda tangan Armada Pusat muncul setelah ACC Armada Pusat dicentang, tanda tangan Manager Armada setelah ACC Manager Armada. ACC area hanya centang, tanpa tanda tangan.</p>
  </div>
  <div><span class="lbl">Pratinjau form pemakaian</span><div class="sheetwrap" style="margin-top:8px">${formHTML(t,c,rec)}</div></div>
  <div><span class="lbl">Pratinjau checklist pemeriksaan</span><div class="sheetwrap" style="margin-top:8px">${checklistHTML(t,c)}</div></div>
  ${rec&&isAdminLike()&&!rec.dep&&!rec.returned?`<div class="act"><button class="btn alt sm" id="delRec" type="button">${S.confirm==='del'?'Klik lagi untuk memastikan':'Batalkan pengajuan ini'}</button><span class="hint">Menghapus pengajuan beserta semua ACC. Berkas di Drive tidak ikut terhapus.</span></div>`:''}`;
  $('dlForm').onclick=()=>savePdf('form');
  $('dlCk').onclick=()=>savePdf('ck');
  $('prAll').onclick=saveHtml;
  const mkb=$('mk');if(mkb)mkb.onclick=createRec;
  box.querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>toggle(rec,b.dataset.k));
  const dr=$('delRec');if(dr)dr.onclick=()=>delRec(rec);
  if(rec){drawUpload(rec,'ber');drawUpload(rec,'pul')}
}
async function createRec(){
  const {t,c}=view();if(!t||!c||S.busy||!canCreate())return;
  S.busy=true;say('actMsg','Menyimpan pengajuan …');
  const nm=names(t);
  const rec={id:ridOf(t.sppd),sppd:t.sppd,nib:t.nib.slice(),nama:nm,agenda:t.agenda,bTxt:t.bTxt,pTxt:t.pTxt,berangkat:dStr(t.berangkat),pulang:dStr(t.pulang),
    nopol:c.nopol,jenis:c.jenis,merk:c.merk,tipe:c.tipe,lokasi:c.lokasi,grup:c.grup,kode:c.kode,area:c.area,
    ac:false,ar:false,pu:false,dep:false,returned:false,createdAt:new Date().toISOString(),createdBy:actor()};
  try{
    const ex=await db.doc('pakai/'+rec.id).get();
    if(ex.exists){REC.set(rec.id,Object.assign({},ex.data(),{id:rec.id}));S.car=ex.data().nopol||'';say('actMsg','SPPD ini sudah diajukan sebelumnya. Menampilkan data yang tersimpan.')}
    else await patch(rec,{},'pakai_ajukan');
  }catch(e){S.busy=false;say('actMsg',e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':'Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);return}
  S.busy=false;S.car=c.nopol;render();
}
let confT=0;
async function toggle(rec,k){
  if(S.busy)return;
  if(S.confirm!==k){S.confirm=k;drawResult();clearTimeout(confT);confT=setTimeout(()=>{if(S.confirm===k){S.confirm=null;drawResult()}},4000);return}
  clearTimeout(confT);S.confirm=null;S.busy=true;drawResult();
  try{
    const cur=REC.get(rec.id)||rec,val=!cur[k],now=new Date().toISOString();
    if(k==='ac'&&!canAC(cur))throw {code:'local',message:'Akun Anda tidak berwenang untuk area ini.'};
    if((k==='ar'||k==='pu'||k==='dep')&&!isAdminLike())throw {code:'local',message:'Hanya Armada Pusat dan Admin.'};
    if(k==='pu'&&val&&!cur.ar)throw {code:'local',message:'ACC Armada Pusat harus dicentang lebih dulu.'};
    if(k==='ar'&&!val&&cur.pu)throw {code:'local',message:'Batalkan ACC Manager Armada dulu.'};
    if(k==='dep'&&val&&!(cur.ar&&cur.pu))throw {code:'local',message:'ACC Armada Pusat dan ACC Manager Armada harus lengkap dulu.'};
    if(k==='dep'&&!val&&cur.returned)throw {code:'local',message:'Unit sudah kembali, status berangkat tidak bisa dibatalkan.'};
    const ch=k==='dep'?{dep:val,depAt:val?now:'',depBy:val?actor():''}:{[k]:val,[k+'At']:val?now:'',[k+'By']:val?actor():''};
    const nm=({ac:'acc_area',ar:'acc_armada_pusat',pu:'acc_manager',dep:'berangkat'})[k];
    await patch(cur,ch,'pakai_'+(val?'':'batal_')+nm);
    S.busy=false;render();
    say('actMsg',k==='dep'?(val?'Tersimpan. Pemakaian masuk riwayat dengan status Berangkat.':'Status berangkat dibatalkan.'):(val?'Tersimpan. Persetujuan tercatat.':'Persetujuan dibatalkan.'));
  }catch(e){
    S.busy=false;drawResult();
    say('actMsg',e&&e.code==='local'?e.message:e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':'Gagal menyimpan: '+((e&&e.message)||'coba lagi'),true);
  }
}
async function delRec(rec){
  if(S.busy)return;
  if(S.confirm!=='del'){S.confirm='del';drawResult();clearTimeout(confT);confT=setTimeout(()=>{if(S.confirm==='del'){S.confirm=null;drawResult()}},4000);return}
  clearTimeout(confT);S.confirm=null;S.busy=true;
  try{
    const cur=REC.get(rec.id)||rec;
    if(cur.dep||cur.returned)throw {code:'local',message:'Pemakaian yang sudah berangkat tidak bisa dibatalkan.'};
    await db.doc('pakai/'+rec.id).delete();REC.delete(rec.id);
    try{if(ME.id)db.collection('log').add({nomor:rec.sppd,aksi:'pakai_hapus',by:ME.id,at:new Date().toISOString()})}catch(e){}
    S.busy=false;S.car='';render();
  }catch(e){S.busy=false;drawResult();say('actMsg',e&&e.code==='local'?e.message:'Gagal membatalkan: '+((e&&e.message)||'coba lagi'),true)}
}

/* ---------- unduh dokumen ---------- */
async function savePdf(kind){
  const {rec,t,c}=view();if(!t||!c||S.busy)return;
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){say('dlMsg','Penyimpanan file tidak tersedia di tampilan ini.',true);return}
  if(!window.html2canvas||!window.jspdf){say('dlMsg','Pustaka PDF belum termuat. Muat ulang halaman atau pakai Cetak keduanya.',true);return}
  S.busy=true;$('dlForm').disabled=true;$('dlCk').disabled=true;say('dlMsg','Menyiapkan PDF …');
  const host=window.document.createElement('div');host.style.cssText='position:fixed;left:-9999px;top:0;width:813px;background:#fff';
  host.innerHTML='<style>'+paperCss()+'</style>'+(kind==='form'?formHTML(t,c,rec):checklistHTML(t,c));
  (window.__realDoc||window.document).body.appendChild(host);
  try{
    await Promise.all([...host.querySelectorAll('img')].map(i=>i.decode?i.decode().catch(()=>{}):0));
    const {jsPDF}=window.jspdf,doc=new jsPDF({unit:'pt',format:[609.45,935.43]});
    const pw=doc.internal.pageSize.getWidth(),ph=doc.internal.pageSize.getHeight();
    const el=host.querySelector('.paper');
    const cv=await window.html2canvas(el,{scale:2,backgroundColor:'#ffffff'});
    let w=pw,h=cv.height*w/cv.width;if(h>ph){h=ph;w=cv.width*h/cv.height}
    doc.addImage(cv.toDataURL('image/jpeg',.92),'JPEG',(pw-w)/2,0,w,h);
    const fn=kind==='form'?`Form Pemakaian ${safeName(t.sppd)}.pdf`:`Checklist Pemeriksaan ${safeName(c.nopol)} ${safeName(t.sppd)}.pdf`;
    await dl.save({filename:fn,data:doc.output('blob')});
    say('dlMsg',kind==='form'?'Form pemakaian siap disimpan.':'Checklist pemeriksaan siap disimpan.');
  }catch(e){say('dlMsg',(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'PDF gagal dibuat ('+((e&&e.code)||(e&&e.message)||'error')+').',true)}
  finally{host.remove();S.busy=false;if($('dlForm')){$('dlForm').disabled=false;$('dlCk').disabled=false}}
}
async function saveHtml(){
  const {rec,t,c}=view();if(!t||!c)return;
  const dl=await window.claude.use('downloads').catch(()=>null);
  if(!dl){say('dlMsg','Penyimpanan file tidak tersedia di tampilan ini.',true);return}
  const html='<!doctype html><html lang="id"><head><meta charset="utf-8"><title>Form Pemakaian '+esc(t.sppd)+'</title><style>@page{size:215mm 330mm;margin:0}body{margin:0;background:#fff;--paper:#fff;--ink:#0b0b0b}'+paperCss()+'.paper{margin:0 auto}.paper.ck{height:1247px}</style></head><body>'+formHTML(t,c,rec)+checklistHTML(t,c)+'<script>addEventListener("load",function(){setTimeout(function(){print()},500)})<\/script></body></html>';
  try{await dl.save({filename:'Form Pemakaian '+safeName(t.sppd)+'.html',data:new Blob([html],{type:'text/html'})});say('dlMsg','File siap disimpan. Buka file itu dan dialog cetak akan muncul sendiri.')}
  catch(e){say('dlMsg',(e&&e.code==='declined')?'Penyimpanan dibatalkan.':'Gagal menyiapkan file ('+((e&&e.code)||'error')+').',true)}
}

/* ---------- upload ke Google Drive: form berangkat dan form pulang ---------- */
const b64=d=>d.slice(d.indexOf(',')+1);
const payOf=x=>{let v=x&&x.payload;if(!v){try{v=JSON.parse(x.content[0].text)}catch(e){}}return v||{}};
/* server menyimpan ke subfolder area di Drive (membuat bila belum ada), mengubah JPEG menjadi PDF, dan membuang berkas lama area yang sama */
async function driveUp(rec,jenis,p,old){
  const up=payOf(await mcp.callTool(DRIVE,'create_file',{code:rec.kode,jenis,base64Content:b64(p.dataUrl),oldId:old&&old.id||''},{cache:false}));
  if(!up.id)throw {code:'local',message:'Google Drive tidak mengembalikan ID file.'};
  return {id:up.id,url:up.viewUrl||`https://drive.google.com/file/d/${up.id}/view?usp=drivesdk`,title:up.title,folder:up.folder};
}
function shrinkImg(file,max){
  return new Promise((res,rej)=>{
    const u=URL.createObjectURL(file),im=new Image();
    im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('Berkas ini bukan gambar yang bisa dibaca.'))};
    im.onload=()=>{
      URL.revokeObjectURL(u);
      let side=1500,q=.82;
      for(let i=0;i<10;i++){
        const k=Math.min(1,side/Math.max(im.width,im.height)),c=window.document.createElement('canvas');
        c.width=Math.max(1,Math.round(im.width*k));c.height=Math.max(1,Math.round(im.height*k));
        const gx=c.getContext('2d');gx.fillStyle='#fff';gx.fillRect(0,0,c.width,c.height);gx.drawImage(im,0,0,c.width,c.height);
        const d=c.toDataURL('image/jpeg',q);
        if(d.length<=max)return res(d);
        if(q>.5)q-=.1;else side=Math.round(side*.8);
      }
      rej(new Error('Foto terlalu besar. Coba foto dengan resolusi lebih kecil.'));
    };
    im.src=u;
  });
}
/* JPG atau PDF menjadi paket siap unggah */
async function prepFile(f,say2){
  const isPdf=f.type==='application/pdf'||/\.pdf$/i.test(f.name),isImg=/^image\//.test(f.type)||/\.(jpe?g|png|webp)$/i.test(f.name);
  if(!isPdf&&!isImg)throw new Error('Format harus foto (JPG) atau PDF.');
  if(isPdf){
    const d=await new Promise((res,rej)=>{const fr=new FileReader();fr.onload=()=>res(fr.result);fr.onerror=()=>rej(new Error('PDF tidak terbaca.'));fr.readAsDataURL(f)});
    if(atob(d.slice(d.indexOf(',')+1,d.indexOf(',')+9)).slice(0,4)!=='%PDF')throw new Error('Berkas ini bukan PDF yang valid.');
    if(f.size>PDF_MAX)throw new Error('PDF terlalu besar ('+Math.round(f.size/1024/1024*10)/10+' MB, maksimal 4 MB). Kecilkan PDF atau unggah foto JPG.');
    return {dataUrl:d,ext:'pdf',mime:'application/pdf'};
  }
  return {dataUrl:await shrinkImg(f,FOTO_MAX),ext:'jpg',mime:'image/jpeg'};
}
const UP={
  ber:{box:'berSec',title:'Form keberangkatan (checklist pemeriksaan)',jenis:'PAKAI_BERANGKAT',idK:'berId',folK:'berFolder',urlK:'berUrl',nmK:'berName',atK:'berAt',byK:'berBy',
    show:r=>r.ar&&r.pu,hint:'Unggah checklist pemeriksaan dan kelengkapan kendaraan yang sudah dicek sebelum berangkat. Format JPG atau PDF (maksimal 4 MB).',wait:'Form keberangkatan bisa diunggah setelah ACC Armada Pusat dan ACC Manager Armada lengkap.'},
  pul:{box:'pulSec',title:'Form kepulangan (pemeriksaan setelah kembali)',jenis:'PAKAI_PULANG',idK:'formId',folK:'formFolder',urlK:'formUrl',nmK:'formName',atK:'formAt',byK:'formBy',
    show:r=>r.dep||r.returned,hint:'Unggah foto atau PDF form pemeriksaan setelah unit kembali. Setelah tersimpan, status berubah menjadi Telah kembali.',wait:'Form kepulangan bisa diunggah setelah unit diberangkatkan.'}
};
function drawUpload(rec,kind){
  const u=UP[kind],box=$(u.box);if(!box)return;
  const fmt=iso=>{const d=isoD(iso);return d?tglS(d)+' '+jam(d):''};
  const has=!!rec[u.urlK],can=canAC(rec)&&!!db&&u.show(rec);
  const head=`<span class="lbl">${esc(u.title)}</span><div style="margin:6px 0">${has?'<span class="pill p-go">Sudah diunggah</span>':'<span class="pill p-na">Belum diunggah</span>'}${has&&rec[u.atK]?` <span class="hint">${esc(fmt(rec[u.atK]))}${rec[u.byK]?' · '+esc(rec[u.byK]):''}</span>`:''}</div>`;
  const ln=has?`<div class="hint" style="margin:6px 0">Berkas di Drive: <a href="${esc(rec[u.urlK])}" target="_blank" rel="noopener">${esc(rec[u.nmK]||'buka di Drive')}</a></div>`:'';
  if(!u.show(rec)){box.innerHTML=`<div>${head}${ln}<p class="hint">${esc(u.wait)}</p></div>`;return}
  if(!can){box.innerHTML=`<div>${head}${ln}</div>`;return}
  box.innerHTML=`<div>${head}${ln}<p class="hint">${esc(u.hint)}</p>
    <div class="act" style="margin:6px 0"><label class="btn alt sm" style="cursor:pointer">${has?'Ganti berkas':'Pilih foto atau PDF'}<input id="${kind}File" type="file" accept="image/*,.pdf,application/pdf" hidden></label><button class="btn" id="${kind}Save" type="button" disabled>${kind==='pul'?'Simpan dan tandai kembali':'Simpan ke Drive'}</button></div>
    <div class="msg" id="${kind}Msg" role="status"></div></div>`;
  const m=(t,err)=>say(kind+'Msg',t,err);
  let pack=null;
  $(kind+'File').onchange=async ev=>{
    const f=ev.target.files&&ev.target.files[0];pack=null;$(kind+'Save').disabled=true;if(!f)return;
    m('Memproses berkas …');
    try{pack=await prepFile(f,m);$(kind+'Save').disabled=false;m('Berkas siap: '+f.name+(pack.cut?' (10 halaman pertama)':'')+'. Tekan tombol di sebelahnya untuk menyimpan.')}
    catch(e){pack=null;m(e.message||'Berkas gagal diproses.',true)}
  };
  $(kind+'Save').onclick=async()=>{
    if(!pack)return;
    $(kind+'Save').disabled=true;m('Mengunggah ke Google Drive …');
    try{
      const cur=REC.get(rec.id)||rec;
      const d0=await driveUp(cur,u.jenis,pack,cur[u.idK]?{id:cur[u.idK],folder:cur[u.folK]}:null);
      const now=new Date().toISOString();
      const ch={[u.idK]:d0.id,[u.folK]:d0.folder,[u.urlK]:d0.url,[u.nmK]:d0.title,[u.atK]:now,[u.byK]:actor()};
      if(kind==='pul'){ch.returned=true;ch.retAt=now;ch.retBy=actor()}
      await patch(cur,ch,'pakai_upload_'+(kind==='ber'?'berangkat':'pulang'));
      try{await mcp.invalidate()}catch(e){}
      render();
      say(kind+'Msg',kind==='pul'?'Form kepulangan tersimpan. Status: Telah kembali.':'Form keberangkatan tersimpan di Google Drive.');
    }catch(e){m(e&&e.code==='invalid_argument'?'Akun Anda tidak boleh menyimpan data ini.':e&&e.code==='local'?e.message:errText(e,'Google Drive')+' Tidak ada yang diubah.',true);$(kind+'Save').disabled=false}
  };
}

/* ---------- daftar: dalam proses dan riwayat ---------- */
function listRows(kind){
  const q=(kind==='proc'?S.pq:S.hq).trim().toLowerCase();
  let a=recs().filter(r=>kind==='proc'?(!r.dep&&!r.returned):(r.dep||r.returned));
  if(kind==='hist'){
    if(S.hst==='GO')a=a.filter(r=>r.dep&&!r.returned);
    if(S.hst==='BACK')a=a.filter(r=>r.returned);
  }
  if(q)a=a.filter(r=>(r.sppd+' '+r.nopol+' '+(r.area||'')+' '+(r.nama||[]).map(n=>n.name+' '+n.nib).join(' ')+' '+(r.agenda||'')).toLowerCase().includes(q));
  const key=kind==='proc'?'createdAt':'depAt';
  return a.sort((x,y)=>String(y[key]||'').localeCompare(String(x[key]||''))||y.sppd.localeCompare(x.sppd));
}
function drawListTab(kind){
  const rows=listRows(kind),cnt=$(kind==='proc'?'pCount':'hCount'),tb=$(kind==='proc'?'pTbl':'hTbl');
  cnt.textContent=`${fmtN(rows.length)} pemakaian · klik baris untuk membuka detail`;
  if(!rows.length){tb.innerHTML=`<div class="empty">${kind==='proc'?'Tidak ada pemakaian yang sedang diproses.':'Belum ada pemakaian yang diberangkatkan.'}</div>`;return}
  const fmt=iso=>{const d=isoD(iso);return d?tglS(d)+' '+jam(d):'–'};
  tb.innerHTML=`<table><thead><tr><th>${kind==='proc'?'Diajukan':'Berangkat'}</th><th>No. SPPD</th><th>Karyawan</th><th>Mobil</th><th>Area</th><th>Status</th><th>Berkas</th></tr></thead><tbody>${rows.slice(0,300).map(r=>{
    const s=stat(r);
    return `<tr tabindex="0" data-id="${esc(r.id)}"><td class="num">${esc(fmt(kind==='proc'?r.createdAt:r.depAt))}</td><td><b class="num">${esc(r.sppd)}</b><small>${esc(r.agenda||'')}</small></td><td>${(r.nama||[]).map(n=>esc(n.name||('NIB '+n.nib))).join('<br>')}</td><td><b>${esc(r.nopol)}</b><small>${esc([r.jenis,r.merk].filter(Boolean).join(' '))}</small></td><td>${esc(r.area||r.kode||'')}</td><td><span class="pill p-${s.k}">${esc(s.t)}</span></td><td>${r.berUrl?`<a href="${esc(r.berUrl)}" target="_blank" rel="noopener">Berangkat</a>`:''}${r.berUrl&&r.formUrl?' · ':''}${r.formUrl?`<a href="${esc(r.formUrl)}" target="_blank" rel="noopener">Pulang</a>`:''}${!r.berUrl&&!r.formUrl?'<span class="hint">belum ada</span>':''}</td></tr>`}).join('')}</tbody></table>`;
}
function drawTab(){
  for(const k of ['pick','proc','hist'])$('tab-'+k).setAttribute('aria-selected',S.tab===k);
  $('vPick').hidden=S.tab!=='pick';$('vProc').hidden=S.tab!=='proc';$('vHist').hidden=S.tab!=='hist';
  if(S.tab==='proc')drawListTab('proc');
  if(S.tab==='hist')drawListTab('hist');
}
function openRec(id){
  const r=REC.get(id);if(!r)return;
  S.sppd=r.sppd;S.car=r.nopol;S.tab='pick';S.confirm=null;render();
  try{window.scrollTo(0,0)}catch(e){}
}

/* ---------- interaksi ---------- */
function setOpen(v){S.open=v;drawTrigger();if(v){const q=$('spQ');setTimeout(()=>q&&q.focus(),0)}}
$('spBtn').onclick=()=>setOpen(!S.open);
$('spQ').oninput=e=>{S.q=e.target.value;drawList()};
$('spList').addEventListener('click',e=>{
  const b=e.target.closest('[data-s]');if(!b)return;
  S.sppd=b.dataset.s;const rc=recOf();S.car=rc?rc.nopol:'';S.open=false;S.confirm=null;render();
});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&S.open){setOpen(false);$('spBtn').focus()}});
document.addEventListener('click',e=>{if(S.open&&!e.target.closest('.spwrap'))setOpen(false)});
$('carSel').onchange=e=>{S.car=e.target.value;drawResult()};
for(const k of ['pick','proc','hist'])$('tab-'+k).onclick=()=>{S.tab=k;S.confirm=null;drawTab()};
$('pQ').oninput=e=>{S.pq=e.target.value;drawListTab('proc')};
$('hQ').oninput=e=>{S.hq=e.target.value;drawListTab('hist')};
$('hSt').onchange=e=>{S.hst=e.target.value;drawListTab('hist')};
$('pTbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-id]');if(tr&&!e.target.closest('a'))openRec(tr.dataset.id)});
$('hTbl').addEventListener('click',e=>{const tr=e.target.closest('tr[data-id]');if(tr&&!e.target.closest('a'))openRec(tr.dataset.id)});
$('pTbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-id]');if(tr)openRec(tr.dataset.id)}});
$('hTbl').addEventListener('keydown',e=>{if(e.key==='Enter'){const tr=e.target.closest('tr[data-id]');if(tr)openRec(tr.dataset.id)}});
/* muat ulang: pilihan SPPD, mobil, dan pencarian ikut dikosongkan */
$('reload').onclick=async()=>{
  $('reload').disabled=true;
  S.sppd=null;S.car='';S.q='';S.open=false;S.confirm=null;S.pq='';S.hq='';S.hst='ALL';
  $('spQ').value='';$('pQ').value='';$('hQ').value='';$('hSt').value='ALL';
  try{await mcp.invalidate()}catch(e){}
  try{await loadData(render);render()}finally{$('reload').disabled=false}
};
;(function(){const t=$('themeBtn');if(t)t.onclick=()=>{const r=document.documentElement;r.dataset.theme=r.dataset.theme==='dark'?'light':'dark'}})();
const lg=$('logoImg');if(lg)lg.src=logoSrc();

/* ---------- boot ---------- */
async function boot(){
  gate('Memuat data pemakaian','Menyiapkan akses dan membaca spreadsheet.');
  const cl=window.claude;
  if(!cl||!cl.use){gate('Halaman belum siap','Muat ulang halaman ini lalu masuk lagi.','Coba lagi');return}
  [mcp,db,user]=await Promise.all([cl.use('mcp').catch(()=>null),cl.use('db').catch(()=>null),cl.use('user').catch(()=>null)]);
  let me={id:null,isOwner:false,canEdit:false};
  try{if(user)me=await user.me()}catch(e){}
  ME.id=me.id;ME.role=null;ME.areas=[];
  const AC=window.__acct;
  if(AC){
    ME.id=AC.user;
    if(AC.role==='admin'||AC.role==='pusat')ME.role=AC.role;
    else if(AC.role==='daerah'&&(AC.areas||[]).length){ME.role='daerah';ME.areas=AC.areas.slice()}
  }
  else if(me.isOwner||me.canEdit)ME.role='admin';
  else if(db&&me.id){
    try{const s=await db.doc('roles/'+me.id).get();if(s.exists){const x=s.data()||{};if(x.role==='pusat')ME.role='pusat';else if(Array.isArray(x.areas)&&x.areas.length){ME.role='daerah';ME.areas=x.areas}}}catch(e){}
  }
  if(!ME.role){gate('Akun ini tidak punya akses ke fitur ini','Fitur Pemakaian Unit hanya untuk akun Admin, Armada Pusat, dan Armada Daerah. Masuk dengan akun lain.');return}
  if(!mcp){gate('Koneksi ke server tidak tersedia','Muat ulang halaman ini lalu masuk lagi.','Coba lagi');return}
  if(!db){gate('Database tidak tersedia','Persetujuan dan riwayat disimpan di server. Muat ulang halaman ini lalu masuk lagi.','Coba lagi');return}
  if(!canCreate())S.tab='proc';
  let shown=false;
  const assets=loadPrivateAssets();
  try{await loadData(()=>{
    if(canCreate()&&!TRIPS.length&&!REC.size&&PROBLEMS.length){gate('Data belum bisa dibaca',PROBLEMS.join(' '),'Coba lagi');return}
    shown=true;render();
  })}catch(e){gate('Data belum bisa dibaca',errText(e),'Coba lagi');return}
  await assets;if(shown)render();/* tanda tangan dan template checklist tiba terakhir */
}
boot();
})();

}},admin:{css:"\n/* Panel admin: kelola akun, lihat aktivitas, status sistem. Token warna sama dengan Peminjaman. */\n:host{\n  --bg:#f6f8ff;--surface:#ffffff;--surface2:#eff3ff;--fg:#0a1640;--muted:#52618f;--line:#d3ddf5;\n  --accent:#1a4bd8;--accent-fg:#ffffff;--accent-soft:rgba(26,75,216,.09);--late:#d6182f;--late-bg:rgba(214,24,47,.08);--ok:#0a7a45;--ok-bg:rgba(10,122,69,.1);\n  --display:'Chakra Petch','Segoe UI',system-ui,sans-serif;--sans:'Manrope',system-ui,-apple-system,'Segoe UI',sans-serif;--mono:'JetBrains Mono',ui-monospace,Menlo,monospace;\n  color-scheme:light}\n@media (prefers-color-scheme:dark){:host(:not([data-theme=\"light\"])){--bg:#060b1f;--surface:#0d1530;--surface2:#121c3d;--fg:#eaf0ff;--muted:#9aaad6;--line:#24305e;--accent:#5b8cff;--accent-fg:#06102e;--accent-soft:rgba(91,140,255,.14);--late:#ff5a70;--late-bg:rgba(255,90,112,.14);--ok:#4ade9b;--ok-bg:rgba(74,222,155,.12);color-scheme:dark}}\n:host([data-theme=\"dark\"]){--bg:#060b1f;--surface:#0d1530;--surface2:#121c3d;--fg:#eaf0ff;--muted:#9aaad6;--line:#24305e;--accent:#5b8cff;--accent-fg:#06102e;--accent-soft:rgba(91,140,255,.14);--late:#ff5a70;--late-bg:rgba(255,90,112,.14);--ok:#4ade9b;--ok-bg:rgba(74,222,155,.12);color-scheme:dark}\n*{box-sizing:border-box}\n[hidden]{display:none!important}\n.mbody{margin:0;background:var(--bg);color:var(--fg);font-family:var(--sans);font-size:14px;line-height:1.5;padding:20px max(16px,env(safe-area-inset-left,0px)) 48px}\n.wrap{max-width:1240px;margin:0 auto;display:flex;flex-direction:column;gap:18px}\nh1{font-family:var(--display);font-size:26px;margin:0}\nh2{font-family:var(--display);font-size:17px;margin:0}\n.sub{color:var(--muted);margin:2px 0 0}\n.top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap}\n.panel{background:var(--surface);border:1px solid var(--line);border-radius:14px;padding:16px 18px}\n.ph{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}\n.btn{border:1px solid var(--accent);background:var(--accent);color:var(--accent-fg);border-radius:10px;padding:8px 16px;font:600 14px var(--sans);cursor:pointer}\n.btn:disabled{opacity:.5;cursor:not-allowed}\n.btn.alt{background:transparent;color:var(--accent)}\n.btn.warn{background:var(--late);border-color:var(--late);color:#fff}\n.btn.sm{padding:4px 12px;font-size:12px}\n.btn:focus-visible,input:focus-visible,select:focus-visible{outline:2px solid var(--accent);outline-offset:2px}\n.tw{overflow-x:auto}\ntable{border-collapse:collapse;width:100%;min-width:760px}\nth{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);white-space:nowrap}\ntd{padding:9px 10px;border-bottom:1px solid var(--line);vertical-align:middle}\ntd.num,.num{font-family:var(--mono);font-size:12px}\ntd .acts{display:flex;gap:6px;flex-wrap:wrap}\n.pill{display:inline-block;padding:2px 10px;border-radius:999px;font-size:12px;font-weight:700;white-space:nowrap}\n.pill.ok{background:var(--ok-bg);color:var(--ok)}\n.pill.off{background:var(--late-bg);color:var(--late)}\n.pill.role{background:var(--accent-soft);color:var(--accent)}\n.form{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;align-items:end}\n.f{display:flex;flex-direction:column;gap:4px}\nlabel,.lbl{font-size:11px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);font-weight:600}\ninput,select{background:var(--surface2);color:var(--fg);border:1px solid var(--line);border-radius:10px;padding:8px 12px;font:14px var(--sans);min-width:0}\n.areas{display:flex;gap:6px 12px;flex-wrap:wrap;grid-column:1/-1}\n.areas label{text-transform:none;letter-spacing:0;font-size:13px;font-weight:500;color:var(--fg);display:inline-flex;gap:5px;align-items:center}\n.msg{min-height:20px;color:var(--muted)}\n.msg.err{color:var(--late)}\n.secret{font-family:var(--mono);background:var(--surface2);border:1px dashed var(--accent);border-radius:10px;padding:10px 12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap}\n.kv{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}\n.kv div{background:var(--surface2);border-radius:10px;padding:10px 12px}\n.kv b{display:block;font-size:18px;font-family:var(--display)}\n.kv span{color:var(--muted);font-size:12px}\n.bad{color:var(--late);font-weight:600}\n@media (max-width:640px){h1{font-size:21px}}\n\n.mbody{min-height:100%;isolation:isolate}[hidden]{display:none!important}\n#dr,.dr,#veil,.veil,#login{top:calc(var(--navh) + env(safe-area-inset-top,0px))!important}",html:"<div class=\"wrap\">\n  <header class=\"top\">\n    <div><h1>Admin<\/h1><p class=\"sub\">Kelola akun, lihat aktivitas, dan periksa status sistem.<\/p><\/div>\n    <button class=\"btn alt sm\" id=\"themeBtn\" type=\"button\">Ganti tema<\/button>\n  <\/header>\n\n  <section class=\"panel\" aria-labelledby=\"sysT\">\n    <div class=\"ph\"><h2 id=\"sysT\">Status sistem<\/h2><button class=\"btn alt sm\" id=\"sysReload\" type=\"button\">Segarkan<\/button><\/div>\n    <div class=\"kv\" id=\"sys\"><\/div>\n    <p class=\"msg\" id=\"sysMsg\" role=\"status\"><\/p>\n  <\/section>\n\n  <section class=\"panel\" aria-labelledby=\"usrT\">\n    <div class=\"ph\"><h2 id=\"usrT\">Akun pengguna<\/h2><button class=\"btn sm\" id=\"addBtn\" type=\"button\">Tambah akun<\/button><\/div>\n    <form id=\"addForm\" class=\"form\" hidden autocomplete=\"off\">\n      <div class=\"f\"><label for=\"nUser\">Username<\/label><input id=\"nUser\" required minlength=\"3\" maxlength=\"64\" pattern=\"[A-Za-z0-9._\\-]+\" autocapitalize=\"none\" spellcheck=\"false\"><\/div>\n      <div class=\"f\"><label for=\"nRole\">Peran<\/label><select id=\"nRole\"><option value=\"daerah\">Armada Daerah<\/option><option value=\"pusat\">Armada Pusat<\/option><option value=\"admin\">Admin<\/option><option value=\"viewer\">Hanya lihat<\/option><\/select><\/div>\n      <div class=\"f\"><label for=\"nPass\">Password awal<\/label><input id=\"nPass\" type=\"text\" required minlength=\"8\" autocomplete=\"off\" spellcheck=\"false\"><\/div>\n      <div class=\"f\"><button class=\"btn alt\" id=\"nGen\" type=\"button\">Buat password acak<\/button><\/div>\n      <div class=\"areas\" id=\"nAreas\"><\/div>\n      <div class=\"f\"><button class=\"btn\" id=\"nSave\" type=\"submit\">Simpan akun<\/button><\/div>\n    <\/form>\n    <div class=\"secret\" id=\"secret\" hidden><span id=\"secretTxt\"><\/span><button class=\"btn alt sm\" id=\"secretCopy\" type=\"button\">Salin<\/button><button class=\"btn alt sm\" id=\"secretClose\" type=\"button\">Tutup<\/button><\/div>\n    <p class=\"msg\" id=\"usrMsg\" role=\"status\"><\/p>\n    <div class=\"tw\"><table><thead><tr><th>Username<\/th><th>Peran<\/th><th>Area<\/th><th>Status<\/th><th>Login terakhir<\/th><th>Aksi<\/th><\/tr><\/thead><tbody id=\"usrBody\"><\/tbody><\/table><\/div>\n  <\/section>\n\n  <section class=\"panel\" aria-labelledby=\"audT\">\n    <div class=\"ph\"><h2 id=\"audT\">Log aktivitas<\/h2><button class=\"btn alt sm\" id=\"audReload\" type=\"button\">Segarkan<\/button><\/div>\n    <div class=\"tw\"><table><thead><tr><th>Waktu<\/th><th>Pengguna<\/th><th>Aksi<\/th><th>Target<\/th><th>Rincian<\/th><th>IP<\/th><\/tr><\/thead><tbody id=\"audBody\"><\/tbody><\/table><\/div>\n  <\/section>\n<\/div>",run:function(document){
(()=>{
const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const API=window.__api;
const ROLE={admin:'Admin',pusat:'Armada Pusat',daerah:'Armada Daerah',viewer:'Hanya lihat'};
let USERS=[],AREAS={};
const ME=(window.__acct&&window.__acct.user)||'';
const when=iso=>{if(!iso)return '–';const d=new Date(iso);return isNaN(d)?'–':d.toLocaleString('id-ID',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'})};
const say=(id,t,err)=>{const m=$(id);m.textContent=t||'';m.classList.toggle('err',!!err)};
const errMsg=e=>(e&&e.message)||'Terjadi kesalahan.';
const AL='abcdefghjkmnpqrstuvwxyzACDEFGHJKLMNPQRTUVWXYZ2346789';
const gen=()=>Array.from(crypto.getRandomValues(new Uint8Array(14)),x=>AL[x%AL.length]).join('');

/* ---------- status sistem ---------- */
async function loadSys(){
  say('sysMsg','');
  try{
    const s=await API.get('/api/admin/status'),sh=s.sheets||{};
    const up=s.uptimeSec,upT=up>86400?Math.floor(up/86400)+' hari':up>3600?Math.floor(up/3600)+' jam':Math.max(1,Math.floor(up/60))+' menit';
    const cells=[
      ['Versi',(s.version||'–')+(s.commit&&s.commit!=='dev'?' · '+String(s.commit).slice(0,7):'')],['Berjalan',upT],['Mode',s.env],
      ['Akun aktif',s.counts.users],['Sesi aktif',s.counts.sessions],['Catatan koreksi',s.counts.cek],
      ['Google Sheets',!sh.configured?'Belum dikonfigurasi':sh.error?'Gagal masuk':'Tersambung',!sh.configured||!!sh.error],
      ['Area terbaca',sh.areas+(sh.areas?'':' (cek akses MASTER)'),!sh.areas]];
    $('sys').replaceChildren(...cells.map(([k,v,bad])=>{
      const d=document.createElement('div'),l=document.createElement('span'),b=document.createElement('b');
      l.textContent=k;b.textContent=String(v);if(bad)b.className='bad';d.append(l,b);return d}));
    const msgs=[];
    if(sh.error)msgs.push('Google: '+sh.error);
    if(sh.areasError)msgs.push('Daftar area: '+sh.areasError);
    if((s.lockedUsers||[]).length)msgs.push('Akun terkunci karena salah password: '+s.lockedUsers.map(u=>u.username).join(', ')+'. Reset password untuk membukanya.');
    say('sysMsg',msgs.join(' '),!!msgs.length);
  }catch(e){say('sysMsg',errMsg(e),true)}
}

/* ---------- akun ---------- */
function areaBoxes(el,selected){
  el.innerHTML=Object.entries(AREAS).map(([c,n])=>`<label><input type="checkbox" value="${esc(c)}"${selected.includes(c)?' checked':''}>${esc(n)}</label>`).join('');
}
const picked=el=>[...el.querySelectorAll('input:checked')].map(i=>i.value);
const actions=u=>u.username===ME
  ?'<small>Akun Anda. Ganti password lewat tombol di bilah atas.</small>'
  :`<div class="acts"><button class="btn alt sm" data-a="pw" type="button">Reset password</button><button class="btn alt sm" data-a="edit" type="button">Ubah peran/area</button><button class="btn ${u.disabled?'alt':'warn'} sm" data-a="toggle" type="button">${u.disabled?'Aktifkan':'Nonaktifkan'}</button></div>`;
function renderUsers(){
  $('usrBody').innerHTML=USERS.map(u=>`<tr data-u="${esc(u.username)}">
    <td><b>${esc(u.username)}</b><br><small class="num">${esc(u.label)}</small></td>
    <td><span class="pill role">${esc(ROLE[u.role]||u.role)}</span></td>
    <td>${u.role==='daerah'?esc(u.areas.map(c=>AREAS[c]||c).join(', ')):'–'}</td>
    <td><span class="pill ${u.disabled?'off':'ok'}">${u.disabled?'Nonaktif':'Aktif'}</span></td>
    <td class="num">${esc(when(u.lastLoginAt))}</td>
    <td>${actions(u)}</td></tr>`).join('')||'<tr><td colspan="6">Belum ada akun.</td></tr>';
}
async function loadUsers(){
  try{const r=await API.get('/api/admin/users');USERS=r.users;AREAS=r.areas;renderUsers();areaBoxes($('nAreas'),[]);toggleAreas()}
  catch(e){say('usrMsg',errMsg(e),true)}
}
const toggleAreas=()=>{$('nAreas').hidden=$('nRole').value!=='daerah'};
function showSecret(text){$('secretTxt').textContent=text;$('secret').hidden=false}
$('secretClose').onclick=()=>{$('secret').hidden=true;$('secretTxt').textContent='';delete $('secretTxt').dataset.pw;say('usrMsg','')};
$('secretCopy').onclick=async()=>{try{await navigator.clipboard.writeText($('secretTxt').dataset.pw||'');say('usrMsg','Password disalin.')}catch(e){say('usrMsg','Salin manual dari kotak di atas.',true)}};
function secret(user,pw){$('secretTxt').dataset.pw=pw;showSecret(`${user} · password: ${pw}`);say('usrMsg','Catat password ini sekarang dan sampaikan ke pemiliknya. Setelah kotak ditutup tidak bisa dilihat lagi.')}
$('addBtn').onclick=()=>{$('addForm').hidden=!$('addForm').hidden;if(!$('addForm').hidden){$('nPass').value=gen();$('nUser').focus()}};
$('nRole').onchange=toggleAreas;
$('nGen').onclick=()=>{$('nPass').value=gen()};
$('addForm').addEventListener('submit',async ev=>{
  ev.preventDefault();$('nSave').disabled=true;say('usrMsg','Menyimpan …');
  const body={username:$('nUser').value.trim(),role:$('nRole').value,password:$('nPass').value,areas:picked($('nAreas'))};
  try{
    await API.post('/api/admin/users',body);
    secret(body.username,body.password);
    $('addForm').hidden=true;$('nUser').value='';
    await loadUsers();loadAudit();
  }catch(e){say('usrMsg',errMsg(e),true)}
  finally{$('nSave').disabled=false}
});
$('usrBody').addEventListener('click',async ev=>{
  const b=ev.target.closest('button[data-a]');if(!b)return;
  const name=b.closest('tr').dataset.u,u=USERS.find(x=>x.username===name);if(!u)return;
  try{
    if(b.dataset.a==='pw'){
      const pw=gen();b.disabled=true;
      await patchUser(name,{password:pw});secret(name,pw);
    }else if(b.dataset.a==='toggle'){
      b.disabled=true;await patchUser(name,{disabled:!u.disabled});say('usrMsg',u.disabled?'Akun diaktifkan.':'Akun dinonaktifkan dan sesinya diakhiri.');
    }else if(b.dataset.a==='edit'){
      editRow(b.closest('tr'),u);return;
    }
    await loadUsers();loadAudit();
  }catch(e){say('usrMsg',errMsg(e),true);b.disabled=false}
});
const patchUser=(name,body)=>API.patch('/api/admin/users/'+encodeURIComponent(name),body);
function editRow(tr,u){
  tr.innerHTML=`<td colspan="6"><div class="form" style="margin:6px 0">
    <div class="f"><label>Username</label><b>${esc(u.username)}</b></div>
    <div class="f"><label for="eRole">Peran</label><select id="eRole">${Object.entries(ROLE).map(([k,v])=>`<option value="${k}"${k===u.role?' selected':''}>${v}</option>`).join('')}</select></div>
    <div class="areas" id="eAreas"></div>
    <div class="f"><button class="btn" id="eSave" type="button">Simpan</button></div>
    <div class="f"><button class="btn alt" id="eCancel" type="button">Batal</button></div></div></td>`;
  const ar=tr.querySelector('#eAreas'),rs=tr.querySelector('#eRole');
  areaBoxes(ar,u.areas);const t=()=>{ar.hidden=rs.value!=='daerah'};t();rs.onchange=t;
  tr.querySelector('#eCancel').onclick=renderUsers;
  tr.querySelector('#eSave').onclick=async()=>{
    try{await patchUser(u.username,{role:rs.value,areas:picked(ar)});say('usrMsg','Perubahan disimpan. Sesi pengguna itu diakhiri agar peran barunya berlaku.');await loadUsers();loadAudit()}
    catch(e){say('usrMsg',errMsg(e),true)}
  };
}

/* ---------- log aktivitas ---------- */
async function loadAudit(){
  try{
    const r=await API.get('/api/admin/audit?limit=100');
    $('audBody').innerHTML=r.items.map(a=>`<tr><td class="num">${esc(when(a.at))}</td><td>${esc(a.username||'–')}</td><td>${esc(a.action)}</td><td>${esc(a.target||'')}</td><td><small>${esc(a.detail||'')}</small></td><td class="num">${esc(a.ip||'')}</td></tr>`).join('')||'<tr><td colspan="6">Belum ada aktivitas.</td></tr>';
  }catch(e){$('audBody').innerHTML=`<tr><td colspan="6" class="bad">${esc(errMsg(e))}</td></tr>`}
}
$('sysReload').onclick=loadSys;$('audReload').onclick=loadAudit;
$('themeBtn').onclick=()=>{const r=document.documentElement,d=r.dataset.theme==='dark'||(r.dataset.theme!=='light'&&matchMedia('(prefers-color-scheme:dark)').matches);r.dataset.theme=d?'light':'dark'};
loadSys();loadUsers();loadAudit();
})();

}}};
