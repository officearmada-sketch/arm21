/* Penghubung browser ke server Armada.
   Kode Monitor dan Peminjaman dulu berjalan di dalam claude.ai dan memakai window.claude.use(...) untuk
   database, Google Sheets, identitas, dan unduhan. Berkas ini menyediakan antarmuka yang sama, tetapi
   semuanya lewat API server sendiri (sesi cookie HttpOnly, aturan akses ditegakkan di server). */
(function () {
  'use strict';
  const HDR = { 'X-Requested-With': 'armada-web' };

  function emit(name, detail) { try { window.dispatchEvent(new CustomEvent(name, { detail })); } catch (e) { /* abaikan */ } }

  async function api(method, path, body, opt) {
    opt = opt || {};
    const init = { method, credentials: 'same-origin', headers: Object.assign({ Accept: 'application/json' }, HDR), cache: 'no-store' };
    if (body !== undefined) { init.headers['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
    let res;
    try { res = await fetch(path, init); }
    catch (e) { const er = new Error('Server tidak bisa dihubungi. Periksa koneksi internet Anda.'); er.code = 'network'; throw er; }
    let data = null;
    if ((res.headers.get('content-type') || '').includes('json')) { try { data = await res.json(); } catch (e) { /* kosong */ } }
    if (!res.ok) {
      const x = (data && data.error) || {};
      const er = new Error(x.message || ('Permintaan gagal (' + res.status + ').'));
      er.code = x.code || ('http_' + res.status);
      er.status = res.status;
      if (res.status === 401 && !opt.quiet && er.code === 'unauthenticated') emit('armada-expired', {});
      throw er;
    }
    return data;
  }
  const enc = (s) => encodeURIComponent(s);
  window.__api = {
    get: (p, o) => api('GET', p, undefined, o),
    post: (p, b, o) => api('POST', p, b === undefined ? {} : b, o),
    put: (p, b, o) => api('PUT', p, b, o),
    patch: (p, b, o) => api('PATCH', p, b, o),
    del: (p, o) => api('DELETE', p, undefined, o),
  };

  /* ---------- database dokumen: /api/db ---------- */
  function splitPath(p) {
    const i = String(p).indexOf('/');
    if (i < 1 || i === p.length - 1) throw Object.assign(new Error('Jalur dokumen tidak valid: ' + p), { code: 'bad_path' });
    return [p.slice(0, i), p.slice(i + 1)];
  }
  const docSnap = (d) => ({ id: d.id, exists: true, data: () => d.data });
  function query(coll, st) {
    st = st || {};
    const q = {
      orderBy: (f, dir) => query(coll, Object.assign({}, st, { ob: f, dir: dir === 'desc' ? 'desc' : 'asc' })),
      limit: (n) => query(coll, Object.assign({}, st, { lim: n })),
      async get() {
        const qs = [];
        if (st.ob) { qs.push('orderBy=' + enc(st.ob)); qs.push('dir=' + st.dir); }
        if (st.lim) qs.push('limit=' + st.lim);
        const r = await api('GET', '/api/db/' + enc(coll) + (qs.length ? '?' + qs.join('&') : ''));
        const docs = r.docs.map(docSnap);
        return { docs, size: docs.length, empty: docs.length === 0 };
      },
      async add(data) { const r = await api('POST', '/api/db/' + enc(coll), { data }); return { id: r.id }; },
    };
    return q;
  }
  const db = {
    collection: (c) => query(c),
    doc(path) {
      const [c, id] = splitPath(path);
      const url = '/api/db/' + enc(c) + '/' + enc(id);
      return {
        async get() {
          const r = await api('GET', url);
          return r.exists ? docSnap(r) : { id, exists: false, data: () => undefined };
        },
        async set(data) { await api('PUT', url, { data }); },
        async delete() { await api('DELETE', url); },
      };
    },
  };

  /* ---------- Google Sheets lewat proxy server ---------- */
  const mcp = {
    async callTool(server, tool, input) {
      if (server === 'Google Drive' && tool === 'create_file') return api('POST', '/api/drive/create_file', input);
      if (!['get_values', 'update_values', 'update_formulas', 'append_values'].includes(tool)) throw Object.assign(new Error('Perintah tidak didukung.'), { code: 'unsupported' });
      return api('POST', '/api/sheets/' + tool, input);
    },
    async describeTool() { throw Object.assign(new Error('Tidak tersedia.'), { code: 'unsupported' }); },
    async invalidate() { try { await api('POST', '/api/sheets/invalidate', {}); } catch (e) { /* hanya staf; akun lain cukup menunggu cache kedaluwarsa */ } },
  };

  /* ---------- pengguna ---------- */
  const user = {
    async me() {
      const r = await api('GET', '/api/session');
      return { id: r.user.username, isOwner: r.user.role === 'admin', canEdit: r.user.role === 'admin' };
    },
  };

  /* ---------- unduhan: simpan berkas lewat browser ---------- */
  const downloads = {
    async save(o) {
      const blob = o.data instanceof Blob ? o.data : new Blob([o.data], { type: o.type || 'application/octet-stream' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = o.filename || 'berkas'; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 30000);
      return { ok: true };
    },
  };

  const caps = { db, mcp, user, downloads };
  window.claude = Object.assign(window.claude || {}, {
    web: true,
    use: async (name) => {
      if (!caps[name]) throw Object.assign(new Error('Kemampuan tidak tersedia: ' + name), { code: 'unsupported' });
      return caps[name];
    },
  });
})();
