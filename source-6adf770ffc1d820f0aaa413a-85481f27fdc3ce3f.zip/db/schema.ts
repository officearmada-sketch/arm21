// Skema Netlify Database (Postgres). Aturan penting dijaga database (CHECK / UNIQUE / FK), bukan hanya kode aplikasi.
// Waktu disimpan sebagai milidetik epoch (bigint), sama seperti versi SQLite sebelumnya.
import { sql } from "drizzle-orm";
import { pgTable, serial, text, bigint, integer, boolean, index, uniqueIndex, check } from "drizzle-orm/pg-core";

const ms = (name: string) => bigint(name, { mode: "number" });

export const users = pgTable(
  "users",
  {
    id: serial().primaryKey(),
    username: text().notNull(),
    // kosong = password belum diatur (akun awal). Admin awal memakai ADMIN_PASSWORD saat login pertama.
    passwordHash: text("password_hash").notNull().default(""),
    role: text().notNull(),
    areas: text().notNull().default("[]"),
    label: text().notNull().default(""),
    disabled: boolean().notNull().default(false),
    failedCount: integer("failed_count").notNull().default(0),
    lockedUntil: ms("locked_until").notNull().default(0),
    createdAt: ms("created_at").notNull(),
    updatedAt: ms("updated_at").notNull(),
    lastLoginAt: ms("last_login_at"),
  },
  (t) => [
    uniqueIndex("users_username_lower").on(sql`lower(${t.username})`),
    check("users_username_ok", sql`${t.username} ~ '^[A-Za-z0-9._-]{3,64}$'`),
    check("users_role_ok", sql`${t.role} IN ('admin','pusat','daerah','viewer')`),
    check("users_label_len", sql`length(${t.label}) <= 80`),
    check("users_failed_ok", sql`${t.failedCount} >= 0`),
    check("users_daerah_areas", sql`${t.role} <> 'daerah' OR ${t.areas} <> '[]'`),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    idHash: text("id_hash").primaryKey(),
    userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
    createdAt: ms("created_at").notNull(),
    lastSeenAt: ms("last_seen_at").notNull(),
    expiresAt: ms("expires_at").notNull(),
    ip: text(),
    ua: text(),
  },
  (t) => [index("sessions_user").on(t.userId), index("sessions_exp").on(t.expiresAt)],
);

// Akun Gmail yang disambungkan tiap pengguna. Refresh token disimpan terenkripsi (AES-256-GCM) oleh server.
export const googleAccounts = pgTable("google_accounts", {
  userId: integer("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  email: text().notNull(),
  refreshTokenEnc: text("refresh_token_enc").notNull(),
  scope: text().notNull().default(""),
  connectedAt: ms("connected_at").notNull(),
  updatedAt: ms("updated_at").notNull(),
});

// Penyimpanan dokumen (pengganti database artefak): path = koleksi/id
export const docs = pgTable(
  "docs",
  {
    path: text().primaryKey(),
    collection: text().notNull(),
    id: text().notNull(),
    data: text().notNull(),
    version: integer().notNull().default(1),
    updatedAt: ms("updated_at").notNull(),
    updatedBy: integer("updated_by").references(() => users.id, { onDelete: "set null" }),
  },
  (t) => [
    index("docs_collection").on(t.collection),
    check("docs_path_ok", sql`${t.path} = ${t.collection} || '/' || ${t.id}`),
    check("docs_coll_len", sql`length(${t.collection}) BETWEEN 1 AND 64`),
    check("docs_id_len", sql`length(${t.id}) BETWEEN 1 AND 200`),
  ],
);

// Catatan koreksi/clear Monitor. Pelaku dicatat oleh SERVER dari sesi login, bukan dari kiriman browser.
export const cek = pgTable(
  "cek",
  {
    key: text().primaryKey(),
    cek: text().notNull().default(""),
    catatan: text().notNull().default(""),
    oleh: text().notNull().default(""),
    olehUser: text("oleh_user").notNull().default(""),
    at: ms("at").notNull(),
    jenis: text().notNull().default(""),
    jenisBy: text("jenis_by").notNull().default(""),
    jenisAt: ms("jenis_at").notNull().default(0),
  },
  (t) => [
    check("cek_key_len", sql`length(${t.key}) BETWEEN 1 AND 300`),
    check("cek_cek_ok", sql`${t.cek} IN ('','CLEAR')`),
    check("cek_catatan_len", sql`length(${t.catatan}) <= 1000`),
    check("cek_jenis_ok", sql`${t.jenis} IN ('','TITIKAN','LANGSUNG')`),
  ],
);

export const cekHist = pgTable(
  "cek_hist",
  {
    id: serial().primaryKey(),
    key: text().notNull().references(() => cek.key, { onDelete: "cascade" }),
    at: ms("at").notNull(),
    oleh: text().notNull(),
    olehUser: text("oleh_user").notNull(),
    act: text().notNull(),
    note: text().notNull().default(""),
  },
  (t) => [index("cek_hist_key").on(t.key, t.at.desc()), check("cek_hist_act_ok", sql`${t.act} IN ('note','clear','open','jenis')`)],
);

// Jejak audit untuk semua perubahan penting (login, ACC, ubah pengguna, sambung Gmail).
export const audit = pgTable(
  "audit",
  {
    id: serial().primaryKey(),
    at: ms("at").notNull(),
    userId: integer("user_id"),
    username: text(),
    action: text().notNull(),
    target: text(),
    detail: text(),
    ip: text(),
  },
  (t) => [index("audit_at").on(t.at.desc())],
);

// Nilai kecil: data bawaan Monitor (gzip+base64), daftar area terakhir, catatan unggahan Drive, dll.
export const kv = pgTable("kv", {
  key: text().primaryKey(),
  value: text().notNull(),
});

// Tautan dibuat hanya setelah pengguna membuktikan sesi akun internalnya.
export const identityLinks = pgTable("identity_links", {
  identityId: text("identity_id").primaryKey(),
  userId: integer("user_id").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  createdAt: ms("created_at").notNull(),
});
