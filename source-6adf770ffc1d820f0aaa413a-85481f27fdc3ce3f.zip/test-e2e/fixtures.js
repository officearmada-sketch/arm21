'use strict';
// Data uji E2E dengan bentuk sama seperti spreadsheet sungguhan (kolom, baris judul, format tanggal). Semua nama fiktif.
const ACC = '1uwenWPo9NR9rkTfZpHuJaXQFEGnspVjg0Ty6K4xpSDI';
const FORM = '1V18f6If7Emm_bgpfuMUnLiJDCzA-4w1bAnM7D5EhJjw';
const SPPD = '19BQ1RVmu04zoehzE_SNJYuurRAH9hgysJU2z_370Q5M';
const EMP = '1h5jyC0dui20lPWCQLaKguzMuVvcHtjjIVPMkd4jrzNA';
const AREA = { PST: 'AREA_PST_aaaaaaaaaaaaaaaaaaaa', CPY: 'AREA_CPY_bbbbbbbbbbbbbbbbbbbb', LPG: 'AREA_LPG_cccccccccccccccccccc', JMBR: 'AREA_JMBR_dddddddddddddddddd' };
const NAME = { PST: 'PUSAT', CPY: 'CIPAYUNG', LPG: 'LAMPUNG', JMBR: 'JEMBRANA' };
const HEAD = ['Timestamp', 'NOMOR FORM PEMINJAMAN', 'NAMA', 'NO. KTP', 'NO. SIM', 'NO. WHATSAPP', 'NO. TELPON AKTIF', 'STATUS PEMINJAM', 'NOPOL UNIT KENDARAAN', 'LOKASI TERAKHIR UNIT', 'LOKASI TUJUAN PEMINJAMAN', 'TUJUAN PEMINJAMAN', 'JENIS ARMADA', 'MERK', 'GRUP UNIT ARMADA', 'TANGGAL PEMINJAMAN', 'TANGGAL PENGEMBALIAN', 'ACC ARMADA', 'TANGGAL ACC', 'ACC PUSAT', 'STATUS KENDARAAN', 'UPLOAD BERKAS', 'UPLOAD PENGEMBALIAN', 'KETERANGAN'];

// [kode, nomor, nama, nopol, tujuan, tanggal(dmy), kembali(dmy), jam, R, T, Y(area), YACC]
const SUB = [
  ['PST', 'PST261009001', 'Budi Uji', 'B 1001 UJI', 'taman mini', '09/10/2026', '31/10/2026', '14:25:51', true, true, false, true],
  ['CPY', 'CPY261016001', 'Citra Uji', 'AE 2002 UJI', 'JOKER SPA', '16/10/2026', '18/10/2026', '18:41:49', false, false, false, false],
  ['LPG', 'LPG261017001', 'Dewi Uji', 'BM 3003 UJI', 'MAKASSAR', '17/10/2026', '31/10/2026', '16:18:21', false, true, false, true],
  ['LPG', 'LPG261017002', 'Eko Uji', 'BM 4004 UJI', 'BIMA', '17/10/2026', '31/10/2026', '16:38:59', true, true, true, true],
  ['JMBR', 'JMBR261019001', 'Fajar Uji', 'P 5005 UJI', 'Bandung', '19/10/2026', '23/10/2026', '09:02:17', false, false, false, false], // sengaja TIDAK ada di ACC PUSAT
];
const mdy = (d) => { const [dd, mm, yy] = d.split('/'); return `${+mm}/${+dd}/${yy}`; };
const bool = (v) => !!v;

function dataRow(s, order) {
  const [kode, nomor, nama, nopol, tuj, tgl, kem, jam, r, t, , ] = s;
  const f = order === 'mdy' ? mdy : (x) => x;
  return [`${f(tgl)} ${jam}`, nomor, nama, '3300000000000001', '3300000000000002', '0811111111', '0822222222', 'STAFF', nopol, NAME[kode], tuj, 'KEPERLUAN PRIBADI', 'MINIBUS', 'SUZUKI', 'OPERASIONAL', f(tgl), f(kem), r, r ? `${f(tgl)} 20:00:00` : '', t, t ? (r ? 'BERANGKAT' : 'SILAHKAN ACC ARMADA TERLEBIH DAHULU') : (r ? 'DIPARKIR' : ''), '', '', ''];
}

function fixtures() {
  const acc = [HEAD.concat(['KOLOM UNTUK ACC PUSAT'])];
  for (const s of SUB) if (s[0] !== 'JMBR') acc.push(dataRow(s, 'mdy').concat([bool(s[11])]));
  const area = (code) => {
    const rows = [[], [ 'PORT', NAME[code] ], [], HEAD.concat(['ACC AREA'])];
    for (const s of SUB.filter((x) => x[0] === code)) rows.push(dataRow(s, 'dmy').concat([bool(s[10])]));
    return { 'DATA PEMINJAM': rows };
  };
  const form = [['Timestamp', 'NOMOR FORM PEMINJAMAN', 'NAMA'].concat(HEAD.slice(3, 17))];
  for (const s of SUB) form.push(dataRow(s, 'dmy').slice(0, 17));
  return {
    [ACC]: {
      MASTER: Object.keys(AREA).map((c) => [c, NAME[c], `https://docs.google.com/spreadsheets/d/${AREA[c]}/edit?gid=0#gid=0`]),
      'ACC PUSAT': acc,
    },
    [FORM]: {
      DATA: form,
      // MASTER armada: grup OPERASIONAL (kolom L) yang dipakai Pemakaian Unit; kode area di kolom P, nama area di kolom Q
      MASTER: [
        ['NOPOL', 'JENIS', 'RANGKA', 'MESIN', 'TAHUN', 'MERK', 'TIPE', 'S1', 'S2', 'S3', 'LOKASI', 'GRUP', 'LOKASI 2', 'PT', '', 'KODE', 'AREA'],
        ['B 9134 UJI', 'MINIBUS', 'MHC1', 'G1', '2023', 'DAIHATSU', 'GRAND MAX', '', '', '', 'PUSAT', 'OPERASIONAL', 'PUSAT', 'BARAKA', '', 'CPY', 'CIPAYUNG'],
        ['B 9200 UJI', 'CDD', 'MHC2', 'G2', '2022', 'ISUZU', 'NMR', '', '', '', 'PUSAT', 'LUAR KOTA', 'PUSAT', 'BARAKA', '', 'PST', 'PUSAT'],
      ],
    },
    // Pemakaian Unit: urutan kolom sama dengan sheet sungguhan (setelah kolom JARAK PERJALANAN (KM) ditambahkan, agenda ada di kolom O)
    [SPPD]: {
      'LIST PERJALANAN DINAS NEW': [
        [],
        ['NO', 'NO. SPPD', 'KATEGORI', 'TANGGAL BERANGKAT', 'TANGGAL PULANG', 'KARYAWAN', '', '', '', '', '', 'TIPE KENDARAAN', 'JARAK PERJALANAN (KM)', 'JUMLAH TITIKAN', 'AGENDA PERJALANAN DINAS', 'Biaya Lain-lain'],
        ['', '', '', '', '', '1', '2', '3', '4', '5', '6'],
        ['1', 'SPPD/PUSAT-UJI/24102026/0001', 'RANGE 1', 'Sabtu, 24 Oktober 2026', 'Sabtu, 24 Oktober 2026', '100959', '400108', '', '', '', '', 'MOBIL INVENTARIS', '', '', 'KE AGEN KREKOT AGENDA PERBAIKAN KOMPUTER'],
        ['2', 'SPPD/PUSAT-UJI/24102026/0002', 'RANGE 1', 'Sabtu, 24 Oktober 2026', 'Sabtu, 24 Oktober 2026', '100959', '', '', '', '', '', 'MOTOR', '', '', 'KE AGEN LAIN AGENDA TIDAK DITARIK'],
      ],
    },
    [EMP]: {
      STAFF: [['NIB', 'NAMA'], ['100959', 'FIKTIF ALFA']],
      'NON-STAFF': [['NIB', 'NAMA'], ['400108', 'FIKTIF BETA']],
      SOPIR: [['NIB', 'NAMA']],
      TKBM: [['NIB', 'NAMA']],
    },
    '1d39r0zquQEgUA45ZxEbXx0uFjAmobUW4Qkimzb7qaBY': { 'LOG PERUBAHAN': [['WAKTU', 'AKSI']] },
    ...Object.fromEntries(Object.keys(AREA).map((c) => [AREA[c], area(c)])),
  };
}

// Data bawaan Monitor: deterministik, nama sopir fiktif
function builtin() {
  const names = ['AGUS UJI', 'BAMBANG UJI', 'CAHYO UJI', 'DEDI UJI', 'EKO UJI', 'FIRMAN UJI'];
  const asal = ['BOGOR', 'LEGUNDI', 'CIPAYUNG', 'LAMPUNG', 'JEMBRANA'];
  const rows = [];
  let seed = 7;
  const rnd = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  for (let d = 1; d <= 10; d++) {
    for (let i = 0; i < 6; i++) {
      const standar = 9000, express = 5400 + Math.round(rnd() * 600), normal = express + 1800;
      const tempuh = Math.round(3000 + rnd() * 9000);
      const status = tempuh <= express ? 'JAM EXPRESS' : tempuh <= standar ? 'NORMAL' : 'TERLAMBAT';
      const tgl = `2026-10-${String(d).padStart(2, '0')}`;
      rows.push({
        sopir: names[(d + i) % names.length], sopir2: '', nopol: `B ${9000 + d * 10 + i} UJI`, armada: i % 2 ? 'FUSO' : 'CDD',
        asal: asal[(d + i) % asal.length], tujuan: 'PUSAT', tempuh, jarak: 24 + i, express, normal, standar, bonus: 0, denda: 0,
        ketExpress: 'BERLAKU', struk: `STUT/PST/${String(d).padStart(2, '0')}102026${String(i + 1).padStart(3, '0')}`, jenis: 'LANGSUNG', status,
        fokus: i === 2 ? 'PERLU KOREKSI' : '', tgl, datang: `${tgl}T0${3 + i}:30`, berangkat: `${tgl}T0${1 + i}:10`,
      });
    }
  }
  return rows;
}

module.exports = { fixtures, builtin, ids: { ACC, FORM, SPPD, EMP, ...AREA } };
