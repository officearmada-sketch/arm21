'use strict';
// Menjalankan server sungguhan (kode produksi) dengan Google palsu, akun uji, dan data uji, untuk tes E2E browser.
//   node test-e2e/stack.js --port 4100         -> mencetak satu baris JSON {"port":..,"ctl":..} saat siap
// Server kontrol (port+1, hanya 127.0.0.1): GET /peek?id=&sheet=&row=&col=  -> nilai sel di Google palsu
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const zlib = require('node:zlib');
const crypto = require('node:crypto');
const { load } = require('../server/config');
const { createApp } = require('../server/app');
const { hashPassword } = require('../server/auth');
const { createFakeGoogle } = require('../test/fake-google');
const fx = require('./fixtures');

const ROOT = path.resolve(__dirname, '..');
const port = Number(process.argv[process.argv.indexOf('--port') + 1]) || 4100;
const PASS = 'Password-Uji-1';

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'armada-e2e-'));
  const google = createFakeGoogle({ fixtures: fx.fixtures });
  const cfg = load({
    DATA_DIR: dir, PUBLIC_DIR: path.join(ROOT, 'public'), PRIVATE_DIR: path.join(ROOT, 'private'), PORT: String(port), HOST: '127.0.0.1', LOG_LEVEL: 'warn',
    GOOGLE_SA_JSON: google.saJson, SHEETS_API_BASE: 'http://google.test', GOOGLE_TOKEN_URL: 'http://google.test/token',
    SHEETS_CACHE_TTL_MS: '0', SHEETS_AREA_REFRESH_MS: '1000', DATA_KEY: crypto.randomBytes(32).toString('base64'),
  });
  const app = createApp(cfg, { fetchImpl: (u, o) => google.fetchImpl(u, o), logger: { debug() {}, info() {}, warn() {}, error: (m, x) => console.error(m, x) } });
  const now = Date.now();
  const ins = app.db.prepare('INSERT INTO users (username, password_hash, role, areas, label, created_at, updated_at) VALUES (?,?,?,?,?,?,?)');
  const ph = await hashPassword(PASS);
  for (const [u, r, a] of [['admin', 'admin', []], ['armada.pusat', 'pusat', []], ['manager', 'pusat', []], ['armada.lpg', 'daerah', ['LPG']], ['armada.cpy', 'daerah', ['CPY']], ['armada.jmbr', 'daerah', ['JMBR']], ['lihat', 'viewer', []], ['ganti.pw', 'viewer', []]]) ins.run(u, ph, r, JSON.stringify(a), '', now, now);
  app.db.prepare("INSERT INTO kv (key, value) VALUES ('builtin_gz', ?)").run(zlib.gzipSync(Buffer.from(JSON.stringify(fx.builtin()))).toString('base64'));
  await new Promise((r) => app.server.listen(port, '127.0.0.1', r));

  const ctl = http.createServer((req, res) => {
    const u = new URL(req.url, 'http://x');
    if (u.pathname === '/peek') {
      const wb = google.state.data[u.searchParams.get('id')] || {};
      const sh = wb[u.searchParams.get('sheet')] || [];
      const cell = (sh[Number(u.searchParams.get('row')) - 1] || [])[Number(u.searchParams.get('col'))];
      res.end(JSON.stringify({ value: cell === undefined ? null : cell }));
    } else if (u.pathname === '/calls') {
      res.end(JSON.stringify(google.state.calls));
    } else { res.statusCode = 404; res.end('{}'); }
  });
  await new Promise((r) => ctl.listen(port + 1, '127.0.0.1', r));
  console.log(JSON.stringify({ port, ctl: port + 1, ids: fx.ids, password: PASS }));
  const stop = async () => { await app.close(); ctl.close(); fs.rmSync(dir, { recursive: true, force: true }); process.exit(0); };
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
})().catch((e) => { console.error(e); process.exit(1); });
