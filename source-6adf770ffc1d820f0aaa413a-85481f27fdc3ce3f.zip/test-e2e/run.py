#!/usr/bin/env python3
"""Tes end-to-end di browser sungguhan (Chromium + Playwright untuk Python).
Menjalankan server produksi (kode asli) dengan Google palsu dan data uji, lalu menguji alur utama per peran.

  pip install playwright && playwright install chromium     # sekali saja
  npm run build && python3 test-e2e/run.py                  # atau: npm run test:e2e
Env: CHROMIUM=/path/ke/chromium (opsional), SHOTS=folder (simpan tangkapan layar), HEADED=1
"""
import json, os, re, subprocess, sys, time, traceback, urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent.parent
PORT = int(os.environ.get('E2E_PORT', '4180'))
SHOTS = Path(os.environ['SHOTS']) if os.environ.get('SHOTS') else None
PASS = 'Password-Uji-1'
if SHOTS: SHOTS.mkdir(parents=True, exist_ok=True)

# ---------- server ----------
def start_stack():
    if not (ROOT / 'public' / 'index.html').exists():
        subprocess.run(['node', str(ROOT / 'scripts' / 'build-web.js')], check=True)
    p = subprocess.Popen(['node', '--disable-warning=ExperimentalWarning', str(ROOT / 'test-e2e' / 'stack.js'), '--port', str(PORT)],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=ROOT)
    line = p.stdout.readline()
    if not line.startswith('{'):
        p.kill(); raise SystemExit('Stack gagal start: ' + line + p.stderr.read())
    return p, json.loads(line)

def peek(info, id_, sheet, row, col):
    u = f"http://127.0.0.1:{info['ctl']}/peek?id={id_}&sheet={urllib.parse.quote(sheet)}&row={row}&col={col}"
    return json.load(urllib.request.urlopen(u))['value']

import urllib.parse

# ---------- helpers ----------
class Env:
    def __init__(self, pw, info):
        self.pw, self.info = pw, info
        self.base = f"http://127.0.0.1:{info['port']}"
        self.browser = pw.chromium.launch(executable_path=os.environ.get('CHROMIUM') or ('/opt/pw-browsers/chromium' if Path('/opt/pw-browsers/chromium').exists() else None),
                                          headless=not os.environ.get('HEADED'), args=['--no-sandbox'])
        self.problems = []   # pesan konsol/CSP/halaman yang tidak boleh ada

    def page(self, w=1280, h=800, dark=False):
        ctx = self.browser.new_context(viewport={'width': w, 'height': h}, color_scheme='dark' if dark else 'light')
        pg = ctx.new_page()
        pg.on('pageerror', lambda e: self.problems.append('pageerror: ' + str(e)[:300]))
        def on_console(m):
            t = m.text
            if m.type in ('error', 'warning') and not re.search(r'status of 401|favicon', t):
                self.problems.append(f'console.{m.type}: {t[:300]}')
        pg.on('console', on_console)
        pg.on('response', lambda r: self.problems.append(f'http {r.status} {r.url}') if r.status >= 400 and not (r.status == 401 and re.search(r'/api/(session|login)$', r.url)) and '/vendor/' not in r.url else None)
        pg.add_init_script("document.addEventListener('securitypolicyviolation',e=>console.error('CSP: '+e.violatedDirective+' '+e.blockedURI))")
        pg.goto(self.base); pg.wait_for_selector('#h-monitor #lgUser')
        return pg

    def login(self, pg, user, pw=PASS):
        pg.fill('#h-monitor #lgUser', user); pg.fill('#h-monitor #lgPass', pw); pg.click('#h-monitor #lgGo')

    def login_ok(self, pg, user):
        self.login(pg, user)
        pg.wait_for_selector('#h-monitor #app:not([hidden])', timeout=8000)

    def shot(self, pg, name):
        if SHOTS: pg.screenshot(path=str(SHOTS / (name + '.png')))

    def open_pu(self, pg):
        pg.click('#t-peminjaman')
        pg.wait_for_selector('#h-peminjaman #app:not([hidden]), #h-peminjaman #gate:not([hidden])', timeout=8000)
        pg.wait_for_function("() => { const r=document.querySelector('#h-peminjaman').shadowRoot; const g=r.getElementById('gate'); return !g.hidden ? !/Memuat/.test(g.textContent) : true }", timeout=10000)

    def api(self, pg, path):
        return pg.evaluate("p => fetch(p,{credentials:'same-origin'}).then(async r=>({status:r.status,json:await r.json().catch(()=>null)}))", path)

RESULTS = []
def test(fn):
    RESULTS.append(fn); return fn

# ---------- tes ----------
@test
def login_gagal_dan_berhasil(e):
    pg = e.page()
    e.login(pg, 'armada.pusat', 'salah-banget')
    pg.wait_for_function("() => /salah/i.test(document.querySelector('#h-monitor').shadowRoot.getElementById('lgMsg').textContent)")
    assert pg.locator('#h-monitor #app').is_hidden()
    e.shot(pg, '01_login_gagal')
    e.login_ok(pg, 'armada.pusat')
    assert 'armada.pusat' in pg.locator('#h-monitor #who').inner_text()
    assert pg.locator('#t-peminjaman').is_visible()
    e.shot(pg, '02_monitor_pusat')
    # data bawaan datang dari server: 60 trip
    expect(pg.locator('#h-monitor #periode')).to_contain_text('60 trip')

@test
def sesi_bertahan_saat_muat_ulang_dan_logout(e):
    pg = e.page(); e.login_ok(pg, 'armada.pusat')
    pg.reload(); pg.wait_for_selector('#h-monitor #app:not([hidden])', timeout=8000)
    pg.click('#h-monitor #logout')
    pg.wait_for_selector('#h-monitor #lgUser')
    assert e.api(pg, '/api/session')['status'] == 401
    assert pg.evaluate("document.cookie") == ''   # cookie sesi HttpOnly: tidak terbaca dari JS

@test
def catatan_tercatat_siapa_pelakunya(e):
    # trip ke-3 setiap hari ditandai PERLU KOREKSI. Semua akun boleh menulis; nama pelaku diisi server.
    key = 'STUT/PST/01102026003'
    pg = e.page(); e.login_ok(pg, 'armada.lpg')
    pg.click('#h-monitor #t-catatan')
    pg.locator(f'#h-monitor tr[data-t]:has-text("{key}")').click()
    pg.fill('#h-monitor #fCat', 'Jam tiba salah input, sudah dicek ke driver')
    pg.click('#h-monitor #cSave')
    expect(pg.locator('#h-monitor #cMsg')).to_contain_text('Catatan tersimpan')
    expect(pg.locator('#h-monitor #cekBox')).to_contain_text('oleh Armada Lampung')
    e.shot(pg, '03_catatan_lampung')
    # pengguna lain melihat catatan itu, lalu clear atas namanya sendiri
    pg2 = e.page(); e.login_ok(pg2, 'manager')
    pg2.click('#h-monitor #t-catatan')
    pg2.locator(f'#h-monitor tr[data-t]:has-text("{key}")').click()
    expect(pg2.locator('#h-monitor #cekBox')).to_contain_text('Armada Lampung')
    pg2.fill('#h-monitor #fCat', 'Sudah benar, di-clear')
    pg2.click('#h-monitor #cClear')
    expect(pg2.locator('#h-monitor #cMsg')).to_contain_text('clear')
    box = pg2.locator('#h-monitor #cekBox')
    expect(box).to_contain_text('Manager Armada')
    box.locator('summary').click()
    expect(box).to_contain_text('Armada Lampung')   # riwayat memuat kedua pelaku
    items = e.api(pg2, '/api/cek')['json']['items']
    it = next(i for i in items if i['k'] == key)
    assert it['cek'] == 'CLEAR' and it['oleh'] == 'Manager Armada' and [h['by'] for h in it['hist']] == ['Manager Armada', 'Armada Lampung'], it
    # akun "hanya lihat" tidak boleh menulis (hasil tinjauan keamanan)
    pg3 = e.page(); e.login_ok(pg3, 'lihat')
    r = pg3.evaluate("() => fetch('/api/cek',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-Requested-With':'armada-web'},body:JSON.stringify({key:'STUT/PST/02102026003',act:'note',note:'dari akun lihat'})}).then(r=>r.json())")
    assert 'oleh' not in r and r.get('error'), r
    e.problems[:] = [m for m in e.problems if '403' not in m]   # 403 itu memang yang diuji

@test
def judul_peminjaman_mengikuti_akun_dan_tema(e):
    for user, title in [('armada.pusat', 'ARMADA PUSAT'), ('manager', 'ARMADA PUSAT'), ('armada.cpy', 'ARMADA CIPAYUNG'), ('armada.lpg', 'ARMADA LAMPUNG')]:
        pg = e.page(); e.login_ok(pg, user); e.open_pu(pg)
        expect(pg.locator('#unitName')).to_have_text(title)
        expect(pg.locator('.nav .brand b')).to_have_text(title)   # judul di bilah atas ikut berubah
        if user == 'armada.cpy':
            e.shot(pg, '04_peminjaman_cipayung')
            pg.click('#themeBtn')
            assert pg.evaluate("document.querySelector('#h-peminjaman').dataset.theme") == 'dark' or pg.locator('#h-peminjaman').get_attribute('data-theme') == 'dark'
            e.shot(pg, '05_peminjaman_gelap')

@test
def peminjaman_pusat_daftar_dan_banner_sinkron(e):
    pg = e.page(); e.login_ok(pg, 'armada.pusat'); e.open_pu(pg)
    rows = pg.locator('#h-peminjaman #tbl tr[data-n]')
    expect(rows).to_have_count(4)                      # PST, CPY, LPG, LPG
    expect(pg.locator('#h-peminjaman #banner')).to_contain_text('JMBR261019001')   # ada di database formulir, belum di ACC PUSAT
    expect(pg.locator('#h-peminjaman #banner')).to_contain_text('IZIN AKSES')
    e.shot(pg, '06_peminjaman_pusat')

@test
def acc_area_ditulis_ke_sheet_area(e):
    pg = e.page(); e.login_ok(pg, 'armada.cpy'); e.open_pu(pg)
    expect(pg.locator('#h-peminjaman #tbl tr[data-n]')).to_have_count(1)
    pg.locator('#h-peminjaman #tbl tr[data-n]').click()
    assert pg.locator('#h-peminjaman #bAR').count() == 0   # akun area tidak punya tombol ACC Armada Pusat aktif
    pg.click('#h-peminjaman #bAC'); pg.click('#h-peminjaman #bAC')   # klik kedua = konfirmasi
    expect(pg.locator('#h-peminjaman #actMsg')).to_contain_text('Tersimpan')
    assert peek(e.info, e.info['ids']['CPY'], 'DATA PEMINJAM', 5, 24) is True

@test
def acc_pusat_dan_manager_ditulis_ke_sheet(e):
    pg = e.page(); e.login_ok(pg, 'armada.pusat'); e.open_pu(pg)
    pg.locator('#h-peminjaman #tbl tr[data-n]:has-text("CPY261016001")').click()
    pg.click('#h-peminjaman #bAR'); pg.click('#h-peminjaman #bAR')
    expect(pg.locator('#h-peminjaman #actMsg')).to_contain_text('Tersimpan')
    assert peek(e.info, e.info['ids']['CPY'], 'DATA PEMINJAM', 5, 17) is True          # kolom R di workbook area
    pg.click('#h-peminjaman #bPU'); pg.click('#h-peminjaman #bPU')
    expect(pg.locator('#h-peminjaman #actMsg')).to_contain_text('Tersimpan')
    assert peek(e.info, e.info['ids']['ACC'], 'ACC PUSAT', 3, 24) is True              # kolom Y di ACC PUSAT (baris ke-3 data)
    e.shot(pg, '07_acc_selesai')

@test
def akun_viewer_tidak_punya_akses_peminjaman(e):
    pg = e.page(); e.login_ok(pg, 'lihat'); e.open_pu(pg)
    expect(pg.locator('#h-peminjaman #gate')).to_contain_text('tidak punya akses')

@test
def sesi_berakhir_menampilkan_pesan_jelas(e):
    pg = e.page(); e.login_ok(pg, 'armada.pusat')
    pg.click('#h-monitor #t-catatan')
    pg.locator('#h-monitor tr[data-t]').first.click()
    pg.context.clear_cookies()                          # seolah sesi dicabut server
    pg.fill('#h-monitor #fCat', 'tes sesi berakhir'); pg.click('#h-monitor #cSave')
    expect(pg.locator('#expired')).to_be_visible()
    e.problems[:] = [m for m in e.problems if not m.startswith('http 401')]   # 401 itu memang yang diuji
    e.shot(pg, '08_sesi_berakhir')

@test
def aset_privat_dan_bundel_publik(e):
    pg = e.page(); e.login_ok(pg, 'armada.pusat')
    assert e.api(pg, '/api/asset/ttd_mgr.png')['status'] in (200,)  # status saja; isi biner
    anon = e.pw.request.new_context(base_url=e.base)
    assert anon.get('/api/asset/ttd_mgr.png').status == 401
    assert anon.get('/assets/ttd_mgr.png').status == 404
    assert anon.get('/api/builtin').status == 401
    for p in (ROOT / 'public').rglob('*'):
        if p.is_file() and p.suffix in ('.js', '.html', '.css'):
            assert 'iVBORw0KGgo' not in p.read_text(errors='ignore'), f'gambar tertanam di {p.name}'   # tidak ada PNG base64 di berkas publik

@test
def tampilan_ponsel(e):
    pg = e.page(390, 800); e.shot(pg, '09_login_ponsel')
    e.login_ok(pg, 'armada.cpy'); e.open_pu(pg)
    e.shot(pg, '10_peminjaman_ponsel')
    assert pg.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), 'halaman bergeser horizontal di ponsel'
    for sel in ('#t-monitor', '#t-peminjaman', '#pwBtn'):                # semua tab dan tombol akun harus terlihat utuh, tidak terpotong
        r = pg.locator(sel).bounding_box()
        assert r and r['x'] >= 0 and r['x'] + r['width'] <= 391, f'{sel} terpotong di ponsel: {r}'

@test
def unduh_pdf_atau_pesan_ramah(e):
    pg = e.page(); e.login_ok(pg, 'armada.pusat'); e.open_pu(pg)
    pg.locator('#h-peminjaman #tbl tr[data-n]').first.click()
    has_libs = pg.evaluate("!!(window.html2canvas && window.jspdf)")
    if has_libs:
        with pg.expect_download(timeout=30000) as d: pg.click('#h-peminjaman #pdfBtn')
        assert d.value.suggested_filename.endswith('.pdf')
    else:
        pg.click('#h-peminjaman #pdfBtn')
        expect(pg.locator('#h-peminjaman #pdfMsg')).to_contain_text('Pustaka PDF belum termuat')
    with pg.expect_download(timeout=10000) as d: pg.click('#h-peminjaman #htmlBtn')
    assert d.value.suggested_filename.endswith('.html')

@test
def admin_kelola_akun_lewat_panel(e):
    pg = e.page(); e.login_ok(pg, 'admin')
    expect(pg.locator('#t-admin')).to_be_visible()
    pg.click('#t-admin')
    pg.wait_for_selector('#h-admin #usrBody tr[data-u]', timeout=8000)
    expect(pg.locator('#h-admin #sys')).to_contain_text('Tersambung')
    assert 'Akun Anda' in pg.locator('#h-admin tr[data-u="admin"]').inner_text()
    assert pg.locator('#h-admin tr[data-u="admin"] button').count() == 0, 'admin tidak boleh menonaktifkan akunnya sendiri dari panel'
    e.shot(pg, '11_admin')
    # tambah akun area
    pg.click('#h-admin #addBtn')
    pg.fill('#h-admin #nUser', 'armada.mks'); pg.select_option('#h-admin #nRole', 'daerah')
    pg.check('#h-admin #nAreas input[value="MKS"]')
    pw = pg.input_value('#h-admin #nPass'); assert len(pw) >= 12
    pg.click('#h-admin #nSave')
    expect(pg.locator('#h-admin #secret')).to_be_visible()
    expect(pg.locator('#h-admin #secretTxt')).to_contain_text('armada.mks')
    expect(pg.locator('#h-admin #secretTxt')).to_contain_text(pw)
    row = pg.locator('#h-admin tr[data-u="armada.mks"]'); expect(row).to_contain_text('Makassar'); expect(row).to_contain_text('Aktif')
    expect(pg.locator('#h-admin #audBody')).to_contain_text('user.create')
    pg.click('#h-admin #secretClose'); expect(pg.locator('#h-admin #secret')).to_be_hidden()
    assert pw not in pg.locator('#h-admin').inner_text(), 'password harus hilang dari layar setelah ditutup'
    # akun baru benar-benar bisa masuk dan label pelaku dihitung server
    pg2 = e.page(); e.login(pg2, 'armada.mks', pw); pg2.wait_for_selector('#h-monitor #app:not([hidden])', timeout=8000)
    assert 'MKS' in pg2.locator('#h-monitor #who').inner_text()
    assert pg2.locator('#t-admin').is_hidden(), 'akun non-admin tidak boleh melihat tab Admin'
    # admin menonaktifkan -> sesi akun itu langsung mati
    pg.click('#h-admin tr[data-u="armada.mks"] button[data-a="toggle"]')
    expect(pg.locator('#h-admin tr[data-u="armada.mks"]')).to_contain_text('Nonaktif')
    assert e.api(pg2, '/api/session')['status'] == 401
    # ubah peran lewat panel
    pg.click('#h-admin tr[data-u="armada.mks"] button[data-a="toggle"]')
    expect(pg.locator('#h-admin tr[data-u="armada.mks"]')).to_contain_text('Aktif')
    pg.click('#h-admin tr[data-u="armada.mks"] button[data-a="edit"]')
    pg.select_option('#h-admin #eRole', 'viewer'); pg.click('#h-admin #eSave')
    expect(pg.locator('#h-admin tr[data-u="armada.mks"]')).to_contain_text('Hanya lihat')

@test
def admin_tidak_terlihat_untuk_akun_lain(e):
    pg = e.page(); pg.goto(e.base + '#admin')
    pg.wait_for_selector('#h-monitor #lgUser'); e.login_ok(pg, 'armada.pusat')
    assert pg.locator('#t-admin').is_hidden()
    assert pg.locator('#h-admin').is_hidden()
    assert e.api(pg, '/api/admin/users')['status'] == 403
    e.problems[:] = [m for m in e.problems if '403' not in m]              # 403 itu memang yang diuji

@test
def admin_tampilan_ponsel(e):
    pg = e.page(390, 800); e.login_ok(pg, 'admin'); pg.click('#t-admin')
    pg.wait_for_selector('#h-admin #usrBody tr[data-u]', timeout=8000)
    e.shot(pg, '12_admin_ponsel')
    assert pg.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), 'panel admin bergeser horizontal di ponsel'

@test
def ganti_password_sendiri(e):
    pg = e.page(); e.login_ok(pg, 'ganti.pw')
    pg.click('#pwBtn'); expect(pg.locator('#pwDlg')).to_be_visible()
    pg.fill('#pwCur', 'bukan-password-saya'); pg.fill('#pwNew', 'Password-Baru-77'); pg.fill('#pwNew2', 'Password-Baru-77'); pg.click('#pwGo')
    expect(pg.locator('#pwMsg')).to_contain_text('salah')
    pg.fill('#pwCur', PASS); pg.fill('#pwNew2', 'beda-sekali-123'); pg.click('#pwGo')
    expect(pg.locator('#pwMsg')).to_contain_text('tidak sama')
    pg.fill('#pwNew2', 'Password-Baru-77'); pg.click('#pwGo')
    expect(pg.locator('#pwMsg')).to_contain_text('Password diganti')
    pg.wait_for_selector('#h-monitor #lgUser', timeout=8000)                  # sesi berakhir, layar masuk muncul lagi
    e.problems[:] = [m for m in e.problems if '403' not in m]
    pg2 = e.page(); e.login(pg2, 'ganti.pw', PASS)
    pg2.wait_for_function("() => /salah/i.test(document.querySelector('#h-monitor').shadowRoot.getElementById('lgMsg').textContent)")
    e.problems[:] = [m for m in e.problems if '401' not in m]
    pg3 = e.page(); e.login(pg3, 'ganti.pw', 'Password-Baru-77'); pg3.wait_for_selector('#h-monitor #app:not([hidden])', timeout=8000)


@test
def pemakaian_unit_alur_lengkap(e):
    """SPPD mobil inventaris -> pilih mobil operasional -> ajukan -> ACC -> unggah form -> berangkat -> riwayat."""
    pg = e.page(); e.login_ok(pg, 'armada.pusat')
    pg.click('#t-pemakaian')
    pg.wait_for_selector('#h-pemakaian #spBtn', timeout=10000)
    pg.click('#h-pemakaian #spBtn')
    lst = pg.locator('#h-pemakaian #spList')
    expect(lst).to_contain_text('SPPD/PUSAT-UJI/24102026/0001')
    expect(lst).to_contain_text('KE AGEN KREKOT AGENDA PERBAIKAN KOMPUTER')      # agenda ikut kolom O, bukan kolom lama
    expect(lst).to_contain_text('100959'); expect(lst).to_contain_text('400108')
    assert 'TIDAK DITARIK' not in lst.inner_text(), 'tipe selain MOBIL INVENTARIS tidak boleh muncul'
    pg.fill('#h-pemakaian #spQ', 'fiktif beta')                                  # cari lewat nama karyawan (NIB -> nama)
    expect(lst).to_contain_text('SPPD/PUSAT-UJI/24102026/0001')
    pg.click('#h-pemakaian #spList .spi >> nth=0')
    opts = pg.locator('#h-pemakaian #carSel option').all_inner_texts()
    assert any('B 9134 UJI' in o for o in opts) and not any('B 9200 UJI' in o for o in opts), opts   # hanya grup OPERASIONAL
    pg.select_option('#h-pemakaian #carSel', 'B 9134 UJI')
    expect(pg.locator('#h-pemakaian #result')).to_contain_text('FIKTIF ALFA')
    e.shot(pg, '20_pemakaian_pilih')
    pg.click('#h-pemakaian #mk')
    expect(pg.locator('#h-pemakaian #carHint')).to_contain_text('terkunci')
    expect(pg.locator('#h-pemakaian #delTop')).to_be_visible()                  # tombol batalkan ada di dekat pilihan mobil
    for k in ('ac', 'ar', 'pu'):
        b = pg.locator(f'#h-pemakaian [data-k="{k}"]'); b.click(); b.click()
        expect(pg.locator(f'#h-pemakaian [data-k="{k}"]')).to_contain_text('Batalkan')
    png = ROOT / 'public' / 'assets' / 'logo.png'
    pg.set_input_files('#h-pemakaian #berFile', str(png)); expect(pg.locator('#h-pemakaian #berMsg')).to_contain_text('siap')
    pg.click('#h-pemakaian #berSave'); expect(pg.locator('#h-pemakaian #berMsg')).to_contain_text('tersimpan', timeout=10000)
    b = pg.locator('#h-pemakaian [data-k="dep"]'); b.click(); b.click()
    expect(pg.locator('#h-pemakaian #actMsg')).to_contain_text('Berangkat')
    pg.set_input_files('#h-pemakaian #pulFile', str(png)); pg.click('#h-pemakaian #pulSave')
    expect(pg.locator('#h-pemakaian #pulMsg')).to_contain_text('kembali', timeout=10000)
    pg.click('#h-pemakaian #tab-hist')
    expect(pg.locator('#h-pemakaian #hTbl')).to_contain_text('SPPD/PUSAT-UJI/24102026/0001')
    expect(pg.locator('#h-pemakaian #hTbl')).to_contain_text('Telah kembali')
    e.shot(pg, '21_pemakaian_riwayat')
    d = e.api(pg, '/api/db/pakai')['json']['docs']
    assert len(d) == 1 and d[0]['data']['dep'] and d[0]['data']['returned'] and d[0]['data']['berUrl'], d
    pg.click('#h-pemakaian #reload'); pg.wait_for_function("() => /Pilih SPPD/.test(document.querySelector('#h-pemakaian').shadowRoot.getElementById('spBtn').textContent)")  # muat ulang mereset pilihan

@test
def pemakaian_unit_akun_daerah_hanya_lihat_areanya(e):
    pg = e.page(); e.login_ok(pg, 'armada.lpg')
    pg.click('#t-pemakaian')
    pg.wait_for_selector('#h-pemakaian #tab-proc', timeout=10000)
    assert pg.locator('#h-pemakaian #pickCard').is_hidden(), 'akun daerah tidak membuat pengajuan'
    assert pg.evaluate("fetch('/api/db/pakai',{credentials:'same-origin'}).then(r=>r.json()).then(j=>j.docs.length)") == 0, 'area lain tidak terlihat'

# ---------- main ----------
def main():
    proc, info = start_stack()
    failed = 0; ran = 0
    try:
        with sync_playwright() as pw:
            e = Env(pw, info)
            only = sys.argv[1:]
            for fn in RESULTS:
                if only and fn.__name__ not in only: continue
                e.problems.clear(); t0 = time.time(); ran += 1
                try:
                    fn(e)
                    if e.problems: raise AssertionError('Masalah di konsol/jaringan:\n  ' + '\n  '.join(dict.fromkeys(e.problems)))
                    print(f'  ok   {fn.__name__} ({time.time()-t0:.1f}s)')
                except Exception as ex:
                    failed += 1
                    print(f'  GAGAL {fn.__name__}: {ex.__class__.__name__}: {str(ex)[:600]}')
                    if os.environ.get('TRACE'): traceback.print_exc()
            e.browser.close()
    finally:
        proc.terminate()
    print(f'\n{ran - failed} lulus, {failed} gagal')
    sys.exit(1 if failed else 0)

if __name__ == '__main__':
    main()
